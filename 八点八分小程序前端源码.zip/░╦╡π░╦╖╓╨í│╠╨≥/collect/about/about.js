// pages/about/about.js
const app = getApp()
// // import WxParse from '../../wxParse/wxParse.js';
Page({

  /**
   * 页面的初始数据
   */
  data: {
    width: wx.getSystemInfoSync().windowWidth - 20,//图片宽度  
    height: wx.getSystemInfoSync().windowWidth * 8 / 12.5,//图片高度
  },
  onLoad: function (e) {
    var that = this
    wx.setNavigationBarTitle({
      title: '关于我们',
    })
    var id = e.id
    wx.request({
      url: app.globalData.url + 'api/about/index',
      data:{
        id: id,
        url: app.globalData.url
      },
      method: 'post',
      success: function(res){
        // var content = res.data.info.content;
        // WxParse.wxParse('content', 'html', content, that, 5)
        console.log(res)
        that.setData({
          b_list: res.data.b_list,
          info: res.data.info,
          html: res.data.info.content,
          url: app.globalData.url,
          config: res.data.config
        })
      }
    })
  },
  wxParseTagATap: function(e){
    var that = this
    var src = e.currentTarget.dataset.src
    if (src.indexOf('http') != -1){
      wx.navigateTo({
        url: '../web_view/web_view?p='+e.currentTarget.dataset.src,
      })
    }else{
      wx.makePhoneCall({
        phoneNumber: src,
        
      })
    }
  },
  onShareAppMessage: function (e) {
    console.log(e)
    var that = this
    if (e.from == 'menu') {
      return {
        title: app.globalData.fenxiang1,
        path: '/pages/index/index',
        imageUrl: app.globalData.url + app.globalData.fenxiang,
        success: function (shareTickets) {
          console.info(shareTickets + '成功');
          // 转发成功
        },
        fail: function (res) {
          console.log(res + '失败');
          // 转发失败
        },
        complete: function (res) {
          // 不管成功失败都会执行
        }
      }
    }
  }
})