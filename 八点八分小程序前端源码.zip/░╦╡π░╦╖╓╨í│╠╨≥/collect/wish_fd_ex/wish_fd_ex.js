const app = getApp()
Page({
  data: {
    type: 0
  },
  onLoad: function (e) {
    var that = this
    if(e.id){
      var id = e.id
    }else if(!e.id){
      var id = e
    }
    console.log(id)
    wx.setNavigationBarTitle({
      title: '行程详情',
    })
    wx.request({
      url: app.globalData.url + 'api/wish/show_fd',
      data: {
        id: id,
        url: app.globalData.url
      },
      method: 'post',
      success: function (res) {
        console.log(res)
        that.setData({
          user: res.data.user,
          info: res.data.info,
          wuser: res.data.wuser,
          url: app.globalData.url,
          id: id,
          w_info: res.data.w_info,
          pinpai: app.globalData.pinpai,
          wei: app.globalData.wei,
          bao: app.globalData.bao,
          youxuan: app.globalData.youxuan,
          pinpai1: app.globalData.pinpai1,
          wei1: app.globalData.wei1,
          bao1: app.globalData.bao1,
          youxuan1: app.globalData.youxuan1,
          gengxin: app.globalData.gengxin
        })
      }
    })
  },
  call: function (e) {
    var that = this
    wx.makePhoneCall({
      phoneNumber: e.currentTarget.dataset.tel,
    })
  },
  queren: function(e){
    var that = this
    console.log(e)
    var id = e.currentTarget.dataset.id
    var tel = wx.getStorageSync('tel')
    wx.request({
      url: app.globalData.url+ 'api/wish/fd_queren',
      data:{
        tel: tel,
        id: id
      },
      method: 'post',
      success: function(res){
        console.log(res)
        if(res.data.update == 1){
          wx.showToast({
            title: '确认预约成功',
            duration: 2000,
            icon: 'none'
          })
          that.onLoad(id)
        }
      }
    })
  },
})