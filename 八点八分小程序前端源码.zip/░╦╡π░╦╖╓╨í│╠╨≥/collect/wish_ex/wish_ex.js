const app = getApp()
Page({
  data: {
    type: 0
  },
  onLoad: function (e) {
    var that = this
    var id = e.id
    console.log(id)
    wx.setNavigationBarTitle({
      title: '行程详情',
    })
    app.globalData.cd_id = id
    wx.request({
      url: app.globalData.url + 'api/wish/show',
      data:{
        id: id,
        url: app.globalData.url
      },
      method: 'post',
      success: function(res){
        console.log(res)
        that.setData({
          user: res.data.user,
          info: res.data.info,
          plist: res.data.plist,
          url: app.globalData.url,
          w_info: res.data.w_info,
          pinpai: app.globalData.pinpai,
          wei: app.globalData.wei,
          bao: app.globalData.bao,
          youxuan: app.globalData.youxuan,
          pinpai1: app.globalData.pinpai1,
          wei1: app.globalData.wei1,
          bao1: app.globalData.bao1,
          youxuan1: app.globalData.youxuan1,
          gengxin: app.globalData.gengxin
        })
      }
    })
  },
  call: function(e){
    var that = this
    wx.makePhoneCall({
      phoneNumber: e.currentTarget.dataset.tel,
    })
  },
  quxiao: function(e){
    var that = this
    var id = e.currentTarget.dataset.id
    that.setData({
      type: 1
    })
    wx.showModal({
      title: '提示',
      content: '您确定要取消当前行程？',
      success: function (res) {
        if (res.cancel) {
          that.setData({
            type: 0
          })
        } else {
          
          wx.request({
            url: app.globalData.url + 'api/wish/quxiao',
            data:{
              id: id,
              tel: wx.getStorageSync('tel')
            },
            method: 'post',
            success: function(res){
              console.log(res)
              if(res.data.info == 1){
                wx.showToast({
                  title: '恭喜，取消行程成功',
                  duration: 2000,
                  icon: 'none'
                })
               
                setTimeout(function(){
                  wx.navigateBack({
                    
                  })
                },2000)

              }
            }
          })
        }
      },
    })
  },
  onShow: function (){
    var that = this
    var id = app.globalData.cd_id
    console.log(id)
    wx.setNavigationBarTitle({
      title: '行程详情',
    })
    wx.request({
      url: app.globalData.url + 'api/wish/show',
      data: {
        id: id,
        url: app.globalData.url
      },
      method: 'post',
      success: function (res) {
        console.log(res)
        that.setData({
          user: res.data.user,
          info: res.data.info,
          plist: res.data.plist,
          url: app.globalData.url,
          w_info: res.data.w_info,
          pinpai: app.globalData.pinpai,
          wei: app.globalData.wei,
          bao: app.globalData.bao,
          youxuan: app.globalData.youxuan
        })
      }
    })

  }
})