// pages/about/about.js
const app = getApp()
// // import WxParse from '../../wxParse/wxParse.js';
Page({
  data: {
    width: wx.getSystemInfoSync().windowWidth - 20,//图片宽度  
    height: wx.getSystemInfoSync().windowWidth * 8 / 12.5,//图片高度
  },
  onLoad: function (e) {
    var that = this
    wx.setNavigationBarTitle({
      title: '介绍',
    })
    var id = e.id
    wx.request({
      url: app.globalData.url + 'api/about/index',
      data: {
        id: id,
        url: app.globalData.url
      },
      method: 'post',
      success: function (res) {
        // var content = res.data.info.content;
        // WxParse.wxParse('content', 'html', content, that, 5)
        console.log(res)
        that.setData({
          b_list: res.data.b_list,
          info: res.data.info,
          html: res.data.info.content,
          url: app.globalData.url
        })
      }
    })
  },
})