// pages/register/register.js
const app = getApp()
Page({

  /**
   * 页面的初始数据
   */
  data: {
    type: 1,
    second: 60,
    pic: '../../images/yin.png',
    reg_sub: 0
  },
 
  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (e) {
    var that = this
    wx.setNavigationBarTitle({
      title: '注册',
    })
    wx.request({
      url: app.globalData.url + '/api/about/reg_tishi',
      method: 'post',
      success: function(res){
        console.log(res)
        that.setData({
          logintishi1: res.data.logintishi1,
          logintishi2: res.data.logintishi2,
          xieyi1: res.data.xieyi1,
          xieyi2: res.data.xieyi2,
        })
      }
    })
    this.setData({
      login_logo: app.globalData.login_logo
    })
  },
  tel: function(e){
    var that = this
    that.setData({
      tel: e.detail.value
    })
  },
  huoqu: function(e){
    var that = this
    var tel= that.data.tel
    if(!tel){
      wx.showToast({
        title: '请获取手机号',
        duration: 2000,
        icon:'none'
      })
      return;
    }
    wx.request({
      url: app.globalData.url + 'api/my/check_tel',
      data:{
        tel: tel,
      },
      method: 'post',
      success: function(res){
        console.log(res)
        if(res.data.info == 1){
          wx.showToast({
            title: '当前手机号已被注册',
            duration: 2000,
            icon: 'none',
            mask: true
          })
          return;
        }else if(res.data.info == 0){
          that.setData({
            success: 1
          })
          let promise = new Promise((resolve, reject) => {
            let setTimer = setInterval(
              () => {
                that.setData({
                  second: that.data.second - 1,
                })
                if (that.data.second <= 0) {
                  that.setData({
                    second: 60,
                    alreadySend: false,
                    send: true,
                  })
                  resolve(setTimer)
                }
              }, 1000)
            that.setData({
              disabled: 'disabled'
            })
          })
          promise.then((setTimer) => {
            clearInterval(setTimer)
            that.setData({
              success: 2,
              disabled: ''
            })
          })
        }else if(res.data.info == 2){
          wx.showToast({
            title: '账号已停用',
            duration: 2000,
            icon: 'none',
            mask: true
          })
          return;
        }
      }
    })
  },
  getPhoneNumber: function (e) {
    var that = this
    console.log(e)
    // console.log(app.globalData.encryptedData, app.globalData.iv, wx.getStorageSync('sessionkey'))
    

        wx.request({

          url: app.globalData.url + 'api/wechat/jiemi',

          data: {

            errMsg: e.detail.errMsg,
            encryptedData: e.detail.encryptedData,
            iv: e.detail.iv,

            sessionKey: wx.getStorageSync('sessionkey'),

          },

          method: 'post', // OPTIONS, GET, HEAD, POST, PUT, DELETE, TRACE, CONNECT

          header: {
            'content-type': 'application/x-www-form-urlencoded' // 默认值
          },

          success: function (res) {
            console.log(res)
            //我后台设置的返回值为1是正确
              that.setData({
                tel: res.data.purePhoneNumber
              })
              //存入缓存即可
              // console.log('')
              // wx.setStorageSync('phone', res.phone);

            

          },

          fail: function (err) {

            console.log(err);

          }

        })

     
  },
  password: function(e){
    var that = this
    that.setData({
      password: e.detail.value
    })
  },
  yzm: function(e){
    var that = this
    console.log(e.detail.value)
    if(e.detail.value){
      wx.request({
        url: app.globalData.url + 'api/my/reg_check',
        data:{
          yzm: e.detail.value,
          tel: that.data.tel
        },
        method: 'post',
        success: function(res){
          console.log(res)
          if(res.data.info == 1){
            that.setData({
              reg_check: 1,
              reg_sub: 0
            })
          }else if(res.data.info == 0){
            that.setData({
              reg_check: 1,
              reg_sub: 0
            })
          }
        }
      })
    }else{
      that.setData({
        reg_check: 0,
        reg_sub: 0
      })
    }
    that.setData({
      yzm: e.detail.value
    })
  },
  yin: function(e){
    var that = this
    var type = that.data.type
    var pass = that.data.password
    
    if(type == 1){
      that.setData({
        type: 0,
        pass: pass,
        pic: '../../images/ico7.png'
      })
    } else if (type == 0){
      that.setData({
        type: 1,
        pass: pass,
        pic: '../../images/yin.png'
      })
    }
  },
  checkboxChange: function (e) {
    console.log('checkbox发生change事件，携带value值为：', e.detail.value[0])
    app.globalData.xieyi = e.detail.value[0]
  },
  submit: function(e){
    var that = this
    var yzm = that.data.yzm
    // console.log(yzm)
    var password = that.data.password
    var xieyi = app.globalData.xieyi
    var tel = that.data.tel
    if(!tel){
      wx.showToast({
        title: '请填写电话',
        duration: 2000,
        icon: 'none'
      })
      return;
    }
    if(!yzm){
      wx.showToast({
        title: '请填写验证码',
        duration: 2000,
        icon:'none'
      })
      return;
    }
    if (!password) {
      wx.showToast({
        title: '请填写密码',
        duration: 2000,
        icon: 'none'
      })
      return;
    }
    var mareg = /^[a-zA-Z0-9]{6,18}$/
    if(!mareg.test(password)){
      wx.showToast({
        title: '密码由6-18位数字字母组成',
        duration: 2000,
        icon: 'none'
      })
      return;
    }
    if(xieyi === undefined){
      wx.showToast({
        title: '请阅读用户协议',
        duration: 2000,
        icon: 'none'
      })
      return;
    }
    console.log(app.globalData.user_info)
    wx.request({
      url: app.globalData.url + 'api/my/reg',
      data:{
        openid: wx.getStorageSync('openid'),
        tel: tel,
        password: password,
        yzm: yzm,
        ip: wx.getStorageSync('ip'),
        lat: app.globalData.lat,
        lng: app.globalData.lng,
        uid: wx.getStorageSync('uid'),
        nickname: app.globalData.user_info.nickName,
        picture: app.globalData.user_info.avatarUrl
      },
      method:'post',
      success: function(res){
        console.log(res)
        if(res.data.info == 1){
          wx.showToast({
            title: '恭喜注册成功，正在登录',
            duration: 2000,
            icon: 'none',
            mask: true
          })
          wx.setStorageSync('tel', tel)
          setTimeout(function(){
            wx.reLaunch({
              url: '../index/index',
            })
          },2000)
        }else if(res.data.info == 2){
          wx.showToast({
            title: '验证码不正确',
            duration: 2000,
            icon: 'none',
            mask: true
          })
        }else if(res.data.info == 3){
          wx.showToast({
            title: '账号已停用',
            duration: 2000,
            icon: 'none',
            mask: true
          })
        }
      }
    })
  },
  onShow: function () {
    wx.login({
      success: res => {
        app.globalData.user_code = res.code;
        console.log(app.globalData.user_code)
        // 发送 res.code 到后台换取 openId, sessionKey, unionId
      }
    })
  },
})