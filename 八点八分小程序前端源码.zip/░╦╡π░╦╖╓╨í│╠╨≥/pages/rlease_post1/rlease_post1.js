// pages/rlease_post/rlease_post.js
const app = getApp()
var QQMapWX = require('../../utils/qqmap-wx-jssdk.js');
var qqmapsdk = new QQMapWX({
  key: 'I4CBZ-FYL6G-X2LQD-I56ON-N6K7E-UQFK4' // 必填
});
const date = new Date()
const years = []
const months = []
const days = []

for (let i = date.getFullYear(); i <= 2100; i++) {
  years.push(i)
}

for (let i = 1; i <= 12; i++) {
  months.push(i)
}

for (let i = 1; i <= 31; i++) {
  days.push(i)
}

function search(arr, dst) {
  var i = arr.length;
  while (i -= 1) {
    if (arr[i] == dst) {
      return i;
    }
  }
  return false;
}
Page({
  /**
   * 页面的初始数据
   */
  data: {
    years: years,
    year: date.getFullYear(),
    months: months,
    month: 2,
    days: days,
    day: 2,
    value: [0, 0, 0],
    suishi: 0,
    yincang2: true,
    region: ["四川省", "广元市", "苍溪县"],
    time: '12:00',
    dateTimeArray: null,
    dateTime: null,
    dateTimeArray1: null,
    dateTime1: null,
    startYear: 2000,
    endYear: 2050,
    zu: [],
    res: 0,
    multiArray: [
      [1, 2, 3, 4, 5, 6, 7, 8, 9], '室', [0, 1, 2, 3, 4, 5, 6, 7, 8, 9], '厅', [0, 1, 2, 3, 4, 5, 6, 7, 8, 9], '卫'
    ],
    multiIndex2: [0, 0, 0, 0, 0],
    shi: '室',
    ting: '厅',
    wei: '卫',
    navlist: [{
        id: 0,
        title: "男女不限"
      },
      {
        id: 1,
        title: "限女生"
      },
      {
        id: 2,
        title: "限男生"
      }
    ],
    nav: 0,
    navlist1: [{
        id: 0,
        title: "整租"
      },
      {
        id: 1,
        title: "合租"
      },
    ],
    type2: 0
  },
  suishi: function(e) {
    var that = this
    that.setData({
      suishi: 1,
      yincang2: true,
      bottom: -100,
      onload: 0
    })
    app.globalData.time = '随时入住'
  },
  bakbtn2: function(e) {
    this.setData({
      yincang2: true,
      bottom: -100
    })
  },
  bindChange: function(e) {
    var val = e.detail.value
    var that = this
    console.log(e)
    var days = []
    var months = e.detail.value[1] + 1
    console.log(months)
    if (months == 1) {
      for (let o = 1; o <= 31; o++) {
        days.push(o)
      }
    } else if (months == 2) {
      for (let o = 1; o <= 29; o++) {
        days.push(o)
      }
    } else if (months == 3) {
      for (let o = 1; o <= 31; o++) {
        days.push(o)
      }
    } else if (months == 4) {
      for (let o = 1; o <= 30; o++) {
        days.push(o)
      }
    } else if (months == 5) {
      for (let o = 1; o <= 31; o++) {
        days.push(o)
      }
    } else if (months == 6) {
      for (let o = 1; o <= 30; o++) {
        days.push(o)
      }
    } else if (months == 7) {
      for (let o = 1; o <= 31; o++) {
        days.push(o)
      }
    } else if (months == 8) {
      for (let o = 1; o <= 31; o++) {
        days.push(o)
      }
    } else if (months == 9) {
      for (let o = 1; o <= 30; o++) {
        days.push(o)
      }
    } else if (months == 10) {
      for (let o = 1; o <= 31; o++) {
        days.push(o)
      }
    } else if (months == 11) {
      for (let o = 1; o <= 30; o++) {
        days.push(o)
      }
    } else if (months == 12) {
      for (let o = 1; o <= 31; o++) {
        days.push(o)
      }
    }
    console.log(days)
    that.setData({
      days: days
    })

    that.setData({
      year: that.data.years[val[0]],
      month: that.data.months[val[1]],
      day: that.data.days[val[2]],
      suishi: 0,
      onload: 0,
      rzsj1: that.data.years[val[0]] + '-' + that.data.months[val[1]] + '-' + that.data.days[val[2]]
    })
    var year = that.data.years[val[0]]
    var month = that.data.months[val[1]]
    var day = that.data.days[val[2]]
    app.globalData.time = year + '-' + month + '-' + day
  },
  liubtn2: function(e) {

    this.setData({
      yincang2: false,
      bottom: 0
    })
  },
  listenerButtonPreviewImage: function(e) {
    let index = e.target.dataset.index;
    let that = this;
    wx.previewImage({
      current: that.data.tempFilePaths[index],
      urls: that.data.tempFilePaths,
      success: function(res) {},
      fail: function() {}
    })
  },
  listenerButtonPreviewImage1: function(e) {
    let index = e.target.dataset.index;
    let that = this;
    wx.previewImage({
      current: that.data.tempFilePaths1[index],
      urls: that.data.tempFilePaths1,
      success: function(res) {},
      fail: function() {}
    })
  },
  changeMultiPicker1(e) {
    console.log(e)
    var that = this
    that.setData({
      multiIndex: e.detail.value
    })
    var multiIndex = that.data.multiIndex
    console.log(multiIndex)
    app.globalData.huxing = multiIndex.toString()
    console.log(app.globalData.huxing)
  },
  changeCountry(e) {
    var countryList = this.data.countryList
    app.globalData.huxing = countryList[e.detail.value]
    this.setData({
      countryIndex: e.detail.value
    });
  },
  changeRegin(e) {
    console.log(e)
    app.globalData.dizhi = []
    app.globalData.dz_code = []
    app.globalData.dz_code = e.detail.code
    app.globalData.dizhi = e.detail.value
    this.setData({
      region: e.detail.value
    });
  },
  area: function(e) {
    var that = this
    wx.navigateTo({
      url: '../map/map',
    })
  },
  // 选择二级联动
  changeMultiPicker(e) {
    this.setData({
      multiIndex: e.detail.value
    })
  },
  // 选择三级联动
  changeMultiPicker3(e) {
    this.setData({
      multiIndex3: e.detail.value
    })
  },
  changeDate(e) {
    console.log(e)
    app.globalData.time = e.detail.value
    this.setData({
      date: e.detail.value
    });
  },
  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function(e) {
    var that = this
    var id = e.id
    wx.setNavigationBarTitle({
      title: '求租贴修改',
    })
    wx.request({
      url: app.globalData.url + 'api/qiuzu/index1',
      data: {
        id: id,
        url: app.globalData.url
      },
      method: 'post',
      success: function(res) {
        console.log(res)
        app.globalData.pics = res.data.pics
        app.globalData.zonhe1 = res.data.pics
        app.globalData.zt = res.data.info.zt
        app.globalData.dizhi = res.data.dizhi
        app.globalData.zu = res.data.zu
        app.globalData.huxing = res.data.moren
        var years = that.data.years
        var months = that.data.months
        var days = that.data.days
        var years_index = search(years, date.getFullYear())
        var months_index = search(months, res.data.month)
        var days_index = search(days, res.data.day)
        console.log(years_index, months_index, days_index)
        var value = that.data.value
        value.splice(0, 1, years_index);
        value.splice(1, 1, months_index);
        value.splice(2, 1, days_index);
        // if(res.data.qiuzu[0].id>res.data.qiuzu[1].id){
        //   res.data.zu.reverse()
        // }else{
        //   var zu = res.data.zu
        // }
        // console.log(zu)
        var zhen_zu = []
        var zhen_zu2 = []
        for(var i=0;i<res.data.qiuzu.length;i++){
          var zhen_zu = zhen_zu.concat(0)
        }
        // console.log(res.data.zu.indexOf(40))
        for(var i=0;i<res.data.qiuzu.length;i++){
          if(res.data.zu.indexOf(res.data.qiuzu[i].id.toString()) != '-1'){
            console.log('找到')
            zhen_zu[i] = 1
          }
        }
        for(var i=0;i<res.data.zu.length;i++){
          if(res.data.zu[i] != '0'){
            var zhen_zu2 = zhen_zu2.concat(res.data.zu[i])
          }
        }
        console.log(zhen_zu)
        that.setData({
          countryList: res.data.moren,
          qiuzu: res.data.qiuzu,
          date: res.data.time,
          zu: res.data.zu,
          zhen_zu: zhen_zu,
          zhen_zu2: zhen_zu2,
          region: res.data.dizhi,
          zt: res.data.info.zt,
          jianjie: res.data.info.jianjie,
          price: res.data.info.price,
          nav: res.data.info.setsex,
          title: res.data.info.title,
          info: res.data.info,
          backfill: res.data.info.xiaoqu,
          content: res.data.info.content,
          tempFilePaths: res.data.pics,
          ss_xq_name1: res.data.info.xiaoqu,
          multiIndex: res.data.moren,
          year: res.data.year,
          month: res.data.month,
          day: res.data.day,
          value: value,
          onload: 1
        })
      }
    })
  },
  change1: function(e) {
    var that = this
    var arr = that.data.qiuzu
    var zu = that.data.zu
    var zhen_zu = that.data.zhen_zu
    var zhen_zu2 = that.data.zhen_zu2
    console.log(zu)
    var id = e.currentTarget.dataset.id
    var index = e.currentTarget.dataset.index

    // if (zu[index] == 0) {
    //   zu.splice(index, 1, id)
    // }
    var zhen_zu2 = zhen_zu2.concat(id)
    zhen_zu.splice(index,1,1)
    console.log(zhen_zu)
    console.log(zu)
    app.globalData.zu = zhen_zu2
    that.setData({
      zu: zhen_zu2,
      zhen_zu: zhen_zu,
      zhen_zu2: zhen_zu2
    })
  },
  getLocate(latitude, longitude) {
    var that = this;
    var locationString = latitude + "," + longitude;
    wx.request({
      url: 'https://apis.map.qq.com/ws/geocoder/v1/?location=',
      data: {
        "key": "I4CBZ-FYL6G-X2LQD-I56ON-N6K7E-UQFK4",
        "location": locationString
      },
      method: 'GET',
      success: function(res) {
        console.log(res)
        app.globalData.adcode = res.data.result.ad_info.adcode
        var citycode = res.data.result.ad_info.city_code
        app.globalData.city_name = res.data.result.ad_info.city
        app.globalData.city_code = citycode.slice(3, 9)
        var val = res.data.result.address_component.city
        if (val.indexOf('市') !== -1) { //这里是去掉“市”这个字
          val = val.slice(0, val.indexOf('市'));
        }
        var province = res.data.result.address_component.province
        var city = res.data.result.address_component.city
        var district = res.data.result.address_component.district
        app.globalData.locateCity = val
        app.globalData.dizhi = [province, city, district]
        that.setData({
          locateCity: val,
          region: [province, city, district]
        });
      },
    })
  },

  change: function(e) {
    var that = this
    var id = e.currentTarget.dataset.id
    that.setData({
      nav: id
    })
    app.globalData.setsex = id
  },

  change3: function(e) {
    var that = this
    var zu = that.data.zu
    var zhen_zu = that.data.zhen_zu
    var zhen_zu2 = that.data.zhen_zu2
    var index = e.currentTarget.dataset.index
    var id = e.currentTarget.dataset.id
    var idx = zhen_zu2.indexOf(id)
    zhen_zu2.splice(idx, 1)
    zhen_zu.splice(index,1,0)
    console.log(zhen_zu2)
    console.log(zhen_zu)
    that.setData({
      zu: zhen_zu2,
      zhen_zu: zhen_zu,
      zhen_zu2: zhen_zu2
    })
    app.globalData.zu = zhen_zu2
  },
  change2: function(e) {
    var that = this
    var id = e.currentTarget.dataset.id
    that.setData({
      zt: id
    })
    app.globalData.zt = id
  },
  upload: function() {
    let that = this;
    wx.chooseImage({
      count: 9 - app.globalData.zonhe1.length, // 默认9
      sizeType: ['compressed'], // 可以指定是原图还是压缩图，默认二者都有
      sourceType: ['album', 'camera'], // 可以指定来源是相册还是相机，默认二者都有
      success: res => {
        wx.showToast({
          title: '正在上传...',
          icon: 'loading',
          mask: true,
          duration: 1000
        })
        // 返回选定照片的本地文件路径列表，tempFilePath可以作为img标签的src属性显示图片

        if (app.globalData.zonhe1.length < 9) {
          app.globalData.zonhe1 = app.globalData.pics.concat(res.tempFilePaths)
          app.globalData.pics1 = app.globalData.pics1.concat(res.tempFilePaths)
        } else {
          app.globalData.pics1 = app.globalData.pics1
          wx.showToast({
            title: '互动图片最多9张',
            duration: 2000,
            icon: 'none'
          })
        }
        let tempFilePaths = res.tempFilePaths;
        that.setData({
          tempFilePaths1: app.globalData.pics1
        })
      }
    })
  },
  aaa: function(e) {
    var that = this
    var imgs = app.globalData.pics;
    var index = e.currentTarget.dataset.index;
    imgs.splice(index, 1);
    app.globalData.pics = imgs
    that.setData({
      tempFilePaths: imgs,
    });
  },
  aaa1: function(e) {
    var that = this
    var imgs = app.globalData.pics1;
    var index = e.currentTarget.dataset.index;
    imgs.splice(index, 1);
    app.globalData.pics1 = imgs
    that.setData({
      tempFilePaths1: imgs,
    });
  },

  uploadimg: function(data) {
    var that = this
    var pics = app.globalData.pics1
    var i;

    i = data.i ? data.i : 0,
      wx.uploadFile({
        url: app.globalData.url + 'api/qiuzu/img',
        filePath: pics[i],
        name: 'file',
        formData: null,
        success: (resp) => {
          app.globalData.hugong = app.globalData.hugong + '@' + resp.data
          console.log(app.globalData.hugong)
          var pic_str = app.globalData.hugong
          if (pic_str) {
            console.log('zoule')
            var pic_arr = pic_str.split('@')
            if ((pic_arr.length - 1) == pics.length) {
              console.log('zoule1')
              that.save()
            }
          }
        },
        complete: (res) => {
          i++;
          if (i == pics.length) {
            console.log('执行完毕');
          } else {
            data.i = i;
            that.uploadimg(data);
          }

        }
      });

  },
  content: function(e) {
    var that = this
    that.setData({
      content: e.detail.value
    })
  },
  price: function(e) {
    var that = this
    that.setData({
      price: e.detail.value
    })
  },
  jianjie: function(e) {
    var that = this
    that.setData({
      jianjie: e.detail.value
    })
  },
  backfill: function(e) {
    var that = this
    var id = e.currentTarget.id;
    for (var i = 0; i < that.data.suggestion.length; i++) {
      if (i == id) {
        that.setData({
          backfill: that.data.suggestion[i].title,
          lng: that.data.suggestion[i].longitude,
          lat: that.data.suggestion[i].latitude,
          zt1: 0
        });
      }
    }
  },
  title: function(e) {
    var that = this
    that.setData({
      title: e.detail.value
    })
  },
  xiaoqu: function(e) {
    var _this = this;
    _this.setData({
      xiaoqu: e.detail.value
    });
    if (e.detail.value == '') {
      _this.setData({
        zt1: 0
      })
    }
    qqmapsdk.getSuggestion({

      keyword: e.detail.value,
      success: function(res) {
        console.log(res);
        var sug = [];
        for (var i = 0; i < res.data.length; i++) {
          sug.push({
            title: res.data[i].title,
            id: res.data[i].id,
            addr: res.data[i].address,
            city: res.data[i].city,
            district: res.data[i].district,
            latitude: res.data[i].location.lat,
            longitude: res.data[i].location.lng
          });
        }
        _this.setData({
          suggestion: sug,
          zt1: 1
        });
      },

    });
    _this.setData({
      xiaoqu: e.detail.value
    })
  },
  submit: function(e) {
    var that = this
    var dizhi = app.globalData.dizhi
    var price = that.data.price
    var zt = app.globalData.zt
    var pic1 = app.globalData.pics1
    var pic = app.globalData.pics
    var huxing = app.globalData.huxing
    var time = app.globalData.time
    var setsex = app.globalData.setsex
    var title = that.data.title
    var content = that.data.content
    var zu = app.globalData.zu
    var tel = wx.getStorageSync('tel')

    var jianjie = that.data.jianjie
    var xiaoqu = app.globalData.ss_xq_name
    var pics = pic.concat(pic1)


    if (parseInt(app.globalData.pics.length) + parseInt(app.globalData.pics1.length) == 0) {
      wx.showToast({
        title: '请上传互动图片',
        duration: 2000,
        icon: 'none'
      })
      that.setData({
        res: 0
      })
      return;
    } else if (parseInt(app.globalData.pics.length) + parseInt(app.globalData.pics1.length).length > 9) {
      wx.showToast({
        title: '互动图片最多9张',
        duration: 2000,
        icon: 'none'
      })
      that.setData({
        res: 0
      })
      return;
    }
    if (zt === undefined) {
      wx.showToast({
        title: '请选择类型',
        duration: 2000,
        icon: 'none'
      })
      that.setData({
        res: 0
      })
      return;
    }
    if (!price) {
      wx.showToast({
        title: '请填写预算',
        duration: 2000,
        icon: 'none'
      })
      that.setData({
        res: 0
      })
      return;
    }
    if (!huxing) {
      wx.showToast({
        title: '请选择户型',
        duration: 2000,
        icon: 'none'
      })
      that.setData({
        res: 0
      })
      return;
    }
    if (!time) {
      var time1 = that.data.date
    } else {
      var time1 = time
    }
    if (!setsex) {
      var setsex1 = 0
    } else {
      var setsex1 = setsex
    }
    if (!xiaoqu) {
      var xiaoqu = that.data.info.xiaoqu
      var lat = that.data.info.lat
      var lng = that.data.info.lng
    } else {
      var xiaoqu = app.globalData.ss_xq_name
      var lat = app.globalData.ss_xq_latitude
      var lng = app.globalData.ss_sq_longitude
    }
    if (!title) {
      wx.showToast({
        title: '请填写求租标题',
        duration: 2000,
        icon: 'none'
      })
      that.setData({
        res: 0
      })
      return;
    }
    if (!content) {
      wx.showToast({
        title: '请填写求组描述',
        duration: 2000,
        icon: 'none'
      })
      that.setData({
        res: 0
      })
      return;
    }
    if (!zu) {
      wx.showToast({
        title: '请选择求租要求',
        duration: 2000,
        icon: 'none'
      })
      that.setData({
        res: 0
      })
      return;
    }
    for (var y = 0; y < dizhi.length; y++) {
      var dz = dz + '@' + dizhi[y]
    }
    for (var k = 0; k < pic.length; k++) {
      var tu = tu + '@' + pic[k]
    }
    for (var o = 0; o < zu.length; o++) {
      var yq = yq + '@' + zu[o]
    }
    
    wx.request({
      url: app.globalData.url + 'api/fabu/check_title_content',
      data: {
        title: title,
        content: content
      },
      method: 'post',
      success: function (ftc) {
        console.log(ftc)
        if (ftc.data.info != 1) {
          wx.showToast({
            title: '标题存在敏感词,请重新上传',
            duration: 2000,
            icon: 'none'
          })
          return;
        } else if (ftc.data.info1 != 1) {
          wx.showToast({
            title: '描述存在敏感词,请重新上传',
            duration: 2000,
            icon: 'none'
          })
          return;
        } else if (ftc.data.info == 1 && ftc.data.info1 == 1) {
          var data = []
          app.globalData.pic = app.globalData.hugong
          app.globalData.pics = tu
          app.globalData.zt = zt
          app.globalData.price = price
          app.globalData.huxing = huxing.toString()
          app.globalData.time = time1
          app.globalData.setsex = setsex1
          app.globalData.title = title
          app.globalData.content = content
          app.globalData.zu = yq
          app.globalData.tel = tel
          app.globalData.lng = lng
          app.globalData.lat = lat
          app.globalData.xiaoqu = xiaoqu
          app.globalData.id = e.currentTarget.dataset.id
          that.xianshi()
          if (pic1.length != 0) {
            that.uploadimg(pic1)
          } else {
            that.save()
          }
        }
      }
    })
    
    // console.log(tu);return;
  },
  save: function() {
    var that = this
    wx.request({
      url: app.globalData.url + 'api/qiuzu/update',
      data: {
        pic: app.globalData.hugong,
        pics: app.globalData.pics,
        zt: app.globalData.zt,
        price: app.globalData.price,
        huxing: app.globalData.huxing,
        time: app.globalData.time,
        setsex: app.globalData.setsex,
        title: app.globalData.title,
        content: app.globalData.content,
        zu: app.globalData.zu.toString(),
        tel: app.globalData.tel,
        lng: app.globalData.lng,
        lat: app.globalData.lat,
        xiaoqu: app.globalData.xiaoqu,
        id: app.globalData.id
      },
      method: 'post',
      success: function(res) {
        console.log(res)
        that.setData({
          type2: 1
        })
        if (res.data.info == 1) {
          wx.showToast({
            title: '修改成功，正在返回',
            duration: 2000,
            icon: 'none'
          })
          app.globalData.pics1 = []
          app.globalData.tempFilePaths2 = []
          app.globalData.hugong = ''
          app.globalData.ss_xq_latitude = ''
          app.globalData.ss_sq_longitude = ''
          app.globalData.ss_xq_name = undefined
          app.globalData.ss_xq_addr = undefined
          setTimeout(function() {
            wx.navigateBack({

            })
          }, 2000)
        }
      }
    })
  },
  xianshi: function () {
    var that = this
    if (that.data.type2 == 0) {
      wx.showToast({
        title: '提交中,请稍后...',
        duration: 10000000000000000,
        icon: 'none'
      })
    }
  },
  onShow: function() {
    var that = this
    if (app.globalData.ss_xq_name) {
      that.setData({
        ss_xq_name1: app.globalData.ss_xq_name
      })
    }
  },
})