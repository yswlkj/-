// pages/my_post/my_post.js
const app = getApp()
Page({

  /**
   * 页面的初始数据
   */
  data: {
    yincang1: true,
  },
  liubtn1: function (e) {
    var that = this
    var id = e.currentTarget.dataset.id
    that.setData({
      yincang1: false,
      bottom: 0,
      id: id
    })
  },
  tishi: function (e) {
    var that = this
    wx.showModal({
      title: '提示',
      content: '将当前求租贴上架后可使用当前功能',
      showCancel: false, //是否显示取消按钮-----》false去掉取消按钮
      confirmText: "我知道了", //默认是“确定”
      success: function (res) {
        if (res.confirm) {
          //点击确定
          console.log("您点击了确定")
        }
      }
    })
  },
  bakbtn1: function (e) {
    this.setData({
      yincang1: true,
      bottom: -100
    })
  },
  warnModalTrue1() {
    var self = this;
    wx.showModal({
      title: '是否下架',
      confirmText: '是',
      cancelText: '否',
      success: function (res) {
        if (res.confirm) {
          self.setData({ msg: '微信小程序很好使用！' });
        } else if (res.cancel) {
          self.setData({ msg: '谢谢你的建议，微信小程序需继续优化！' });
        }
      }
    })
  },
  warnModalTrue() {
    var self = this;
    wx.showModal({
      title: '是否删除',
      confirmText: '是',
      cancelText: '否',
      success: function (res) {
        if (res.confirm) {
          self.setData({ msg: '微信小程序很好使用！' });
        } else if (res.cancel) {
          self.setData({ msg: '谢谢你的建议，微信小程序需继续优化！' });
        }
      }
    })
  },
  onLoad: function (e) {
    var that = this
    wx.setNavigationBarTitle({
      title: '我的帖子',
    })
    var tel = wx.getStorageSync('tel')
    wx.request({
      url: app.globalData.url + 'api/qiuzu/qlist1',
      data:{
        tel: tel,
        url: app.globalData.url,
        lat: app.globalData.lat,
        lng: app.globalData.lng
      },
      method: 'post',
      success: function(res){
        console.log(res)
        that.setData({
          list: res.data.list, 
          list1: res.data.list1, 
          url: app.globalData.url,
          fenxiang: res.data.fenxiang.picurl,
          gengxin: app.globalData.gengxin
        })
      }
    })
  },
  getLocate1(lat) {
    var that = this;
    var length = lat.length
    var locateCity1 = []
    var locateQu1 = []
    var locatetown = []
    var locatetownname = []
    for (var i = 0; i < length; i++) {
      wx.request({
        url: 'https://apis.map.qq.com/ws/geocoder/v1/?location=' + lat[i].lat + ',' + lat[i].lng + '&key=I4CBZ-FYL6G-X2LQD-I56ON-N6K7E-UQFK4',
        success: function (res) {
          console.log(res)
          var val1 = res.data.result.address_component.district
          var val = res.data.result.address_component.street_number
          var val2 = res.data.result.address_reference.town.id
          var val3 = res.data.result.address_reference.town.title
          locateCity1.push(val)
          locateQu1.push(val1)
          locatetown.push(val2)
          locatetownname.push(val3)
          that.setData({
            locateQu1: locateQu1,
            locateCity1: locateCity1,
            locatetown: locatetown,
            locatetownname: locatetownname
          })
        },
      })
    }
  },
  xia: function(e){
    var that = this
    var id = e.currentTarget.dataset.id
    var tel = wx.getStorageSync('tel')
    wx.showModal({
      title: '提示',
      content: '是否下架',
      showCancel: true,//是否显示取消按钮
      cancelText: "否",//默认是“取消”
      confirmText: "是",//默认是“确定”
      success: function (res) {
        if (res.cancel) {
          //点击取消,默认隐藏弹框
        } else {
          wx.request({
            url: app.globalData.url + 'api/qiuzu/xia',
            data: {
              id: id,
              tel: tel
            },
            method: 'post',
            success: function (res) {
              console.log(res)
              if (res.data.info == 1) {
                wx.showToast({
                  title: '修改成功',
                  duration: 2000,
                  icon: 'none'
                })
                setTimeout(function () {
                  that.reload();
                }, 2000)
              }
            }
          })
        }
      },
    })
  },
  shang: function (e) {
    var that = this
    var id = e.currentTarget.dataset.id
    var tel = wx.getStorageSync('tel')
    wx.showModal({
      title: '提示',
      content: '是否上架',
      showCancel: true,//是否显示取消按钮
      cancelText: "否",//默认是“取消”
      confirmText: "是",//默认是“确定”
      success: function (res) {
        if (res.cancel) {
          //点击取消,默认隐藏弹框
        } else {
          wx.request({
            url: app.globalData.url + 'api/qiuzu/shang',
            data: {
              id: id,
              tel: tel
            },
            method: 'post',
            success: function (res) {
              console.log(res)
              if (res.data.info == 1) {
                wx.showToast({
                  title: '修改成功',
                  duration: 2000,
                  icon: 'none'
                })
                setTimeout(function () {
                  that.reload();
                }, 2000)
              }else if(res.data.info == 0){
                wx.showToast({
                  title: '请等待修改完成',
                  duration: 2000,
                  icon: 'none'
                })
              } else if (res.data.info == 2){
                wx.showModal({
                  title: '提示',
                  content: '由于当前求租贴被举报下架，如需上架，请修改求租贴信息',
                  showCancel: false, //是否显示取消按钮-----》false去掉取消按钮
                  success: function (res) {
                    if (res.confirm) {
                      //点击确定
                      console.log("您点击了确定")
                    }
                  }
                })
              } else if (res.data.info == 3){
                wx.showToast({
                  title: '上架失败，发布次数不足',
                  duration: 2000,
                  icon: 'none',
                  mask: true
                })
              }

            }
          })
        }
      },
    })
  },
  reload: function(){
    var that = this
    wx.setNavigationBarTitle({
      title: '我的帖子',
    })
    var tel = wx.getStorageSync('tel')
    wx.request({
      url: app.globalData.url + 'api/qiuzu/qlist1',
      data: {
        tel: tel,
        url: app.globalData.url,
        lat: app.globalData.lat,
        lng: app.globalData.lng
      },
      method: 'post',
      success: function (res) {
        console.log(res)
        that.setData({
          list: res.data.list,
          list1: res.data.list1,
          url: app.globalData.url
        })
      }
    })
  },
  shan: function(e){
    var that = this
    var id = e.currentTarget.dataset.id
    var tel = wx.getStorageSync('tel')
    wx.showModal({
      title: '提示',
      content: '是否删除',
      showCancel: true,//是否显示取消按钮
      cancelText: "否",//默认是“取消”
      confirmText: "是",//默认是“确定”
      success: function (res) {
        if (res.cancel) {
          //点击取消,默认隐藏弹框
        } else {
          wx.request({
            url: app.globalData.url + 'api/qiuzu/shan',
            data: {
              id: id,
              tel: tel
            },
            method: 'post',
            success: function (res) {
              console.log(res)
              if (res.data.info == 1) {
                wx.showToast({
                  title: '删除成功',
                  duration: 2000,
                  icon: 'none'
                })
                setTimeout(function () {
                  that.reload();
                }, 2000)
              } else if (res.data.info == 0) {
                wx.showToast({
                  title: '请等待删除完成',
                  duration: 2000,
                  icon: 'none'
                })
              }
            }
          })
        }
      },
    })
  },
  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {
    // var that = this
    // wx.setNavigationBarTitle({
    //   title: '我的帖子',
    // })
    // var tel = wx.getStorageSync('tel')
    // wx.request({
    //   url: app.globalData.url + 'api/qiuzu/qlist1',
    //   data: {
    //     tel: tel,
    //     url: app.globalData.url,
    //     lat: app.globalData.lat,
    //     lng: app.globalData.lng
    //   },
    //   method: 'post',
    //   success: function (res) {
    //     console.log(res)
    //     that.setData({
    //       list: res.data.list,
    //       list1: res.data.list1,
    //       url: app.globalData.url,
    //       fenxiang: res.data.fenxiang.picurl,
    //       yincang1:true
    //     })
    //   }
    // })
    var that = this
    that.setData({
      yincang1: true,
    })
    var tel = wx.getStorageSync('tel')
    wx.request({
      url: app.globalData.url + 'api/qiuzu/qlist1',
      data:{
        tel: tel,
        url: app.globalData.url,
        lat: app.globalData.lat,
        lng: app.globalData.lng
      },
      method: 'post',
      success: function(res){
        console.log(res)
        that.setData({
          list: res.data.list, 
          list1: res.data.list1, 
          url: app.globalData.url,
          fenxiang: res.data.fenxiang.picurl
        })
      }
    })
  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function (e) {
    console.log(e)
    var that = this
    if (e.from == 'button'){
      var id = e.target.dataset.id
      var index = e.target.dataset.index
      if (that.data.list[index].zt == 0){
        var zt = '求整租'
      } else if (that.data.list[index].zt == 1){
        var zt = '求合租'
      }
      return {
        title: zt + '-' + that.data.list[index].xiaoqu + '-' + that.data.list[index].hx[0] + '室' + that.data.list[index].hx[1] + '厅' + that.data.list[index].hx[2]+'卫',
        path: '/pages/rent_ex/rent_ex?id=' + id,
        imageUrl: app.globalData.url + that.data.list[index].pic[0],
        success: function (shareTickets) {
          console.info(shareTickets + '成功');
          
        },
        fail: function (res) {
          
        },
        complete: function (res) {
          
        }
      }
    } else if (e.from == 'menu'){
      return {
        title: app.globalData.fenxiang1,
        path: '/pages/index/index',
        imageUrl: app.globalData.url + that.data.fenxiang,
        success: function (shareTickets) {
          console.info(shareTickets + '成功');
          // 转发成功
        },
        fail: function (res) {
          console.log(res + '失败');
          // 转发失败
        },
        complete: function (res) {
          // 不管成功失败都会执行
        }
      }
    }
  }
})