// pages/pllist/pllist.js
const app = getApp()
Page({

  /**
   * 页面的初始数据
   */
  data: {

  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (e) {
    var that = this
    wx.setNavigationBarTitle({
      title: '评论列表',
    })
    var tel = wx.getStorageSync('tel')
    wx.request({
      url: app.globalData.url + 'api/xiaoxi/pllist',
      data:{
        tel: tel
      },
      method: 'post',
      success: function(res){
        console.log(res)
        that.setData({
          info: res.data.info,
          info1: res.data.info1
        })
      }
    })
  },
})