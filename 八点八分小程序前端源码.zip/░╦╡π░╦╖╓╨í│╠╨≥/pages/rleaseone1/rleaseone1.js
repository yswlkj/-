const app = getApp()
Page({

  /**
   * 页面的初始数据
   */
  data: {
    second: 60,
    index: 0,
    type: 0,
    yincang: true,
    yincang1: true,
    hidden: false,
    countryList14: ['男女不限', '限女生', '限男生'],
    disabled1: '',
    ttype: 0,
    multiArray: [
      [1, 2, 3, 4, 5, 6, 7, 8, 9], '室', [0, 1, 2, 3, 4, 5, 6, 7, 8, 9], '厅', [0, 1, 2, 3, 4, 5, 6, 7, 8, 9], '卫'
    ],
    shi: '室',
    ting: '厅',
    wei: '卫',
    multiArray1: [
      [-1, 1, 2, 3, 4, 5, 6, 7, 8, 9], '层', '共', [1, 2, 3, 4, 5, 6, 7, 8, 9], '层'
    ],
    gong: '共',
    ceng: '层',
    sub_type: 0
  },
  mytouchstart: function (e) {
    let that = this;
    that.setData({
      touch_start: e.timeStamp
    })
    console.log(e.timeStamp + '- touch-start')
  },
  //按下事件结束
  mytouchend: function (e) {
    let that = this;
    that.setData({
      touch_end: e.timeStamp
    })
    console.log(e.timeStamp + '- touch-end')
  },
  changeMultiPicker(e) {
    console.log(e)
    var that = this
    that.setData({
      multiIndex: e.detail.value
    })
    var multiIndex = that.data.multiIndex
    console.log(multiIndex)
    app.globalData.huxing = multiIndex.toString()
    console.log(app.globalData.huxing)
  },
  changeMultiPicker1(e) {
    console.log(e)
    var that = this
    var multiIndex1 = e.detail.value
    var multiArray1 = that.data.multiArray1
    console.log('楼层-------')
    console.log(multiArray1[0][multiIndex1[0]])
    console.log('总楼层-------')
    console.log(multiArray1[3][multiIndex1[3]])

    if (multiArray1[0][multiIndex1[0]] > multiArray1[3][multiIndex1[3]]) {
      var multiIndex1 = [multiIndex1[0], 0, 0, multiIndex1[0] - 2, 0]
    }
    that.setData({
      multiIndex1: multiIndex1,
      multiIndex2: multiIndex1
    })
    var multiIndex1 = that.data.multiIndex1
    console.log(multiIndex1)
    app.globalData.louceng = multiIndex1.toString()
    console.log(app.globalData.louceng)
  },
  bindMultiPickerColumnChange1: function (e) {
    var that = this
    console.log('修改的列为', e.detail.column, '，值为', e.detail.value);
    var multiIndex1 = that.data.multiIndex2
    var multiArray1 = that.data.multiArray1

    if (e.detail.column == 0) {
      if (multiArray1[0][e.detail.value] > multiArray1[3][multiIndex1[3]]) {
        console.log(1)
        var cha = multiArray1[0][e.detail.value] - multiArray1[3][multiIndex1[3]]
        var id = multiIndex1[3] + cha;
        var multiIndex1 = [e.detail.value, 0, 0, id, 0]
        console.log(multiIndex1)
        that.setData({
          multiIndex2: multiIndex1
        })
      }
    } else if (e.detail.column == 3) {
      console.log(multiArray1[3][e.detail.value], multiArray1[0][multiIndex1[0]])
      if (multiArray1[3][e.detail.value] < multiArray1[0][multiIndex1[0]]) {
        var cha = multiArray1[0][multiIndex1[0]] - multiArray1[3][e.detail.value]
        // console.log(cha)
        var id = multiIndex1[0] - cha;
        var multiIndex1 = [id, 0, 0, e.detail.value, 0]
        that.setData({
          multiIndex2: multiIndex1
        })
      }
    }
  },
  fabu: function (e) {

    this.setData({
      yincang: false,
    })
  },
  fabu1: function (e) {

    this.setData({
      yincang1: false,
    })
  },
  fabu_close: function (e) {
    this.setData({
      yincang: true,
    })
  },
  fabu_close1: function (e) {
    this.setData({
      yincang1: true,
    })
  },
  area: function (e) {
    var that = this
    wx.navigateTo({
      url: '../map/map',
    })
  },
  upload: function () {
    let that = this;
    wx.chooseImage({
      count: 9 - app.globalData.fabu_yiyou.length,
      sizeType: ['compressed'],
      sourceType: ['album', 'camera'],
      success: res => {
        wx.showToast({
          title: '正在上传...',
          icon: 'loading',
          mask: true,
          duration: 1000
        })
        if (parseInt(app.globalData.fabu_yiyou.length) < 10) {
          app.globalData.fabu_update = app.globalData.fabu_update.concat(res.tempFilePaths)
          app.globalData.fabu_yiyou = app.globalData.fabu_yiyou.concat(res.tempFilePaths)
          that.setData({
            tempFilePaths: app.globalData.fabu_yiyou
          })

        } else if (app.globalData.fabu_yiyou.length > 9) {
          console.log('超过9张')
          wx.showToast({
            title: '房源图片最多9张',
            duration: 2000,
            icon: 'none'
          })
          that.setData({
            type: 2
          })
        }
      }
    })
  },
  aaa1: function (e) {
    var that = this
    var imgs = app.globalData.fabu_yiyou;
    var imgs1 = app.globalData.fabu_update
    var index = e.currentTarget.dataset.index;
    if (index == that.data.nav) {
      that.setData({
        nav: '-1'
      })
    }
    console.log(imgs)
    console.log(index)
    imgs.splice(index, 1);
    app.globalData.fabu_yiyou = imgs
    console.log(imgs)
    that.setData({
      tempFilePaths: imgs,
    });
  },

  uploadimg: function () {
    var pics = app.globalData.fabu
    for (var i = 0; i < pics.length; i++) {
      wx.uploadFile({
        url: app.globalData.url + 'api/fabu/img',
        filePath: pics[i],
        name: 'file',
        success: function (res) {
          app.globalData.fabu1 = app.globalData.fabu1 + '@' + res.data
        }
      })
    }
  },
  chooseVideo: function () {
    var that = this
    wx.chooseVideo({
      sourceType: ['album', 'camera'],
      maxDuration: 15,
      camera: 'back',
      success: function (res) {
        app.globalData.shipin = res.tempFilePath
        that.setData({
          video: res.tempFilePath,
        })
      }
    })
  },
  shan_vi: function () {
    var that = this
    app.globalData.shipin = ''
    that.setData({
      video: null
    })
  },
  tap: function (e) {
    var that = this
    console.log(e)
    var touchTime = that.data.touch_end - that.data.touch_start;
    if (touchTime > 350) {
      console.log(e)
      var picarr = app.globalData.fabu_yiyou
      var index = e.currentTarget.dataset.index
      wx.showModal({
        title: '提示',
        content: '是否设置当前选中图片为封面',
        showCancel: true,
        cancelText: "我再想想",
        confirmText: "确定设置",
        success: function (res) {
          if (res.cancel) {} else {
            var fengmian = picarr[index]
            that.setData({
              nav: index
            })
            if (app.globalData.fengmian1 == 0) {
              app.globalData.fengmian1 = index
            } else {
              app.globalData.fengmian1 = index
            }
          }
        },
      })
    } else {
      var picarr = app.globalData.fabu_yiyou
      var index = e.currentTarget.dataset.index
      wx.previewImage({
        current: that.data.tempFilePaths[index],
        urls: that.data.tempFilePaths,
        success: function (res) {},
        fail: function () {}
      })
    }
  },
  long: function (e) {
    var that = this
    console.log(e)
    var picarr = app.globalData.fabu_yiyou
    var index = e.currentTarget.dataset.index
    wx.showModal({
      title: '提示',
      content: '是否设置当前选中图片为封面',
      showCancel: true,
      cancelText: "我再想想",
      confirmText: "确定设置",
      success: function (res) {
        if (res.cancel) {} else {
          var fengmian = picarr[index]
          that.setData({
            nav: index
          })
          if (app.globalData.fengmian1 == 0) {
            app.globalData.fengmian1 = index
          } else {
            app.globalData.fengmian1 = index
          }
        }
      },
    })
  },
  uploadvideo: function () {
    var shipin = app.globalData.shipin
    console.log(shipin)
    for (var i = 0; i < shipin.length; i++) {
      wx.uploadFile({
        url: app.globalData.url + 'api/fabu/video',
        filePath: shipin[i],
        name: 'file',
        data: {
          id: 1
        },
        method: 'post',
        success: function (res) {
          //打印
          console.log(res)
          // app.globalData.shipin = app.globalData.shipin + '@' + res.data
          console.log(app.globalData.fabu1)
        }
      })
    }
  },
  changeCountry(e) {
    this.setData({
      countryIndex: e.detail.value
    });
  },
  changeCountry1(e) {
    this.setData({
      countryIndex1: e.detail.value
    });
  },
  changeCountry2(e) {
    this.setData({
      countryIndex2: e.detail.value
    });
  },
  changeCountry3(e) {
    this.setData({
      countryIndex3: e.detail.value
    });
  },
  changeCountry4(e) {
    console.log(e)
    this.setData({
      countryIndex4: e.detail.value
    });
  },
  changeCountry9(e) {
    this.setData({
      countryIndex9: e.detail.value
    });
  },
  changeCountry10(e) {
    this.setData({
      countryIndex10: e.detail.value
    });
  },
  changeCountry11(e) {
    this.setData({
      countryIndex11: e.detail.value
    });
  },
  changeCountry12(e) {
    this.setData({
      countryIndex12: e.detail.value
    });
  },
  changeCountry13(e) {
    var that = this
    var countryList13 = that.data.countryList13
    that.setData({
      countryIndex13: e.detail.value
    });
    var arr = [];
    for (var oo = 1; oo <= countryList13[e.detail.value]; oo++) {
      var arr = arr.concat(oo)
    }
    var countryList12 = arr
    console.log(countryList12)
    that.setData({
      countryList12: countryList12
    })
  },
  changeCountry14(e) {
    this.setData({
      countryIndex14: e.detail.value
    });
  },
  change: function (e) {
    var that = this
    var arr = that.data.zjbh
    var intro = that.data.intro
    if (intro.length == 0) {
      for (var i = 0; i < arr.length; i++) {
        var intro = intro.concat(0)
      }
    }
    var id = e.currentTarget.dataset.id
    var index = e.currentTarget.dataset.index
    if (intro[index] == 0) {
      intro.splice(index, 1, id)
    }
    console.log(intro)
    app.globalData.intro = intro
    that.setData({
      intro: intro
    })
  },
  change2: function (e) {
    var that = this
    var intro = that.data.intro
    var index = e.currentTarget.dataset.index
    var id = e.currentTarget.dataset.id
    intro.splice(index, 1, 0)
    console.log(intro)
    that.setData({
      intro: intro
    })
    app.globalData.intro = intro
  },
  onLoad: function (e) {
    var that = this
    wx.setNavigationBarTitle({
      title: '房源修改',
    })
    var id = e.id
    app.globalData.shipin = ''
    app.globalData.shipin1 = ''
    var tel = wx.getStorageSync('tel')
    that.setData({
      id: id
    })
    app.globalData.fid = e.id
    app.globalData.ss_xq_name = undefined
    app.globalData.ss_xq_addr = undefined
    wx.request({
      url: app.globalData.url + 'api/my/fabu_update_index',
      data: {
        id: id,
        tel: tel,
        url: app.globalData.url
      },
      method: 'post',
      success: function (res) {
        console.log(res)
        app.globalData.fabu_yiyou = res.data.pic
        app.globalData.zonghe = res.data.pic
        app.globalData.md_id = res.data.info.mendian
        var countryList = [];
        var countryList_id = [];
        for (var o = 0; o < res.data.cx.length; o++) {
          var countryList_id = countryList_id.concat(res.data.cx[o].id)
          var countryList = countryList.concat(res.data.cx[o].title)
        }
        var countryList1 = [];
        var countryList1_id = [];
        for (var a = 0; a < res.data.zxqk.length; a++) {
          var countryList1_id = countryList1_id.concat(res.data.zxqk[a].id)
          var countryList1 = countryList1.concat(res.data.zxqk[a].title)
        }
        var countryList2 = [];
        var countryList2_id = [];
        for (var s = 0; s < res.data.lflx.length; s++) {
          var countryList2_id = countryList2_id.concat(res.data.lflx[s].id)
          var countryList2 = countryList2.concat(res.data.lflx[s].title)
        }
        var countryList3 = [];
        var countryList3_id = [];
        for (var d = 0; d < res.data.yjfs.length; d++) {
          var countryList3_id = countryList3_id.concat(res.data.yjfs[d].id)
          var countryList3 = countryList3.concat(res.data.yjfs[d].title)
        }
        var countryList4 = [];
        var countryList4_id = [];
        for (var i = 0; i < res.data.huxing.length; i++) {
          var countryList4_id = countryList4_id.concat(res.data.huxing[i].id)
          var countryList4 = countryList4.concat(res.data.huxing[i].title)
        }
        var countryList9 = [];
        var countryList9_id = [];
        for (var k = 0; k < res.data.rq.length; k++) {
          var countryList9_id = countryList9_id.concat(res.data.rq[k].id)
          var countryList9 = countryList9.concat(res.data.rq[k].title)
        }
        var countryList10 = [];
        var countryList10_id = [];
        for (var x = 0; x < res.data.ws.length; x++) {
          var countryList10_id = countryList10_id.concat(res.data.ws[x].id)
          var countryList10 = countryList10.concat(res.data.ws[x].title)
        }
        var countryList11 = [];
        var countryList11_id = [];
        for (var z = 0; z < res.data.cw.length; z++) {
          var countryList11_id = countryList11_id.concat(res.data.cw[z].id)
          var countryList11 = countryList11.concat(res.data.cw[z].title)
        }
        var countryList14 = [];
        var countryList14_id = [];
        for (var zz = 0; zz < res.data.xbyq.length; zz++) {
          var countryList14_id = countryList14_id.concat(res.data.xbyq[zz].id)
          var countryList14 = countryList14.concat(res.data.xbyq[zz].title)
        }
        var lou = [-2, -1];
        var zong = [];
        for (var v = 1; v <= res.data.lc.title; v++) {
          var zong = zong.concat(v);
          var lou = lou.concat(v);
        }
        var multiArray1 = that.data.multiArray1
        multiArray1.splice(0, 1, lou);
        multiArray1.splice(3, 1, zong);
        if (res.data.info.fylb == 0) {
          that.setData({
            ttype: 1,
            disabled1: 'disabled'
          })
        } else if (res.data.info.fylb == 1) {
          that.setData({
            ttype: 0,
            disabled1: ''
          })
        }
        that.setData({
          md_list: res.data.md_list,
          u_type: res.data.info.u_type,
          fylx: res.data.fylx,
          user: res.data.user,
          countryList: countryList,
          countryList_id: countryList_id,
          countryList1: countryList1,
          countryList1_id: countryList1_id,
          countryList2: countryList2,
          countryList2_id: countryList2_id,
          countryList3: countryList3,
          countryList3_id: countryList3_id,
          countryList4: countryList4,
          countryList4_id: countryList4_id,
          countryList9: countryList9,
          countryList9_id: countryList9_id,
          countryList10: countryList10,
          countryList10_id: countryList10_id,
          countryList11: countryList11,
          countryList11_id: countryList11_id,
          info: res.data.info,

          tempFilePaths: res.data.pic,
          video: res.data.info.video,
          url: app.globalData.url,
          fylx_id: res.data.info.fylx,
          title1: res.data.info.mendian1,
          tel: res.data.info.lc_tel,
          ss_xq_name1: res.data.info.xiaoquname,
          mianji: res.data.info.mianji,
          addr: res.data.info.keywords,
          addr1: res.data.info.keywords,
          menpai: res.data.info.description,
          louceng: res.data.info.high,
          setsex: res.data.info.setsex,
          intro1: res.data.info.intro,
          price: res.data.info.price,
          xq_name: res.data.info.xiaoquname,
          area: res.data.info.xiaoquname,
          intro: res.data.intro,
          zjbh: res.data.zjbh,
          multiArray1: multiArray1,
          multiIndex: res.data.info.hx_value,
          multiIndex1: res.data.info.lc_value,
          nav: res.data.info.nav,
          countryIndex: res.data.info.cx2,
          countryIndex1: res.data.info.zxqk2,
          countryIndex2: res.data.info.lflx2,
          countryIndex3: res.data.info.yjfs2,
          countryIndex9: res.data.info.rq2,
          countryIndex10: res.data.info.ws2,
          countryIndex11: res.data.info.cw2,
          countryIndex14: res.data.info.setsex2,

        })
      }
    })
  },
  addr: function (e) {
    var that = this
    that.setData({
      addr: e.detail.value
    })
  },
  menpai: function (e) {
    var that = this
    that.setData({
      menpai: e.detail.value
    })
  },
  mianji: function (e) {
    var that = this
    that.setData({
      mianji: e.detail.value
    })
  },
  louceng: function (e) {
    var that = this
    that.setData({
      louceng: e.detail.value
    })
  },
  setsex: function (e) {
    var that = this
    that.setData({
      setsex: e.detail.value
    })
  },
  price: function (e) {
    var that = this
    that.setData({
      price: e.detail.value
    })
  },
  intro1: function (e) {
    var that = this
    that.setData({
      intro1: e.detail.value
    })
  },
  xz_fylx: function (e) {
    var that = this
    var id = e.currentTarget.dataset.id
    that.setData({
      fylx_id: id
    })
  },
  code: function (e) {
    var that = this
    that.setData({
      code: e.detail.value
    })
    var code = e.detail.value
    var mobile = that.data.mobile
    if (mobile) {
      var tel = mobile
    } else {
      var tel = wx.getStorageSync('tel')
    }
    console.log(code)
    if (code) {
      wx.request({
        url: app.globalData.url + 'api/fabu/check',
        data: {
          mobile: tel,
          code: e.detail.value
        },
        method: 'post',
        success: function (res) {
          console.log(res)
          if (res.data.info == 0) {
            that.setData({
              type: 1
            })
          } else if (res.data.info == 1) {
            that.setData({
              type: 0
            })
          }
          that.setData({
            y_check: res.data.info
          })
        }
      })
    } else {
      that.setData({
        y_check: 1,
        type: 0
      })
    }
  },
  mobile: function (e) {
    var that = this
    that.setData({
      mobile: e.detail.value
    })
    var tel = that.data.user.mobile
    if (e.detail.value == tel) {
      that.setData({
        xianshi: 1
      })
    } else {
      that.setData({
        xianshi: 2
      })
    }
  },
  yzm: function (e) {
    var that = this
    var tel = that.data.mobile
    if (!tel) {
      var mobile = wx.getStorageSync('tel')
    } else {
      var myreg = /^((1[0-9]{2})+\d{8})$/;
      if (!myreg.test(tel)) {
        wx.showToast({
          title: "手机号格式有误",
          icon: 'none',
          duration: 2000
        })
        return false;
      }
      var mobile = tel
    }
    wx.request({
      url: app.globalData.url + 'api/fabu/yzm',
      data: {
        tel: mobile
      },
      method: 'post',
      success: function (res) {
        console.log(res)
        that.setData({
          success: 1
        })
        let promise = new Promise((resolve, reject) => {
          let setTimer = setInterval(
            () => {
              that.setData({
                second: that.data.second - 1,
              })
              if (that.data.second <= 0) {
                that.setData({
                  second: 60,
                  alreadySend: false,
                  send: true,
                })
                resolve(setTimer)
              }
            }, 1000)
          that.setData({
            disabled: 'disabled'
          })
        })
        promise.then((setTimer) => {
          clearInterval(setTimer)
          that.setData({
            success: 2,
            disabled: ''
          })
        })
      }
    })
  },
  liubtn1: function (e) {
    var that = this
    var yincang1 = that.data.yincang1
    if (yincang1 == false) {
      that.setData({
        yincang1: true,
      })
    } else if (yincang1 == true) {
      that.setData({
        yincang1: false,
      })
    }

  },
  bakbtn1: function (e) {
    var that = this
    var id = e.currentTarget.dataset.id
    app.globalData.md_id = id
    wx.request({
      url: app.globalData.url + 'api/fabu/mendian_show',
      data: {
        id: id,
      },
      method: 'post',
      success: function (res) {
        console.log(res)
        that.getLocate(res.data.lat)
        app.globalData.ss_xq_latitude = res.data.info.lat
        app.globalData.ss_sq_longitude = res.data.info.lng
        that.setData({
          title1: res.data.info.title,
          ss_xq_name1: res.data.info.title,
          disabled1: 'disabled',
          ttype: 1
        })
      }
    })
    that.setData({
      yincang1: true,
    })
  },
  getLocate(lat) {
    var that = this;
    var length = lat.length
    for (var i = 0; i < length; i++) {
      wx.request({
        url: 'https://apis.map.qq.com/ws/geocoder/v1/?location=' + lat[i].lat + ',' + lat[i].lng + '&key=I4CBZ-FYL6G-X2LQD-I56ON-N6K7E-UQFK4',
        success: function (res) {
          console.log(res)
          that.setData({
            addr: res.data.result.address
          })
        },
      })
    }
  },
  submit: function (e) {
    var that = this
    console.log(app.globalData.zonghe)
    var pics = app.globalData.fabu_yiyou
    var video = app.globalData.shipin
    var fylx_id = that.data.fylx_id
    var suoshugy = app.globalData.md_id
    var tel = that.data.mobile
    var yzm = that.data.code
    var xq_name = app.globalData.ss_xq_name
    var addr = that.data.addr
    var menpai = that.data.menpai
    var mianji = that.data.mianji
    var huxing = app.globalData.huxing
    var cx = that.data.countryIndex
    var louceng = app.globalData.louceng
    var zlc = that.data.countryIndex13
    var zxqk = that.data.countryIndex1
    var setsex = that.data.countryIndex14
    var lflx = that.data.countryIndex2
    var price = that.data.price
    var yjfs = that.data.countryIndex3
    var u_type = that.data.u_type
    var rq = that.data.countryIndex9
    var ws = that.data.countryIndex10
    var cw = that.data.countryIndex11
    var intro = that.data.intro
    console.log(video, pics)
    if (!pics[0]) {
      wx.showToast({
        title: '请添加房源图片',
        duration: 2000,
        icon: 'none'
      })

      return;
    }
    if (pics.length > 9) {
      wx.showToast({
        title: '房源图片最多9张',
        duration: 2000,
        icon: 'none'
      })
      return;
    }
    if (!fylx_id) {
      wx.showToast({
        title: '请选择房源类型',
        duration: 2000,
        icon: 'none'
      })

      return;
    }
    if (u_type == 0) {
      if (!suoshugy) {
        wx.showToast({
          title: '请选择所属公寓',
          duration: 2000,
          icon: 'none'
        })

        return;
      }
    }
    if (!tel) {
      app.globalData.u_tel = wx.getStorageSync('tel')
    } else {
      var myreg = /^((1[0-9]{2})+\d{8})$/;
      if (!myreg.test(tel)) {
        wx.showToast({
          title: "手机号格式有误",
          icon: 'none',
          duration: 2000
        })
        return false;
      }
      app.globalData.u_tel = tel
    }
    var xianshi = that.data.xianshi
    if (xianshi == 2) {
      if (!yzm) {
        wx.showToast({
          title: '请填写验证码',
          duration: 2000,
          icon: 'none'
        })
        return;
      }
    }
    if (!xq_name) {
      app.globalData.xq_name = that.data.info.xiaoquname
    } else {
      app.globalData.xq_name = app.globalData.ss_xq_name
    }

    var myreg1 = /^[0-9]*$/;
    if (!myreg1.test(mianji)) {
      wx.showToast({
        title: "面积格式有误",
        icon: 'none',
        duration: 2000
      })

      return;
    }
    if (!huxing) {
      app.globalData.huxing = that.data.multiIndex.toString()
    } else {
      app.globalData.huxing = app.globalData.huxing
    }
    if (!cx) {
      app.globalData.cx = that.data.info.cx
    } else {
      app.globalData.cx = that.data.countryList_id[cx]
    }
    if (!louceng) {
      app.globalData.louceng = that.data.multiIndex1.toString()
    } else {
      app.globalData.louceng = app.globalData.louceng
    }
    if (!zlc) {
      app.globalData.zlc = that.data.info.zlc
    } else {
      app.globalData.zlc = that.data.countryList13_id[countryIndex13]
    }
    if (!rq) {
      app.globalData.rq = that.data.info.ranqi
    } else {
      app.globalData.rq = that.data.countryList9_id[rq]
    }
    if (!ws) {
      app.globalData.ws = that.data.countryList10_id[that.data.info.ws2]
      console.log(app.globalData.ws,1)
    } else {
      app.globalData.ws = that.data.countryList10_id[ws]
      console.log(app.globalData.ws)
    }
    // return
    if (!zxqk) {
      app.globalData.zxqk = that.data.info.zxqk
    } else {
      app.globalData.zxqk = that.data.countryList1_id[zxqk]
    }

    if (!lflx) {
      app.globalData.lflx = that.data.info.lflx
    } else {
      app.globalData.lflx = that.data.countryList2_id[lflx]
    }
    if (!cw) {
      app.globalData.cw = that.data.info.cw
    } else {
      app.globalData.cw = that.data.countryList11_id[cw]
    }
    if (!setsex) {
      app.globalData.setsex = that.data.info.setsex
    } else {
      app.globalData.setsex = that.data.countryList14[setsex]
    }
    if (!price) {
      wx.showToast({
        title: '请填写租金',
        duration: 2000,
        icon: 'none'
      })

      return;
    }
    if (!myreg1.test(price)) {
      wx.showToast({
        title: "租金格式有误",
        icon: 'none',
        duration: 2000
      })

      return;
    }
    if (!yjfs) {
      app.globalData.yjfs = that.data.info.yjfs
    } else {
      app.globalData.yjfs = that.data.countryList3_id[yjfs]
    }
    // if (intro.filter(Boolean) == 0) {
    //   wx.showToast({
    //     title: '请选择租金包含',
    //     duration: 2000,
    //     icon: 'none'
    //   })

    //   return;
    // }
    console.log(app.globalData.ss_xq_latitude, app.globalData.ss_sq_longitude)
    app.globalData.fylx_id = fylx_id
    app.globalData.suoshugy = suoshugy
    app.globalData.addr = addr
    app.globalData.mianji = mianji
    app.globalData.menpai = menpai
    app.globalData.nav = that.data.nav



    app.globalData.price = price
    if (intro.filter(Boolean) != 0) {
      for (var a = 0; a < intro.length; a++) {
        var bh = bh + ',' + intro[a]
      }
      app.globalData.intro1 = bh
    }
    console.log(app.globalData.zonghe)
    wx.navigateTo({
      url: '../rleasetwo1/rleasetwo1?id=' + that.data.id,
    })
  },
  onShow: function () {
    var that = this
    var ss_xq_name = app.globalData.ss_xq_name
    if (ss_xq_name !== undefined) {
      var ss_xq_name1 = app.globalData.ss_xq_name
      that.getLocate1()
    }
    var ss_xq_address = app.globalData.ss_xq_addr
    if (ss_xq_name !== undefined) {
      var ss_xq_address1 = app.globalData.ss_xq_addr
    }
    that.setData({
      ss_xq_name2: ss_xq_name1,
      area: ss_xq_name1,
      ss_xq_address1: ss_xq_address1,
      addr1: ss_xq_address1
    })
  },
  getLocate1() {
    var that = this;
    var longitude = app.globalData.ss_sq_longitude
    var latitude = app.globalData.ss_xq_latitude
    wx.request({
      url: 'https://apis.map.qq.com/ws/geocoder/v1/?location=' + latitude + ',' + longitude + '&key=I4CBZ-FYL6G-X2LQD-I56ON-N6K7E-UQFK4',
      success: function (res) {
        console.log(res)
        wx.request({
          url: app.globalData.url + 'api/fabu/dizhi',
          data: {
            dizhi: res.data.result.ad_info.province,
            adcode: res.data.result.ad_info.adcode,
            city: res.data.result.ad_info.city
          },
          method: 'post',
          success: function (rag) {
            console.log(rag)
            if (rag.data.prov_status == 0) {
              wx.showToast({
                title: '当前省份未开放',
                duration: 2000,
                icon: 'none',
                mask: true
              })
              app.globalData.ss_xq_name = undefined
              app.globalData.ss_xq_addr = undefined
              that.setData({
                sub_type: 1,
                area: '',
                addr: '',
                addr1: ''
              })
            } else {
              that.setData({
                sub_type: 0
              })
            }
          }
        })
      },
    })
  },
})