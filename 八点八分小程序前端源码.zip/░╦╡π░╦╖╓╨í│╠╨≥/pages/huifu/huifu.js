// pages/comment/comment.js
const app = getApp()
Page({

  /**
   * 页面的初始数据
   */
  data: {
    items: [
      {
        name: '0',
        value: '私密评论（仅房东可见）',
        checked: false
      },
      {
        name: '1',
        value: '公开评论',
        checked: false
      }
    ],
    nav: 0,
    nav1: 0
  },
  content: function (e) {
    var that = this
    that.setData({
      content: e.detail.value
    })
  },
  submit: function (e) {
    console.log(121111)
    var that = this
    var id = that.data.id
    var zt = that.data.zt
    var content = that.data.content
    if (!content) {
      wx.showToast({
        title: '请填写评论详情',
        duration: 2000,
        icon: 'none'
      })
    }
    if (content.length > 100) {
      wx.showToast({
        title: '详情最多填写100字',
        duration: 2000,
        icon: 'none'
      })
      return;
    }
    
    wx.request({
      url: app.globalData.url + 'api/my/huifu',
      data:{
        id: id,
        content: content
      },
      method: 'post',
      success: function(res){
        console.log(res)
        if(res.data.info == 1){
          wx.showToast({
            title: '回复成功',
            duration: 2000,
            icon: 'none'
          })
          setTimeout(function () {
            wx.navigateBack({

            })
          }, 2000)
        }else if(res.data.info == 2){
          wx.showToast({
            title: '回复内容存在敏感词,请重新上传',
            duration: 2000,
            icon: 'none'
          })
        }
      }
    })

  },
  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (e) {
    var that = this
    var id = e.id
    var zt = e.zt
    // app.globalData.f_id = id
    // app.globalData.type = zt
    that.setData({
      id: id,
      zt: zt
    })
    wx.setNavigationBarTitle({
      title: '回复',
    })
  },
})