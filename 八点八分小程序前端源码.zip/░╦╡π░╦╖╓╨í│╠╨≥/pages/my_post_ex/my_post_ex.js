// pages/my_post_ex/my_post_ex.js
const app = getApp()
// // import WxParse from '../../wxParse/wxParse.js';
Page({

  /**
   * 页面的初始数据
   */
  data: {
    width: wx.getSystemInfoSync().windowWidth - 20, //图片宽度  
    height: wx.getSystemInfoSync().windowWidth * 8 / 13, //图片高度
    yincang1: true,
  },
  liubtn1: function(e) {

    this.setData({
      yincang1: false,
      bottom: 0
    })
  },
  bakbtn1: function(e) {
    this.setData({
      yincang1: true,
      bottom: -100
    })
  },
  
  xia: function(e) {
    var that = this
    var id = e.currentTarget.dataset.id
    var tel = wx.getStorageSync('tel')
    wx.showModal({
      title: '提示',
      content: '是否下架',
      showCancel: true, //是否显示取消按钮
      cancelText: "否", //默认是“取消”
      confirmText: "是", //默认是“确定”
      success: function(res) {
        if (res.cancel) {
          //点击取消,默认隐藏弹框
        } else {
          wx.request({
            url: app.globalData.url + 'api/qiuzu/xia',
            data: {
              id: id,
              tel: tel
            },
            method: 'post',
            success: function(res) {
              console.log(res)
              if (res.data.info == 1) {
                wx.showToast({
                  title: '修改成功',
                  duration: 2000,
                  icon: 'none'
                })
                setTimeout(function() {
                  that.reload();
                }, 2000)
              }
            }
          })
        }
      },
    })
  },
  previewImg: function(e) {
    var that = this
    console.log(e)
    console.log(e.currentTarget.dataset.index);
    var index = e.currentTarget.dataset.index;

    var imgArr = that.data.picss;
    wx.previewImage({
      current: imgArr[index], //当前图片地址
      urls: imgArr, //所有要预览的图片的地址集合 数组形式
      success: function(res) {},
      fail: function(res) {},
      complete: function(res) {},
    })
  },
  shang: function(e) {
    var that = this
    var id = e.currentTarget.dataset.id
    var tel = wx.getStorageSync('tel')
    wx.showModal({
      title: '提示',
      content: '是否上架',
      showCancel: true, //是否显示取消按钮
      cancelText: "否", //默认是“取消”
      confirmText: "是", //默认是“确定”
      success: function(res) {
        if (res.cancel) {
          //点击取消,默认隐藏弹框
        } else {
          wx.request({
            url: app.globalData.url + 'api/qiuzu/shang',
            data: {
              id: id,
              tel: tel
            },
            method: 'post',
            success: function(res) {
              console.log(res)
              if (res.data.info == 1) {
                wx.showToast({
                  title: '修改成功',
                  duration: 2000,
                  icon: 'none'
                })
                setTimeout(function() {
                  that.reload();
                }, 2000)
              } else if (res.data.info == 0) {
                wx.showToast({
                  title: '请等待修改完成',
                  duration: 2000,
                  icon: 'none'
                })
              } else if (res.data.info == 2) {
                wx.showModal({
                  title: '提示',
                  content: '由于当前求租贴被举报下架，如需上架，请修改求租贴信息',
                  showCancel: false, //是否显示取消按钮-----》false去掉取消按钮
                  confirmText: "我知道了", //默认是“确定”
                  success: function (res) {
                    if (res.confirm) {
                      //点击确定
                      console.log("您点击了确定")
                    }
                  }
                })
              }
            }
          })
        }
      },
    })
  },
  reload: function() {
    var that = this
    wx.setNavigationBarTitle({
      title: '帖子详情',
    })
    wx.request({
      url: app.globalData.url + 'api/qiuzu/show',
      data: {
        url: app.globalData.url,
        id: app.globalData.f_id,
        lat: app.globalData.lat,
        lng: app.globalData.lng
      },
      method: 'post',
      success: function(res) {
        console.log(res)
        var lat = res.data.lat
        that.getLocate1(lat)
        that.setData({
          info: res.data.info,
          pics: res.data.pics,
          picss: res.data.picss,
          qzyq: res.data.qzyq,
          user: res.data.user,
          url: app.globalData.url,
          longitude: res.data.info.lng,
          latitude: res.data.info.lat,
          markers: [{
            longitude: res.data.info.lng,
            latitude: res.data.info.lat,
            label: {
              bgColor: '#fff',
              anchorX: -60,
              anchorY: 10,
              padding: 5,
              borderRadius: 5,
            },
          }],
          list: res.data.list,
          pingjia: res.data.pinjia
        })
      }
    })
  },
  shan: function(e) {
    var that = this
    var id = e.currentTarget.dataset.id
    var tel = wx.getStorageSync('tel')
    wx.showModal({
      title: '提示',
      content: '是否删除',
      showCancel: true, //是否显示取消按钮
      cancelText: "否", //默认是“取消”
      confirmText: "是", //默认是“确定”
      success: function(res) {
        if (res.cancel) {
          //点击取消,默认隐藏弹框
        } else {
          wx.request({
            url: app.globalData.url + 'api/qiuzu/shan',
            data: {
              id: id,
              tel: tel
            },
            method: 'post',
            success: function(res) {
              console.log(res)
              if (res.data.info == 1) {
                wx.showToast({
                  title: '删除成功',
                  duration: 2000,
                  icon: 'none'
                })
                setTimeout(function() {
                  that.reload();
                }, 2000)
              } else if (res.data.info == 0) {
                wx.showToast({
                  title: '请等待删除完成',
                  duration: 2000,
                  icon: 'none'
                })
              }
            }
          })
        }
      },
    })
  },
  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function(e) {
    var that = this
    var id = e.id
    wx.setNavigationBarTitle({
      title: '帖子详情',
    })
    app.globalData.f_id = id
    var tel = wx.getStorageSync('tel')

    wx.request({
      url: app.globalData.url + 'api/qiuzu/show',
      data: {
        url: app.globalData.url,
        id: id,
        lat: app.globalData.lat,
        lng: app.globalData.lng,
        tel: tel
      },
      method: 'post',
      success: function(res) {
        console.log(res)
        var lat = res.data.lat
        that.getLocate(res.data.info.lng, res.data.info.lat)
        // var content1 = res.data.info.content;
        // WxParse.wxParse('content1', 'html', content1, that, 5)
        that.setData({
          info: res.data.info,
          html: res.data.info.content,
          pics: res.data.pics,
          picss: res.data.picss,
          qzyq: res.data.qzyq,
          user: res.data.user,
          url: app.globalData.url,
          longitude: res.data.info.lng,
          latitude: res.data.info.lat,
          markers: [{
            longitude: res.data.info.lng,
            latitude: res.data.info.lat,
            label: {
              bgColor: '#fff',
              anchorX: -60,
              anchorY: 10,
              padding: 5,
              borderRadius: 5,
            },
          }],
          list: res.data.list,
          pingjia: res.data.pinjia
        })
      }
    })
  },
  getLocate: function(lng, lat) {
    var that = this;
    var locateCity1 = []
    var locateQu1 = []
    var locatetown = []
    var locatetownname = []
    wx.request({
      url: 'https://apis.map.qq.com/ws/geocoder/v1/?location=' + lat + ',' + lng + '&key=I4CBZ-FYL6G-X2LQD-I56ON-N6K7E-UQFK4',
      success: function(res) {
        console.log(res)
        var val1 = res.data.result.address_component.district
        var val = res.data.result.address_component.street


        that.setData({
          qu: val1,
          lu: val
        })
      },
    })

  },
  getLocate1(lat) {
    var that = this;
    var length = lat.length
    var locateCity1 = []
    var locateQu1 = []
    var locatetown = []
    var locatetownname = []
    for (var i = 0; i < length; i++) {
      wx.request({
        url: 'https://apis.map.qq.com/ws/geocoder/v1/?location=' + lat[i].lat + ',' + lat[i].lng + '&key=I4CBZ-FYL6G-X2LQD-I56ON-N6K7E-UQFK4',
        success: function(res) {
          console.log(res)
          var val1 = res.data.result.address_component.district
          var val = res.data.result.address_component.street_number
          var val2 = res.data.result.address_reference.town.id
          var val3 = res.data.result.address_reference.town.title
          locateCity1.push(val)
          locateQu1.push(val1)
          locatetown.push(val2)
          locatetownname.push(val3)
          that.setData({
            locateQu1: locateQu1,
            locateCity1: locateCity1,
            locatetown: locatetown,
            locatetownname: locatetownname
          })
        },
      })
    }
  },
  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function() {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function() {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function() {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function() {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function() {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function() {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function(e) {
    console.log(e)
    var that = this
    if (!e.target){
      var id = that.data.info.id
    }else{
      var id = e.target.dataset.id
    }
    if (that.data.info.zt == 0) {
      var zt = '求整租'
    } else if (that.data.info.zt == 1) {
      var zt = '求合租'
    }
    return {
      title: zt + '-' + that.data.info.xiaoqu + '-' + that.data.info.hx[0] + '室' + that.data.info.hx[1] + '厅' + that.data.info.hx[2] + '卫',
      path: '/pages/rent_ex/rent_ex?id=' + id,
      imageUrl: app.globalData.url + that.data.pics[0],
      success: function(shareTickets) {
        console.info(shareTickets + '成功');
        // 转发成功
      },
      fail: function(res) {
        console.log(res + '失败');
        // 转发失败
      },
      complete: function(res) {
        // 不管成功失败都会执行
      }
    }

  }
})