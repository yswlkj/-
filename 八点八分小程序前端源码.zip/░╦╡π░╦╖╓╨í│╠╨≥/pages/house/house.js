// pages/house/house.js
const app = getApp()
// import WxParse from '../../wxParse/wxParse.js';
Page({

  /**
   * 页面的初始数据
   */
  data: {
    navList:['热门房型','其他门店'],
    nav: 0,
    yincang: true,
    yincang1: true, 
    yincang2: true, 
    yincang3: true, 
    yincang4: true, 
  },
  renzheng: function (e) {

    this.setData({
      yincang: false,
    })
  },
  renzhengclose: function (e) {
    this.setData({
      yincang: true,
    })
  },
  renzheng1: function (e) {

    this.setData({
      yincang1: false,
    })
  },
  renzhengclose1: function (e) {
    this.setData({
      yincang1: true,
    })
  },
  renzheng2: function (e) {

    this.setData({
      yincang2: false,
    })
  },
  renzhengclose2: function (e) {
    this.setData({
      yincang2: true,
    })
  },
  renzheng4: function (e) {

    this.setData({
      yincang4: false,
    })
  },
  renzhengclose4: function (e) {
    this.setData({
      yincang4: true,
    })
  },
  chengnuo: function (e) {

    this.setData({
      yincang3: false,
    })
  },
  chengnuoclose: function (e) {
    this.setData({
      yincang3: true,
    })
  },
  change: function(e){
    var that = this
    wx.setNavigationBarTitle({
      title: '公寓详情',
    })
    var index = e.currentTarget.dataset.index
    var id = e.currentTarget.dataset.id
    that.setData({
      nav: index
    })
    wx.request({
      url: app.globalData.url + 'api/person/mendian_change',
      data:{
        id: id,
        index: index,
        url: app.globalData.url,
        lng1: app.globalData.lng,
        lat1: app.globalData.lat
      },
      method: 'post',
      success: function(res){
        console.log(res)

        that.setData({
          gongyu: res.data.gongyu,
          plist: res.data.plist,
          url: app.globalData.url,
          id: id,
          rz_list: res.data.rz_list,
          min: res.data.min,
          xianshi1: res.data.xianshi1,
          xianshi2: res.data.xianshi2,
          min_price: res.data.min_price,
          max_price: res.data.max_price,
          url: app.globalData.url,
        })
      }
    })
  },
  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (e) {
    var that = this
    var id = e.id
    wx.setNavigationBarTitle({
      title: '公寓详情',
    })
    wx.request({
      url: app.globalData.url + 'api/person/mendian_show',
      data:{
        id: id,
        url: app.globalData.url,
        lng1: app.globalData.lng,
        lat1: app.globalData.lat
      },
      method: 'post',
      success: function(res){
        console.log(res)
        that.setData({
          gongyu: res.data.gongyu,
          plist: res.data.plist,
          url: app.globalData.url,
          id: id,
          bq_list: res.data.bq_list,
          xianshi1: res.data.xianshi1,
          xianshi2: res.data.xianshi2,
          pinpai: app.globalData.pinpai,
          wei: app.globalData.wei,
          bao: app.globalData.bao,
          youxuan: app.globalData.youxuan,
          pinpai1: app.globalData.pinpai1,
          wei1: app.globalData.wei1,
          bao1: app.globalData.bao1,
          youxuan1: app.globalData.youxuan1,
          gengxin: app.globalData.gengxin
        })
      }
    })
  },
  tiao: function(e){
    var that = this
    var id = e.currentTarget.dataset.id
    console.log(id)
    wx.navigateTo({
      url: '../brand_hot/brand_hot?id='+id,
    }) 
  },
})