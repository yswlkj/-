const app = getApp()
Page({
  data: {
    items: [{
      name: '2',
      value: '',
      checked: false
    },],
  },
  onLoad: function (e) {
    var that = this
    wx.setNavigationBarTitle({
      title: '置顶列表',
    })
    
    wx.request({
      url: app.globalData.url + 'api/fabu/zdlist',
      success: function(res){
        console.log(res)
        that.setData({
          list: res.data.list,
          discount: res.data.list[0].discount,
          id: res.data.list[0].id,
          varvalue: res.data.varvalue,
          xieyi: res.data.xieyi
        })
      }
    })
  },
  radioChange: function (e) {
    var that = this
    var id = e.detail.value
    that.reload(id)
  },
  reload: function(id){
    var that = this
    wx.request({
      url: app.globalData.url + 'api/fabu/reload_zhiding',
      data:{
        id: id
      },
      method: 'post',
      success: function(res){
        console.log(res)
        that.setData({
          discount: res.data.info.discount,
          id: id
        })
      }
    })
  },
  radioChange2: function (e) {
    app.globalData.fabu_xieyi_zhiding = e.detail.value;
    console.log(app.globalData.fabu_xieyi_zhiding)
  },
  zhifu: function(e){
    var that = this
    var id = e.currentTarget.dataset.id
    var price = e.currentTarget.dataset.id
    if (!app.globalData.fabu_xieyi_zhiding){
      wx.showToast({
        title: "请勾选'我已阅读并同意推广规则'",
        duration: 2000,
        icon:'none'
      })
    }else{
      app.globalData.fabu_zhiding_id = id
      app.globalData.fabu_zhiding_price = price
      wx.showToast({
        title: '金额会在发布时收取',
        duration: 2000,
        icon: 'none'
      })
      setTimeout(function(){
        wx.navigateBack({
          
        })
      },2000) 
    }
  },
})