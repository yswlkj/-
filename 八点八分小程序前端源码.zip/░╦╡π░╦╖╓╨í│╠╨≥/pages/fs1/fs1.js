const app = getApp()
Page({
  data: {

  },
  onLoad: function (e) {
    var that = this
    wx.setNavigationBarTitle({
      title: '发布成功',
    })
    that.setData({
      id: e.id
    })
    wx.request({
      url: app.globalData.url + 'api/qiuzu/show2',
      data: {
        url: app.globalData.url,
        id: e.id,
        
      },
      method: 'post',
      success: function (res) {
        console.log(res)
        that.setData({
          info: res.data.info,
          picss: res.data.picss,
          tishi: res.data.tishi
        })
      }
    })
  },

  onShareAppMessage: function (e) {
    console.log(e)
    var that = this
    var id = that.data.id
    if (that.data.info.zt == 0) {
      var title = '求整租-' + that.data.info.xiaoqu + '-' + that.data.info.huxing[0] + '室' + that.data.info.huxing[1] + '厅' + that.data.info.huxing[2] + '卫'
    } else if (that.data.info.zt == 1) {
      var title = '求合租-' + that.data.info.xiaoqu + '-' + that.data.info.huxing[0] + '室' + that.data.info.huxing[1] + '厅' + that.data.info.huxing[2] + '卫'
    }
    return {
      title: title,
      path: '/pages/rent_ex/rent_ex?id=' + id,
      imageUrl: that.data.picss[0],
    }
  }
})