// pages/integral/integral.js
const app = getApp()
// import WxParse from '../../wxParse/wxParse.js';
Page({

  /**
   * 页面的初始数据
   */
  data: {
    yincang1: true,
  },
  liubtn1: function (e) {
    this.setData({
      yincang1: false,
      bottom: 0
    })
  },
  jifen: function (e) {
    var that = this
    that.setData({
      jifen: e.detail.value
    })
  },
  bakbtn2:function (e){
    var that = this
    that.setData({
      yincang1: true,
      bottom: -100
    })
  },
  bakbtn1: function (e) {
    var that = this
    var jifen = that.data.jifen
    var tel = wx.getStorageSync('tel')
    if(!jifen){
      wx.showToast({
        title: '请填写积分数量',
        duration: 2000,
        icon: 'none'
      })
      return;
    }
    var mxreg = /^[1-9]*$/
    if(!mxreg.test(jifen)){
      wx.showToast({
        title: '积分为非零的纯数字',
        duration: 2000,
        icon: 'none'
      })
      return;
    }
    wx.request({
      url: app.globalData.url + 'api/xitong/use_jifen',
      data:{
        jifen: jifen,
        tel: tel
      },
      method: 'post',
      success: function(res){
        console.log(res)
        if(res.data.info == 0){
          wx.showToast({
            title: '积分不足,无法使用',
            duration: 2000,
            icon: 'none'
          })
          return;
        }else if(res.data.info == 1){
          wx.showToast({
            title: '使用成功',
            duration: 2000,
            icon: 'none'
          })
          that.setData({
            yincang1: true,
            bottom: -100
          })
          that.reload()
        }
      }
    })
    
  },
  reload: function(){
    var that = this
    wx.setNavigationBarTitle({
      title: '积分',
    })
    var tel = wx.getStorageSync('tel')
    wx.request({
      url: app.globalData.url + 'api/jifen/index',
      data: {
        tel: tel
      },
      method: 'post',
      success: function (res) {
        // var content = res.data.info.content;
        // WxParse.wxParse('content', 'html', content, that, 5)
        console.log(res)
        that.setData({
          user: res.data.user,
          html: res.data.info.content,
        })
      }
    })
  },
  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (e) {
    var that = this
    wx.setNavigationBarTitle({
      title: app.globalData.webname,
    })
    var tel = wx.getStorageSync('tel')
    wx.request({
      url: app.globalData.url + 'api/jifen/index',
      data:{
        tel: tel
      },
      method: 'post',
      success: function(res){
        // var content = res.data.info.content;
        // WxParse.wxParse('content', 'html', content, that, 5)
        console.log(res)
        that.setData({
          user: res.data.user,
        })
      }
    })
  },
  onShow: function(e){
    var that = this
    that.reload()
  },
})