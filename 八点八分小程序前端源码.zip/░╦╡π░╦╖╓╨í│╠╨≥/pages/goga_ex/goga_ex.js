const app = getApp()
// import WxParse from '../../wxParse/wxParse.js';
Page({
  data: {

  },
  onLoad: function (e) {
    var that = this
    var id = e.id
    wx.setNavigationBarTitle({
      title: '公告消息',
    })
    wx.request({
      url: app.globalData.url + 'api/xitong/gogashow',
      data: {
        id: id,
        tel: wx.getStorageSync('tel'),
        url: app.globalData.url
      },
      method: 'post',
      success: function (res) {
        // var content = res.data.info.content;
        // WxParse.wxParse('content', 'html', content, that, 5)
        // var intro = res.data.info.intro;
        // WxParse.wxParse('intro', 'html', intro, that, 5)
        console.log(res)
        that.setData({
          info: res.data.info,
          html: res.data.info.content,
          intro: res.data.info.intro,
          url: app.globalData.url
        })
      }
    })
  },
})