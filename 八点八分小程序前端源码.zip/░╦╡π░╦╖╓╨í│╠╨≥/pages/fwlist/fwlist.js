const app = getApp()
Page({
  data: {
    type: 0,
    shan_zt: 0,
    yincang: true,
    yincang2: true,
    batchIds: [],
    select_all: ''
  },
  liubtn: function(e) {
    this.setData({
      yincang: false,
      yincang2: false,
      bottom: 0,
      shan_zt: 1
    })
  },
  liubtn1: function(e) {
    var that = this
    
    that.setData({
      yincang: true,
      yincang2: true,
      bottom: 0,
      shan_zt: 0,
      zzt: 0,
      select_all: '',
      batchIds: [],
      batchIds1: [],
    })
  },
  quanxuan: function(e) {
    console.log(e)
    var that = this;
    var batchIds = that.data.batchIds
    var length = that.data.length
    that.setData({
      yincang: false,
      yincang2: false,
      bottom: 0,
      shan_zt: 1
    })
    if(that.data.select_all == ''){
      that.setData({
        select_all: 'checked'
      })
    }else{
      that.setData({
        select_all: ''
      })
    }
    if(length == batchIds.length){
      that.setData({
        batchIds: [],
        zzt: 0
      })
    }else{
      if(batchIds.length == 0){
        for(var i=0;i<length;i++){
          var batchIds = batchIds.concat(that.data.list[i].id)
        }
      }else{
        for(var i=0;i<length;i++){
          if(!batchIds.includes(that.data.list[i].id)){
            var batchIds = batchIds.concat(that.data.list[i].id)
          }
        }
      }
      that.setData({
        batchIds: batchIds,
        zzt: 1
      })
    }
    console.log(batchIds)
    that.setData({
      list: that.data.list,
      
    })
  },
  danxuan: function(e) {
    // console.log(e)
    var that = this
    var id = e.currentTarget.dataset.id
    var batchIds = that.data.batchIds
    var length = that.data.length
    console.log(batchIds)
    if(batchIds.length == 0){
      var batchIds = batchIds.concat(id)
      console.log(batchIds)
      
    }else{
      if(batchIds.includes(id)){
        var idx = batchIds.indexOf(id)
        batchIds.splice(idx,1)
      }else{
        var batchIds = batchIds.concat(id)
      }
      console.log(batchIds)
    }
    if(length == batchIds.length){
      that.setData({
        select_all: 'checked'
      })
    }else{
      that.setData({
        select_all: ''
      })
    }
    that.setData({
      batchIds: batchIds
    })
  },
  shan: function(e){
    var that = this
    var type = that.data.type
    var batchIds = that.data.batchIds
    if (batchIds.length == 0 && type == 0) {
      wx.showToast({
        title: '请选择需要删除的来访记录',
        duration: 2000,
        icon: 'none',
        mask: true
      })
      return;
    }
    wx.request({
      url: app.globalData.url + 'api/xitong/fw_shan_lf',
      data:{
        tel: wx.getStorageSync('tel'),
        batchIds: batchIds.toString()
      },
      method: 'post',
      success: function(res){
        console.log(res)
        if(res.data.info == 1){
          wx.showToast({
            title: '删除成功',
            duration: 2000,
            icon: 'none',
            mask: true
          })
          that.reload(that.data.type)
        }
      }
    })
  },
  reload: function(type){
    var that = this
    
    wx.request({
      url: app.globalData.url + 'api/xitong/fw_list',
      data: {
        tel: wx.getStorageSync('tel'),
        url: app.globalData.url
      },
      method: 'post',
      success: function(res) {
        console.log(res)
        that.setData({
          list: res.data.list,
          length: res.data.list.length,
          url: app.globalData.url,
          select_all: '',
          batchIds:[],
          zzt: 0,
          shan_zt: 0,
          yincang: true,
          yincang2: true
        })
      }
    })
  },
  onLoad: function(e) {
    var that = this
    var tel = wx.getStorageSync('tel')
    that.setData({
      type: e.type
    })
    if (e.type == 0) {
      wx.setNavigationBarTitle({
        title: '来访用户',
      })
      wx.request({
        url: app.globalData.url + 'api/xitong/fw_list',
        data: {
          tel: tel,
          url: app.globalData.url
        },
        method: 'post',
        success: function(res) {
          console.log(res)
          that.setData({
            list: res.data.list,
            length: res.data.list.length,
            url: app.globalData.url
          })
        }
      })
    } else {
      wx.setNavigationBarTitle({
        title: '邀请记录',
      })
      wx.request({
        url: app.globalData.url + 'api/xitong/yq_list',
        data: {
          tel: tel,
          url: app.globalData.url
        },
        method: 'post',
        success: function (res) {
          console.log(res)
          that.setData({
            list: res.data.list,
            length: res.data.list.length,
            url: app.globalData.url
          })
        }
      })
    }
  },
})