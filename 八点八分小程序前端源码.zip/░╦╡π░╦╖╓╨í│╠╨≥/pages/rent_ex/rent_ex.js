// pages/rent_ex/rent_ex.js
const app = getApp()
// import WxParse from '../../wxParse/wxParse.js';
Page({

  /**
   * 页面的初始数据
   */
  data: {
    currentSwiper: 0,
    width: wx.getSystemInfoSync().windowWidth - 20, //图片宽度  
    height: wx.getSystemInfoSync().windowWidth * 8 / 13, //图片高度
    pic12: '../../images/ico45.png',
    lianxi: 0,
    num: 2,
    page: 0,
    txtHidden: true,
    canIUseGetUserProfile: false,
  },
  txtToggle: function () {
    let that = this;
    that.setData({
      txtHidden: !that.data.txtHidden
    })
  },
  swiperChange: function (e) {
    this.setData({
      currentSwiper: e.detail.current
    })
  },
  tishi: function () {
    var that = this
    wx.showModal({
      title: '提示',
      content: '将当前求租贴上架后可使用当前功能',
      showCancel: false, //是否显示取消按钮-----》false去掉取消按钮
      confirmText: "我知道了", //默认是“确定”
      success: function (res) {
        if (res.confirm) {
          //点击确定
          console.log("您点击了确定")
        }
      }
    })
  },
  getLocation: function () {
    var that = this
    wx.getLocation({
      type: 'gcj02', //返回可以用于wx.openLocation的经纬度
      success: function (res) {
        console.log(res)
        var latitude = that.data.info.lat
        var longitude = that.data.info.lng
        console.log(parseFloat(latitude), parseFloat(longitude))
        wx.openLocation({
          latitude: parseFloat(latitude),
          longitude: parseFloat(longitude),
          name: that.data.info.xiaoqu,
          address: that.data.info.jiename,
          scale: 16
        })
      }
    })
  },
  previewImg: function (e) {
    var that = this
    console.log(e)
    console.log(e.currentTarget.dataset.index);
    var index = e.currentTarget.dataset.index;

    var imgArr = that.data.picss;
    wx.previewImage({
      current: imgArr[index], //当前图片地址
      urls: imgArr, //所有要预览的图片的地址集合 数组形式
      success: function (res) {},
      fail: function (res) {},
      complete: function (res) {},
    })
  },
  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (e) {
    var that = this
    var id = e.id
    if (wx.getUserProfile) {
      that.setData({
        canIUseGetUserProfile: true
      })
    }
    app.globalData.q_id = id
    if (e.zt) {
      var zt = e.zt
    } else {
      var zt = 0
    }
    app.globalData.q_zt = zt
    wx.setNavigationBarTitle({
      title: '求租贴',
    })
    wx.request({
      url: app.globalData.url + 'api/qiuzu/show',
      data: {
        url: app.globalData.url,
        id: id,
        lat: app.globalData.lat,
        lng: app.globalData.lng,
        num: that.data.num,
        page: that.data.page,
        tel: wx.getStorageSync('tel'),
        city_code: app.globalData.city_code
      },
      method: 'post',
      success: function (res) {
        console.log(res)
        that.getLocate(res.data.info.lng, res.data.info.lat)
        var lat = res.data.lat

        if (res.data.guanzhu == 1) {
          that.setData({
            pic12: '../../images/ico42.png'
          })
        } else if (res.data.guanzhu == 0) {
          that.setData({
            pic12: '../../images/ico45.png'
          })
        }
        if (res.data.info.status != 1) {
          wx.hideShareMenu({

          })
        }
        // var content = res.data.tishi.content;
        // WxParse.wxParse('content', 'html', content, that, 5)
        // var content1 = res.data.info.content;
        // WxParse.wxParse('content1', 'html', content1, that, 5)
        app.globalData.picarray = res.data.picss
        that.setData({
          info: res.data.info,
          html: res.data.tishi.content,
          pics: res.data.pics,
          picss: res.data.picss,
          qzyq: res.data.qzyq,
          user: res.data.user,
          url: app.globalData.url,
          longitude: res.data.info.lng,
          latitude: res.data.info.lat,
          markers: [{
            longitude: res.data.info.lng,
            latitude: res.data.info.lat,
            label: {
              bgColor: '#fff',
              anchorX: -60,
              anchorY: 10,
              padding: 5,
              borderRadius: 5,
            },
          }],
          list: res.data.list,
          pingjia: res.data.pinjia,
          zt: zt,
          tishi_logo: app.globalData.tishi_logo,
          gengxin: app.globalData.gengxin
        })
        wx.createSelectorQuery().select('#box').boundingClientRect(function (rect) {
          // console.log(rect)
          var height = rect.height
          console.log(height, 1)
          that.setData({
            height1: height
          })
        }).exec()
      }
    })

    wx.request({
      url: app.globalData.url + 'api/qiuzu/liulan',
      data: {
        tel: wx.getStorageSync('tel'),
        id: id
      },
      method: 'post',
      success: function (rag) {
        console.log(rag)
      }
    })
    if (wx.getStorageSync('tel')) {
      that.setData({
        login: 1
      })
    } else {
      that.setData({
        login: 0
      })
    }
  },
  more: function (e) {
    var that = this
    var num = that.data.num
    var page = that.data.page + 2
    var tel = wx.getStorageSync('tel')
    var list = that.data.list
    wx.request({
      url: app.globalData.url + 'api/qiuzu/show',
      data: {
        url: app.globalData.url,
        id: e.currentTarget.dataset.id,
        lat: app.globalData.lat,
        lng: app.globalData.lng,
        num: num,
        page: page,
        tel: wx.getStorageSync('tel'),
        city_code: app.globalData.city_code
      },
      method: 'post',
      success: function (res) {
        console.log(res)
        that.setData({
          loadText: "数据请求中",
          loading: true,
          list: list.concat(res.data.list),
          loadText: "加载更多",
          loading: false,
          page: page,
          num: num
        })
        if (res.data.list.length == 0) {
          wx.showToast({
            title: '没有更多数据!',
            duration: 2000,
            icon: 'none'
          })
        }
      }
    })
  },
  jubao: function (e) {
    var that = this
    var id = e.currentTarget.dataset.id
    var tel = wx.getStorageSync('tel')
    wx.request({
      url: app.globalData.url + 'api/qiuzu/jubao_check',
      data: {
        id: id,
        tel: tel
      },
      method: 'post',
      success: function (res) {
        console.log(res)
        if (res.data.count == 1) {
          wx.showToast({
            title: '不可举报自己发布的求租贴',
            duration: 2000,
            icon: 'none'
          })
        } else if (res.data.count == 0) {
          wx.navigateTo({
            url: '../report/report?id=' + id + '&zt=1',
          })
        }
      }
    })
  },

  getLocate: function (lng, lat) {
    var that = this;
    var locateCity1 = []
    var locateQu1 = []
    var locatetown = []
    var locatetownname = []
    wx.request({
      url: 'https://apis.map.qq.com/ws/geocoder/v1/?location=' + lat + ',' + lng + '&key=I4CBZ-FYL6G-X2LQD-I56ON-N6K7E-UQFK4',
      success: function (res) {
        console.log(res)
        var val1 = res.data.result.address_component.district
        var val = res.data.result.address_component.street


        that.setData({
          qu: val1,
          lu: val
        })
      },
    })

  },
  sc: function (e) {
    var that = this
    var id = e.currentTarget.dataset.id
    var tel = wx.getStorageSync('tel')
    wx.request({
      url: app.globalData.url + 'api/qiuzu/shoucang',
      data: {
        id: id,
        tel: tel
      },
      method: 'post',
      success: function (res) {
        console.log(res)
        if (res.data.info == 0) {
          wx.showToast({
            title: '收藏失败',
            duration: 2000,
            icon: 'none'
          })
        } else if (res.data.info == 1) {
          wx.showToast({
            title: '收藏成功',
            duration: 2000,
            icon: 'none'
          })
          that.setData({
            pic12: '../../images/ico42.png'
          })
        } else if (res.data.info == 2) {
          wx.showToast({
            title: '取消收藏成功',
            duration: 2000,
            icon: 'none'
          })
          that.setData({
            pic12: '../../images/ico45.png'
          })
        } else if (res.data.info == 3) {
          wx.showToast({
            title: '取消收藏失败',
            duration: 2000,
            icon: 'none'
          })
        } else if (res.data.info == 4) {
          wx.showToast({
            title: '请勿收藏自己发布的求租贴',
            duration: 2000,
            icon: 'none'
          })
        }
      }
    })
  },
  liu: function (e) {
    var that = this
    var tel = wx.getStorageSync('tel')
    var id = e.currentTarget.dataset.id
    wx.request({
      url: app.globalData.url + 'api/qiuzu/liuyan',
      data: {
        tel: tel,
        id: id
      },
      method: 'post',
      success: function (res) {
        console.log(res)
        if (res.data.info == 1) {
          wx.navigateTo({
            url: '../message/message?id=' + id,
          })
        } else if (res.data.info == 0) {
          wx.showToast({
            title: '请勿为自己的求租贴留言',
            duration: 2000,
            icon: 'none'
          })
          return;
        }
      }
    })
  },
  call: function (e) {
    var that = this
    var id = e.currentTarget.dataset.id
    var tel = wx.getStorageSync('tel')
    wx.request({
      url: app.globalData.url + 'api/about/qiu_check',
      data: {
        id: id,
        tel: wx.getStorageSync('tel')
      },
      method: 'post',
      success: function (rag) {
        console.log(rag)
        if (rag.data.qiu_status == 1) {
          wx.showToast({
            title: '请勿联系自己',
            duration: 2000,
            icon: 'none',
            mask: true
          })
          return;
        } else if (rag.data.qiu_status == 0) {
          wx.request({
            url: app.globalData.url + 'api/yanzheng/qiuzu_lianxi',
            data: {
              fid: id,
              type: 1,
              tel: tel
            },
            method: 'post',
            success: function (res1) {
              console.log(res1)
              if (res1.data.count == 1) {
                wx.request({
                  url: app.globalData.url + 'api/qiuzu/dianhua1',
                  data: {
                    tel: tel,
                    id: id
                  },
                  method: 'post',
                  success: function (res) {
                    console.log(res)
                    if (res.data.info == 0) {
                      wx.showToast({
                        title: '请勿联系自己',
                        duration: 2000,
                        icon: 'none'
                      })
                      return;
                    } else if (res.data.info == 2) {
                      wx.showModal({
                        title: '提示',
                        content: '贴主已隐藏手机号',
                        showCancel: false, //是否显示取消按钮
                        confirmText: "知道了", //默认是“确定”
                        success: function (ras) {

                        },
                      })
                    } else if (res.data.info == 1) {
                      that.setData({
                        mobile1: res.data.info1.mobile
                      })
                      wx.showModal({
                        title: '提示',
                        content: '联系我时请备注在【租小圣租房】小程序上看到的～',
                        showCancel: true, //是否显示取消按钮
                        confirmText: "确认拨打", //默认是“确定”
                        cancelText: "我再想想",
                        success: function (ras) {
                          if (ras.cancel) {
                            //点击取消,默认隐藏弹框
                          } else {
                            //点击确定
                            wx.makePhoneCall({
                              phoneNumber: that.data.mobile1,
                            })
                          }
                        },
                      })
                    }
                  }
                })
              } else if (res1.data.count == 0) {
                wx.request({
                  url: app.globalData.url + 'api/yanzheng/check_qiuzu',
                  data: {
                    id: id,
                    type: 1
                  },
                  method: 'post',
                  success: function (rag1) {
                    console.log(rag1)
                    if (rag1.data.user == 0) {
                      wx.showModal({
                        title: '提示',
                        content: '当前贴主已隐藏手机号',
                        showCancel: false, //是否显示取消按钮
                        confirmText: "知道了", //默认是“确定”
                        success: function (res) {},
                      })
                    } else {
                      if (that.data.lianxi == 0) {
                        wx.showModal({
                          title: '提示',
                          content: '获取贴主手机号需要消耗1积分',
                          cancelText: "我再想想",
                          confirmText: "确认获取",
                          success: function (res) {
                            if (res.cancel) {} else {
                              wx.request({
                                url: app.globalData.url + 'api/qiuzu/dianhua',
                                data: {
                                  tel: tel,
                                  id: id
                                },
                                method: 'post',
                                success: function (res) {
                                  console.log(res)
                                  if (res.data.info == 0) {
                                    wx.showToast({
                                      title: '请勿联系自己',
                                      duration: 2000,
                                      icon: 'none'
                                    })
                                    return;
                                  } else if (res.data.info == 1) {
                                    if (res.data.info1 == 0) {
                                      wx.showModal({
                                        title: '提示',
                                        content: '当前贴主已隐藏手机号，积分未消耗',
                                        showCancel: false, //是否显示取消按钮
                                        confirmText: "知道了", //默认是“确定”
                                        success: function (res) {},
                                      })
                                    } else {
                                      console.log(1)
                                      that.setData({
                                        lianxi: 1
                                      })
                                      wx.showModal({
                                        title: '提示',
                                        content: '联系我时请备注在【租小圣租房】小程序上看到的～',
                                        showCancel: true, //是否显示取消按钮
                                        confirmText: "确认拨打", //默认是“确定”
                                        cancelText: "我再想想",
                                        success: function (ras) {
                                          if (ras.cancel) {
                                            //点击取消,默认隐藏弹框
                                          } else {
                                            //点击确定
                                            wx.makePhoneCall({
                                              phoneNumber: res.data.info1.mobile,
                                            })
                                          }
                                        },
                                      })

                                    }
                                  } else {
                                    wx.showToast({
                                      title: '您的积分为0无法拨打发布人电话',
                                      duration: 2000,
                                      icon: 'none'
                                    })
                                    return;
                                  }
                                }
                              })
                            }
                          },
                        })
                      } else {
                        wx.request({
                          url: app.globalData.url + 'api/qiuzu/dianhua1',
                          data: {
                            tel: tel,
                            id: id
                          },
                          method: 'post',
                          success: function (res) {
                            console.log(res)
                            if (res.data.info == 0) {
                              wx.showToast({
                                title: '请勿联系自己',
                                duration: 2000,
                                icon: 'none'
                              })
                              return;
                            } else if (res.data.info == 2) {
                              wx.showToast({
                                title: '贴主已隐藏手机号',
                                duration: 2000,
                                icon: 'none'
                              })
                              return;
                            } else if (res.data.info == 1) {
                              that.setData({
                                mobile1: res.data.info1.mobile
                              })
                              wx.showModal({
                                title: '提示',
                                content: '联系我时请备注在【租小圣租房】小程序上看到的～',
                                showCancel: true, //是否显示取消按钮
                                confirmText: "确认拨打", //默认是“确定”
                                cancelText: "我再想想",
                                success: function (ras) {
                                  if (ras.cancel) {
                                    //点击取消,默认隐藏弹框
                                  } else {
                                    //点击确定
                                    wx.makePhoneCall({
                                      phoneNumber: that.data.mobile,
                                    })
                                  }
                                },
                              })
                            }
                          }
                        })
                      }
                    }
                  }
                })
              }

            }
          })
        }
      }
    })

  },
  wechat: function (e) {
    var that = this
    var tel = wx.getStorageSync('tel')
    var id = e.currentTarget.dataset.id
    wx.request({
      url: app.globalData.url + 'api/about/qiu_check',
      data: {
        id: id,
        tel: wx.getStorageSync('tel')
      },
      method: 'post',
      success: function (rag) {
        console.log(rag)
        if (rag.data.qiu_status == 1) {
          wx.showToast({
            title: '请勿联系自己',
            duration: 2000,
            icon: 'none',
            mask: true
          })
          return;
        } else if (rag.data.qiu_status == 0) {
          wx.request({
            url: app.globalData.url + 'api/yanzheng/qiuzu_lianxi',
            data: {
              fid: id,
              type: 1,
              tel: wx.getStorageSync('tel')
            },
            method: 'post',
            success: function (res1) {
              if (res1.data.count == 1) {
                wx.request({
                  url: app.globalData.url + 'api/qiuzu/weixin1',
                  data: {
                    tel: wx.getStorageSync('tel'),
                    id: id
                  },
                  method: 'post',
                  success: function (res) {
                    console.log(res)
                    if (res.data.info == 0) {
                      wx.showToast({
                        title: '请勿联系自己',
                        duration: 2000,
                        icon: 'none'
                      })
                      return;
                    } else {
                      if (!res.data.info1.wechat) {
                        wx.showToast({
                          title: '贴主未完善微信号，建议使用电话联系。',
                          duration: 2000,
                          icon: 'none',
                          mask: true
                        })
                        return;
                      }
                      that.setData({
                        wechat1: res.data.info1.wechat
                      })
                      wx.showModal({
                        title: '提示',
                        content: '联系贴主时请备注在【租小圣租房】小程序上看到的~',
                        showCancel: true, //是否显示取消按钮
                        confirmText: "复制微信", //默认是“确定”
                        cancelText: "否",
                        success: function (ras) {
                          if (ras.cancel) {
                            //点击取消,默认隐藏弹框
                          } else {
                            //点击确定
                            wx.setClipboardData({
                              data: that.data.wechat1,
                              success: function (rag) {
                                wx.getClipboardData({
                                  success: function (rags) {
                                    wx.showToast({
                                      title: '微信号已复制',
                                      icon: 'success',
                                      duration: 2000
                                    })
                                  }
                                })
                              }
                            })
                          }
                        },
                      })
                    }
                  }
                })
              } else if (res1.data.count == 0) {
                if (that.data.lianxi == 0) {
                  wx.showModal({
                    title: '提示',
                    content: '获取贴主微信号需要消耗1积分',
                    cancelText: "我再想想",
                    confirmText: "确认获取",
                    success: function (res) {
                      if (res.cancel) {
                        //点击取消,默认隐藏弹框
                      } else {
                        //点击确定
                        wx.request({
                          url: app.globalData.url + 'api/qiuzu/weixin',
                          data: {
                            tel: wx.getStorageSync('tel'),
                            id: id
                          },
                          method: 'post',
                          success: function (res) {
                            console.log(res)
                            if (res.data.info == 0) {
                              wx.showToast({
                                title: '请勿联系自己',
                                duration: 2000,
                                icon: 'none'
                              })
                              return;
                            } else if (res.data.info == 1) {
                              that.setData({
                                lianxi: 1
                              })
                              wx.showModal({
                                title: '提示',
                                content: '加我时请备注在【租小圣租房】小程序上看到的~',
                                showCancel: true, //是否显示取消按钮
                                confirmText: "复制微信", //默认是“确定”
                                cancelText: "否",
                                success: function (ras) {
                                  if (ras.cancel) {
                                    //点击取消,默认隐藏弹框
                                  } else {
                                    //点击确定
                                    wx.setClipboardData({
                                      data: res.data.info1.wechat,
                                      success: function (rag) {
                                        wx.getClipboardData({
                                          success: function (rags) {
                                            wx.showToast({
                                              title: '微信号已复制',
                                              icon: 'success',
                                              duration: 2000
                                            })
                                          }
                                        })
                                      }
                                    })
                                  }
                                },
                              })

                            } else if (res.data.info == 2) {
                              wx.showToast({
                                title: '您的积分为0无法查看发布人微信',
                                duration: 2000,
                                icon: 'none'
                              })
                              return;
                            }
                          }
                        })
                      }
                    },
                  })
                } else {
                  wx.request({
                    url: app.globalData.url + 'api/qiuzu/weixin1',
                    data: {
                      tel: wx.getStorageSync('tel'),
                      id: id
                    },
                    method: 'post',
                    success: function (res) {
                      console.log(res)
                      if (res.data.info == 0) {
                        wx.showToast({
                          title: '请勿联系自己',
                          duration: 2000,
                          icon: 'none'
                        })
                        return;
                      } else {
                        that.setData({
                          wechat1: res.data.info1.wechat
                        })
                        wx.showModal({
                          title: '提示',
                          content: '您已支付1积分可直接复制当前贴主微信号，联系贴主时请备注在【租小圣租房】小程序上看到的~',
                          showCancel: true, //是否显示取消按钮
                          confirmText: "复制微信", //默认是“确定”
                          cancelText: "否",
                          success: function (ras) {
                            if (ras.cancel) {
                              //点击取消,默认隐藏弹框
                            } else {
                              //点击确定
                              wx.setClipboardData({
                                data: that.data.wechat1,
                                success: function (rag) {
                                  wx.getClipboardData({
                                    success: function (rags) {
                                      wx.showToast({
                                        title: '微信号已复制',
                                        icon: 'success',
                                        duration: 2000
                                      })
                                    }
                                  })
                                }
                              })
                            }
                          },
                        })
                      }
                    }
                  })

                }
              }
            }
          })
        }
      }
    })

  },
  powerDrawer: function (e) {
    console.log(1)
    var currentStatu1 = e.currentTarget.dataset.statu;
    this.util(currentStatu1)
  },
  util: function (currentStatu1) {
    /* 动画部分 */
    // 第1步：创建动画实例
    var animation1 = wx.createAnimation({
      duration: 1, //动画时长
      timingFunction: "linear", //线性
      delay: 0 //0则不延迟
    });
    // 第2步：这个动画实例赋给当前的动画实例
    this.animation1 = animation1;
    // 第3步：执行第一组动画：Y轴偏移240px后(盒子高度是240px)，停
    animation1.translateX(240).step();
    // 第4步：导出动画对象赋给数据对象储存
    this.setData({
      animationData1: animation1.export()
    })
    // 第5步：设置定时器到指定时候后，执行第二组动画
    setTimeout(function () {
      // 执行第二组动画：Y轴不偏移，停
      animation1.translateX(0).step()
      // 给数据对象储存的第一组动画，更替为执行完第二组动画的动画对象
      this.setData({
        animationData1: animation1
      })
      //关闭抽屉
      if (currentStatu1 == "close") {
        this.setData({
          showModalStatus1: false
        });
      }
    }.bind(this), 1)
    // 显示抽屉
    if (currentStatu1 == "open") {
      this.setData({
        showModalStatus1: true
      });
    }
  },
  getUserProfile(e) {
    var that = this
    // 推荐使用wx.getUserProfile获取用户信息，开发者每次通过该接口获取用户个人信息均需用户确认
    // 开发者妥善保管用户快速填写的头像昵称，避免重复弹窗
    wx.getUserProfile({
      desc: '用于完善会员资料', // 声明获取用户个人信息后的用途，后续会展示在弹窗中，请谨慎填写
      success: (res) => {
        console.log(res)
        app.globalData.user_info = res.userInfo
        wx.login({
          success: res1 => {
            app.globalData.user_code = res1.code;
            wx.request({
              url: app.globalData.url + 'api/wechat/login',
              headers: {
                "Content-Type": "application/x-www-form-urlencoded"
              },
              data: {
                user_code: app.globalData.user_code,
                url: app.globalData.url,
                ip: wx.getStorageSync('ip')
              },
              method: 'POST',
              dataType: 'json',
              responseType: 'Text',
              success: function (res) {
                console.log(res)
                var openid = res.data.info.openid
                var sessionkey = res.data.info.session_key
                wx.setStorageSync('sessionkey', sessionkey)
                wx.setStorageSync('openid', openid)
                wx.reLaunch({
                  url: '../login/login',
                })
              }
            })
          }
        })

        that.setData({
          userInfo: res.userInfo,
          hasUserInfo: true
        })
      }
    })
  },
  getUserInfo(e) {
    // 不推荐使用getUserInfo获取用户信息，预计自2021年4月13日起，getUserInfo将不再弹出弹窗，并直接返回匿名的用户个人信息
    this.setData({
      userInfo: e.detail.userInfo,
      hasUserInfo: true
    })
  },
  // getUserInfo(e) {
  //   // 把用户信息设置成全局变量
  //   console.log(e)
  //   var that = this
  //   if (e.detail.errMsg === 'getUserInfo:ok') {
  //     app.globalData.user_info = e.detail.userInfo
  //     console.log(app.globalData.user_info)
  //     wx.login({
  //       success: res => {
  //         app.globalData.user_code = res.code;
  //       }
  //     })
  //     app.globalData.iv = e.detail.iv
  //     app.globalData.encryptedData = e.detail.encryptedData
  //     app.globalData.errMsg = e.detail.errMsg
  //     wx.request({
  //       url: app.globalData.url + 'api/wechat/login',
  //       headers: {
  //         "Content-Type": "application/x-www-form-urlencoded"
  //       },
  //       data: {
  //         user_code: app.globalData.user_code,
  //         url: app.globalData.url,
  //         ip: wx.getStorageSync('ip')
  //       },
  //       method: 'POST',
  //       dataType: 'json',
  //       responseType: 'Text',
  //       success: function(res) {
  //         console.log(res)
  //         var openid = res.data.info.openid
  //         var sessionkey = res.data.info.session_key
  //         wx.setStorageSync('sessionkey', sessionkey)
  //         wx.setStorageSync('openid', openid)
  //         wx.reLaunch({
  //           url: '../login/login',
  //         })
  //       }
  //     })
  //   } else if (e.detail.errMsg === 'getUserInfo:fail auth deny') {
  //     wx.showToast({
  //       title: '取消授权将无法正常使用小程序',
  //       icon: 'none',
  //       duration: 5000
  //     })
  //     that.setData({
  //       warning: false,
  //     })
  //   }
  // },

  onShow: function () {
    var that = this
    if (app.globalData.huan == 2) {
      wx.setNavigationBarTitle({
        title: '求租贴',
      })
      wx.request({
        url: app.globalData.url + 'api/qiuzu/show',
        data: {
          url: app.globalData.url,
          id: app.globalData.q_id,
          lat: app.globalData.lat,
          lng: app.globalData.lng,
          num: that.data.num,
          page: that.data.page,
          tel: wx.getStorageSync('tel'),
          city_code: app.globalData.city_code
        },
        method: 'post',
        success: function (res) {
          console.log(res)
          that.getLocate(res.data.info.lng, res.data.info.lat)
          var lat = res.data.lat

          if (res.data.guanzhu == 1) {
            that.setData({
              pic12: '../../images/ico42.png'
            })
          } else if (res.data.guanzhu == 0) {
            that.setData({
              pic12: '../../images/ico45.png'
            })
          }
          if (res.data.info.status != 1) {
            wx.hideShareMenu({

            })
          }
          // var content = res.data.tishi.content;
          // WxParse.wxParse('content', 'html', content, that, 5)
          // var content1 = res.data.info.content;
          // WxParse.wxParse('content1', 'html', content1, that, 5)
          app.globalData.picarray = res.data.picss
          that.setData({
            info: res.data.info,
            pics: res.data.pics,
            picss: res.data.picss,
            qzyq: res.data.qzyq,
            user: res.data.user,
            url: app.globalData.url,
            longitude: res.data.info.lng,
            latitude: res.data.info.lat,
            markers: [{
              longitude: res.data.info.lng,
              latitude: res.data.info.lat,
              label: {
                bgColor: '#fff',
                anchorX: -60,
                anchorY: 10,
                padding: 5,
                borderRadius: 5,
              },
            }],
            list: res.data.list,
            pingjia: res.data.pinjia,
            zt: app.globalData.q_zt,
            tishi_logo: app.globalData.tishi_logo
          })
        }
      })
      app.globalData.huan = 1
    }


    if (wx.getStorageSync('tel')) {
      that.setData({
        login: 1
      })
    } else {
      that.setData({
        login: 0
      })
    }
  },
  onShareAppMessage: function (e) {
    console.log(e)
    var that = this
    if (that.data.info.status != 1) {
      wx.showModal({
        title: '提示',
        content: '将当前求租贴上架后可使用当前功能',
        showCancel: false, //是否显示取消按钮-----》false去掉取消按钮
        confirmText: "我知道了", //默认是“确定”
        success: function (res) {
          if (res.confirm) {
            //点击确定
            console.log("您点击了确定")
          }
        }
      })
    } else {
      if (!e.target) {
        var id = that.data.info.id
      } else {
        var id = e.target.dataset.id
      }
      if (that.data.info.zt == 0) {
        var zt = '求整租'
      } else if (that.data.info.zt == 1) {
        var zt = '求合租'
      }
      return {
        title: zt + '-' + that.data.info.xiaoqu + '-' + that.data.info.hx[0] + '室' + that.data.info.hx[1] + '厅' + that.data.info.hx[2] + '卫',
        path: '/pages/rent_ex/rent_ex?id=' + id,
        imageUrl: app.globalData.url + that.data.pics[0],

      }
    }
  }
})