const app = getApp()
// import WxParse from '../../wxParse/wxParse.js';
Page({
  data: {

  },
  onLoad: function (e) {
    var that = this
    var id = e.id
    wx.setNavigationBarTitle({
      title: '评论详情',
    })
    wx.request({
      url: app.globalData.url + 'api/xiaoxi/pl_ex',
      data:{
        id: id
      },
      method: 'post',
      success: function(res){
        // var content = res.data.info.content;
        // WxParse.wxParse('content', 'html', content, that, 5)
        console.log(res)
        that.setData({
          html: res.data.info.content,
        })
      }
    })
  },
})