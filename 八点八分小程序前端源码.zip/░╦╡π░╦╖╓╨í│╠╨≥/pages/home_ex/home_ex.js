const app = getApp()
// import WxParse from '../../wxParse/wxParse.js';
Page({
  data: {
    width: wx.getSystemInfoSync().windowWidth - 30,
    height: wx.getSystemInfoSync().windowWidth * 8 / 13,
    l_num: 1,
    nav: 0,
    num: 3,
    page: 0,
    yincang1: true,
    pic: '../../images/ico45.png',
    currentTab: 0,
    currentSwiper: 0,
    txtHidden: true,
    canIUseGetUserProfile: false,
  },
  txtToggle: function () {
    let that = this;
    that.setData({
      txtHidden: !that.data.txtHidden
    })
  },
  bindchange: function (e) {
    let that = this;
    that.setData({
      currentTab: e.detail.current,
      currentSwiper: e.detail.current,
    })
  },
  lianxi: function (e) {
    var that = this
    var id = e.currentTarget.dataset.id
    var uid = e.currentTarget.dataset.uid
    wx.request({
      url: app.globalData.url + 'api/about/fabu',
      data: {
        id: id,
        tel: wx.getStorageSync('tel')
      },
      method: 'post',
      success: function (res) {
        console.log(res)
        if (res.data.fabu_status == 1) {
          wx.showToast({
            title: '请勿预约自己发布的房源',
            duration: 2000,
            icon: 'none',
            mask: true
          })
          return;
        } else if (res.data.fabu_status == 0) {
          wx.navigateTo({
            url: '../home_offer/home_offer?id=' + id,
          })
        }
      }
    })
  },
  contact: function (e) {
    var that = this
    var id = e.currentTarget.dataset.id
    wx.request({
      url: app.globalData.url + 'api/about/fabu',
      data: {
        id: id,
        tel: wx.getStorageSync('tel')
      },
      method: 'post',
      success: function (res) {
        console.log(res)
        if (res.data.fabu_status == 1) {
          wx.showToast({
            title: '请勿联系自己',
            duration: 2000,
            icon: 'none',
            mask: true
          })
          return;
        } else if (res.data.fabu_status == 0) {
          wx.navigateTo({
            url: '../message1/message1?id=' + id,
          })
        }
      }
    })
  },
  tishi: function () {
    var that = this
    wx.showModal({
      title: '提示',
      content: '将当前房源上架后可使用当前功能',
      showCancel: false, //是否显示取消按钮-----》false去掉取消按钮
      confirmText: "我知道了", //默认是“确定”
      success: function (res) {
        if (res.confirm) {
          //点击确定
          console.log("您点击了确定")
        }
      }
    })
  },
  clickTab: function (e) {
    let that = this;
    if (that.data.currentTab === e.currentTarget.dataset.current) {
      return false;
    } else {
      that.setData({
        currentTab: e.currentTarget.dataset.current
      })
    }
  },
  swiperChange: function (e) {
    this.setData({
      currentSwiper: e.detail.current
    })
  },
  liubtn1: function (e) {
    this.setData({
      yincang1: false,
      bottom: 0
    })
  },
  previewImg: function (e) {
    var index = e.currentTarget.dataset.index;
    var imgArr = app.globalData.picarray;
    wx.previewImage({
      current: imgArr[index],
      urls: imgArr,
    })
  },
  bakbtn1: function (e) {
    this.setData({
      yincang1: true,
      bottom: -100
    })
  },
  getLocation: function () {
    var that = this
    wx.getLocation({
      type: 'gcj02',
      success: function (res) {
        console.log(res)
        var latitude = that.data.latitude
        var longitude = that.data.longitude
        wx.openLocation({
          latitude: parseFloat(latitude),
          longitude: parseFloat(longitude),
          name: that.data.xiaoqu,
          address: that.data.info.jieid,
          scale: 16
        })
      }
    })
  },
  choose(e) {
    let index = e.currentTarget.dataset.index
    var bool = this.data.configure[index].checked
    this.setData({
      ['configure[' + index + '].checked']: !bool
    })
  },
  onclick: function (e) {
    this.setData({
      nav: e.currentTarget.dataset.index
    })
  },
  clickNum: function (e) {
    this.setData({
      l_num: e.target.dataset.num
    })
  },
  more: function (e) {
    var that = this
    var num = that.data.num
    var page = that.data.page + 3
    var tel = wx.getStorageSync('tel')
    var list = that.data.p_list
    console.log(num, page)
    wx.request({
      url: app.globalData.url + 'api/mokuai/show',
      data: {
        id: e.currentTarget.dataset.id,
        tel: tel,
        num: num,
        page: page,
        url: app.globalData.url,
        city_code: app.globalData.city_code,
        lat: app.globalData.lat,
        lng: app.globalData.lng
      },
      method: 'post',
      success: function (res) {
        console.log(res)
        that.setData({
          loadText: "数据请求中",
          loading: true,
          p_list: list.concat(res.data.plist),
          loadText: "加载更多",
          loading: false,
          page: page,
          num: num
        })
        if (res.data.plist.length == 0) {
          wx.showToast({
            title: '没有更多数据!',
            duration: 2000,
            icon: 'none',
            mask: true
          })
        }
      }
    })
  },
  jubao: function (e) {
    var that = this
    var id = e.currentTarget.dataset.id
    var tel = wx.getStorageSync('tel')
    wx.request({
      url: app.globalData.url + 'api/fabu/jubao_check',
      data: {
        id: id,
        tel: tel
      },
      method: 'post',
      success: function (res) {
        console.log(res)
        if (res.data.count == 1) {
          wx.showToast({
            title: '不可举报自己发布的房源',
            duration: 2000,
            icon: 'none',
            mask: true
          })
        } else if (res.data.count == 0) {
          wx.navigateTo({
            url: '../report/report?id=' + id + '&zt=0',
          })
        }
      }
    })
  },
  tiao: function (e) {
    var that = this
    var url = e.currentTarget.dataset.url
    wx.navigateTo({
      url: '../video/video?url=' + url,
    })
  },
  onLoad: function (e) {
    var that = this
    var id = e.id
    app.globalData.f_id = id
    wx.setNavigationBarTitle({
      title: '房源详情',
    })
    if (wx.getUserProfile) {
      that.setData({
        canIUseGetUserProfile: true
      })
    }
    var tel = wx.getStorageSync('tel')
    if (e.zt) {
      var zt = e.zt
    } else {
      var zt = 0
    }
    app.globalData.f_zt = zt
    wx.request({
      url: app.globalData.url + 'api/mokuai/show',
      data: {
        id: id,
        tel: tel,
        num: that.data.num,
        page: that.data.page,
        url: app.globalData.url,
        city_code: app.globalData.city_code,
        lat: app.globalData.lat,
        lng: app.globalData.lng
      },
      method: 'post',
      success: function (res) {
        console.log(res)
        if (res.data.info.status != 1) {
          wx.hideShareMenu({

          })
        }
        // var content = res.data.tishi.content;
        // WxParse.wxParse('content', 'html', content, that, 5)
        // var content1 = res.data.info.content;
        // WxParse.wxParse('content1', 'html', content1, that, 5)
        var lon = res.data.info.lon
        var lat = res.data.info.lat
        app.globalData.picarray = res.data.info.picarr1
        if (res.data.shoucang == 0) {
          that.setData({
            pic: '../../images/ico45.png'
          })
        } else if (res.data.shoucang == 1) {
          that.setData({
            pic: '../../images/ico45_1.png'
          })
        }
        var tel = wx.getStorageSync('tel')
        if (tel) {
          that.setData({
            tel: 1
          })
        } else {
          that.setData({
            tel: 0
          })
        }
        that.getLocate1(lon, lat)
        that.setData({
          html: res.data.tishi.content,
          arr: res.data.arr,
          arr1: res.data.arr1,
          arr3: res.data.arr3,
          fwts: res.data.fwts,
          info: res.data.info,
          user: res.data.user,
          url: app.globalData.url,
          picarr: res.data.info.picarr1,
          longitude: res.data.info.lon,
          latitude: res.data.info.lat,
          p_list: res.data.plist,
          pinjia: res.data.pinjia,
          pinpai: app.globalData.pinpai,
          wei: app.globalData.wei,
          bao: app.globalData.bao,
          youxuan: app.globalData.youxuan,
          pinpai1: app.globalData.pinpai1,
          wei1: app.globalData.wei1,
          bao1: app.globalData.bao1,
          youxuan1: app.globalData.youxuan1,
          tishi_logo: app.globalData.tishi_logo,
          id: id,
          zt: zt,
          fenxiang: res.data.fenxiang.picurl,
          markers: [{
            longitude: res.data.info.lon,
            latitude: res.data.info.lat,
            label: {
              bgColor: '#fff',
              anchorX: -60,
              anchorY: 10,
              padding: 5,
              borderRadius: 5,
            },
          }],
          gengxin: app.globalData.gengxin,
          length111: res.data.info.u_name.length*10+'%'
        })
        wx.createSelectorQuery().select('#box').boundingClientRect(function (rect) {
          // console.log(rect)
          var height = rect.height
          console.log(height, 1)
          that.setData({
            height1: height
          })
        }).exec()
      }
    })
    if (wx.getStorageSync('tel')) {
      that.setData({
        login: 1
      })
    } else {
      that.setData({
        login: 0
      })
    }
  },
  wechat: function (e) {
    var that = this
    var id = that.data.info.id


    wx.request({
      url: app.globalData.url + 'api/tese/weixin',
      data: {
        tel: wx.getStorageSync('tel'),
        id: id
      },
      method: 'post',
      success: function (res) {
        console.log(res)
        if (res.data.info == 0) {
          wx.showToast({
            title: '请勿联系自己',
            duration: 2000,
            icon: 'none',
            mask: true
          })
          return;
        } else if (res.data.info == 3) {
          wx.showToast({
            title: '当前房源是由平台发布，可以电话联系',
            duration: 2000,
            icon: 'none',
            mask: true
          })
          return;
        } else if (res.data.info == 1) {
          if (res.data.info1.wechat == 0) {
            console.log(1)
            wx.showModal({
              title: '提示',
              content: '当前用户已隐藏微信号，请使用其他方式联系房东',
              showCancel: false,
              confirmText: "知道了",
              success: function (res) {
                if (res.cancel) {

                } else {

                }
              },
            })
          } else {
            console.log(2)
            wx.showModal({
              title: '提示',
              content: '房东微信号：' + res.data.info1.wechat,
              showCancel: false, //是否显示取消按钮
              confirmText: "知道了", //默认是“确定”
              success: function (res) {
                if (res.cancel) {
                  //点击取消,默认隐藏弹框
                } else {
                  //点击确定
                }
              },
            })
          }
        }
      }
    })
  },
  sc: function (e) {
    var that = this
    var tel = wx.getStorageSync('tel')
    // var ip = wx.getStorageSync('ip')
    var id = e.currentTarget.dataset.id
    wx.request({
      url: app.globalData.url + 'api/tese/shoucang',
      data: {
        tel: tel,
        id: id,
        // ip: ip
      },
      method: 'post',
      success: function (res) {
        console.log(res)
        if (res.data.info == 1) {
          wx.showToast({
            title: '收藏成功',
            duration: 2000,
            icon: 'none',
            mask: true
          })
          that.setData({
            pic: '../../images/ico45_1.png'
          })
        } else if (res.data.info == 0) {
          wx.showToast({
            title: '取消收藏成功',
            duration: 2000,
            icon: 'none',
            mask: true
          })
          that.setData({
            pic: '../../images/ico45.png'
          })
        } else if (res.data.info == 2) {
          wx.showToast({
            title: '不可收藏自己发布的房源',
            duration: 2000,
            icon: 'none',
            mask: true
          })
          return;
        }
      }
    })
  },
  fenxiang: function () {
    var that = this
    that.onShareAppMessage();
  },
  getLocate(lat) {
    var that = this;
    var length = lat.length
    var locateCity = []
    var locateQu = []
    var locatetown = []
    var locatetownname = []
    for (var i = 0; i < length; i++) {
      wx.request({
        url: 'https://apis.map.qq.com/ws/geocoder/v1/?location=' + lat[i].lat + ',' + lat[i].lng + '&key=I4CBZ-FYL6G-X2LQD-I56ON-N6K7E-UQFK4',
        success: function (res) {
          console.log(res)
          var val1 = res.data.result.address_component.district
          var val = res.data.result.address_component.street_number
          var val2 = res.data.result.address_reference.town.id
          var val3 = res.data.result.address_reference.town.title
          locateCity.push(val)
          locateQu.push(val1)
          locatetown.push(val2)
          locatetownname.push(val3)
          that.setData({
            locateQu: locateQu,
            locateCity: locateCity,
            locatetown: locatetown,
            locatetownname: locatetownname
          })
        },
      })
    }
  },
  call: function (e) {
    var that = this
    var id = e.currentTarget.dataset.id
    var tel = wx.getStorageSync('tel')
    wx.request({
      url: app.globalData.url + 'api/mokuai/phone_call',
      data: {
        id: id,
        tel: tel
      },
      method: 'post',
      success: function (res) {
        console.log(res)
        if (res.data.info == 0) {
          wx.showToast({
            title: '请勿联系自己',
            duration: 2000,
            icon: 'none',
            mask: true
          })
          return;
        } else if (res.data.info == 1) {
          wx.showModal({
            title: '提示',
            content: '联系我时请说明【租小圣租房】小程序上看到的～',
            showCancel: false,
            confirmText: "我知道了",
            success: function (rag) {
              if (rag.cancel) {
                //点击取消,默认隐藏弹框
              } else {
                //点击确定
                wx.makePhoneCall({
                  phoneNumber: res.data.info1.tel,
                })
              }
            },
          })

        } else if (res.data.info == 2) {
          wx.showToast({
            title: '当前房源的房东已隐藏手机号',
            duration: 2000,
            icon: 'none',
            mask: true
          })
          return;
        }
      }
    })
  },

  getLocate1(lon, lat) {
    var that = this;
    console.log(111)
    var qu = ''
    var lu = ''
    var xiaoqu = ''
    wx.request({
      url: 'https://apis.map.qq.com/ws/geocoder/v1/?location=' + lat + ',' + lon + '&key=I4CBZ-FYL6G-X2LQD-I56ON-N6K7E-UQFK4',
      success: function (res) {
        console.log(res)
        var qu = res.data.result.address_component.district
        var lu = res.data.result.address_reference.street.title
        var xiaoqu = res.data.result.address_reference.landmark_l2.title
        var xiaoquid = res.data.result.address_reference.landmark_l2.id
        that.setData({
          qu: qu,
          lu: lu,
          xiaoqu: xiaoqu
        })
        wx.request({
          url: app.globalData.url + 'api/mokuai/update',
          data: {
            id: app.globalData.m_id,
            xq_id: xiaoquid,
            xq_name: xiaoqu
          },
          method: 'post',
          success: function (res) {
            console.log(res)
          }
        })
      },
    })

  },
  login: function (e) {
    wx.showToast({
      title: '登录后可使用此功能',
      duration: 2000,
      icon: 'none',
      mask: true
    })
  },
  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },
  powerDrawer: function (e) {
    console.log(1)
    var currentStatu1 = e.currentTarget.dataset.statu;
    this.util(currentStatu1)
  },
  util: function (currentStatu1) {
    /* 动画部分 */
    // 第1步：创建动画实例
    var animation1 = wx.createAnimation({
      duration: 1, //动画时长
      timingFunction: "linear", //线性
      delay: 0 //0则不延迟
    });
    // 第2步：这个动画实例赋给当前的动画实例
    this.animation1 = animation1;
    // 第3步：执行第一组动画：Y轴偏移240px后(盒子高度是240px)，停
    animation1.translateX(240).step();
    // 第4步：导出动画对象赋给数据对象储存
    this.setData({
      animationData1: animation1.export()
    })
    // 第5步：设置定时器到指定时候后，执行第二组动画
    setTimeout(function () {
      // 执行第二组动画：Y轴不偏移，停
      animation1.translateX(0).step()
      // 给数据对象储存的第一组动画，更替为执行完第二组动画的动画对象
      this.setData({
        animationData1: animation1
      })
      //关闭抽屉
      if (currentStatu1 == "close") {
        this.setData({
          showModalStatus1: false
        });
      }
    }.bind(this), 1)
    // 显示抽屉
    if (currentStatu1 == "open") {
      this.setData({
        showModalStatus1: true
      });
    }
  },
  getUserProfile(e) {
    var that = this
    // 推荐使用wx.getUserProfile获取用户信息，开发者每次通过该接口获取用户个人信息均需用户确认
    // 开发者妥善保管用户快速填写的头像昵称，避免重复弹窗
    wx.getUserProfile({
      desc: '用于完善会员资料', // 声明获取用户个人信息后的用途，后续会展示在弹窗中，请谨慎填写
      success: (res) => {
        console.log(res)
        app.globalData.user_info = res.userInfo
        wx.login({
          success: res1 => {
            app.globalData.user_code = res1.code;
            wx.request({
              url: app.globalData.url + 'api/wechat/login',
              headers: {
                "Content-Type": "application/x-www-form-urlencoded"
              },
              data: {
                user_code: app.globalData.user_code,
                url: app.globalData.url,
                ip: wx.getStorageSync('ip')
              },
              method: 'POST',
              dataType: 'json',
              responseType: 'Text',
              success: function (res) {
                console.log(res)
                var openid = res.data.info.openid
                var sessionkey = res.data.info.session_key
                wx.setStorageSync('sessionkey', sessionkey)
                wx.setStorageSync('openid', openid)
                wx.reLaunch({
                  url: '../login/login',
                })
              }
            })
          }
        })

        that.setData({
          userInfo: res.userInfo,
          hasUserInfo: true
        })
      }
    })
  },
  getUserInfo(e) {
    // 不推荐使用getUserInfo获取用户信息，预计自2021年4月13日起，getUserInfo将不再弹出弹窗，并直接返回匿名的用户个人信息
    this.setData({
      userInfo: e.detail.userInfo,
      hasUserInfo: true
    })
  },
  // getUserInfo(e) {
  //   // 把用户信息设置成全局变量
  //   console.log(e)
  //   var that = this
  //   if (e.detail.errMsg === 'getUserInfo:ok') {
  //     app.globalData.user_info = e.detail.userInfo
  //     // console.log(app.globalData.openid)
  //     console.log(app.globalData.user_info)
  //     wx.login({
  //       success: res => {
  //         app.globalData.user_code = res.code;
  //         // console.log(that.globalData.user_code)
  //         // 发送 res.code 到后台换取 openId, sessionKey, unionId
  //       }
  //     })
  //     app.globalData.iv = e.detail.iv
  //     app.globalData.encryptedData = e.detail.encryptedData
  //     app.globalData.errMsg = e.detail.errMsg
  //     wx.request({
  //       url: app.globalData.url + 'api/wechat/login',
  //       headers: {
  //         "Content-Type": "application/x-www-form-urlencoded"
  //       },
  //       data: {
  //         user_code: app.globalData.user_code,
  //         url: app.globalData.url,
  //         ip: wx.getStorageSync('ip')
  //       },
  //       method: 'POST',
  //       dataType: 'json',
  //       responseType: 'Text',
  //       success: function (res) {
  //         console.log(res)
  //         var openid = res.data.info.openid
  //         var sessionkey = res.data.info.session_key
  //         wx.setStorageSync('sessionkey', sessionkey)
  //         wx.setStorageSync('openid', openid)
  //         wx.reLaunch({
  //           url: '../login/login',
  //         })
  //       }
  //     })
  //     ///3.得到全局变量中的用户信息
  //     // console.log(app.globalData.user_code)
  //   } else if (e.detail.errMsg === 'getUserInfo:fail auth deny') {
  //     wx.showToast({
  //       title: '取消授权将无法正常使用小程序',
  //       icon: 'none',
  //       duration: 5000,
  //       mask: true
  //     })
  //     that.setData({
  //       warning: false,
  //     })
  //   }
  // },
  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {
    var that = this
    if (app.globalData.huan == 2) {
      if (that.data.yincang1 == false) {
        that.setData({
          yincang1: true
        })
      }
      wx.setNavigationBarTitle({
        title: '房源详情',
      })
      var tel = wx.getStorageSync('tel')
      wx.request({
        url: app.globalData.url + 'api/mokuai/show',
        data: {
          id: app.globalData.f_id,
          tel: tel,
          num: that.data.num,
          page: that.data.page,
          url: app.globalData.url,
          city_code: app.globalData.city_code,
          lat: app.globalData.lat,
          lng: app.globalData.lng
        },
        method: 'post',
        success: function (res) {
          console.log(res)
          if (res.data.info.status != 1) {
            wx.hideShareMenu({

            })
          }
          // var content = res.data.tishi.content;
          // WxParse.wxParse('content', 'html', content, that, 5)
          // var content1 = res.data.info.content;
          // WxParse.wxParse('content1', 'html', content1, that, 5)
          var lon = res.data.info.lon
          var lat = res.data.info.lat
          app.globalData.picarray = res.data.info.picarr1
          if (res.data.shoucang == 0) {
            that.setData({
              pic: '../../images/ico45.png'
            })
          } else if (res.data.shoucang == 1) {
            that.setData({
              pic: '../../images/ico45_1.png'
            })
          }
          var tel = wx.getStorageSync('tel')
          if (tel) {
            that.setData({
              tel: 1
            })
          } else {
            that.setData({
              tel: 0
            })
          }
          that.getLocate1(lon, lat)
          that.setData({
            arr: res.data.arr,
            arr1: res.data.arr1,
            arr3: res.data.arr3,
            fwts: res.data.fwts,
            info: res.data.info,
            user: res.data.user,
            url: app.globalData.url,
            picarr: res.data.info.picarr1,
            longitude: res.data.info.lon,
            latitude: res.data.info.lat,
            p_list: res.data.plist,
            pinjia: res.data.pinjia,
            pinpai: app.globalData.pinpai,
            wei: app.globalData.wei,
            bao: app.globalData.bao,
            youxuan: app.globalData.youxuan,
            pinpai1: app.globalData.pinpai1,
            wei1: app.globalData.wei1,
            bao1: app.globalData.bao1,
            youxuan1: app.globalData.youxuan1,
            tishi_logo: app.globalData.tishi_logo,
            id: app.globalData.f_id,
            zt: app.globalData.f_zt,
            fenxiang: res.data.fenxiang.picurl,
            markers: [{
              longitude: res.data.info.lon,
              latitude: res.data.info.lat,
              label: {
                bgColor: '#fff',
                anchorX: -60,
                anchorY: 10,
                padding: 5,
                borderRadius: 5,
              },
            }],
          })
        }
      })
      app.globalData.huan = 1
    }
      if (wx.getStorageSync('tel')) {
        that.setData({
          login: 1
        })
      } else {
        that.setData({
          login: 0
        })
      }
      
  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function (e) {
    console.log(e)
    var that = this
    var id = that.data.id
    if (that.data.info.type == 0) {
      var leibie = '合租'
    } else if (that.data.info.type == 1) {
      var leibie = '整租'
    }
    return {
      title: leibie + '-' + that.data.info.xiaoquname + '-' + that.data.info.shi + '室' + that.data.info.ting + '厅' + that.data.info.wei + '卫',
      path: '/pages/home_ex/home_ex?id=' + id,
      imageUrl: that.data.picarr[0],
      success: function (shareTickets) {
        console.info(shareTickets + '成功');
        // 转发成功
      },
      fail: function (res) {
        console.log(res + '失败');
        // 转发失败
      },
      complete: function (res) {
        // 不管成功失败都会执行
      }
    }
  }
})