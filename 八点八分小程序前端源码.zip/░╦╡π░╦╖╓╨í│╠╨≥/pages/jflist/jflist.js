// pages/lflist/lflist.js
const app = getApp()
Page({

  /**
   * 页面的初始数据
   */
  data: {

  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (e) {
    var that = this
    wx.setNavigationBarTitle({
      title: '积分列表',
    })
    wx.request({
      url: app.globalData.url + 'api/xitong/jflist',
      data:{
        tel: wx.getStorageSync('tel')
      },
      method: 'post',
      success: function (res) {
        console.log(res)
        that.setData({
          jf_list: res.data.jf_list
        })
      }
    })
  },
})