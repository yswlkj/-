// pages/lf_ex/lf_ex.js
const app = getApp()
// import WxParse from '../../wxParse/wxParse.js';
Page({

  /**
   * 页面的初始数据
   */
  data: {

  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (e) {
    var that = this
    var id = e.id
    wx.setNavigationBarTitle({
      title: '消息提醒',
    })
    wx.request({
      url: app.globalData.url + 'api/xitong/uhuifushow',
      data: {
        id: id,
        tel: wx.getStorageSync('tel'),
        url: app.globalData.url
      },
      method: 'post',
      success: function (res) {
        // var content = res.data.info.content;
        // WxParse.wxParse('content', 'html', content, that, 5)
        console.log(res)
        that.setData({
          info: res.data.info,
          html: res.data.info.content,
          url: app.globalData.url
        })
      }
    })
  },
})