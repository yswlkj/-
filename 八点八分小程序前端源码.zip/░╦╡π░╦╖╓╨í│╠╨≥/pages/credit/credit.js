const app = getApp()
Page({
  data: {
    type: 0
  },
  onLoad: function (e) {
    var that = this
    wx.setNavigationBarTitle({
      title: '信用认证',
    })
    var tel = wx.getStorageSync('tel')
    wx.request({
      url: app.globalData.url + 'api/xinyong/index',
      data: {
        tel: tel,
      },
      method: 'post',
      success: function (res) {
        console.log(res)
        if (res.data.u_info != null) {
          if (res.data.u_info.sfz_pic) {
            var sfz_pic = app.globalData.url + res.data.u_info.sfz_pic
          } else {
            var sfz_pic = null
          }
          if (res.data.u_info.sfz_pic2) {
            var sfz_pic2 = app.globalData.url + res.data.u_info.sfz_pic2
          } else {
            var sfz_pic2 = null
          }
          if (res.data.u_info.gp_pic) {
            var gp_pic = app.globalData.url + res.data.u_info.gp_pic
          } else {
            var gp_pic = null
          }
          if (res.data.u_info.yy_pic) {
            var yy_pic = app.globalData.url + res.data.u_info.yy_pic
          } else {
            var yy_pic = null
          }
        } else {
          var yy_pic = null
          var gp_pic = null
          var sfz_pic2 = null
          var sfz_pic = null
        }
        that.setData({
          info: res.data.u_info,
          user: res.data.user,
          count: res.data.u_count,
          url: app.globalData.url,
          sfz_pic: sfz_pic,
          sfz_pic2: sfz_pic2,
          gp_pic: gp_pic,
          yy_pic: yy_pic,
          mingpian: app.globalData.url + res.data.mingpian,
          gongzuozheng: app.globalData.url + res.data.gongzuozheng,
          hetong: app.globalData.url + res.data.hetong,
          zhanshi_rz_person: res.data.zhanshi_rz_person
        })
      }
    })
  },
  upload: function () {
    let that = this;
    wx.chooseImage({
      count: 1,
      sizeType: ['compressed'],
      sourceType: ['album', 'camera'],
      success: res => {
        wx.showToast({
          title: '正在上传...',
          icon: 'loading',
          mask: true,
          duration: 1000
        })
        app.globalData.sfz1 = res.tempFilePaths
        that.uploadimg();
        let tempFilePaths = res.tempFilePaths;
        that.setData({
          sfz_pic: app.globalData.sfz1
        })
      }
    })
  },
  uploadimg: function () {
    var that = this
    var pics = app.globalData.sfz1
    wx.uploadFile({
      url: app.globalData.url + 'api/qiuzu/img',
      filePath: pics[0],
      name: 'file',
      success: function (res) {
        app.globalData.sfz11 = res.data
        wx.request({
          url: app.globalData.url + 'api/yanzheng/check_sf_pic',
          data: {
            pic: res.data
          },
          method: 'post',
          success: function (ras) {
            console.log(ras)
            app.globalData.sfz111 = ras
            if (ras.data.code == 1) {
              wx.showToast({
                title: '身份证照片通过审核',
                duration: 2000,
                icon: 'none',
                mask: true
              })
              that.setData({
                type: 0
              })
              return;
            } else {
              wx.showToast({
                title: '身份证照片未通过审核',
                duration: 2000,
                icon: 'none',
                mask: true
              })
              that.setData({
                type: 1
              })
              return;
            }

          }
        })
      }
    })
  },
  upload1: function () {
    let that = this;
    wx.chooseImage({
      count: 1,
      sizeType: ['compressed'],
      sourceType: ['album', 'camera'],
      success: res => {
        wx.showToast({
          title: '正在上传...',
          icon: 'loading',
          mask: true,
          duration: 1000
        })
        app.globalData.sfz2 = res.tempFilePaths
        console.log(app.globalData.sfz2)
        that.uploadimg1();
        let tempFilePaths = res.tempFilePaths;
        that.setData({
          sfz_pic2: app.globalData.sfz2
        })
      }
    })
  },
  uploadimg1: function () {
    var that = this
    var pics = app.globalData.sfz2
    wx.uploadFile({
      url: app.globalData.url + 'api/qiuzu/img',
      filePath: pics[0],
      name: 'file',
      success: function (res) {
        app.globalData.sfz21 = res.data
        wx.request({
          url: app.globalData.url + 'api/yanzheng/check_sf_pic',
          data: {
            pic: res.data
          },
          method: 'post',
          success: function (ras) {
            console.log(ras)
            app.globalData.sfz211 = ras
            if (ras.data.code == 2) {
              wx.showToast({
                title: '身份证照片通过审核',
                duration: 2000,
                icon: 'none',
                mask: true
              })
              that.setData({
                type: 0
              })
              return;
            } else if (ras.data.code == -7) {
              wx.showToast({
                title: '身份证照片未通过审核',
                duration: 2000,
                icon: 'none',
                mask: true
              })
              that.setData({
                type: 1
              })
              return;
            } else if (ras.data.code == 1) {
              wx.showToast({
                title: '请上传身份证背面照片',
                duration: 2000,
                icon: 'none',
                mask: true
              })
              that.setData({
                type: 1
              })
              return;
            }
          }
        })
      }
    })
  },
  upload2: function () {
    let that = this;
    wx.chooseImage({
      count: 1,
      sizeType: ['compressed'],
      sourceType: ['album', 'camera'],
      success: res => {
        wx.showToast({
          title: '正在上传...',
          icon: 'loading',
          mask: true,
          duration: 1000
        })
        app.globalData.gp = res.tempFilePaths
        that.uploadimg2();
        let tempFilePaths = res.tempFilePaths;
        that.setData({
          gp_pic: app.globalData.gp
        })
      }
    })
  },
  uploadimg2: function () {
    var pics = app.globalData.gp
    wx.uploadFile({
      url: app.globalData.url + 'api/qiuzu/img',
      filePath: pics[0],
      name: 'file',
      success: function (res) {
        app.globalData.gp2 = res.data
      }
    })
  },
  upload3: function () {
    let that = this;
    wx.chooseImage({
      count: 1,
      sizeType: ['compressed'],
      sourceType: ['album', 'camera'],
      success: res => {
        wx.showToast({
          title: '正在上传...',
          icon: 'loading',
          mask: true,
          duration: 1000
        })
        app.globalData.yy = res.tempFilePaths
        that.uploadimg3();
        let tempFilePaths = res.tempFilePaths;
        that.setData({
          yy_pic: app.globalData.yy
        })
      }
    })
  },
  uploadimg3: function () {
    var pics = app.globalData.yy
    var that = this
    wx.uploadFile({
      url: app.globalData.url + 'api/qiuzu/img',
      filePath: pics[0],
      name: 'file',
      success: function (res) {
        app.globalData.yy2 = res.data
        wx.request({
          url: app.globalData.url + 'api/yanzheng/check_yy_pic',
          data: {
            pic: res.data
          },
          method: 'post',
          success: function (ras) {
            console.log(ras)
            app.globalData.yyzz = ras.data.out_put
            wx.setStorageSync('yyzz', ras.data.out_put)
            if (ras.data.out_put.ENTERPRISE_TAXPAYER_REGISTER_ID != '') {
              wx.showToast({
                title: '营业执照照片通过审核',
                duration: 2000,
                icon: 'none',
                mask: true
              })
              that.setData({
                type: 0
              })
              return;
            } else {
              wx.showToast({
                title: '营业执照照片未通过审核',
                duration: 2000,
                icon: 'none',
                mask: true
              })
              that.setData({
                type: 1
              })
              return;
            }

          }
        })
      }
    })
  },
  name: function (e) {
    var that = this
    that.setData({
      name: e.detail.value
    })
  },
  code: function (e) {
    var that = this
    that.setData({
      code: e.detail.value
    })
  },
  onShow: function () {
    var that = this
    that.onLoad()
  },
  submit: function (e) {
    var that = this
    that.setData({
      type: 1
    })
    var name = that.data.name
    var code = that.data.code
    var sfz_pic = app.globalData.sfz11
    var sfz_pic2 = app.globalData.sfz21
    var gp_pic = app.globalData.gp2
    var yy_pic = app.globalData.yy2
    if (that.data.zhanshi_rz_person == 'Y') {
      if (!name) {
        if (that.data.info) {
          var name = that.data.info.name
          if (app.globalData.sfz111) {
            if (name != app.globalData.sfz111.data.result.name) {
              wx.showToast({
                title: '当前姓名与身份证不一致',
                duration: 2000,
                icon: 'none',
                mask: true
              })
              that.setData({
                type: 0
              })
              return;
            }
          } else {

          }
        } else {
          if (that.data.info) {
            if (name != that.data.info.name) {
              wx.showToast({
                title: '当前姓名与身份证不一致',
                duration: 2000,
                icon: 'none',
                mask: true
              })
              that.setData({
                type: 0
              })
              return;
            }
          } else {
            wx.showToast({
              title: '请上传身份证正面照片,进行验证',
              duration: 2000,
              icon: 'none',
              mask: true
            })
            return;
          }
        }
      } else {
        var name = name
        if (app.globalData.sfz111) {
          if (name != app.globalData.sfz111.data.result.name) {
            wx.showToast({
              title: '当前姓名与身份证不一致',
              duration: 2000,
              icon: 'none',
              mask: true
            })
            that.setData({
              type: 0
            })
            return;
          }
        } else {
          if (that.data.info) {
            if (name != that.data.info.name) {
              console.log(4444)
              wx.showToast({
                title: '当前姓名与身份证不一致',
                duration: 2000,
                icon: 'none',
                mask: true
              })
              that.setData({
                type: 0
              })
              return;
            }
          } else {
            wx.showToast({
              title: '请上传身份证正面照片,进行验证',
              duration: 2000,
              icon: 'none',
              mask: true
            })
            return;
          }
        }
      }
      if (!code) {
        if (that.data.info) {
          var code = that.data.info.code
          if (app.globalData.sfz111) {
            if (code != app.globalData.sfz111.data.result.code) {
              wx.showToast({
                title: '当前身份证号与身份证不一致',
                duration: 2000,
                icon: 'none',
                mask: true
              })
              that.setData({
                type: 0
              })
              return;
            }
          } else {

          }
        } else {
          if (that.data.info) {
            if (code != that.data.info.code) {
              wx.showToast({
                title: '当前身份证号与身份证不一致',
                duration: 2000,
                icon: 'none',
                mask: true
              })
              that.setData({
                type: 0
              })
              return;
            }
          } else {
            wx.showToast({
              title: '请上传身份证正面照片,进行验证',
              duration: 2000,
              icon: 'none',
              mask: true
            })
            return;
          }
        }
      } else {
        var code = code
        if (app.globalData.sfz111) {
          if (code != app.globalData.sfz111.data.result.code) {
            wx.showToast({
              title: '当前身份证号与身份证不一致',
              duration: 2000,
              icon: 'none',
              mask: true
            })
            that.setData({
              type: 0
            })
            return;
          }
        } else {
          if (that.data.info) {
            if (code != that.data.info.code) {
              wx.showToast({
                title: '当前身份证号与身份证不一致',
                duration: 2000,
                icon: 'none',
                mask: true
              })
              that.setData({
                type: 0
              })
              return;
            }
          } else {
            wx.showToast({
              title: '请上传身份证正面照片,进行认证',
              duration: 2000,
              icon: 'none',
              mask: true
            })
            return;
          }
        }
      }
      if (!sfz_pic) {
        var sfz_pic = that.data.info.sfz_pic
      } else {
        var sfz_pic = sfz_pic
      }
      if (!sfz_pic2) {
        if (that.data.sfz_pic2) {
          var sfz_pic2 = that.data.info.sfz_pic2
        } else {
          wx.showToast({
            title: '请上传身份证背面照片',
            duration: 2000,
            icon: 'none',
            mask: true
          })
          return;
        }
      } else {
        var sfz_pic2 = sfz_pic2
      }
      if (!gp_pic) {
        if (that.data.gp_pic) {
          var gp_pic = that.data.info.gp_pic
        } else {
          wx.showToast({
            title: '请上传名片或工作证照片',
            duration: 2000,
            icon: 'none',
            mask: true
          })
          return;
        }
      } else {
        var gp_pic = gp_pic
      }
      if (!yy_pic) {
        if (that.data.info) {
          var yy_pic = that.data.info.yy_pic
        } else {
          wx.showToast({
            title: '请上传营业执照',
            duration: 2000,
            icon: 'none',
            mask: true
          })
          return;
        }
      } else {
        var yy_pic = yy_pic
      }
    } else {
      var name = that.data.info.name
      var code = that.data.info.code
      var sfz_pic = that.data.info.sfz_pic
      var sfz_pic2 = that.data.info.sfz_pic2
    }
    

    wx.request({
      url: app.globalData.url + 'api/xinyong/save',
      data: {
        tel: wx.getStorageSync('tel'),
        name: name,
        code: code,
        sfz_pic: sfz_pic,
        sfz_pic2: sfz_pic2,
        gp_pic: gp_pic,
        yy_pic: yy_pic,
      },
      method: 'post',
      success: function (res) {
        console.log(res)
        if (res.data.info == 1 || res.data.info == 0) {
          wx.showToast({
            title: '提交成功',
            duration: 2000,
            icon: 'none',
            mask: true
          })
          setTimeout(function () {
            wx.navigateBack({

            })
          }, 2000)
        }
      }
    })
  },
})