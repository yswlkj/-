const app = getApp()
Page({
  data: {

  },
  onLoad: function (e) {
    wx.setNavigationBarTitle({
      title: "修改密码",
    })
  },
  oldpass: function(e){
    var that = this
    that.setData({
      oldpass: e.detail.value
    })
  },
  newpass: function (e) {
    var that = this
    that.setData({
      newpass: e.detail.value
    })
  },
  repass: function (e) {
    var that = this
    that.setData({
      repass: e.detail.value
    })
  },
  submit: function(e){
    var that = this
    var oldpass = that.data.oldpass
    var newpass = that.data.newpass
    var repass = that.data.repass
    if (!oldpass) {
      wx.showToast({
        title: '请填写旧密码',
        duration: 2000,
        icon: 'none'
      })
      return;
    }
    if(!newpass){
      wx.showToast({
        title: '请填写新密码',
        duration: 2000,
        icon:'none'
      })
      return;
    }
    var mareg = /^[a-zA-Z0-9]{6,18}$/
    if (!mareg.test(newpass)) {
      wx.showToast({
        title: '密码由6-18位数字字母组成',
        duration: 2000,
        icon: 'none',
        mask: true
      })
      return;
    }
    if (!repass) {
      wx.showToast({
        title: '请填写确认密码',
        duration: 2000,
        icon: 'none'
      })
      return;
    }
    if(repass != newpass){
      wx.showToast({
        title: '新密码与确认密码不一致，修改失败，请重新填写',
        duration: 2000,
        icon: 'none'
      })
      return;
    }
    if (oldpass == newpass) {
      wx.showToast({
        title: '新密码与旧密码一致，修改失败，请重新填写',
        duration: 2000,
        icon: 'none'
      })
      return;
    }
    var tel = wx.getStorageSync('tel')
    wx.request({
      url: app.globalData.url + 'api/my/pass',
      data:{
        tel: tel,
        oldpass: oldpass,
        newpass: newpass
      },
      method: 'post',
      success: function(res){
        console.log(res)
        if(res.data.info == 1){
          wx.showToast({
            title: '修改成功',
            duration: 2000,
            icon: 'none'
          })
          setTimeout(function(){
            wx.reLaunch({
              url: '../my/my',
            })
          },2000)
        } else if (res.data.info == 2){
          wx.showToast({
            title: '旧密码输入错误',
            duration: 2000,
            icon: 'none'
          })
          return;
        }
      }
    })
  },
})