const app = getApp()
// // import WxParse from '../../wxParse/wxParse.js';
Page({
  data: {

  },
  onLoad: function (e) {
    var that = this
    wx.setNavigationBarTitle({
      title: app.globalData.webname,
    })
    wx.request({
      url: app.globalData.url + 'api/about/shiyong',
      success:function(res){
        console.log(res)
        // var content = res.data.info.content;
        // WxParse.wxParse('content', 'html', content, that, 5)
        that.setData({
          html: res.data.info.content,
        })
      }
    })
  },
  jifen: function (e) {
    var that = this
    that.setData({
      jifen: e.detail.value
    })
  },
  bakbtn1: function (e) {
    var that = this
    var jifen = that.data.jifen
    var tel = wx.getStorageSync('tel')
    if (!jifen) {
      wx.showToast({
        title: '请填写积分数量',
        duration: 2000,
        icon: 'none'
      })
      return;
    }
    var mxreg = /^\+?[1-9][0-9]*$/
    if (!mxreg.test(jifen)) {
      wx.showToast({
        title: '积分为非零的纯数字',
        duration: 2000,
        icon: 'none'
      })
      return;
    }
    wx.request({
      url: app.globalData.url + 'api/xitong/use_jifen',
      data: {
        jifen: jifen,
        tel: tel
      },
      method: 'post',
      success: function (res) {
        console.log(res)
        if (res.data.info == 0) {
          wx.showToast({
            title: '积分不足,无法使用',
            duration: 2000,
            icon: 'none'
          })
          return;
        } else if (res.data.info == 1) {
          wx.showToast({
            title: '使用成功',
            duration: 2000,
            icon: 'none'
          })
          setTimeout(function(){
            wx.navigateBack({

            })
          },2000)
          
        }
      }
    })

  },
})