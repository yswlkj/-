// pages/my_run/my_run.js
const app = getApp()
Page({

  /**
   * 页面的初始数据
   */
  data: {
    yincang1: true,
    type: 0,
    xianshi: 0
  },
  chooseVideo: function(e) {
    var that = this
    console.log('choosevideo')
    var id = e.currentTarget.dataset.id
    if (that.data.t_weituo == 1 || that.data.t_weituo == 2 || that.data.t_weituo == 4) {
      if(that.data.info.weituo == 2){
        wx.showModal({
          title: '提示',

          content: '当前房源委托中，暂无支持此功能。',

          showCancel: false, //是否显示取消按钮-----》false去掉取消按钮

          confirmText: "我知道了", //默认是“确定”


          success: function (res) {

            if (res.cancel) {

              //点击取消

              console.log("您点击了取消")

            } else if (res.confirm) {

              //点击确定

              console.log("您点击了确定")

            }

          }
        })
      }else {
      wx.showModal({
        title: '提示',

        content: '当前房源委托中，暂无支持此功能。',

        showCancel: false, //是否显示取消按钮-----》false去掉取消按钮

        confirmText: "我知道了", //默认是“确定”


        success: function (res) {

          if (res.cancel) {

            //点击取消

            console.log("您点击了取消")

          } else if (res.confirm) {

            //点击确定

            console.log("您点击了确定")

          }

        }
      })
      }
    } else {
      if(that.data.info.status == 0){
        that.shangjia()
      }else{
      wx.chooseVideo({
        sourceType: ['album', 'camera'],
        maxDuration: 15,
        camera: 'back',
        success: function(res) {
          that.setData({
            video: res.tempFilePath,
          })
          that.uploadvideo(res.tempFilePath, id)
        }
      })
      }
    }
  },
  shangjia: function(e) {
    var that = this
    wx.showModal({
      title: '提示',
      content: '将当前房源上架后可使用当前功能',
      showCancel: false, //是否显示取消按钮-----》false去掉取消按钮
      confirmText: "我知道了", //默认是“确定”
      success: function(res) {
        if (res.confirm) {
          //点击确定
          console.log("您点击了确定")
        }
      }
    })
  },
  close: function(e) {
    var that = this
    that.setData({
      xianshi: 2
    })
  },
  uploadvideo: function(video, id) {
    var that = this
    wx.uploadFile({
      url: app.globalData.url + 'api/fabu/video',
      filePath: video,
      name: 'file',
      success: function(res) {
        console.log(res)
        wx.request({
          url: app.globalData.url + 'api/fabu/save_video',
          data: {
            video: res.data,
            id: id
          },
          method: 'post',
          success: function(rag) {
            console.log(rag)
            if (rag.data.info == 1) {
              wx.showToast({
                title: '上传成功，等待后台审核',
                duration: 2000,
                icon: 'none',
                mask: true
              })
              that.onLoad(that.data.id)
            }
          }
        })
      }
    })

  },
  weituo: function() {
    var that = this
    wx.showModal({
      title: '提示',
      content: '是否确认委托给平台',
      cancelText: "否", //默认是“取消”
      confirmText: "是", //默认是“确定”
      success: function(res) {
        if (res.cancel) {
          //点击取消,默认隐藏弹框
        } else {
          wx.request({
            url: app.globalData.url + 'api/fabu/save_weituo',
            data: {
              id: that.data.id,
            },
            method: 'post',
            success: function(res) {
              console.log(res)
              if (res.data.info == 1) {
                wx.showToast({
                  title: '修改成功',
                  duration: 2000,
                  icon: 'none'
                })
                setTimeout(function() {
                  that.onLoad(that.data.id)
                }, 2000)

              }
            }
          })
        }
      },
    })
  },
  quxiao: function() {
    var that = this
    wx.showModal({
      title: '提示',
      content: '是否申请取消委托',
      cancelText: "否", //默认是“取消”
      confirmText: "是", //默认是“确定”
      success: function(res) {
        if (res.cancel) {
          //点击取消,默认隐藏弹框
        } else {

          wx.request({
            url: app.globalData.url + 'api/fabu/quxiao_weituo',
            data: {
              id: that.data.id,
            },
            method: 'post',
            success: function(res) {
              console.log(res)
              if (res.data.info == 1) {
                wx.showToast({
                  title: '修改成功',
                  duration: 2000,
                  icon: 'none'
                })
              }
              setTimeout(function() {
                that.onLoad(that.data.id)
              }, 2000)
            }
          })
        }
      },
    })
  },
  checkboxChange_wz1: function(e) {
    var that = this
    console.log('checkboxChange_wz1发生change事件，携带value值为：', e.detail.value[0])
    that.setData({
      xieyi: e.detail.value[0]
    })
  },
  bakbtn1: function(e) {
    this.setData({
      yincang1: true,
      bottom: -100
    })
  },
  warnModalTrue(e) {
    var that = this;
    var id = e.currentTarget.dataset.id
    that.setData({
      type: 1
    })
    wx.showModal({
      title: '是否删除',
      confirmText: '是',
      cancelText: '否',
      success: function(res) {
        if (res.confirm) {
          wx.request({
            url: app.globalData.url + 'api/my/fabu_shan',
            data: {
              id: id,
              tel: wx.getStorageSync('tel')
            },
            method: 'post',
            success: function(res) {
              console.log(res)
              if (res.data.info == 1) {
                wx.showToast({
                  title: '删除成功',
                  duration: 2000,
                  icon: 'none'
                })
                setTimeout(function() {
                  wx.navigateBack({

                  })
                }, 2000)
              }
            }
          })
        } else if (res.cancel) {
          that.setData({
            type: 0
          })
        }
      }
    })
  },
  warnModalTrue1(e) {
    var that = this;
    var id = e.currentTarget.dataset.id
    that.setData({
      type: 1
    })
    // if()
    wx.showModal({
      title: '是否下架',
      confirmText: '是',
      cancelText: '否',
      success: function(res) {
        if (res.confirm) {
          console.log(1)
          wx.request({
            url: app.globalData.url + 'api/my/fabu_xia',
            data: {
              id: id,
              tel: wx.getStorageSync('tel')
            },
            method: 'post',
            success: function(res) {
              console.log(res)
              if (res.data.info == 1) {
                wx.showToast({
                  title: '下架成功',
                  duration: 2000,
                  icon: 'none'
                })
                that.setData({
                  type: 0
                })
                setTimeout(function() {
                  that.onLoad(id)
                }, 2000)
              }
            }
          })
        } else if (res.cancel) {
          console.log(2)
          that.setData({
            type: 0
          })
        }
      }
    })
  },
  warnModalTrue3(e) {
    var that = this;
    var id = e.currentTarget.dataset.id
    that.setData({
      type: 1
    })
    wx.showModal({
      title: '是否上架',
      confirmText: '是',
      cancelText: '否',
      success: function(res) {
        if (res.confirm) {
          console.log(1)
          wx.request({
            url: app.globalData.url + 'api/my/fabu_shang',
            data: {
              id: id
            },
            method: 'post',
            success: function(res) {
              console.log(res)
              if (res.data.info == 1) {
                wx.showToast({
                  title: '上架成功',
                  duration: 2000,
                  icon: 'none'
                })
                that.setData({
                  type: 0
                })
                setTimeout(function() {
                  that.reLoad(id)
                }, 2000)
              } else if (res.data.info == 2) {
                wx.showModal({
                  title: '提示',
                  content: '由于当前房源被举报下架，如需上架，请修改房源信息',
                  showCancel: false, //是否显示取消按钮-----》false去掉取消按钮
                  confirmText: "我知道了", //默认是“确定”
                  success: function(res) {
                    if (res.confirm) {
                      //点击确定
                      console.log("您点击了确定")
                    }
                  }
                })
              } else if (res.data.info == 3) {
                wx.showModal({
                  title: '提示',
                  content: '由于当前房源原所属门店已被删除，请重新创建门店并绑定',
                  showCancel: false, //是否显示取消按钮-----》false去掉取消按钮
                  confirmText: "我知道了", //默认是“确定”
                  success: function(res) {
                    if (res.confirm) {
                      //点击确定
                      console.log("您点击了确定")
                    }
                  }
                })
              }else if(res.data.info == 4){
                wx.showToast({
                  title: '上架失败，发布次数不足',
                  duration: 2000,
                  icon: 'none'
                })
              }else if(res.data.info == 5){
                wx.showToast({
                  title: '上架失败，房东身份审核中',
                  duration: 2000,
                  icon: 'none'
                })
              }
            }
          })
        } else if (res.cancel) {
          console.log(2)
          that.setData({
            type: 0
          })
        }
      }
    })
  },
  reLoad: function(id) {
    var that = this
    wx.setNavigationBarTitle({
      title: '房源编辑',
    })
    var tel = wx.getStorageSync('tel')
    wx.request({
      url: app.globalData.url + 'api/my/fabu_show',
      data: {
        id: id,
        tel: tel
      },
      method: 'post',
      success: function(res) {
        console.log(res)
        that.setData({
          info: res.data.info,
          url: app.globalData.url,
          id: id
        })
      }
    })
  },
  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function(e) {
    var that = this
    if (!e.id) {
      var id = e
    } else {
      var id = e.id
    }
    wx.setNavigationBarTitle({
      title: '房源编辑',
    })
    that.setData({
      id: id
    })
    var pages = getCurrentPages();
    console.log(pages)
    var tel = wx.getStorageSync('tel')
    wx.request({
      url: app.globalData.url + 'api/my/fabu_show',
      data: {
        id: id,
        tel: tel
      },
      method: 'post',
      success: function(res) {
        console.log(res)
        if (res.data.info.status != 1) {
          wx.hideShareMenu({

          })
        }
        console.log(res.data.info.weituo1)
        that.setData({
          info: res.data.info,
          t_weituo: res.data.info.weituo1,
          url: app.globalData.url,
          id: id,
          paishe: res.data.paishe,
          fenxiang: res.data.fenxiang.picurl,
          guize: res.data.guize,
          pinpai: app.globalData.pinpai,
          wei: app.globalData.wei,
          bao: app.globalData.bao,
          youxuan: app.globalData.youxuan,
          pinpai1: app.globalData.pinpai1,
          wei1: app.globalData.wei1,
          bao1: app.globalData.bao1,
          youxuan1: app.globalData.youxuan1,
          xieyi: res.data.xieyi,
          fangyuanfabutishi: res.data.fangyuanfabutishi,
          xianshicailiao: res.data.xianshicailiao,
          cailiaoshangchuantitle: res.data.cailiaoshangchuantitle,
          cailiaoshangchuanintro: res.data.cailiaoshangchuanintro,
          cailiaoshangchuanpic: res.data.cailiaoshangchuanpic,
          cailiao: res.data.cailiao,
          gengxin: app.globalData.gengxin
        })
      }
    })
  },
  shangchuan: function(e){
    var that = this
    var id = e.currentTarget.dataset.id
    wx.navigateTo({
      url: '../attestation_stuff/attestation_stuff?id='+id,
    })
  },
  danbao: function(e) {
    var that = this
    var id = e.currentTarget.dataset.id
    wx.navigateTo({
      url: '../bond/bond?id=' + id,
    })
  },
  zhifu1: function(e) {
    var that = this
    that.setData({
      xianshi: 1
    })
  },

  zhifu: function(e) {
    var that = this
    var id = e.currentTarget.dataset.id
    var xieyi = that.data.xieyi
    if (xieyi == 1) {
      wx.request({
        url: app.globalData.url + 'api/fabu/check_baozheng',
        data: {
          id: id
        },
        method: 'post',
        success: function(ui) {
          console.log(ui)
          if (ui.data.info == 1) {
            wx.showToast({
              title: '该房源已经支付过保证金',
              duration: 2000,
              icon: 'none'
            })
          } else if (ui.data.info == 0) {
            wx.request({
              url: app.globalData.url + 'api/fabu/baozheng',
              success: function(res) {
                console.log(res)
                wx.request({
                  url: app.globalData.url + 'api/zhifu/payOrder',
                  data: {
                    openid: wx.getStorageSync('openid'),
                    total_fee: res.data.money
                  },
                  method: 'post',
                  success: function(rag) {
                    console.log(rag)
                    wx.requestPayment({
                      'timeStamp': rag.data.timeStamp,
                      'nonceStr': rag.data.nonceStr,
                      'package': rag.data.package,
                      'signType': rag.data.signType,
                      'paySign': rag.data.paySign,
                      'success': function(ras) {
                        wx.request({
                          url: app.globalData.url + 'api/fabu/save_baozheng',
                          data: {
                            id: id,
                            bz_status: 1,
                            tel: wx.getStorageSync('tel')
                          },
                          method: 'post',
                          success: function(rad) {
                            console.log(rad)
                            if (rad.data.info == 1) {
                              wx.showToast({
                                title: '恭喜担保成功',
                                duration: 2000,
                                icon: 'none'
                              })
                              that.setData({
                                xianshi: 0
                              })
                              that.onLoad(that.data.id)
                            }
                          }
                        })
                      },
                      'fail': function(ras) {

                      }
                    })
                  }
                })
              }
            })
          }
        }
      })
    } else {
      wx.showToast({
        title: '请阅读并同意房源推广服务协议',
        duration: 2000,
        icon: 'none'
      })
    }
  },
  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function() {

  },
  tishi: function(e) {
    var that = this
    var type = e.currentTarget.dataset.type
    console.log('tishi')
    if (type == 1) {
      wx.showModal({
        title: '提示',

        content: '当前房源已委托给平台，如需修改请先取消委托或联系客服。',

        showCancel: false, //是否显示取消按钮-----》false去掉取消按钮

        confirmText: "我知道了", //默认是“确定”


        success: function(res) {

          if (res.cancel) {

            //点击取消

            console.log("您点击了取消")

          } else if (res.confirm) {

            //点击确定

            console.log("您点击了确定")

          }

        }
      })
    } else if (type == 2) {
      wx.showModal({
        title: '提示',

        content: '当前房源已委托给平台，如需重新上传视频请先取消委托或联系客服。',

        showCancel: false, //是否显示取消按钮-----》false去掉取消按钮

        confirmText: "我知道了", //默认是“确定”


        success: function(res) {

          if (res.cancel) {

            //点击取消

            console.log("您点击了取消")

          } else if (res.confirm) {

            //点击确定

            console.log("您点击了确定")

          }

        }
      })
    } else if (type == 3) {
      wx.showModal({
        title: '提示',

        content: '当前房源已申请委托给平台，如需上传视频请先取消委托申请或联系客服。',

        showCancel: false, //是否显示取消按钮-----》false去掉取消按钮

        confirmText: "我知道了", //默认是“确定”


        success: function (res) {

          if (res.cancel) {

            //点击取消

            console.log("您点击了取消")

          } else if (res.confirm) {

            //点击确定

            console.log("您点击了确定")

          }

        }
      })
    }
  },
  tishi_xia: function() {
    var that = this
    wx.showModal({
      title: '提示',

      content: '当前房源已委托给平台，如需下架请先取消委托或联系客服。',

      showCancel: false, //是否显示取消按钮-----》false去掉取消按钮

      confirmText: "我知道了", //默认是“确定”


      success: function(res) {

        if (res.cancel) {

          //点击取消

          console.log("您点击了取消")

        } else if (res.confirm) {

          //点击确定

          console.log("您点击了确定")

        }

      }
    })
  },
  tishi_shang: function() {
    var that = this
    wx.showModal({
      title: '提示',

      content: '当前房源已委托给平台，如需上架请先取消委托或联系客服。',

      showCancel: false, //是否显示取消按钮-----》false去掉取消按钮

      confirmText: "我知道了", //默认是“确定”


      success: function(res) {

        if (res.cancel) {

          //点击取消

          console.log("您点击了取消")

        } else if (res.confirm) {

          //点击确定

          console.log("您点击了确定")

        }

      }
    })
  },
  tishi_shan: function() {
    var that = this
    wx.showModal({
      title: '提示',

      content: '当前房源已委托给平台，如需删除请先取消委托或联系客服。',

      showCancel: false, //是否显示取消按钮-----》false去掉取消按钮

      confirmText: "我知道了", //默认是“确定”


      success: function(res) {

        if (res.cancel) {

          //点击取消

          console.log("您点击了取消")

        } else if (res.confirm) {

          //点击确定

          console.log("您点击了确定")

        }

      }
    })
  },
  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function() {
    var that = this
    var id = that.data.id
    wx.setNavigationBarTitle({
      title: '房源编辑',
    })
    var tel = wx.getStorageSync('tel')
    wx.request({
      url: app.globalData.url + 'api/my/fabu_show',
      data: {
        id: id,
        tel: tel
      },
      method: 'post',
      success: function(res) {
        console.log(res)

        that.setData({
          info: res.data.info,
          t_weituo: res.data.info.weituo1,
          cailiao: res.data.cailiao,
          url: app.globalData.url,
          id: id
        })
      }
    })
  },
  onShareAppMessage: function(e) {
    console.log(e)
    var that = this
    var id = that.data.id
    if (that.data.info.type == 0) {
      var title = '合租-' + that.data.info.xiaoquname + '-' + that.data.info.shi + '室' + that.data.info.ting + '厅' + that.data.info.wei + '卫 ' + that.data.info.price + '元'
    } else if (that.data.info.type == 1) {
      var title = '整租-' + that.data.info.xiaoquname + '-' + that.data.info.shi + '室' + that.data.info.ting + '厅' + that.data.info.wei + '卫 ' + that.data.info.price + '元'
    }
    return {
      title: title,
      path: '/pages/home_ex/home_ex?id=' + id,
      imageUrl: that.data.info.picurl,
      success: function(shareTickets) {
        console.info(shareTickets + '成功');
        // 转发成功
      },
      fail: function(res) {
        console.log(res + '失败');
        // 转发失败
      },
      complete: function(res) {
        // 不管成功失败都会执行
      }
    }
  },
  // onUnload: function() {
  //   wx.navigateTo({
  //     url: '../my_release/my_release?dedao=0'
  //   })
  // },
})