const app = getApp()
// // import WxParse from '../../wxParse/wxParse.js';
Page({
  data: {
    width: wx.getSystemInfoSync().windowWidth - 30,//图片宽度  
    height: wx.getSystemInfoSync().windowWidth * 8 / 12.5,//图片高度
    yincang: true,
  },
  renzheng2: function (e) {

    this.setData({
      yincang: false,
    })
  },
  renzhengclose: function (e) {
    this.setData({
      yincang: true,
    })
  },
  onLoad: function (e) {
    var that = this
    var id = e.id
    wx.setNavigationBarTitle({
      title: '公寓介绍',
    })
    wx.request({
      url: app.globalData.url + 'api/gongyu/show',
      data: {
        id: id,
        url: app.globalData.url
      },
      method: 'post',
      success: function (res) {
        // var content = res.data.md_info.content;
        // WxParse.wxParse('content', 'html', content, that, 5)
        console.log(res)
        var lat = res.data.lat
        var md_info = res.data.md_info
        that.getLocate1(md_info.lat, md_info.lng)
        that.setData({
          url: app.globalData.url,
          html: res.data.md_info.content,
          rz_list: res.data.rz_list,
          md_info: res.data.md_info,
          content1: res.data.content,
          pinpai: app.globalData.pinpai,
          wei: app.globalData.wei,
          bao: app.globalData.bao,
          youxuan: app.globalData.youxuan,
          pinpai1: app.globalData.pinpai1,
          wei1: app.globalData.wei1,
          bao1: app.globalData.bao1,
          youxuan1: app.globalData.youxuan1,
          gengxin: app.globalData.gengxin
        })
      }
    })
  },
  getLocate1(lat, lng) {
    var that = this;
    var locatetown1 = ''
    var locatetownname1 = ''
    wx.request({
      url: 'https://apis.map.qq.com/ws/geocoder/v1/?location=' + lat + ',' + lng + '&key=I4CBZ-FYL6G-X2LQD-I56ON-N6K7E-UQFK4',
      success: function (res) {
        console.log(res)
        var val1 = res.data.result.address_component.district
        var val3 = res.data.result.address_reference.town.title
        that.setData({
          locatetown1: val1,
          locatetownname1: val3
        })
      },
    })
  },
})