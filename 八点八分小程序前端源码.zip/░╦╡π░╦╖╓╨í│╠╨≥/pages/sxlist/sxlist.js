const app = getApp()
Page({
  data: {

  },
  onLoad: function (e) {
    var that = this
    wx.setNavigationBarTitle({
      title: app.globalData.webname,
    })
    wx.request({
      url: app.globalData.url + 'api/fabu/sxlist',
      success: function (res) {
        console.log(res)
        that.setData({
          list: res.data.list
        })
      }
    })
  },
})