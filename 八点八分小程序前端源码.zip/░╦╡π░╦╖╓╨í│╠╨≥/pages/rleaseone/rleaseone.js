const app = getApp()
Page({

  /**
   * 页面的初始数据
   */
  data: {
    second: 60,
    index: 0,
    type1: 0,
    yincang: true,
    yincang1: true,
    hidden: false,
    countryIndex: 0,
    countryIndex1: 0,
    countryIndex2: 0,
    countryIndex3: 0,
    countryIndex4: 0,
    countryList14: ['男女不限', '限女生', '限男生'],
    ttype: 0,
    disabled: '',
    sub_type: 0,
    multiArray: [
      [1, 2, 3, 4, 5, 6, 7, 8, 9], '室', [0, 1, 2, 3, 4, 5, 6, 7, 8, 9], '厅', [0, 1, 2, 3, 4, 5, 6, 7, 8, 9], '卫'
    ],
    multiIndex2: [0, 0, 0, 0, 1, 0],
    multiIndex3: [2, 0, 0, 0, 0],
    shi: '室',
    ting: '厅',
    wei: '卫',
    multiArray1: [
      [-2, -1, 1, 2, 3, 4, 5, 6, 7, 8, 9], '层', '共', [1, 2, 3, 4, 5, 6, 7, 8, 9], '层'
    ],
    gong: '共',
    ceng: '层',
    baohan: [],
    code_xs: 0,
    fm: 0,
    arr: []
  },
  changeMultiPicker(e) {
    console.log(e)
    var that = this
    that.setData({
      multiIndex: e.detail.value,
      multiIndex2: e.detail.value,
    })
    var multiIndex = that.data.multiIndex

    console.log(multiIndex)
    app.globalData.huxing = multiIndex.toString()
    console.log(app.globalData.huxing)
  },
  changeMultiPicker1(e) {
    console.log(e)
    var that = this
    var multiIndex1 = e.detail.value
    var multiArray1 = that.data.multiArray1
    console.log('楼层-------')
    console.log(multiArray1[0][multiIndex1[0]])
    console.log('总楼层-------')
    console.log(multiArray1[3][multiIndex1[3]])

    if (multiArray1[0][multiIndex1[0]] > multiArray1[3][multiIndex1[3]]) {
      var multiIndex1 = [multiIndex1[0], 0, 0, multiIndex1[0] - 2, 0]
    }
    that.setData({
      multiIndex1: multiIndex1,
      multiIndex3: multiIndex1
    })
    var multiIndex1 = that.data.multiIndex1
    console.log(multiIndex1)
    app.globalData.louceng = multiIndex1.toString()
    console.log(app.globalData.louceng)
  },
  bindMultiPickerColumnChange1: function(e) {
    var that = this
    console.log('修改的列为', e.detail.column, '，值为', e.detail.value);
    var multiIndex1 = that.data.multiIndex3
    var multiArray1 = that.data.multiArray1

    if (e.detail.column == 0) {
      if (multiArray1[0][e.detail.value] > multiArray1[3][multiIndex1[3]]) {
        // console.log(1)
        var cha = multiArray1[0][e.detail.value] - multiArray1[3][multiIndex1[3]]
        var id = multiIndex1[3] + cha;
        var multiIndex1 = [e.detail.value, 0, 0, id, 0]
        // console.log(multiIndex1)
        that.setData({
          multiIndex3: multiIndex1
        })
      }
    } else if (e.detail.column == 3) {
      console.log(multiArray1[3][e.detail.value], multiArray1[0][multiIndex1[0]])
      if (multiArray1[3][e.detail.value] < multiArray1[0][multiIndex1[0]]) {
        var cha = multiArray1[0][multiIndex1[0]] - multiArray1[3][e.detail.value]
        // console.log(cha)
        var id = multiIndex1[0] - cha;
        var multiIndex1 = [id, 0, 0, e.detail.value, 0]
        that.setData({
          multiIndex3: multiIndex1
        })
      }
    }
  },
  huxing: function(e) {
    var that = this
    that.setData({
      shi_index: e.detail.value
    });
  },
  fabu: function(e) {

    this.setData({
      yincang: false,
    })
  },
  fabu1: function(e) {

    this.setData({
      yincang1: false,
    })
  },
  fabu_close: function(e) {
    this.setData({
      yincang: true,
    })
  },
  fabu_close1: function(e) {
    this.setData({
      yincang1: true,
    })
  },
  area: function(e) {
    var that = this
    wx.navigateTo({
      url: '../map/map',
    })
  },
  changeCountry12(e) {
    this.setData({
      countryIndex12: e.detail.value
    });
  },
  upload: function() {
    var that = this;
    wx.chooseImage({
      count: 9 - app.globalData.fabu.length,
      sizeType: ['compressed'],
      sourceType: ['album', 'camera'],
      success: res => {
        wx.showToast({
          title: '正在上传...',
          icon: 'loading',
          mask: true,
          duration: 1000
        })
        if (app.globalData.fabu.length < 9) {
          app.globalData.fabu = app.globalData.fabu.concat(res.tempFilePaths)
        } else {
          app.globalData.fabu = app.globalData.fabu
          console.log('超过9张')
          wx.showToast({
            title: '房源图片最多9张',
            duration: 2000,
            icon: 'none'
          })
          that.setData({
            type1: 2
          })
        }
        console.log(app.globalData.fabu)
        let tempFilePaths = res.tempFilePaths;
        that.setData({
          tempFilePaths: app.globalData.fabu
        })


        if (app.globalData.fabu.length > 9) {
          console.log('超过9张')
          wx.showToast({
            title: '房源图片最多9张',
            duration: 2000,
            icon: 'none'
          })
          that.setData({
            type1: 2
          })
        }
      }

    })
  },
  aaa: function(e) {
    var that = this
    var imgs = app.globalData.fabu;
    var index = e.currentTarget.dataset.index;
    imgs.splice(index, 1);
    app.globalData.fabu = imgs
    that.setData({
      tempFilePaths: imgs,
    });
    if (app.globalData.fabu.length > 9) {
      wx.showToast({
        title: '房源图片最多上传9张',
        duration: 2000,
        icon: 'none'
      })
      that.setData({
        type1: 2
      })
    } else if (app.globalData.fabu.length <= 9) {
      that.setData({
        type1: 0
      })
    }
  },
  tap: function(e) {
    var that = this
    console.log(e)
    var picarr = app.globalData.fabu
    var index = e.currentTarget.dataset.index
    wx.previewImage({
      current: that.data.tempFilePaths[index],
      urls: that.data.tempFilePaths,
      success: function(res) {},
      fail: function() {}
    })
  },
  long: function(e) {
    var that = this
    console.log(e)
    var picarr = app.globalData.fabu
    var index = e.currentTarget.dataset.index
    wx.showModal({
      title: '提示',
      content: '是否设置当前选中图片为封面',
      showCancel: true,
      cancelText: "我再想想",
      confirmText: "确定设置",
      success: function(res) {
        if (res.cancel) {} else {
          var fengmian = picarr[index]
          that.setData({
            fm: index
          })
          if (app.globalData.fengmian == 0) {
            app.globalData.fengmian = index
          } else {
            app.globalData.fengmian = index
          }
        }
      },
    })
  },
  chooseVideo: function() {
    var that = this
    wx.chooseVideo({
      sourceType: ['album', 'camera'],
      maxDuration: 15,
      camera: 'back',
      success: function(res) {
        app.globalData.shipin = app.globalData.shipin.concat(res.tempFilePath)
        that.setData({
          video: res.tempFilePath,
        })
      }
    })
  },
  shan_vi: function() {
    var that = this
    app.globalData.shipin = []
    that.setData({
      video: null,

    })
  },
  uploadvideo: function(video) {
    wx.uploadFile({
      url: app.globalData.url + 'api/fabu/video',
      filePath: video,
      name: 'file',
      success: function(res) {}
    })
  },
  changeCountry(e) {
    this.setData({
      countryIndex: e.detail.value
    });
  },
  changeCountry1(e) {
    this.setData({
      countryIndex1: e.detail.value
    });
  },
  changeCountry2(e) {
    this.setData({
      countryIndex2: e.detail.value
    });
  },
  changeCountry3(e) {
    this.setData({
      countryIndex3: e.detail.value
    });
  },
  changeCountry4(e) {
    this.setData({
      countryIndex4: e.detail.value
    });
  },
  changeCountry9(e) {
    this.setData({
      countryIndex9: e.detail.value
    });
  },
  changeCountry10(e) {
    this.setData({
      countryIndex10: e.detail.value
    });
  },
  changeCountry11(e) {
    this.setData({
      countryIndex11: e.detail.value
    });
  },
  changeCountry12(e) {
    var that = this
    var countryList12 = that.data.countryList12
    if (countryList12[0] == '') {
      wx.showToast({
        title: '请先选择总楼层',
        duration: 2000,
        icon: 'none'
      })
      return;
    }
    that.setData({
      countryIndex12: e.detail.value
    });
  },
  changeCountry13(e) {
    var that = this
    var countryList13 = that.data.countryList13
    that.setData({
      countryIndex13: e.detail.value
    });
    var arr = [];
    for (var oo = 1; oo <= countryList13[e.detail.value]; oo++) {
      var arr = arr.concat(oo)
    }
    arr.reverse();
    var countryList12 = arr
    that.setData({
      countryList12: countryList12
    })
  },
  changeCountry14(e) {
    this.setData({
      countryIndex14: e.detail.value
    });
  },
  onLoad: function(e) {
    var that = this
    wx.setNavigationBarTitle({
      title: '房源发布',
    })
    app.globalData.fabu = []
    app.globalData.shipin = []
    app.globalData.shipin1 = ''
    var type_id = e.type_id
    var type = e.type
    var tel = wx.getStorageSync('tel')
    that.setData({
      tel: tel,
      type: type,
      type_id: type_id
    })
    app.globalData.zt = e.zt
    app.globalData.ss_xq_name = undefined
    app.globalData.ss_xq_addr = undefined
    var ss_xq_name = app.globalData.ss_xq_name
    if (ss_xq_name !== undefined) {
      var ss_xq_name1 = app.globalData.ss_xq_name
    }
    var ss_xq_address = app.globalData.ss_xq_addr
    if (ss_xq_address !== undefined) {
      var ss_xq_address1 = app.globalData.ss_xq_addr
    }
    
    wx.request({
      url: app.globalData.url + 'api/fabu/index',
      data: {
        tel: tel
      },
      method: 'post',
      success: function(res) {
        console.log(res)
        var countryList = [];
        var countryList_id = [];
        for (var o = 0; o < res.data.cx.length; o++) {
          var countryList_id = countryList_id.concat(res.data.cx[o].id)
          var countryList = countryList.concat(res.data.cx[o].title)
        }
        var countryList1 = [];
        var countryList1_id = [];
        for (var a = 0; a < res.data.zxqk.length; a++) {
          var countryList1_id = countryList1_id.concat(res.data.zxqk[a].id)
          var countryList1 = countryList1.concat(res.data.zxqk[a].title)
        }
        var countryList2 = [];
        var countryList2_id = [];
        for (var s = 0; s < res.data.lflx.length; s++) {
          var countryList2_id = countryList2_id.concat(res.data.lflx[s].id)
          var countryList2 = countryList2.concat(res.data.lflx[s].title)
        }
        var countryList3 = [];
        var countryList3_id = [];
        for (var d = 0; d < res.data.yjfs.length; d++) {
          var countryList3_id = countryList3_id.concat(res.data.yjfs[d].id)
          var countryList3 = countryList3.concat(res.data.yjfs[d].title)
        }
        var countryList4 = [];
        var countryList4_id = [];
        for (var i = 0; i < res.data.huxing.length; i++) {
          var countryList4_id = countryList4_id.concat(res.data.huxing[i].id)
          var countryList4 = countryList4.concat(res.data.huxing[i].title)
        }
        var countryList9 = [];
        var countryList9_id = [];
        for (var k = 0; k < res.data.rq.length; k++) {
          var countryList9_id = countryList9_id.concat(res.data.rq[k].id)
          var countryList9 = countryList9.concat(res.data.rq[k].title)
        }
        var countryList10 = [];
        var countryList10_id = [];
        for (var x = 0; x < res.data.ws.length; x++) {
          var countryList10_id = countryList10_id.concat(res.data.ws[x].id)
          var countryList10 = countryList10.concat(res.data.ws[x].title)
        }
        var countryList11 = [];
        var countryList11_id = [];
        for (var z = 0; z < res.data.cw.length; z++) {
          var countryList11_id = countryList11_id.concat(res.data.cw[z].id)
          var countryList11 = countryList11.concat(res.data.cw[z].title)
        }
        var countryList14 = [];
        var countryList14_id = [];
        for (var zz = 0; zz < res.data.xbyq.length; zz++) {
          var countryList14_id = countryList14_id.concat(res.data.xbyq[zz].id)
          var countryList14 = countryList14.concat(res.data.xbyq[zz].title)
        }
        var lou = [-2, -1];
        var zong = [];
        for (var v = 1; v <= res.data.lc.title; v++) {
          var zong = zong.concat(v);
          var lou = lou.concat(v);
        }
        var baohan = []
        if (that.data.baohan.length == 0) {
          for (var i = 0; i < res.data.zjbh.length; i++) {
            var baohan = baohan.concat(0)
          }
        }
        var multiArray1 = that.data.multiArray1
        multiArray1.splice(0, 1, lou);
        multiArray1.splice(3, 1, zong);
        that.setData({
          md_list: res.data.md_list,
          u_type: res.data.u_type,
          fylx: res.data.fylx,
          user: res.data.user,
          zjbh: res.data.zjbh,
          ss_xq_name1: ss_xq_name1,
          ss_xq_address1: ss_xq_address1,
          countryList: countryList,
          countryList_id: countryList_id,
          countryList1: countryList1,
          countryList1_id: countryList1_id,
          countryList2: countryList2,
          countryList2_id: countryList2_id,
          countryList3: countryList3,
          countryList3_id: countryList3_id,
          countryList4: countryList4,
          countryList4_id: countryList4_id,
          countryList9: countryList9,
          countryList9_id: countryList9_id,
          countryList10: countryList10,
          countryList10_id: countryList10_id,
          countryList11: countryList11,
          countryList11_id: countryList11_id,
          countryList14: countryList14,
          countryList14_id: countryList14_id,
          multiArray1: multiArray1,
          fylx_id: res.data.fylx_id,
          baohan: baohan
        })
      }
    })
  },
  change: function(e) {
    var that = this
    var arr = that.data.zjbh
    var baohan = that.data.baohan
    if (baohan.length == 0) {
      for (var i = 0; i < arr.length; i++) {
        var baohan = baohan.concat(0)
      }
    }
    var id = e.currentTarget.dataset.id
    var index = e.currentTarget.dataset.index
    if (baohan[index] == 0) {
      baohan.splice(index, 1, id)
    }
    console.log(baohan)
    app.globalData.baohan = baohan
    that.setData({
      baohan: baohan
    })
  },
  change2: function(e) {
    var that = this
    var baohan = that.data.baohan
    var index = e.currentTarget.dataset.index
    var id = e.currentTarget.dataset.id
    baohan.splice(index, 1, 0)
    console.log(baohan)
    that.setData({
      baohan: baohan
    })
    app.globalData.baohan = baohan
  },
  addr: function(e) {
    var that = this
    that.setData({
      addr: e.detail.value
    })
  },
  menpai: function(e) {
    var that = this
    that.setData({
      menpai: e.detail.value
    })
  },
  mianji: function(e) {
    var that = this
    that.setData({
      mianji: e.detail.value
    })
  },
  louceng: function(e) {
    var that = this
    that.setData({
      louceng: e.detail.value
    })
  },
  setsex: function(e) {
    var that = this
    that.setData({
      setsex: e.detail.value
    })
  },
  price: function(e) {
    var that = this
    that.setData({
      price: e.detail.value
    })
  },
  intro1: function(e) {
    var that = this
    that.setData({
      intro1: e.detail.value
    })
  },
  xz_fylx: function(e) {
    var that = this
    var id = e.currentTarget.dataset.id
    that.setData({
      fylx_id: id
    })
  },
  code: function(e) {
    var that = this
    that.setData({
      code: e.detail.value
    })
    var code = e.detail.value
    var mobile = that.data.mobile
    if (mobile) {
      var tel = mobile
    } else {
      var tel = wx.getStorageSync('tel')
    }
    console.log(code)
    if (code) {
      wx.request({
        url: app.globalData.url + 'api/fabu/check',
        data: {
          mobile: tel,
          code: e.detail.value
        },
        method: 'post',
        success: function(res) {
          console.log(res)
          if (res.data.info == 0) {
            that.setData({
              type1: 1
            })
          } else if (res.data.info == 1) {
            that.setData({
              type1: 0
            })
          }
          that.setData({
            y_check: res.data.info
          })
        }
      })
    } else {
      that.setData({
        y_check: 1,
        type1: 0
      })
    }
  },
  mobile: function(e) {
    var that = this
    that.setData({
      mobile: e.detail.value
    })
    var tel = e.detail.value
    var tel1 = wx.getStorageSync('tel')
    if (tel == tel1) {
      that.setData({
        code_xs: 0
      })
    } else if (tel != tel1) {
      that.setData({
        code_xs: 1
      })
    }
    if (!tel) {
      that.setData({
        code_xs: 0
      })
    }
  },
  yzm: function(e) {
    var that = this
    var tel = that.data.mobile
    if (!tel) {
      var mobile = wx.getStorageSync('tel')
    } else {
      var myreg = /^((1[0-9]{2})+\d{8})$/;
      if (!myreg.test(tel)) {
        wx.showToast({
          title: "手机号格式有误",
          icon: 'none',
          duration: 2000
        })
        return false;
      }
      var mobile = tel
    }
    wx.request({
      url: app.globalData.url + 'api/fabu/yzm',
      data: {
        tel: mobile
      },
      method: 'post',
      success: function(res) {
        console.log(res)
        that.setData({
          success: 1
        })
        let promise = new Promise((resolve, reject) => {
          let setTimer = setInterval(
            () => {
              that.setData({
                second: that.data.second - 1,
              })
              if (that.data.second <= 0) {
                that.setData({
                  second: 60,
                  alreadySend: false,
                  send: true,
                })
                resolve(setTimer)
              }
            }, 1000)
          that.setData({
            disabled: 'disabled'
          })
        })
        promise.then((setTimer) => {
          clearInterval(setTimer)
          that.setData({
            success: 2,
            disabled: ''
          })
        })
      }
    })
  },
  liubtn1: function(e) {
    var that = this
    var yincang1 = that.data.yincang1
    if (yincang1 == false) {
      that.setData({
        yincang1: true,
      })
    } else if (yincang1 == true) {
      that.setData({
        yincang1: false,
      })
    }

  },
  bakbtn1: function(e) {
    var that = this
    var id = e.currentTarget.dataset.id
    app.globalData.md_id = id
    wx.request({
      url: app.globalData.url + 'api/fabu/mendian_show',
      data: {
        id: id,
      },
      method: 'post',
      success: function(res) {
        console.log(res)
        app.globalData.ss_xq_latitude = res.data.info.lat
        app.globalData.ss_sq_longitude = res.data.info.lng
        that.setData({
          title1: res.data.info.title,
          ss_xq_name1: res.data.info.title,
          ss_xq_address1: res.data.info.intro,
          disabled: 'disabled',
          ttype: 1
        })
      }
    })
    that.setData({
      yincang1: true,
    })
  },
  
  submit: function(e) {
    var that = this
    var pics = app.globalData.fabu
    var video = app.globalData.shipin
    var fylx_id = that.data.fylx_id
    var suoshugy = app.globalData.md_id
    var tel = that.data.mobile
    var yzm = that.data.code
    var xq_name = that.data.ss_xq_name1
    var addr = that.data.ss_xq_address1
    var mianji = that.data.mianji
    var huxing = app.globalData.huxing
    var cx = that.data.countryIndex
    var louceng = that.data.countryIndex12
    var zxqk = that.data.countryIndex1
    var setsex = that.data.countryIndex14
    var lflx = that.data.countryIndex2
    var price = that.data.price
    var yjfs = that.data.countryIndex3
    var intro1 = that.data.intro1
    var u_type = that.data.u_type
    var louceng = app.globalData.louceng
    var rq = that.data.countryIndex9
    var ws = that.data.countryIndex10
    var cw = that.data.countryIndex11
    var baohan = that.data.baohan
    console.log(addr, xq_name, app.globalData.ss_sq_longitude, app.globalData.ss_xq_latitude)
    if (!pics[0]) {
      wx.showToast({
        title: '请添加房源图片',
        duration: 2000,
        icon: 'none'
      })
      that.setData({
        type1: 0
      })
      return;
    }
    if (!fylx_id) {
      wx.showToast({
        title: '请选择房源类型',
        duration: 2000,
        icon: 'none'
      })
      that.setData({
        type1: 0
      })
      return;
    }
    if (u_type == 0) {
      if (!suoshugy) {
        wx.showToast({
          title: '请选择所属公寓',
          duration: 2000,
          icon: 'none'
        })
        that.setData({
          type1: 0
        })
        return;
      }
    }
    if (!tel) {
      app.globalData.u_tel = wx.getStorageSync('tel')
    } else {
      var myreg = /^((1[0-9]{2})+\d{8})$/;
      if (!myreg.test(tel)) {
        wx.showToast({
          title: "手机号格式有误",
          icon: 'none',
          duration: 2000
        })
        return false;
      }
      app.globalData.u_tel = tel
    }
    if (that.data.code_xs == 1) {
      if (!yzm) {
        wx.showToast({
          title: '请填写验证码',
          duration: 2000,
          icon: 'none'
        })
        return;
      }
    }
    if (!xq_name) {
      wx.showToast({
        title: '请选择小区名称',
        duration: 2000,
        icon: 'none'
      })
      that.setData({
        type1: 0
      })
      return;
    }

    if (!mianji) {
      wx.showToast({
        title: '请填写面积',
        duration: 2000,
        icon: 'none'
      })
      that.setData({
        type1: 0
      })
      return;
    }
    var myreg1 = /^[0-9]*$/;
    if (!myreg1.test(mianji)) {
      wx.showToast({
        title: "面积格式有误",
        icon: 'none',
        duration: 2000
      })
      that.setData({
        type1: 0
      })
      return;
    }
    if (!huxing) {
      wx.showToast({
        title: '请选择户型',
        duration: 2000,
        icon: 'none'
      })
      that.setData({
        type1: 0
      })
      return;
    }
    if (!cx) {
      wx.showToast({
        title: '请选择朝向',
        duration: 2000,
        icon: 'none'
      })
      that.setData({
        type1: 0
      })
      return;
    }
    if (!louceng) {
      wx.showToast({
        title: '请选择楼层',
        duration: 2000,
        icon: 'none'
      })
      that.setData({
        type1: 0
      })
      return;
    }
    if (!louceng) {
      wx.showToast({
        title: '请选择楼层',
        duration: 2000,
        icon: 'none'
      })
      that.setData({
        type1: 0
      })
      return;
    }
    if (!rq) {
      wx.showToast({
        title: '请选择燃气',
        duration: 2000,
        icon: 'none'
      })
      that.setData({
        type1: 0
      })
      return;
    }
    if (that.data.type == 0) {
      if (!ws) {
        wx.showToast({
          title: '请选择卧室',
          duration: 2000,
          icon: 'none'
        })
        that.setData({
          type1: 0
        })
        return;
      }
    }
    if (!zxqk) {
      wx.showToast({
        title: '请选择装修情况',
        duration: 2000,
        icon: 'none'
      })
      that.setData({
        type1: 0
      })
      return;
    }
    if (!setsex) {
      wx.showToast({
        title: '请选择性别要求',
        duration: 2000,
        icon: 'none'
      })
      that.setData({
        type1: 0
      })
      return;
    }
    if (!lflx) {
      wx.showToast({
        title: '请选择是否有电梯',
        duration: 2000,
        icon: 'none'
      })
      that.setData({
        type1: 0
      })
      return;
    }
    if (!cw) {
      wx.showToast({
        title: '请选择车位情况',
        duration: 2000,
        icon: 'none'
      })
      that.setData({
        type1: 0
      })
      return;
    }
    if (!price) {
      wx.showToast({
        title: '请填写租金',
        duration: 2000,
        icon: 'none'
      })
      that.setData({
        type1: 0
      })
      return;
    }
    if (!myreg1.test(price)) {
      wx.showToast({
        title: "租金格式有误",
        icon: 'none',
        duration: 2000
      })
      that.setData({
        type1: 0
      })
      return;
    }
    if (!yjfs) {
      wx.showToast({
        title: '请选择押金方式',
        duration: 2000,
        icon: 'none'
      })
      that.setData({
        type1: 0
      })
      return;
    }

    // if (baohan.length == 0) {
    //   wx.showToast({
    //     title: '请选择租金包含',
    //     duration: 2000,
    //     icon: 'none'
    //   })
    //   that.setData({
    //     type1: 0
    //   })
    //   return;
    // }
    console.log(app.globalData.ss_xq_latitude, app.globalData.ss_sq_longitude)
    app.globalData.fylx_id = fylx_id
    app.globalData.suoshugy = suoshugy
    app.globalData.xq_name = xq_name
    app.globalData.addr = addr
    app.globalData.mianji = mianji
    app.globalData.cx = that.data.countryList_id[cx]
    app.globalData.zxqk = that.data.countryList1_id[zxqk]
    app.globalData.setsex = that.data.countryList14[setsex]
    app.globalData.lflx = that.data.countryList2_id[lflx]
    app.globalData.price = price
    app.globalData.yjfs = that.data.countryList3_id[yjfs]
    console.log(baohan)
    // return;
    if (!baohan) {
      for (var a = 0; a < baohan.length; a++) {
        var bh = bh + ',' + baohan[a]
      }
      app.globalData.intro1 = bh
    } else {
      for (var a = 0; a < baohan.length; a++) {
        var bh = bh + ',' + baohan[a]
      }
      app.globalData.intro1 = bh
    }
    app.globalData.rq = that.data.countryList9_id[rq]
    app.globalData.ws = that.data.countryList10_id[ws]
    app.globalData.cw = that.data.countryList11_id[cw]
    // console.log(app.globalData.cw)
    // return
    app.globalData.menpai = that.data.menpai
    wx.navigateTo({
      url: '../rleasetwo/rleasetwo?type_id=' + that.data.type_id + '&type=' + that.data.type,
    })
  },
  onShow: function() {
    var that = this
    var ss_xq_name = app.globalData.ss_xq_name
    if (ss_xq_name !== undefined) {
      var ss_xq_name1 = app.globalData.ss_xq_name
      that.getLocate1()
    }
    var ss_xq_address = app.globalData.ss_xq_addr
    if (ss_xq_name !== undefined) {
      var ss_xq_address1 = app.globalData.ss_xq_addr
    }
    that.setData({
      ss_xq_name1: ss_xq_name1,
      ss_xq_address1: ss_xq_address1
    })
    var tel = wx.getStorageSync('tel')
    wx.request({
      url: app.globalData.url + 'api/fabu/index',
      data: {
        tel: tel,
      },
      method: 'post',
      success: function(res) {
        console.log(res)
        if (res.data.user.type != 0) {
          if (res.data.user.wechat == null) {
            wx.showToast({
              title: '请填写个人资料',
              duration: 2000,
              icon: 'none'
            })
            setTimeout(function() {
              wx.navigateTo({
                url: '../personal/personal?tiaozhuan=1&type_id=' + that.data.type_id + '&type=' + that.data.type,
              })
            }, 2000)
          } else {
            if (res.data.user.xy_status == 0) {
              console.log('信用认证')
              if (that.data.user.type == 0) {
                console.log(111)
                if (that.data.user.mendian == null) {
                  wx.showToast({
                    title: '请绑定门店信息',
                    duration: 2000,
                    icon: 'none'
                  })
                  setTimeout(function() {
                    wx.navigateTo({
                      url: '../landlord/landlord?zt=0&type_id=' + that.data.type_id + '&type=' + that.data.type,
                    })
                  }, 2000)
                }
              }
            } else {
              if (that.data.user.type == 0) {
                console.log(222)
                if (that.data.user.mendian == null) {
                  wx.showToast({
                    title: '请绑定公寓信息',
                    duration: 2000,
                    icon: 'none'
                  })
                  setTimeout(function() {
                    wx.navigateTo({
                      url: '../gongyu/gongyu',
                    })
                  }, 2000)
                }
              }
            }
          }
        } else if (res.data.user.type == 0) {
          console.log(111)
          if (res.data.user.fuze_zt == 0) {
            if (res.data.user.gongyu == null || res.data.user.gongyu == '') {
              wx.showToast({
                title: '请绑定公寓信息',
                duration: 2000,
                icon: 'none'
              })
              setTimeout(function() {
                wx.navigateTo({
                  url: '../gongyu/gongyu',
                })
              }, 2000)
            } else {
              if (res.data.user.mendian == null || res.data.user.mendian == '') {
                wx.showToast({
                  title: '请绑定门店信息',
                  duration: 2000,
                  icon: 'none'
                })
                setTimeout(function() {
                  wx.navigateTo({
                    url: '../landlord/landlord?zt=0&type_id=' + that.data.type_id + '&type=' + that.data.type,
                  })
                }, 2000)
              }
            }
          } else if (res.data.user.fuze_zt == 1) {
            if (res.data.user.gongyu == null || res.data.user.gongyu == '') {
              wx.showToast({
                title: '请绑定公寓信息',
                duration: 2000,
                icon: 'none'
              })
              setTimeout(function() {
                wx.navigateTo({
                  url: '../gongyu/gongyu',
                })
              }, 2000)
            } else {
              if (res.data.user.mendian == null || res.data.user.mendian == '') {
                wx.showToast({
                  title: '请绑定门店信息',
                  duration: 2000,
                  icon: 'none'
                })
                setTimeout(function() {
                  wx.navigateTo({
                    url: '../landlord/landlord?zt=0&type_id=' + that.data.type_id + '&type=' + that.data.type,
                  })
                }, 2000)
              }
            }
          }
        }
      }
    })
  },
  getLocate1() {
    var that = this;
    var longitude = app.globalData.ss_sq_longitude
    var latitude = app.globalData.ss_xq_latitude
    wx.request({
      url: 'https://apis.map.qq.com/ws/geocoder/v1/?location=' + latitude + ',' + longitude + '&key=I4CBZ-FYL6G-X2LQD-I56ON-N6K7E-UQFK4',
      success: function(res) {
        console.log(res)
        wx.request({
          url: app.globalData.url + 'api/fabu/dizhi',
          data: {
            dizhi: res.data.result.ad_info.province,
            adcode: res.data.result.ad_info.adcode,
            city: res.data.result.ad_info.city
          },
          method: 'post',
          success: function(rag) {
            console.log(rag)
            if (rag.data.prov_status == 0) {
              wx.showToast({
                title: '当前省份未开放',
                duration: 2000,
                icon: 'none',
                mask:true
              })
              app.globalData.ss_xq_name = undefined
              that.setData({
                sub_type: 1,
                area: '',
                addr: ''
              })
            } else {
              that.setData({
                sub_type: 0
              })
            }
          }
        })
      },
    })
  },
})