const app = getApp()
Page({
  data: {
    items: [{
      name: '2',
      value: '',
      checked: false
    }, ],
  },
  changeDate(e) {
    var that = this
    var date = e.detail.value
    var date1 = app.globalData.date1
    if (!date1) {
      var date1 = that.data.date1
    } else {
      var date1 = date1
    }
    var begin = date.replace(/-/g, '/');
    var end = date1.replace(/-/g, '/');
    var before = Date.parse(new Date()) / 1000;
    var begin = Date.parse(begin) / 1000;
    var end = Date.parse(end) / 1000;
    console.log(begin, end)
    if (before > begin) {
      wx.showToast({
        title: '开始时间应不小于当前时间',
        duration: 2000,
        icon: 'none'
      })
      return;
    }
    if (begin >= end) {
      wx.showToast({
        title: '结束时间应大于开始时间',
        duration: 2000,
        icon: 'none'
      })
      return;
    }
    app.globalData.date = e.detail.value
    wx.request({
      url: app.globalData.url + 'api/zhiding/time_change',
      data: {
        date1: date1,
        date: date
      },
      method: 'post',
      success: function(res) {
        console.log(res)
        that.setData({
          price: res.data.price
        })
      }
    })
    that.setData({
      date: e.detail.value
    });
  },
  changeDate1(e) {
    var that = this

    var date1 = e.detail.value
    var date = app.globalData.date
    if (!date) {
      var date = that.data.date
    } else {
      var date = date
    }
    var begin = date.replace(/-/g, '/');
    var end = date1.replace(/-/g, '/');
    var before = Date.parse(new Date()) / 1000;
    var begin = Date.parse(begin) / 1000;
    var end = Date.parse(end) / 1000;
    console.log(begin, end)
    if (before > end) {
      wx.showToast({
        title: '开始时间应不小于当前时间',
        duration: 2000,
        icon: 'none'
      })
      return;
    }
    if (begin >= end) {
      wx.showToast({
        title: '结束时间应大于开始时间',
        duration: 2000,
        icon: 'none'
      })
      return;
    }
    app.globalData.date1 = e.detail.value
    wx.request({
      url: app.globalData.url + 'api/zhiding/time_change',
      data: {
        date1: date1,
        date: date
      },
      method: 'post',
      success: function(res) {
        console.log(res)
        that.setData({
          price: res.data.price,
          zhi_id: res.data.zhi_id
        })
      }
    })
    that.setData({
      date1: e.detail.value
    });
  },
  zhiya1: function(e) {
    var items = this.data.items;
    for (var i = 0; i < items.length; i++) {
      if (items[i].name == this.data.aa) {
        for (var j = 0; j < items.length; j++) {
          console.log('----------------')
          console.log(items[j].checked)
          app.globalData.check3 = items[j].checked
          if (items[j].checked && j != i) {
            items[j].checked = false;
            app.globalData.check2 = false;
          }
        }
        items[i].checked = !(items[i].checked);
        this.setData(this.data.items[i]);
      }
    }
    this.setData({
      items: items
    });
  },
  radioChange2: function(e) {
    this.data.aa = e.detail.value;
    app.globalData.xieyi = e.detail.value;
  },
  onLoad: function(e) {
    var that = this
    var id = e.id
    app.globalData.f_id = id
    wx.setNavigationBarTitle({
      title: '推广置顶',
    })
    wx.request({
      url: app.globalData.url + 'api/zhiding/yuyue_show',
      data: {
        id: id
      },
      method: 'post',
      success: function(res) {
        console.log(res)
        app.globalData.date = res.data.time
        app.globalData.date1 = res.data.time1
        that.setData({
          info: res.data.info,
          date: res.data.time,
          date1: res.data.time1,
          fid: id,
          price: res.data.price,
          zhi_id: res.data.zhi_id,
          yuyuezhidingtishi: res.data.yuyuezhidingtishi,
          yuyuexieyi: res.data.xieyi,
          mianfei: res.data.mianfei
        })
      }
    })
  },
  submit: function(e) {
    var that = this
    var price = e.currentTarget.dataset.price
    var id = e.currentTarget.dataset.id
    var xieyi = app.globalData.check3
    var openid = wx.getStorageSync('openid')
    var tel = wx.getStorageSync('tel')
    var date = app.globalData.date
    var date1 = app.globalData.date1
    if (!date) {
      var date = that.data.date
    } else {
      var date = date
    }
    if (!date1) {
      var date1 = that.data.date1
    } else {
      var date1 = date1
    }
    console.log(date1)
    if (xieyi === undefined || xieyi == true) {
      wx.showToast({
        title: '请先阅读并同意'+that.data.yuyuexieyi,
        duration: 2000,
        icon: 'none'
      })
      return;
    } else {
      wx.request({
        url: app.globalData.url + 'api/zhiding/zhiding_check',
        data: {
          id: app.globalData.f_id,
          type: 0
        },
        method: 'post',
        success: function(res1) {
          console.log(res1)
          if (res1.data.res == 1) {
            wx.showToast({
              title: '当前求租贴置顶中，请勿重复置顶',
              duration: 2000,
              icon: 'none'
            })
          } else if (res1.data.res == 0) {
            wx.request({
              url: app.globalData.url + 'api/zhifu/payOrder',
              data: {
                openid: openid,
                total_fee: price,
              },
              method: 'post',
              success: function(rag) {
                console.log(rag)
                wx.requestPayment({
                  'timeStamp': rag.data.timeStamp,
                  'nonceStr': rag.data.nonceStr,
                  'package': rag.data.package,
                  'signType': rag.data.signType,
                  'paySign': rag.data.paySign,
                  'success': function(res) {
                    console.log(res)
                    wx.request({
                      url: app.globalData.url + 'api/zhiding/yuyue_zhiding',
                      data: {
                        tel: tel,
                        id: app.globalData.f_id,
                        date: date,
                        date1: date1,
                        price: price,
                        zhi_id: that.data.zhi_id
                      },
                      method: 'post',
                      success: function(ras) {
                        console.log(ras)
                        if (ras.data.info == 1) {
                          wx.showToast({
                            title: '购买成功，正在跳转',
                            duration: 2000,
                            icon: 'none'
                          })
                          setTimeout(function() {
                            wx.navigateBack({

                            })
                          }, 2000)
                        }
                      }
                    })
                  },
                  'fail': function(res) {

                  },
                })
              }
            })
          }
        }
      })

    }
    console.log(price, id)
  },
  onShow: function() {
    app.globalData.check3 = true
  },
})