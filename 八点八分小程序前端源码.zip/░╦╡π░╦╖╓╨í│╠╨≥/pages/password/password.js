// pages/password/password.js
const app = getApp()
Page({

  /**
   * 页面的初始数据
   */
  data: {
    second: 60,
    pic1: '../../images/yin.png',
    pic3: '../../images/yin.png',
    type: 1,
    type1: 1,
    sub_type: 0
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function(e) {
    wx.setNavigationBarTitle({
      title: '修改密码',
    })
  },
  tel: function(e) {
    var that = this
    that.setData({
      tel: e.detail.value
    })
  },
  yzm: function(e) {
    var that = this
    that.setData({
      yzm: e.detail.value
    })
  },
  pass: function(e) {
    var that = this
    that.setData({
      pass: e.detail.value
    })
  },
  kan: function(e) {
    var that = this
    var type = that.data.type
    var pass = that.data.pass
    console.log(pass)
    if (type == 1) {
      that.setData({
        type: 0,
        pass: pass,
        pic1: '../../images/ico7.png'
      })
    } else if (type == 0) {
      that.setData({
        type: 1,
        pass: pass,
        pic1: '../../images/yin.png'
      })
    }
  },
  newpass: function(e) {
    var that = this
    that.setData({
      newpass: e.detail.value
    })
  },
  kan1: function(e) {
    var that = this
    var type1 = that.data.type1
    var newpass = that.data.newpass

    if (type1 == 1) {
      that.setData({
        type1: 0,
        newpass: newpass,
        pic3: '../../images/ico7.png'
      })
    } else if (type1 == 0) {
      that.setData({
        type1: 1,
        newpass: newpass,
        pic3: '../../images/yin.png'
      })
    }
  },
  huoqu: function(e) {
    var that = this
    var tel = that.data.tel
    if (!tel) {
      wx.showToast({
        title: '请填写手机号',
        duration: 2000,
        icon: 'none',
        mask: true
      })
      return;
    }
    var merag = /^((13[0-9])|(14[0-9])|(15[0-9])|(17[0-9])|(18[0-9]))\d{8}$/
    if (!merag.test(tel)) {
      wx.showToast({
        title: '手机号格式错误',
        duration: 2000,
        icon: 'none',
        mask: true
      })
      return;
    }
    wx.request({
      url: app.globalData.url + 'api/my/tel_check1',
      data:{
        tel: tel,
        openid: wx.getStorageSync('openid')
      },
      method: 'post',
      success: function(rag){
        console.log(rag)
        if(rag.data == 1){
          wx.request({
            url: app.globalData.url + 'api/my/forget_tel_check',
            data: {
              tel: tel
            },
            method: 'post',
            success: function (res) {
              console.log(res)
              if (res.data.info == 1) {
                wx.request({
                  url: app.globalData.url + 'api/sms/send_yzm',
                  data: {
                    tel: tel
                  },
                  method: 'post',
                  success: function (ras) {
                    console.log(ras)
                    that.setData({
                      success: 1
                    })
                    let promise = new Promise((resolve, reject) => {
                      let setTimer = setInterval(
                        () => {
                          that.setData({
                            second: that.data.second - 1,
                          })
                          if (that.data.second <= 0) {
                            that.setData({
                              second: 60,
                              alreadySend: false,
                              send: true,
                            })
                            resolve(setTimer)
                          }
                        }, 1000)
                      that.setData({
                        disabled: 'disabled'
                      })
                    })
                    promise.then((setTimer) => {
                      clearInterval(setTimer)
                      that.setData({
                        success: 2,
                        disabled: ''
                      })
                    })
                  }
                })
              } else if (res.data.info == 0) {
                wx.showToast({
                  title: '当前手机号未被注册',
                  duration: 2000,
                  icon: 'none',
                  mask: true
                })
                return;
              }
            }
          })
        }else if(rag.data == 2){
          wx.showToast({
            title: '手机号与当前账号绑定手机号不符',
            duration: 2000,
            icon: 'none',
            mask: true
          })
          return
        }else if(rag.data == 3){
          wx.showToast({
            title: '账号已停用',
            duration: 2000,
            icon: 'none',
            mask: true
          })
          return
        }
      }
    })
    
  },
  submit: function(e) {
    var that = this
    var pass = that.data.pass
    var tel = that.data.tel
    var yzm = that.data.yzm
    var newpass = that.data.newpass
    if (!tel) {
      wx.showToast({
        title: '请填写手机号',
        duration: 2000,
        icon: 'none',
        mask: true
      })
      return;
    }
    var merag = /^((13[0-9])|(14[0-9])|(15[0-9])|(17[0-9])|(18[0-9]))\d{8}$/
    if (!merag.test(tel)) {
      wx.showToast({
        title: '手机号格式错误',
        duration: 2000,
        icon: 'none',
        mask: true
      })
      return;
    }
    if (!yzm) {
      wx.showToast({
        title: '请输入验证码',
        duration: 2000,
        icon: 'none',
        mask: true
      })
      return;
    }
    var mareg = /^[a-zA-Z0-9]{6,18}$/
    if (!mareg.test(pass)) {
      wx.showToast({
        title: '密码由6-18位数字字母组成',
        duration: 2000,
        icon: 'none',
        mask: true
      })
      return;
    }
    if (!pass) {
      wx.showToast({
        title: '请填写密码',
        duration: 2000,
        icon: 'none',
        mask: true
      })
      return;
    }
    if (!newpass) {
      wx.showToast({
        title: '请再次输入密码',
        duration: 2000,
        icon: 'none',
        mask: true
      })
      return;
    }
    if (pass != newpass){
      wx.showToast({
        title: '密码输入不一致',
        duration: 2000,
        icon: 'none',
        mask: true
      })
      return;
    }
    wx.request({
      url: app.globalData.url + 'api/my/forget_pass_change',
      data: {
        tel: tel,
        yzm: yzm,
        pass: pass
      },
      method: 'post',
      success: function(res) {
        console.log(res)
        if (res.data.info == 1) {
          wx.showToast({
            title: '恭喜,修改成功',
            duration: 2000,
            icon: 'none',
            mask: true
          })
          setTimeout(function() {
            wx.navigateBack({

            })
          }, 2000)

          return;
        } else if (res.data.info == 0) {
          wx.showToast({
            title: '密码与原密码一致，修改失败',
            duration: 2000,
            icon: 'none',
            mask: true
          })
          return;
        } else if (res.data.info == 2) {
          wx.showToast({
            title: '验证码不正确',
            duration: 2000,
            icon: 'none',
            mask: true
          })
          return;
        }else if(res.data.info == 3){
          wx.showToast({
            title: '账号已停用',
            duration: 2000,
            icon: 'none',
            mask: true
          })
          return;
        }
      }
    })
  },
})