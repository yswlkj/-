const app = getApp()
Page({
  data: {
    statu: 'open',

    dedao:0,
    yincang: true,
    yincang_look: true,
    yincang_fangdong: true,

    yincang1: true,

    yincang2: true,
    yincang2_look: true,
    yincang2_fangdong: true,
    
    shan_zt: 0,
    shan_zt_look: 0,
    shan_zt_fangdong: 0,


    select_all: false,
    select_all_look: false,
    select_all_fangdong: false,

    batchIds: [],
    batchIds_look: [],
    batchIds1_look: [],
    batchIds_fangdong: [],
    batchIds1_fangdong: [],
    canIUseGetUserProfile: false,
  },
  qiehuan:function(e){
    var that = this
    var id = e.currentTarget.dataset.dedao
    that.setData({
      dedao: id
    })
    app.globalData.dedao = e.currentTarget.dataset.dedao
    if(id == 1){
      var tel = wx.getStorageSync('tel')
      wx.request({
        url: app.globalData.url + 'api/wish/xingcheng',
        data: {
          tel: tel,
          url: app.globalData.url
        },
        method: 'post',
        success: function (res) {
          console.log(res)
          var arr = []
          var arr1 = []
          var arr_1 = []
          if (res.data.list) {
            for (let i = 0; i < res.data.list.length; i++) {
              for (var j = 0; j < res.data.list[i].info.length; j++) {
                var arr = arr.concat(res.data.list[i].info[j].id);
              }
            }
          }
          if (res.data.list_1) {
            for (let i = 0; i < res.data.list_1.length; i++) {
              for (var j = 0; j < res.data.list_1[i].info.length; j++) {
                var arr_1 = arr_1.concat(res.data.list_1[i].info[j].id);
              }
            }
          }
          if (res.data.guo_list) {
            for (let a = 0; a < res.data.guo_list.length; a++) {
              for (var b = 0; b < res.data.guo_list[a].info.length; b++) {
                var arr1 = arr1.concat(res.data.guo_list[a].info[b].id);
              }
            }
          }
          that.setData({
            list: res.data.list,
            list_1: res.data.list_1,
            g_list: res.data.guo_list,
            user: res.data.user,
            url: app.globalData.url,
            zong_look: arr,
            zong1_look: arr1,
            zong2_look: arr_1,
            select_all_look: false,
            shan_zt_look: 0,
            yincang_look: true,
            yincang2_look: true,
          })
        }
      })
    }else if(id == 0){
      var tel = wx.getStorageSync('tel')
      wx.request({
        url: app.globalData.url + 'api/wish/wlist',
        data: {
          tel: tel,
          city_code: app.globalData.city_code,
          url: app.globalData.url
        },
        method: 'post',
        success: function (res) {
          console.log(res)
          var arr = []
          if (res.data.info) {
            for (let i = 0; i < res.data.info.length; i++) {
              for (var j = 0; j < res.data.info[i].info.length; j++) {
                var arr = arr.concat(res.data.info[i].info[j].id);

              }
            }
          }
          that.setData({
            url: app.globalData.url,
            info: res.data.info,
            lat: res.data.lat,
            p_list: res.data.plist,
            user: res.data.user,
            type: 0,
            zong: arr,
            shan_zt: 0,
            select_all: false,
            yincang: true,
            yincang2: true,
          })
        }
      })
    }else if(id == 2){
      var tel = wx.getStorageSync('tel')
      wx.request({
        url: app.globalData.url + 'api/wish/xingcheng_fd',
        data: {
          tel: tel,
          url: app.globalData.url
        },
        method: 'post',
        success: function (res) {
          console.log(res)
          var arr = []
          var arr1 = []
          if (res.data.yy_list) {
            for (let i = 0; i < res.data.yy_list.length; i++) {
              for (var j = 0; j < res.data.yy_list[i].info.length; j++) {
                var arr = arr.concat(res.data.yy_list[i].info[j].id);
              }
            }
          }
          if (res.data.yy_list1) {
            for (let a = 0; a < res.data.yy_list1.length; a++) {
              for (var b = 0; b < res.data.yy_list1[a].info.length; b++) {
                var arr1 = arr1.concat(res.data.yy_list1[a].info[b].id);
              }
            }
          }
          that.setData({
            list: res.data.yy_list,
            g_list: res.data.yy_list1,
            url: app.globalData.url,
            zong_fangdong: arr,
            zong1_fangdong: arr1,
            shan_zt_fangdong: 0,
            select_all_fangdong: false,
            yincang_fangdong: true,
            yincang2_fangdong: true,
          })
        }
      })
    }
  },
  liubtn: function(e) {
    this.setData({
      yincang: false,
      yincang2: false,
      bottom: 0,
      shan_zt: 1
    })
  },
  liubtn_look: function (e) {
    this.setData({
      yincang_look: false,
      yincang2_look: false,
      bottom: 0,
      shan_zt_look: 1
    })
  },
  liubtn_fangdong: function (e) {

    this.setData({
      yincang_fangdong: false,
      yincang2_fangdong: false,
      bottom: 0,
      shan_zt_fangdong: 1
    })
  },
  //取消
  liubtn1: function(e) {
    var that = this
    var tel = wx.getStorageSync('tel')
    wx.request({
      url: app.globalData.url + 'api/wish/wlist',
      data: {
        tel: tel,
        url: app.globalData.url
      },
      method: 'post',
      success: function(res) {
        console.log(res)

        that.setData({

          info: res.data.info,
          select_all: false

        })
      }
    })
    that.setData({
      yincang: true,
      yincang2: true,
      bottom: 0,
      shan_zt: 0,
      batchIds: []
    })
  },
  liubtn1_look: function (e) {
    var that = this
    var tel = wx.getStorageSync('tel')
    wx.request({
      url: app.globalData.url + 'api/wish/xingcheng',
      data: {
        tel: tel,
        url: app.globalData.url
      },
      method: 'post',
      success: function (res) {
        console.log(res)
        that.setData({
          list: res.data.list,
          g_list: res.data.guo_list,
        })
      }
    })
    that.setData({
      yincang_look: true,
      yincang2_look: true,
      bottom: 0,
      shan_zt_look: 0,
      select_all_look: false,
      batchIds_look: [],
      batchIds1_look: [],
    })
  },
  liubtn1_fangdong: function (e) {
    var that = this
    var tel = wx.getStorageSync('tel')
    wx.request({
      url: app.globalData.url + 'api/wish/xingcheng_fd',
      data: {
        tel: tel,
        url: app.globalData.url
      },
      method: 'post',
      success: function (res) {
        console.log(res)
        that.setData({
          list: res.data.yy_list,
        })
      }
    })
    that.setData({
      yincang_fangdong: true,
      yincang2_fangdong: true,
      bottom: 0,
      shan_zt_fangdong: 0,
      select_all_fangdong: false,
      batchIds_fangdong: [],
      batchIds1_fangdong: [],
    })
  },
  //全选
  quanxuan: function(e) {
    console.log(e)
    var that = this;
    var arr = []; //存放选中id的数组
    if(that.data.info != null){
      for (let i = 0; i < that.data.info.length; i++) {
        for (var j = 0; j < that.data.info[i].info.length; j++) {
          that.data.info[i].info[j].checked = (!that.data.select_all)
          if (that.data.info[i].info[j].checked == true) {
            arr = arr.concat(that.data.info[i].info[j].id);
          }
        }
      }
    }
    console.log(arr)
    that.setData({
      info: that.data.info,
      select_all: (!that.data.select_all),
      batchIds: arr
    })
  },
  quanxuan_look: function (e) {
    console.log(e)
    var that = this;
    var arr = []; //存放选中id的数组
    if(that.data.list != null){
      for (let i = 0; i < that.data.list.length; i++) {
        for (var j = 0; j < that.data.list[i].info.length; j++) {
          that.data.list[i].info[j].checked = (!that.data.select_all_look)

          if (that.data.list[i].info[j].checked == true) {
            // 全选获取选中的值
            arr = arr.concat(that.data.list[i].info[j].y_id);
          }
        }
      }
    }
    console.log(arr)
    var arr1 = []; 
    if(that.data.g_list != null){
      for (let a = 0; a < that.data.g_list.length; a++) {
        for (var b = 0; b < that.data.g_list[a].info.length; b++) {
          that.data.g_list[a].info[b].checked = (!that.data.select_all_look)
          if (that.data.g_list[a].info[b].checked == true) {
            arr1 = arr1.concat(that.data.g_list[a].info[b].y_id);
          }
        }
      }
    }
    console.log(arr1)
    that.setData({
      g_list: that.data.g_list,
      list: that.data.list,
      select_all_look: (!that.data.select_all_look),
      batchIds_look: arr,
      batchIds1_look: arr1,
    })
  },
  quanxuan_fangdong: function (e) {
    console.log(e)
    var that = this;
    var arr = []; 
    if (that.data.list != null){
      for (let i = 0; i < that.data.list.length; i++) {
        for (var j = 0; j < that.data.list[i].info.length; j++) {
          that.data.list[i].info[j].checked = (!that.data.select_all_fangdong)
          if (that.data.list[i].info[j].checked == true) {
            arr = arr.concat(that.data.list[i].info[j].y_id);
          }
        }
      }
    }
    console.log(arr)
    var arr1 = []; 
    if (that.data.g_list != null){
      for (let a = 0; a < that.data.g_list.length; a++) {
        for (var b = 0; b < that.data.g_list[a].info.length; b++) {
          that.data.g_list[a].info[b].checked = (!that.data.select_all_fangdong)
          if (that.data.g_list[a].info[b].checked == true) {
            arr1 = arr1.concat(that.data.g_list[a].info[b].y_id);
          }
        }
      }
    }
    that.setData({
      g_list: that.data.g_list,
      list: that.data.list,
      select_all_fangdong: (!that.data.select_all_fangdong),
      batchIds_fangdong: arr,
      batchIds1_fangdong: arr1
    })
  },
  //单选
  danxuan: function(e) {
    var that = this
    if (e.detail.value == '') {
      var id = e.currentTarget.dataset.id
      var batchIds = that.data.batchIds
      var index = batchIds.indexOf(id)
      batchIds.splice(index, 1);
      that.setData({
        select_all: false,
        batchIds: batchIds
      })
    } else {
      if (that.data.batchIds.includes(parseInt(e.detail.value))) {
        that.setData({
          select_all: true
        })
      } else {
        var batchIds = []
        var batchIds = that.data.batchIds.concat(parseInt(e.detail.value))
        if (batchIds.length == that.data.zong.length) {
          that.setData({
            select_all: true
          })
        }
        that.setData({
          batchIds: batchIds
        })
      }
    }

  },
  danxuan_look: function (e) {
    var that = this
    var type = e.currentTarget.dataset.type
    
    if (e.detail.value == '') {
      var id = e.currentTarget.dataset.id
      var type = e.currentTarget.dataset.type
      var batchIds = that.data.batchIds_look
      var batchIds1 = that.data.batchIds1_look
      if (type == 0) {
        var index = batchIds.indexOf(id)
        batchIds.splice(index, 1);
      } else if (type == 1) {
        var index = batchIds1.indexOf(id)
        batchIds1.splice(index, 1);
      }
      that.setData({
        select_all_look: false,
        batchIds_look: batchIds,
        batchIds1_look: batchIds1
      })
    } else {
      if (type == 0) {
        if (that.data.batchIds_look.includes(parseInt(e.detail.value))) {
          that.setData({
            select_all_look: true
          })
        } else {
          var batchIds = []
          var batchIds = that.data.batchIds_look.concat(parseInt(e.detail.value))
          that.setData({
            batchIds_look: batchIds
          })
        }
      } else if (type == 1) {
        if (that.data.batchIds1_look.includes(parseInt(e.detail.value))) {
          that.setData({
            select_all_look: true
          })
        } else {
          var batchIds1 = []
          var batchIds1 = that.data.batchIds1_look.concat(parseInt(e.detail.value))
          that.setData({
            batchIds1_look: batchIds1
          })
        }
      }
      var batchIds1 = that.data.batchIds1_look
      var batchIds = that.data.batchIds_look
      console.log(batchIds1,batchIds)
      console.log(that.data.zong_look,that.data.zong1_look)
      if ((batchIds.length + batchIds1.length) == (that.data.zong_look.length + that.data.zong1_look.length + that.data.zong1_look.length)) {
        console.log(1)
        that.setData({
          select_all_look: 'checked'
        })
      } else {
        that.setData({
          select_all_look: ''
        })
      }
    }
  },
  danxuan_fangdong: function (e) {
    var that = this
    var type = e.currentTarget.dataset.type
    if (e.detail.value == '') {
      var id = e.currentTarget.dataset.id
      var type = e.currentTarget.dataset.type
      var batchIds = that.data.batchIds_fangdong
      var batchIds1 = that.data.batchIds1_fangdong
      if (type == 0) {
        var index = batchIds.indexOf(id)
        batchIds.splice(index, 1);
      } else if (type == 1) {
        var index = batchIds1.indexOf(id)
        batchIds1.splice(index, 1);
      }
      that.setData({
        select_all_fangdong: false,
        batchIds_fangdong: batchIds,
        batchIds1_fangdong: batchIds1
      })
    } else {
      if (type == 0) {
        if (that.data.batchIds_fangdong.includes(parseInt(e.detail.value))) {
          that.setData({
            select_all_fangdong: true
          })
        } else {
          var batchIds = []
          var batchIds = that.data.batchIds_fangdong.concat(parseInt(e.detail.value))
          that.setData({
            batchIds_fangdong: batchIds
          })
        }
      } else if (type == 1) {
        if (that.data.batchIds1_fangdong.includes(parseInt(e.detail.value))) {
          that.setData({
            select_all_fangdong: true
          })
        } else {
          var batchIds1 = []
          var batchIds1 = that.data.batchIds1_fangdong.concat(parseInt(e.detail.value))

          that.setData({
            batchIds1_fangdong: batchIds1
          })
        }
      }
      var batchIds1 = that.data.batchIds1_fangdong
      var batchIds = that.data.batchIds_fangdong
      if ((batchIds.length + batchIds1.length) == (that.data.zong_fangdong.length + that.data.zong1_fangdong.length)) {
        that.setData({
          select_all_fangdong: true
        })
      } else {
      }
    }
  },
  //删除
  shan: function (e) {
    var that = this
    if (that.data.batchIds.length == 0) {
      wx.showToast({
        title: '请选择需要删除的房源',
        duration: 2000,
        icon: 'none'
      })
      return;
    }
    var id = that.data.batchIds.toString()
    wx.showModal({
      title: '提示',
      content: '确定删除当前收藏房源',
      showCancel: true, 
      cancelText: "我再想想", 
      confirmText: "确定删除", 
      success: function (res) {
        if (res.cancel) {
          
        } else {
          
          wx.request({
            url: app.globalData.url + 'api/my/liulan_shan',
            data: {
              id: id,
              tel: wx.getStorageSync('tel')
            },
            method: 'post',
            success: function (res) {
              console.log(res)
              wx.showToast({
                title: '删除成功',
                duration: 2000,
                icon: 'none'
              })
              that.reload()
              that.setData({
                type: 1,
                batchIds: [],
                shan_zt: 0,
                select_all: false,
                yincang: true,
                yincang2: true,
              })

            }
          })
        }
      },
    })

  },
  shan_look: function (e) {
    var that = this
    if (that.data.batchIds_look.length == 0 && that.data.batchIds1_look.length == 0) {
      wx.showToast({
        title: '请选择需要删除的行程',
        duration: 2000,
        icon: 'none'
      })
      return;
    }
    var fid = that.data.batchIds_look.toString()
    var qid = that.data.batchIds1_look.toString()
    console.log(fid,qid)
    // return
    wx.showModal({
      title: '提示',
      content: '确定删除当前行程',
      showCancel: true, 
      cancelText: "我再想想", 
      confirmText: "确定删除", 
      success: function (res) {
        if (res.cancel) {

        } else {

          wx.request({
            url: app.globalData.url + 'api/my/xingcheng_shan',
            data: {
              fid: fid,
              qid: qid,
              tel: wx.getStorageSync('tel')
            },
            method: 'post',
            success: function (res) {
              console.log(res)
              wx.showToast({
                title: '删除成功',
                duration: 2000,
                icon: 'none'
              })
              that.reload()
              that.setData({
                type: 1,
                batchIds_look: [],
                batchIds1_look: [],
                shan_zt_look: 0,
                select_all_look: false,
                yincang_look: true,
                yincang2_look: true,
              })
            }
          })
        }
      },
    })
  },
  shan_fangdong: function (e) {
    var that = this
    if (that.data.batchIds_fangdong.length == 0 && that.data.batchIds1_fangdong.length == 0) {
      wx.showToast({
        title: '请选择需要删除的行程',
        duration: 2000,
        icon: 'none'
      })
      return;
    }
    var fid = that.data.batchIds_fangdong.toString()
    var qid = that.data.batchIds1_fangdong.toString()
    wx.showModal({
      title: '提示',
      content: '确定删除当前行程',
      showCancel: true, 
      cancelText: "我再想想", 
      confirmText: "确定删除", 
      success: function (res) {
        if (res.cancel) {

        } else {

          wx.request({
            url: app.globalData.url + 'api/my/xingcheng_fd_shan',
            data: {
              fid: fid,
              qid: qid,
              tel: wx.getStorageSync('tel')
            },
            method: 'post',
            success: function (res) {
              console.log(res)
              wx.showToast({
                title: '删除成功',
                duration: 2000,
                icon: 'none'
              })
              that.reload()
              that.setData({
                type: 1,
                batchIds_fangdong: [],
                batchIds1_fangdong: [],
                shan_zt_fangdong: 0,
                select_all_fangdong: false,
                yincang_fangdong: true,
                yincang2_fangdong: true,
              })
            }
          })
        }
      },
    })
  },
  tiao: function (e) {
    var that = this
    
    wx.navigateTo({
      url: '../home_ex/home_ex?id=' + e.currentTarget.dataset.id,
    })
  },
  tishi: function (e) {
    var that = this
    wx.showToast({
      title: '当前房源已下架',
      duration: 2000,
      icon: 'none'
    })
  },
  reload:function(){
    var that = this
    var tel = wx.getStorageSync('tel')
    var dedao = that.data.dedao
    app.globalData.dedao = dedao
    if(dedao == 0){
      var tel = wx.getStorageSync('tel')
      wx.request({
        url: app.globalData.url + 'api/wish/wlist',
        data: {
          tel: tel,
          url: app.globalData.url,
          city_code: app.globalData.city_code,
          lat: app.globalData.lat,
          lng: app.globalData.lng
        },
        method: 'post',
        success: function (res) {
          console.log(res)
          var arr = []
          if (res.data.info) {
            for (let i = 0; i < res.data.info.length; i++) {
              for (var j = 0; j < res.data.info[i].info.length; j++) {
                var arr = arr.concat(res.data.info[i].info[j].id);

              }
            }
          }
          that.setData({
            url: app.globalData.url,
            info: res.data.info,
            lat: res.data.lat,
            p_list: res.data.plist,
            user: res.data.user,
            type: 0,
            zong: arr
          })
        }
      })
    }else if(dedao == 1){
      var tel = wx.getStorageSync('tel')
      wx.request({
        url: app.globalData.url + 'api/wish/xingcheng',
        data: {
          tel: tel,
          url: app.globalData.url
        },
        method: 'post',
        success: function (res) {
          console.log(res)
          var arr = []
          var arr1 = []
          var arr_1 = []
          if (res.data.list) {
            for (let i = 0; i < res.data.list.length; i++) {
              for (var j = 0; j < res.data.list[i].info.length; j++) {
                var arr = arr.concat(res.data.list[i].info[j].id);
              }
            }
          }
          if (res.data.list_1) {
            for (let i = 0; i < res.data.list_1.length; i++) {
              for (var j = 0; j < res.data.list_1[i].info.length; j++) {
                var arr_1 = arr_1.concat(res.data.list_1[i].info[j].id);
              }
            }
          }
          if (res.data.guo_list) {
            for (let a = 0; a < res.data.guo_list.length; a++) {
              for (var b = 0; b < res.data.guo_list[a].info.length; b++) {
                var arr1 = arr1.concat(res.data.guo_list[a].info[b].id);
              }
            }
          }
          that.setData({
            list: res.data.list,
            list_1: res.data.list_1,
            g_list: res.data.guo_list,
            user: res.data.user,
            url: app.globalData.url,
            zong_look: arr,
            zong1_look: arr1,
            zong2_look: arr_1
          })
        }
      })
    }else if(dedao == 2){
      var tel = wx.getStorageSync('tel')
      wx.request({
        url: app.globalData.url + 'api/wish/xingcheng_fd',
        data: {
          tel: tel,
          url: app.globalData.url
        },
        method: 'post',
        success: function (res) {
          console.log(res)
          var arr = []
          var arr1 = []
          if (res.data.yy_list) {
            for (let i = 0; i < res.data.yy_list.length; i++) {
              for (var j = 0; j < res.data.yy_list[i].info.length; j++) {
                var arr = arr.concat(res.data.yy_list[i].info[j].id);
              }
            }
          }
          if (res.data.yy_list1) {
            for (let a = 0; a < res.data.yy_list1.length; a++) {
              for (var b = 0; b < res.data.yy_list1[a].info.length; b++) {
                var arr1 = arr1.concat(res.data.yy_list1[a].info[b].id);
              }
            }
          }
          that.setData({
            list: res.data.yy_list,
            g_list: res.data.yy_list1,
            url: app.globalData.url,
            zong_fangdong: arr,
            zong1_fangdong: arr1
          })
        }
      })
    }
  },
  onLoad: function(e) {
    var that = this
    wx.setNavigationBarTitle({
      title: '心愿单',
    })
    if (wx.getUserProfile) {
      that.setData({
        canIUseGetUserProfile: true
      })
    }
    app.globalData.dedao = 0
    var tel = wx.getStorageSync('tel')
    wx.request({
      url: app.globalData.url + 'api/wish/wlist',
      data: {
        tel: tel,
        url: app.globalData.url,
        city_code: app.globalData.city_code,
        lat: app.globalData.lat,
        lng:app.globalData.lng
      },
      method: 'post',
      success: function(res) {
        console.log(res)
        var arr = []
        if(res.data.info){
          if (res.data.info.length != 0) {
            for (let i = 0; i < res.data.info.length; i++) {
              for (var j = 0; j < res.data.info[i].info.length; j++) {
                var arr = arr.concat(res.data.info[i].info[j].id);
              }
            }
          }
          if (res.data.info.length != 0){
            var info = res.data.info
          }else{
            var info = null
          }
        }else{
          var info = null
        }
        that.setData({
          url: app.globalData.url,
          info: info,
          lat: res.data.lat,
          p_list: res.data.plist,
          user: res.data.user,
          type: 0,
          zong: arr,
          shan_zt: 0,
          openid:wx.getStorageSync('openid'),
          tel: wx.getStorageSync('tel'),
          pinpai: app.globalData.pinpai,
          wei: app.globalData.wei,
          bao: app.globalData.bao,
          youxuan: app.globalData.youxuan,
          pinpai1: app.globalData.pinpai1,
          wei1: app.globalData.wei1,
          bao1: app.globalData.bao1,
          youxuan1: app.globalData.youxuan1,
          tishi_logo: app.globalData.tishi_logo,
          gengxin: app.globalData.gengxin
        })
      }
    })
  },
  call: function(e) {
    var that = this
    wx.makePhoneCall({
      phoneNumber: e.currentTarget.dataset.call,
    })
  },
  onReady: function() {
    var that = this
    var tel = wx.getStorageSync('tel')
    if (!tel) {
      that.powerDrawer()
    }
  },
  powerDrawer: function(e) {
    console.log(e)
    var that = this
    if (e) {
      var currentStatu1 = e.currentTarget.dataset.statu

    } else {
      var currentStatu1 = that.data.statu
    }
    that.util(currentStatu1)
  },
  util: function(currentStatu1) {
    var animation1 = wx.createAnimation({
      duration: 1,
      timingFunction: "linear", 
      delay: 0 
    });
    
    this.animation1 = animation1;

    animation1.translateX(240).step();

    this.setData({
      animationData1: animation1.export()
    })

    setTimeout(function() {

      animation1.translateX(0).step()

      this.setData({
        animationData1: animation1
      })

      if (currentStatu1 == "close") {
        this.setData({
          showModalStatus1: false
        });
        wx.reLaunch({
          url: '../index/index',
        })
      }
    }.bind(this), 1)

    if (currentStatu1 == "open") {
      this.setData({
        showModalStatus1: true
      });
    }
  },
  getUserProfile(e) {
    var that = this
    // 推荐使用wx.getUserProfile获取用户信息，开发者每次通过该接口获取用户个人信息均需用户确认
    // 开发者妥善保管用户快速填写的头像昵称，避免重复弹窗
    wx.getUserProfile({
      desc: '用于完善会员资料', // 声明获取用户个人信息后的用途，后续会展示在弹窗中，请谨慎填写
      success: (res) => {
        console.log(res)
        app.globalData.user_info = res.userInfo
        wx.login({
          success: res1 => {
            app.globalData.user_code = res1.code;
            wx.request({
              url: app.globalData.url + 'api/wechat/login',
              headers: {
                "Content-Type": "application/x-www-form-urlencoded"
              },
              data: {
                user_code: app.globalData.user_code,
                url: app.globalData.url,
                ip: wx.getStorageSync('ip')
              },
              method: 'POST',
              dataType: 'json',
              responseType: 'Text',
              success: function(res){
                console.log(res)
                var openid = res.data.info.openid
                var sessionkey = res.data.info.session_key
                wx.setStorageSync('sessionkey', sessionkey)
                wx.setStorageSync('openid', openid)
                wx.reLaunch({
                  url: '../login/login',
                })
              }
            })
          }
        })

        that.setData({
          userInfo: res.userInfo,
          hasUserInfo: true
        })
      }
    })
  },
  getUserInfo(e) {
    // 不推荐使用getUserInfo获取用户信息，预计自2021年4月13日起，getUserInfo将不再弹出弹窗，并直接返回匿名的用户个人信息
    this.setData({
      userInfo: e.detail.userInfo,
      hasUserInfo: true
    })
  },
  // getUserInfo(e) {

  //   console.log(e)
  //   var that = this
  //   if (e.detail.errMsg === 'getUserInfo:ok') {
  //     app.globalData.user_info = e.detail.userInfo
  //     wx.login({
  //       success: res => {
  //         app.globalData.user_code = res.code;
  //       }
  //     })
  //     app.globalData.iv = e.detail.iv
  //     app.globalData.encryptedData = e.detail.encryptedData
  //     app.globalData.errMsg = e.detail.errMsg
  //     wx.request({
  //       url: app.globalData.url + 'api/wechat/login',
  //       headers: {
  //         "Content-Type": "application/x-www-form-urlencoded"
  //       },
  //       data: {
  //         user_code: app.globalData.user_code,
  //         url: app.globalData.url,
  //         ip: wx.getStorageSync('ip')
  //       },
  //       method: 'POST',
  //       dataType: 'json',
  //       responseType: 'Text',
  //       success: function(res) {
  //         console.log(res)
  //         var openid = res.data.info.openid
  //         var sessionkey = res.data.info.session_key
  //         wx.setStorageSync('sessionkey', sessionkey)
  //         wx.setStorageSync('openid', openid)
  //         wx.reLaunch({
  //           url: '../login/login',
  //         })
  //       }
  //     })
  //   } else if (e.detail.errMsg === 'getUserInfo:fail auth deny') {
  //     wx.showToast({
  //       title: '取消授权将无法正常使用小程序',
  //       icon: 'none',
  //       duration: 5000
  //     })
  //     that.setData({
  //       warning: false,
  //     })
  //   }
  // },
  onShow: function() {
    var that = this
    wx.setNavigationBarTitle({
      title: '心愿单',
    })
    wx.login({
      success: res => {
        app.globalData.user_code = res.code;
      }
    })
      // var tel = wx.getStorageSync('tel')
      var dedao = app.globalData.dedao
      console.log(dedao)
      console.log('onshow')
      if (dedao == 0) {
        var tel = wx.getStorageSync('tel')
        wx.request({
          url: app.globalData.url + 'api/wish/wlist',
          data: {
            tel: tel,
            url: app.globalData.url,
            city_code: app.globalData.city_code,
            lat: app.globalData.lat,
            lng: app.globalData.lng
          },
          method: 'post',
          success: function (res) {
            console.log(res)
            var arr = []
            if (res.data.info) {
              for (let i = 0; i < res.data.info.length; i++) {
                for (var j = 0; j < res.data.info[i].info.length; j++) {
                  var arr = arr.concat(res.data.info[i].info[j].id);

                }
              }
            }
            that.setData({
              url: app.globalData.url,
              info: res.data.info,
              lat: res.data.lat,
              p_list: res.data.plist,
              user: res.data.user,
              type: 0,
              zong: arr
            })
          }
        })
      } else if (dedao == 1) {
        var tel = wx.getStorageSync('tel')
        wx.request({
          url: app.globalData.url + 'api/wish/xingcheng',
          data: {
            tel: tel,
            url: app.globalData.url
          },
          method: 'post',
          success: function (res) {
            console.log(res)
            var arr = []
            var arr1 = []
            var arr_1 = []
            if (res.data.list) {
              for (let i = 0; i < res.data.list.length; i++) {
                for (var j = 0; j < res.data.list[i].info.length; j++) {
                  var arr = arr.concat(res.data.list[i].info[j].id);
                }
              }
            }
            if (res.data.list_1) {
              for (let i = 0; i < res.data.list_1.length; i++) {
                for (var j = 0; j < res.data.list_1[i].info.length; j++) {
                  var arr_1 = arr_1.concat(res.data.list_1[i].info[j].id);
                }
              }
            }
            if (res.data.guo_list) {
              for (let a = 0; a < res.data.guo_list.length; a++) {
                for (var b = 0; b < res.data.guo_list[a].info.length; b++) {
                  var arr1 = arr1.concat(res.data.guo_list[a].info[b].id);
                }
              }
            }
            that.setData({
              list: res.data.list,
              list_1: res.data.list_1,
              g_list: res.data.guo_list,
              user: res.data.user,
              url: app.globalData.url,
              zong_look: arr,
              zong1_look: arr1,
              zong2_look: arr_1
            })
          }
        })
      } else if (dedao == 2) {
        var tel = wx.getStorageSync('tel')
        wx.request({
          url: app.globalData.url + 'api/wish/xingcheng_fd',
          data: {
            tel: tel,
            url: app.globalData.url
          },
          method: 'post',
          success: function (res) {
            console.log(res)
            var arr = []
            var arr1 = []
            if (res.data.yy_list) {
              for (let i = 0; i < res.data.yy_list.length; i++) {
                for (var j = 0; j < res.data.yy_list[i].info.length; j++) {
                  var arr = arr.concat(res.data.yy_list[i].info[j].id);
                }
              }
            }
            if (res.data.yy_list1) {
              for (let a = 0; a < res.data.yy_list1.length; a++) {
                for (var b = 0; b < res.data.yy_list1[a].info.length; b++) {
                  var arr1 = arr1.concat(res.data.yy_list1[a].info[b].id);
                }
              }
            }
            that.setData({
              list: res.data.yy_list,
              g_list: res.data.yy_list1,
              url: app.globalData.url,
              zong_fangdong: arr,
              zong1_fangdong: arr1
            })
          }
        })
      }
      var tel = wx.getStorageSync('tel')
    wx.request({
      url: app.globalData.url + 'api/index/check_status',
      data: {
        tel: tel
      },
      method: 'post',
      success: function (res) {
        console.log(res)
        if (res.data.info == 0) {
          wx.showModal({
            title: '提示',
            content: '账号已停用',
            showCancel: false, //是否显示取消按钮

            confirmText: "我知道了", //默认是“确定”
            success: function (res) {
              if (res.cancel) {
                //点击取消,默认隐藏弹框
              } else {
                console.log('封号')
                wx.removeStorageSync('tel')
                that.onLoad()
              }
            },
          })
        }
      }
    })
  },
  
})