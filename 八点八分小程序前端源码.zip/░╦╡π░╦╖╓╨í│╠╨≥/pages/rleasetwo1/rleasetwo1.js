let uploadimg = require('../../utils/util.js');
var dateTimePicker = require('../../utils/dateTimePicker.js');

const date = new Date()
const years = []
const months = []
const days = []

for (let i = date.getFullYear(); i <= 2100; i++) {
  years.push(i)
}

for (let i = 1; i <= 12; i++) {
  months.push(i)
}
for (let o = 1; o <= 31; o++) {
  days.push(o)
}

function search(arr, dst) {
  var i = arr.length;
  while (i -= 1) {
    if (arr[i] == dst) {
      return i;
    }
  }
  return false;
}
const app = getApp()
Page({

  /**
   * 页面的初始数据
   */
  data: {
    suishi: 0,
    years: years,
    year: date.getFullYear(),
    months: months,
    month: 2,
    days: days,
    day: 2,
    value: [0, 1, 1],
    dateTimeArray1: null,
    dateTime1: null,
    dateTimeArray2: null,
    dateTime2: null,
    _num: 1,
    nav: 0,
    yincang2: true,
    peizhi: [],
    yaoqiu: [],
    tese: [],
    type: 0,
    multiArray: [years, months, days],
    multiIndex: [2019, 8, 27],
    multiArray1: [years, months, days],
    multiIndex1: [2019, 8, 27],
    countryList14: ['1', '2', '3', '4', '5人以上'],
  },
  bindChange: function (e) {
    var val = e.detail.value
    var that = this
    console.log(e)
    var days = []
    var months = e.detail.value[1] + 1
    console.log(months)
    if (months == 1) {
      for (let o = 1; o <= 31; o++) {
        days.push(o)
      }
    } else if (months == 2) {
      for (let o = 1; o <= 29; o++) {
        days.push(o)
      }
    } else if (months == 3) {
      for (let o = 1; o <= 31; o++) {
        days.push(o)
      }
    } else if (months == 4) {
      for (let o = 1; o <= 30; o++) {
        days.push(o)
      }
    } else if (months == 5) {
      for (let o = 1; o <= 31; o++) {
        days.push(o)
      }
    } else if (months == 6) {
      for (let o = 1; o <= 30; o++) {
        days.push(o)
      }
    } else if (months == 7) {
      for (let o = 1; o <= 31; o++) {
        days.push(o)
      }
    } else if (months == 8) {
      for (let o = 1; o <= 31; o++) {
        days.push(o)
      }
    } else if (months == 9) {
      for (let o = 1; o <= 30; o++) {
        days.push(o)
      }
    } else if (months == 10) {
      for (let o = 1; o <= 31; o++) {
        days.push(o)
      }
    } else if (months == 11) {
      for (let o = 1; o <= 30; o++) {
        days.push(o)
      }
    } else if (months == 12) {
      for (let o = 1; o <= 31; o++) {
        days.push(o)
      }
    }
    console.log(days)
    that.setData({
      days: days
    })

    that.setData({
      year: that.data.years[val[0]],
      month: that.data.months[val[1]],
      day: that.data.days[val[2]],
      suishi: 0,
      rzsj1: that.data.years[val[0]] + '-' + that.data.months[val[1]] + '-' + that.data.days[val[2]]
    })
    var year = that.data.years[val[0]]
    var month = that.data.months[val[1]]
    var day = that.data.days[val[2]]
    app.globalData.zhu_time = year + '-' + month + '-' + day
  },
  suishi: function (e) {
    var that = this
    that.setData({
      suishi: 1,
      yincang2: true,
      bottom: -100
    })
    app.globalData.zhu_time = '随时入住'
  },
  bakbtn2: function (e) {
    this.setData({
      yincang2: true,
      bottom: -100
    })
  },
  liubtn2: function (e) {

    this.setData({
      yincang2: false,
      bottom: 0
    })
  },
  choose(e) {
    var that = this
    var arr = that.data.fwpz
    var peizhi = that.data.peizhi
    if (peizhi.length == 0) {
      for (var i = 0; i < arr.length; i++) {
        var peizhi = peizhi.concat(0)
      }
    }
    var id = e.currentTarget.dataset.id
    var index = e.currentTarget.dataset.index
    if (peizhi[index] == 0) {
      peizhi.splice(index, 1, id)
    }
    console.log(peizhi)
    app.globalData.peizhi = peizhi
    that.setData({
      peizhi: peizhi
    })
  },
  choose1: function (e) {
    var that = this
    var peizhi = that.data.peizhi
    var index = e.currentTarget.dataset.index
    var id = e.currentTarget.dataset.id
    peizhi.splice(index, 1, 0)
    console.log(peizhi)
    that.setData({
      peizhi: peizhi
    })
    app.globalData.peizhi = peizhi
  },
  change: function (e) {
    var that = this
    var arr = that.data.czyq
    var yaoqiu = that.data.yaoqiu
    if (yaoqiu.length == 0) {
      for (var i = 0; i < arr.length; i++) {
        var yaoqiu = yaoqiu.concat(0)
      }
    }
    var id = e.currentTarget.dataset.id
    var index = e.currentTarget.dataset.index
    if (yaoqiu[index] == 0) {
      yaoqiu.splice(index, 1, id)
    }
    console.log(yaoqiu)
    app.globalData.yaoqiu = yaoqiu
    that.setData({
      yaoqiu: yaoqiu
    })
  },
  change2: function (e) {
    var that = this
    var yaoqiu = that.data.yaoqiu
    var index = e.currentTarget.dataset.index
    var id = e.currentTarget.dataset.id
    yaoqiu.splice(index, 1, 0)
    console.log(yaoqiu)
    that.setData({
      yaoqiu: yaoqiu
    })
    app.globalData.yaoqiu = yaoqiu
  },
  change1: function (e) {
    var that = this
    var arr = that.data.fwts
    var tese = that.data.tese
    if (tese.length == 0) {
      for (var i = 0; i < arr.length; i++) {
        var tese = tese.concat(0)
      }
    }
    var id = e.currentTarget.dataset.id
    var index = e.currentTarget.dataset.index
    if (tese[index] == 0) {
      tese.splice(index, 1, id)
    }
    console.log(tese)
    app.globalData.tese = tese
    that.setData({
      tese: tese
    })
  },
  change3: function (e) {
    var that = this
    var tese = that.data.tese
    var index = e.currentTarget.dataset.index
    var id = e.currentTarget.dataset.id
    tese.splice(index, 1, 0)
    console.log(tese)
    that.setData({
      tese: tese
    })
    app.globalData.tese = tese
  },
  onclick: function (e) {
    this.setData({
      nav: e.currentTarget.dataset.index
    })
  },
  clickNum: function (e) {
    console.log(e.target.dataset.num)
    this.setData({
      _num: e.target.dataset.num
    })
  },
  checkboxChange: function (e) {
    console.log('checkbox发生change事件，携带value值为：', e.detail.value[0])
    app.globalData.chengnuo = e.detail.value[0]
  },
  checkboxChange1: function (e) {
    console.log('checkbox1发生change事件，携带value值为：', e.detail.value[0])
    app.globalData.weituo = e.detail.value[0]
  },
  /**
   * 生命周期函数--监听页面加载
   */
  changeCountry1(e) {
    this.setData({
      countryIndex1: e.detail.value
    });
  },
  changeCountry2(e) {
    this.setData({
      countryIndex2: e.detail.value
    });
  },
  changeCountry(e) {
    this.setData({
      countryIndex: e.detail.value
    });
  },
  changeCountry14(e) {
    this.setData({
      countryIndex14: e.detail.value
    });
  },
  onLoad: function (e) {
    var that = this
    wx.setNavigationBarTitle({
      title: '房源修改',
    })
    // 获取完整的年月日 时分秒，以及默认显示的数组
    var id = e.id
    app.globalData.f_id = id
    var ntime = Date.parse(new Date()) / 1000;
    console.log(ntime)
    var notime = uploadimg.formatTimeTwo(ntime)
    console.log(notime);
    that.setData({
      multiIndex: notime,
      multiIndex1: notime
    })
    wx.request({
      url: app.globalData.url + 'api/my/fabu_update_index2',
      data: {
        id: id
      },
      method: 'post',
      success: function (res) {
        console.log(res)
        app.globalData.chengnuo = 1
        var countryList = [];
        var countryList_id = [];
        for (var g = 0; g < res.data.kfsj.length; g++) {
          var countryList_id = countryList_id.concat(res.data.kfsj[g].id)
          var countryList = countryList.concat(res.data.kfsj[g].title)
        }
        var countryList2 = [];
        var countryList2_id = [];
        for (var h = 0; h < res.data.qzq.length; h++) {
          var countryList2_id = countryList2_id.concat(res.data.qzq[h].id)
          var countryList2 = countryList2.concat(res.data.qzq[h].title)
        }
        var countryList14 = [];
        for (var h = 0; h < res.data.yizhu.length; h++) {
          // var countryList2_id = countryList2_id.concat(res.data.qzq[h].id)
          var countryList14 = countryList14.concat(res.data.yizhu[h].title)
        }
        var z_time = res.data.rzsj
        var z_time_arr = z_time.split('-');
        var years = that.data.years
        var months = that.data.months
        var days = that.data.days
        var nian = search(years, z_time_arr[0]);
        var yue = search(months, z_time_arr[1])
        var ri = search(days, z_time_arr[2])

        console.log(nian, yue, ri)
        var value = [nian, yue, ri]
        that.setData({
          fwpz: res.data.fwpz,
          url: app.globalData.url,
          czyq: res.data.czyq,
          fwts: res.data.fwts,
          kan_time: res.data.kan_time,
          zhu_time: res.data.zhu_time,
          countryList: countryList,
          countryList_id: countryList_id,
          countryList2: countryList2,
          countryList14: countryList14,
          countryList2_id: countryList2_id,
          id: id,
          info: res.data.info,
          peizhi: res.data.peizhi,
          yaoqiu: res.data.yaoqiu,
          tese: res.data.tese,
          rzsj1: res.data.rzsj1,
          kfsj1: res.data.kfsj1,
          yizhu: res.data.info.yizhu,
          qizu: res.data.info.qizu,
          title: res.data.info.title,
          intro: res.data.info.content,
          value: value,
          intro1: res.data.intro,
          countryIndex: res.data.info.kfsj2,
          countryIndex14: res.data.info.yizhu2,
          countryIndex2: res.data.info.qzq2,
          guize: res.data.guize,
          hong: res.data.hong,
          xieyi: res.data.xieyi,
          fangyuanfabutishi: res.data.fangyuanfabutishi
        })
      }
    })
  },

  changeDateTimeColumn1(e) {
    console.log(e)
    var arr = this.data.dateTime1,
      dateArr = this.data.dateTimeArray1;

    arr[e.detail.column] = e.detail.value;
    dateArr[2] = dateTimePicker.getMonthDay(dateArr[0][arr[0]], dateArr[1][arr[1]]);
    console.log(dateArr)
    this.setData({
      dateTimeArray1: dateArr
    });
  },
  changeDateTimeColumn2(e) {
    console.log(e)
    var arr = this.data.dateTime2,
      dateArr = this.data.dateTimeArray2;

    arr[e.detail.column] = e.detail.value;
    dateArr[2] = dateTimePicker.getMonthDay(dateArr[0][arr[0]], dateArr[1][arr[1]]);
    console.log(dateArr)
    this.setData({
      dateTimeArray2: dateArr
    });
  },
  changeDateTime1(e) {
    console.log('111', e)
    var that = this

    that.setData({
      dateTime1: e.detail.value
    });
  },
  changeDateTime2(e) {
    console.log('111', e)
    var that = this
    that.setData({
      dateTime2: e.detail.value
    });
  },
  yizhu: function (e) {
    var that = this
    that.setData({
      yizhu: e.detail.value
    })
  },
  qizu: function (e) {
    var that = this
    that.setData({
      qizu: e.detail.value
    })
  },
  title: function (e) {
    var that = this
    that.setData({
      title: e.detail.value
    })
  },
  intro: function (e) {
    var that = this
    that.setData({
      intro: e.detail.value
    })
  },
  submit: function (e) {
    var that = this

    var kan_time = that.data.countryIndex
    var yizhu = that.data.countryIndex14
    var zhu_time = app.globalData.zhu_time
    var qizu = that.data.countryIndex2
    var peizhi = that.data.peizhi
    var yaoqiu = that.data.yaoqiu
    var tese = that.data.tese
    var title = that.data.title
    var intro = e.detail.value.intro
    var cailiao = app.globalData.cailiao
    var chengnuo = app.globalData.chengnuo
    var weituo = app.globalData.weituo
    if (!kan_time) {
      var kan_time = that.data.info.kfsj
    } else {
      var kan_time = that.data.countryList_id[kan_time]
    }
    if (!yizhu) {
      var yizhu = that.data.info.yizhu
    } else {
      var yizhu = that.data.countryList14[yizhu]
    }
    if (!zhu_time) {
      var zhu_time = that.data.info.zhu_time
    } else {
      var zhu_time = app.globalData.zhu_time
    }
    if (!qizu) {
      var qizu = that.data.info.qizu
    } else {
      var qizu = that.data.countryList2[qizu]
    }
    for (var i = 0; i < peizhi.length; i++) {
      if (peizhi[i] != 0) {
        var pz = 1;
        break;
      }
    }
    if (!pz) {
      wx.showToast({
        title: '请选择房屋配置',
        duration: 2000,
        icon: 'none'
      })
      return;
    }
    for (var y = 0; y < yaoqiu.length; y++) {
      if (yaoqiu[y] != 0) {
        var yq = 1;
        break;
      }
    }
    if (!yq) {
      wx.showToast({
        title: '请选择出租要求',
        duration: 2000,
        icon: 'none'
      })
      return;
    }
    for (var o = 0; o < tese.length; o++) {
      if (tese[o] != 0) {
        var ts = 1;
        break;
      }
    }
    if (!ts) {
      wx.showToast({
        title: '请选择房屋特色',
        duration: 2000,
        icon: 'none'
      })
      return;
    }
    if (!title) {
      wx.showToast({
        title: '请填写房屋标题',
        duration: 2000,
        icon: 'none'
      })
      return;
    }
    if (!intro) {
      wx.showToast({
        title: '请填写房屋描述',
        duration: 2000,
        icon: 'none'
      })
      return;
    }
    if (!cailiao) {
      var cailiao = that.data.info.cailiao
    } else {
      var cailiao = app.globalData.cailiao1
    }
    if (!app.globalData.shenfen) {
      var shenfen = that.data.info.shenfen
    } else {
      var shenfen = app.globalData.shenfen
    }
    // console.log(chengnuo)
    if (!chengnuo) {
      wx.showToast({
        title: "请勾选'" + that.data.intro1 + "'",
        duration: 2000,
        icon: 'none'
      })
      return;
    }

    for (var a = 0; a < peizhi.length; a++) {
      var pz1 = pz1 + ',' + peizhi[a]
    }
    for (var s = 0; s < yaoqiu.length; s++) {
      var yq1 = yq1 + ',' + yaoqiu[s]
    }
    for (var d = 0; d < tese.length; d++) {
      var ts1 = ts1 + ',' + tese[d]
    }
    for (var f = 0; f < app.globalData.fabu_yiyou.length; f++) {
      var fabu_yiyou = fabu_yiyou + '@' + app.globalData.fabu_yiyou[f]
    }
    console.log(pz, yq, ts)
    console.log(fabu_yiyou)
    // return
    wx.request({
      url: app.globalData.url + 'api/fabu/check_title_content',
      data: {
        title: title,
        content: intro,
      },
      method: 'post',
      success: function (ftc) {
        console.log(ftc)
        if (ftc.data.info != 1) {
          wx.showToast({
            title: '标题中存在敏感词,请重新输入',
            duration: 2000,
            icon: 'none'
          })
          return;
        } else if (ftc.data.info1 != 1) {
          wx.showToast({
            title: '描述中存在敏感词,请重新输入',
            duration: 2000,
            icon: 'none'
          })
          return;
        } else if (ftc.data.info == 1 && ftc.data.info1 == 1) {
          var data = []
          app.globalData.kfsj = kan_time
          app.globalData.yizhu = yizhu
          app.globalData.rzsj = zhu_time
          app.globalData.qizu = qizu
          app.globalData.fwpz = pz1
          app.globalData.czyq = yq1
          app.globalData.fwts = ts1
          app.globalData.title = title
          app.globalData.content = intro
          app.globalData.cailiao = cailiao
          app.globalData.fabu_yiyou = fabu_yiyou

          if (app.globalData.fabu_update.length != 0) {
            // console.log(app.globalData.fabu_update)
            that.uploadimg(data);
            wx.showToast({
              title: '请稍后...',
              duration: 2000000,
              icon: 'loading',
              mask: true
            })
          } else {
            wx.showToast({
              title: '请稍后...',
              duration: 2000000,
              icon: 'loading',
              mask: true
            })

            if (app.globalData.shipin) {
              that.uploadvideo();
            } else {
              app.globalData.shipin1 = that.data.info.video
              that.save()
            }
          }

          that.setData({
            type2: 0

          })

        }
      }
    })
  },
  save: function () {
    // console.log(app.globalData.ws)
    // return
    var that = this
    // console.log(app.globalData.kan_time + '---' + app.globalData.zhu_time + '---' + app.globalData.fwpz + '---' + app.globalData.yq1 + '----' + app.globalData.ts1)
    // return;
    wx.request({
      url: app.globalData.url + 'api/my/fabu_update_save',
      data: {
        id: app.globalData.f_id,
        fabu_pic: app.globalData.fabu_update1,
        fengmian: app.globalData.fengmian1,
        fabu_pic1: app.globalData.fabu_yiyou,
        fabu_video: app.globalData.shipin1,
        fylx: app.globalData.fylx_id,
        mendian: app.globalData.suoshugy,
        lc_tel: app.globalData.u_tel,
        nav: app.globalData.nav,
        xiaoquname: app.globalData.xq_name,
        addr: app.globalData.addr,
        menpai: app.globalData.menpai,
        mianji: app.globalData.mianji,
        huxing: app.globalData.huxing,
        cx: app.globalData.cx,
        ranqi: app.globalData.rq,
        yongdian: app.globalData.yd,
        yongshui: app.globalData.ys,
        high: app.globalData.louceng,
        zxqk: app.globalData.zxqk,
        setsex: app.globalData.setsex,
        lflx: app.globalData.lflx,
        price: app.globalData.price,
        yjfs: app.globalData.yjfs,
        wx: app.globalData.wx,
        cw: app.globalData.cw,
        intro: app.globalData.intro1,
        lat: app.globalData.ss_xq_latitude,
        lon: app.globalData.ss_sq_longitude,
        xiaoqu_addr: app.globalData.ss_xq_addr,
        kfsj: app.globalData.kfsj,
        yizhu: app.globalData.yizhu,
        rzsj: app.globalData.rzsj,
        qizu: app.globalData.qizu,
        fwpz: app.globalData.fwpz,
        czyq: app.globalData.czyq,
        fwts: app.globalData.fwts,
        title: app.globalData.title,
        content: app.globalData.content,
        shenfen: app.globalData.shenfen,
        cailiao: app.globalData.cailiao,
        chengnuo: app.globalData.chengnuo,
        weituo: app.globalData.weituo,
        ws: app.globalData.ws
      },
      method: 'post',
      success: function (res) {
        console.log(res)
        if (res.data.info == 1 || res.data.info == 0) {
          that.setData({
            type2: 1
          })
          wx.showToast({
            title: '修改成功，正在返回',
            duration: 2000,
            icon: 'none'
          })
          app.globalData.fabu = []
          app.globalData.fabu_yiyou = []
          app.globalData.fabu_update1 = ''
          app.globalData.fabu_update = []
          app.globalData.shipin = []
          app.globalData.shipin1 = ''
          app.globalData.cailiao = ''
          app.globalData.louceng = ''
          app.globalData.huxing = ''
          app.globalData.tempFilePaths1 = []
          app.globalData.zhu_time = ''
          app.globalData.weituo = undefined
          app.globalData.baozheng = undefined
          app.globalData.ss_sq_longitude = ''
          app.globalData.ss_xq_latitude = ''
          app.globalData.ss_xq_addr = undefined
          app.globalData.ss_xq_name = undefined
          setTimeout(function () {
            // wx.redirectTo({
            //   url: '../my_run/my_run?id=' + res.data.id,
            // })
            wx.navigateBack({
              delta: 2
            })
          }, 2000)
        }
      }
    })

  },
  xianshi: function () {
    var that = this
    if (that.data.type2 == 0) {
      wx.showToast({
        title: '提交中,请稍后...',
        duration: 10000000000000000,
        icon: 'none'
      })
    }
  },

  uploadimg: function (data) { //这里触发图片上传的方法
    var that = this
    var pics = app.globalData.fabu_update
    var i;

    i = data.i ? data.i : 0, //当前上传的哪张图片
      wx.uploadFile({
        url: app.globalData.url + 'api/fabu/img',
        filePath: pics[i],
        name: 'file', //这里根据自己的实际情况改
        formData: null, //这里是上传图片时一起上传的数据
        success: (resp) => {
          app.globalData.fabu_update1 = app.globalData.fabu_update1 + '@' + resp.data
          console.log(app.globalData.fabu_update1)
          var pic_str = app.globalData.fabu_update1
          if (pic_str) {
            console.log('zoule')
            var pic_arr = pic_str.split('@')
            if ((pic_arr.length - 1) == pics.length) {
              console.log('zoule1')

              if (app.globalData.shipin) {
                that.uploadvideo();
              } else {
                app.globalData.shipin1 = that.data.info.video
                that.save()
              }
            }
          }
        },
        complete: (res) => {
          i++; //这个图片执行完上传后，开始上传下一张
          if (i == pics.length) { //当图片传完时，停止调用          
            console.log('执行完毕');
          } else { //若图片还没有传完，则继续调用函数
            // console.log(i);
            data.i = i;
            that.uploadimg(data);
          }

        }
      });

  },
  uploadvideo: function () {
    var that = this
    var shipin = app.globalData.shipin
    console.log(shipin)

    wx.uploadFile({
      url: app.globalData.url + 'api/fabu/video',
      filePath: shipin,
      name: 'file',
      method: 'post',
      success: function (res) {
        //打印
        console.log(res)
        app.globalData.shipin1 = res.data
        that.save()
      }
    })

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {
    var that = this
    if (app.globalData.fabu_zhiding_id) {
      wx.request({
        url: app.globalData.url + 'api/fabu/fabu_zhiding_show',
        data: {
          id: app.globalData.fabu_zhiding_id
        },
        method: 'post',
        success: function (res) {
          console.log(res)
          that.setData({
            zhiding: 1,
            zd_title: res.data.info.title,
            zd_price: res.data.info.discount
          })
        }
      })
    }
  },
})