// pages/video/video.js
const app = getApp()
Page({
  data: {

  },
  onLoad: function (e) {
    var that = this
    wx.setNavigationBarTitle({
      title: app.globalData.webname,
    })
    var url = e.url
    console.log(url)
    that.setData({
      url: url,
      qian: app.globalData.url
    })
  },
})