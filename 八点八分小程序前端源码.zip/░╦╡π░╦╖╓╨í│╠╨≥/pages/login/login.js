const app = getApp()
Page({
  data: {
    type: 0,
    second: 60
  },
  onLoad: function (e) {
    wx.setNavigationBarTitle({
      title: '登录',
    })
    var that = this
    wx.request({
      url: app.globalData.url + '/api/about/login_tishi',
      method: 'post',
      success: function (res) {
        console.log(res)
        that.setData({
          logintishi1: res.data.logintishi1,
          logintishi2: res.data.logintishi2,
          xieyi1: res.data.xieyi1,
          xieyi2: res.data.xieyi2,
        })
      }
    })
    that.setData({
      login_logo: app.globalData.login_logo
    })
  },
  tel: function (e) {
    var that = this
    that.setData({
      tel: e.detail.value
    })
  },
  yzm1: function (e) {
    var that = this
    that.setData({
      yzm: e.detail.value
    })
  },
  submit: function (e) {
    var that = this
    var tel = that.data.tel
    var yzm = that.data.yzm
    if (!tel) {
      wx.showToast({
        title: '请填写手机号',
        duration: 2000,
        icon: 'none'
      })
      return;
    }
    if (!yzm) {
      wx.showToast({
        title: '请填写验证码',
        duration: 2000,
        icon: 'none'
      })
      return;
    }
    var myreg = /^((1[0-9]{2})+\d{8})$/;
    if (!myreg.test(tel)) {
      wx.showToast({
        title: "手机号格式有误",
        icon: 'none',
        duration: 2000
      })
      return false;
    }
    wx.request({
      url: app.globalData.url + 'api/my/wetlogin',
      data: {
        tel: tel,
        yzm: yzm,
        openid: wx.getStorageSync('openid'),
        uid: wx.getStorageSync('uid'),
        lat: app.globalData.lat,
        lng: app.globalData.lng,
        nickname: app.globalData.user_info.nickName,
        picture: app.globalData.user_info.avatarUrl
      },
      method: 'post',
      success: function (res) {
        console.log(res)
        if (res.data.info == 0) {
          wx.showToast({
            title: '验证码与手机不符',
            duration: 2000,
            icon: 'none'
          })
          return;
        } else {
          if (res.data.update == 1) {
            wx.setStorageSync('tel', tel)
            wx.showToast({
              title: '登录成功',
              duration: 2000,
              icon: 'none',
              mask:true
            })
            setTimeout(function () {
              wx.reLaunch({
                url: '../index/index',
              })
            }, 2000)
          }else{
            wx.showToast({
              title: '账号已停用',
              duration: 2000,
              icon: 'none',
              mask:true
            })
          }
        }
      }
    })
  },
  yzm: function (e) {
    var that = this
    var tel = that.data.tel
    if (!tel) {
      wx.showToast({
        title: '请填写手机号',
        duration: 2000,
        icon: 'none'
      })
      return;
    }
    wx.request({
      url: app.globalData.url + 'api/my/yzm',
      data: {
        tel: tel
      },
      method: 'post',
      success: function (res) {
        console.log(res)
        if (res.data.info == 0) {
          wx.showToast({
            title: '当前手机号未被注册',
            duration: 2000,
            icon: 'none',
            mask:true
          })
        } else if(res.data.info == 2){
          wx.showToast({
            title: '账号已停用',
            duration: 2000,
            icon: 'none',
            mask:true
          })
        }else if(res.data.info == 1){
          that.setData({
            success: 1
          })
          let promise = new Promise((resolve, reject) => {
            let setTimer = setInterval(
              () => {
                that.setData({
                  second: that.data.second - 1,
                })
                if (that.data.second <= 0) {
                  that.setData({
                    second: 60,
                    alreadySend: false,
                    send: true,
                  })
                  resolve(setTimer)
                }
              }, 1000)
            that.setData({
              disabled: 'disabled'
            })
          })
          promise.then((setTimer) => {
            clearInterval(setTimer)
            that.setData({
              success: 2,
              disabled: ''
            })
          })
        }
      }
    })
  },
  getPhoneNumber: function (e) {
    console.log(e)
    var that = this
    if (e.detail.errMsg === 'getPhoneNumber:ok') {
      wx.request({
        url: app.globalData.url + 'api/wechat/jiemi',
        data: {
          errMsg: e.detail.errMsg,
          encryptedData: e.detail.encryptedData,
          iv: e.detail.iv,
          sessionKey: wx.getStorageSync('sessionkey'),
        },
        method: 'post',
        header: {
          'content-type': 'application/x-www-form-urlencoded'
        },
        success: function (res) {
          console.log(res)
          that.setData({
            tel: res.data.purePhoneNumber
          })
          wx.request({
            url: app.globalData.url + 'api/wechat/kuaijie',
            data: {
              openid: wx.getStorageSync('openid'),
              tel: res.data.purePhoneNumber,
              uid: wx.getStorageSync('uid'),
              lat: app.globalData.lat,
              lng: app.globalData.lng,
              nickname: app.globalData.user_info.nickName,
              picture: app.globalData.user_info.avatarUrl
            },
            method: 'post',
            success: function (rag) {
              console.log(rag)
              if (rag.data.info != 0) {
                wx.showToast({
                  title: '快速登录成功',
                  duration: 2000,
                  icon: 'none'
                })
                wx.setStorageSync('tel', res.data.purePhoneNumber)
                setTimeout(function () {
                  wx.reLaunch({
                    url: '../index/index',
                  })
                }, 2000)
              }else{
                wx.showToast({
                  title: '账号已停用',
                  duration: 2000,
                  icon: 'none'
                })
              }
            }
          })
        },
        fail: function (err) {
          console.log(err);
        }
      })
    } else if (e.detail.errMsg === 'getPhoneNumber:fail user deny'){
      wx.showToast({
        title: '用户已取消快捷登录',
        icon: 'none',
        mask: true,
        duration: 2000
      })
    }
  },
  onShow: function () {
    wx.login({
      success: res => {
        app.globalData.user_code = res.code;
        console.log(app.globalData.user_code)
        
        // 发送 res.code 到后台换取 openId, sessionKey, unionId
      }
    })
  },
})