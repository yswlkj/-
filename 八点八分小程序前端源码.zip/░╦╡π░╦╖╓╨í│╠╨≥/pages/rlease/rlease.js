const app = getApp()
Page({
  data: {
    yincang: true,
    hidden: false,
    canIUseGetUserProfile: false,
  },
  liubtn: function (e) {
    var that = this
    var f_typeid = e.currentTarget.dataset.typeid
    var f_type = e.currentTarget.dataset.type
    var f_status = e.currentTarget.dataset.status
    that.setData({
      yincang: false,
      bottom: 0,
      f_typeid: f_typeid,
      f_type: f_type,
      f_status: f_status
    })
  },
  bakbtn: function (e) {
    var that = this
    var f_type = that.data.f_type
    var f_typeid = that.data.f_typeid
    var f_status = that.data.f_status
    var user = that.data.user
    if(f_status == 0){
      var tiaozhuan = 1;
    }else{
      var tiaozhuan = 1;
    }
    wx.navigateTo({
      url: '../personal/personal?zt='+user.type+'&f_status='+f_status+'&f_type='+f_type+'&f_typeid='+f_typeid+'&tiaozhuan='+tiaozhuan,
    })
    that.setData({
      yincang: true,
      bottom: -100
    })
  },
  onLoad: function (e) {
    var that = this
    wx.setNavigationBarTitle({
      title: app.globalData.webname,
    })
    if (wx.getUserProfile) {
      that.setData({
        canIUseGetUserProfile: true
      })
    }
    var tel = wx.getStorageSync('tel')
    if(tel){
      wx.request({
        url: app.globalData.url + 'api/rlease/show',
        data:{
          tel: tel
        },
        method:'post',
        success: function(res){
          console.log(res)
          that.setData({
            user: res.data.user,
            fy_list: res.data.fy_list,
            qz_list: res.data.qz_list,
            fy_count: res.data.fy_count,
            qz_count: res.data.qz_count,
            fy_type: res.data.fy_type,
            qz_type: res.data.qz_type,
            renzheng: res.data.renzheng,
            wechat: res.data.user.wechat,
            jianjie: res.data.user.jianjie
          })
        }
      })
      that.setData({
        type: 0
      })
    }else{
      that.setData({
        type: 1
      })
    }
    
    that.setData({
      tishi_logo: app.globalData.tishi_logo
    })
  },
  onShow: function () {
    var that = this
    var tel = wx.getStorageSync('tel')
    if (tel) {
      wx.request({
        url: app.globalData.url + 'api/rlease/show',
        data: {
          tel: tel
        },
        method: 'post',
        success: function (res) {
          console.log(res)
          that.setData({
            user: res.data.user,
            fy_list: res.data.fy_list,
            qz_list: res.data.qz_list,
            fy_count: res.data.fy_count,
            qz_count: res.data.qz_count,
            fy_type: res.data.fy_type,
            qz_type: res.data.qz_type,
            renzheng: res.data.renzheng,
            wechat: res.data.user.wechat,
            jianjie: res.data.user.jianjie
          })
        }
      })
      that.setData({
        type: 0
      })
    } else {
      that.setData({
        type: 1
      })
    }
    that.setData({
      tishi_logo: app.globalData.tishi_logo
    })
    var tel = wx.getStorageSync('tel')
    wx.request({
      url: app.globalData.url + 'api/index/check_status',
      data: {
        tel: tel
      },
      method: 'post',
      success: function (res) {
        console.log(res)
        if (res.data.info == 0) {
          wx.showModal({
            title: '提示',
            content: '账号已停用',
            showCancel: false, //是否显示取消按钮

            confirmText: "我知道了", //默认是“确定”
            success: function (res) {
              if (res.cancel) {
                //点击取消,默认隐藏弹框
              } else {
                console.log('封号')
                wx.removeStorageSync('tel')
                that.onLoad()
              }
            },
          })
        }
      }
    })
  },
  tiaozhuan: function(e){
    var that = this
    var typeid = e.currentTarget.dataset.typeid
    var type = e.currentTarget.dataset.type
    wx.request({
      url: app.globalData.url +'api/about/check_renzheng',
      data:{
        'tel': wx.getStorageSync('tel')
      },
      method: 'post',
      success: function(res){
        console.log(res)
        if(res.data.data == 0){
          wx.showToast({
            title: '后台审核成功后可发布房源',
            duration: 2000,
            icon: 'none',
            mask: true
          })
        }else if(res.data.data == 1){
          wx.navigateTo({
            url: '../rleaseone/rleaseone?type_id='+typeid+'&type='+type,
          })
        }else if(res.data.data == 2){
          wx.showToast({
            title: '正在前往进行房东认证',
            duration: 2000,
            icon: 'none'
          })
          setTimeout(function(){
            wx.navigateTo({
              url: '../attestation1/attestation1',
            })
          },2000)
        }
      }
    })
  },
  powerDrawer: function (e) {
    console.log(1)
    var currentStatu1 = e.currentTarget.dataset.statu;
    this.util(currentStatu1)
  },
  util: function (currentStatu1) {
    var animation1 = wx.createAnimation({
      duration: 1, 
      timingFunction: "linear", 
      delay: 0 
    });
    this.animation1 = animation1;
    animation1.translateX(240).step();
    this.setData({
      animationData1: animation1.export()
    })
    setTimeout(function () {
      animation1.translateX(0).step()
      this.setData({
        animationData1: animation1
      })
      if (currentStatu1 == "close") {
        this.setData(
          {
            showModalStatus1: false
          }
        );
      }
    }.bind(this), 1)
    if (currentStatu1 == "open") {
      this.setData(
        {
          showModalStatus1: true
        }
      );
    }
  },
  getUserProfile(e) {
    var that = this
    // 推荐使用wx.getUserProfile获取用户信息，开发者每次通过该接口获取用户个人信息均需用户确认
    // 开发者妥善保管用户快速填写的头像昵称，避免重复弹窗
    wx.getUserProfile({
      desc: '用于完善会员资料', // 声明获取用户个人信息后的用途，后续会展示在弹窗中，请谨慎填写
      success: (res) => {
        console.log(res)
        app.globalData.user_info = res.userInfo
        wx.login({
          success: res1 => {
            app.globalData.user_code = res1.code;
            wx.request({
              url: app.globalData.url + 'api/wechat/login',
              headers: {
                "Content-Type": "application/x-www-form-urlencoded"
              },
              data: {
                user_code: app.globalData.user_code,
                url: app.globalData.url,
                ip: wx.getStorageSync('ip')
              },
              method: 'POST',
              dataType: 'json',
              responseType: 'Text',
              success: function(res){
                console.log(res)
                var openid = res.data.info.openid
                var sessionkey = res.data.info.session_key
                wx.setStorageSync('sessionkey', sessionkey)
                wx.setStorageSync('openid', openid)
                wx.reLaunch({
                  url: '../login/login',
                })
              }
            })
          }
        })

        that.setData({
          userInfo: res.userInfo,
          hasUserInfo: true
        })
      }
    })
  },
  getUserInfo(e) {
    // 不推荐使用getUserInfo获取用户信息，预计自2021年4月13日起，getUserInfo将不再弹出弹窗，并直接返回匿名的用户个人信息
    this.setData({
      userInfo: e.detail.userInfo,
      hasUserInfo: true
    })
  },
  // getUserInfo(e) {
  //   console.log(e)
  //   var that = this
  //   if (e.detail.errMsg === 'getUserInfo:ok') {
  //     app.globalData.user_info = e.detail.userInfo
  //     console.log(app.globalData.user_info)
  //     wx.login({
  //       success: res => {
  //         app.globalData.user_code = res.code;
  //       }
  //     })
  //     app.globalData.iv = e.detail.iv
  //     app.globalData.encryptedData = e.detail.encryptedData
  //     app.globalData.errMsg = e.detail.errMsg
  //     wx.request({
  //       url: app.globalData.url + 'api/wechat/login',
  //       headers: {
  //         "Content-Type": "application/x-www-form-urlencoded"
  //       },
  //       data: {
  //         user_code: app.globalData.user_code,
  //         url: app.globalData.url,
  //         ip: wx.getStorageSync('ip')
  //       },
  //       method: 'POST',
  //       dataType: 'json',
  //       responseType: 'Text',
  //       success: function (res) {
  //         console.log(res)
  //         var openid = res.data.info.openid
  //         var sessionkey = res.data.info.session_key
  //         wx.setStorageSync('sessionkey', sessionkey)
  //         wx.setStorageSync('openid', openid)
  //         wx.reLaunch({
  //           url: '../login/login',
  //         })
  //       }
  //     })
  //   } else if (e.detail.errMsg === 'getUserInfo:fail auth deny') {
  //     wx.showToast({
  //       title: '取消授权将无法正常使用小程序',
  //       icon: 'none',
  //       duration: 5000
  //     })
  //     that.setData({
  //       warning: false,
  //     })
  //   }
  // },
  login: function(){
    var that = this
    var type = that.data.type
    if(type == 1){
      wx.showToast({
        title: '登录后可使用此功能',
        duration: 2000,
        icon: 'none'
      })
      
    }
  },
  change: function(e){
    var that = this
    wx.navigateTo({
      url: '../rlease_post/rlease_post',
    })
  },
  qiuzhengzu: function(e){
    var that = this
    wx.navigateTo({
      url: '../rlease_post/rlease_post?zt=0',
    })
  },
  qiuhezu: function (e) {
    var that = this
    wx.navigateTo({
      url: '../rlease_post/rlease_post?zt=1',
    })
  },
  change1: function (e) {
    var that = this
    wx.navigateTo({
      url: '../attestation/attestation',
    })
  },
  qiu_num: function(e){
    var that = this
    wx.showModal({
      title: '提示',
      content: '抱歉，您的发布次数已用完，可以下架或删除过期求租贴再发布哦～',
      confirmText: '去操作',
      cancelText: '暂不',
      success: function (res) {
        if (res.confirm) {
          wx.navigateTo({
            url: '../my_post/my_post',
          })
        } else if (res.cancel) {

        }
      }
    })
  },
  yongjin: function(e){
    var that = this
    wx.showModal({
      title: '提示',
      content: '抱歉，您的发布次数已用完，可以下架或删除过期房源再发布哦～',
      confirmText: '去操作',
      cancelText: '暂不', 
      success: function (res) {
        if (res.confirm) {
          wx.navigateTo({
            url: '../my_release/my_release?dedao=0',
          })
        } else if (res.cancel) {
          
        }
      }
    })
    
  },
  yongjin1: function (e) {
    var that = this
    wx.showToast({
      title: '抱歉,您尚未成为房东,正在前往进行房东认证',
      duration: 2000,
      icon: 'none'
    })
    setTimeout(function(){
      wx.navigateTo({
        url: '../attestation/attestation',
      })
    },2000)
  },

  /**
   * 生命周期函数--监听页面显示
   */
 
  tishi2:function(e){
    var that = this
    wx.showToast({
      title: '您的房东身份，正在加急审核，如有问题请联系客服~',
      duration: 2000,
      icon: 'none',
      mask: true,
    })
    return;
  },
  onShareAppMessage: function (e) {
    console.log(e)
    var that = this
    if(e.from == 'menu'){
      return {
        title: app.globalData.fenxiang1,
        path: '/pages/index/index',
        imageUrl: app.globalData.url + app.globalData.fenxiang,
        success: function (shareTickets) {
          console.info(shareTickets + '成功');
          // 转发成功
        },
        fail: function (res) {
          console.log(res + '失败');
          // 转发失败
        },
        complete: function (res) {
          // 不管成功失败都会执行
        }
      }
    }
  }
})