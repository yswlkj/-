// pages/mianroof/mianroof.js
const app = getApp()
Page({

  /**
   * 页面的初始数据
   */
  data: {

  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function(e) {
    var that = this
    wx.setNavigationBarTitle({
      title: '免费置顶',
    })
    var id = e.id
    var type = e.type
    that.setData({
      type: type
    })
    
    wx.request({
      url: app.globalData.url + 'api/about/kefu',
      data:{
        type: type,
        id: e.id,
        url: app.globalData.url
      },
      method: 'post',
      success: function(res) {
        console.log(res)
        that.setData({
          info: res.data.info,
          url: app.globalData.url,
          jieshi: res.data.jieshi,
          picss: res.data.picss,
          info1:res.data.info1
        })
      }
    })
  },
  saveImage: function(e) {　　　　　　　　　　　　　　　　 //触发函数
    console.log(e.currentTarget.dataset.pic)
    wx.downloadFile({
      url: e.currentTarget.dataset.pic,
      　　　　　　　 //需要下载的图片url
      success: function(res) {　　　　　　　　　　　　 //成功后的回调函数
        console.log(res)
        wx.saveImageToPhotosAlbum({　　　　　　　　　 //保存到本地
          filePath: res.tempFilePath,
          success(res) {
            wx.showToast({
              title: '保存成功',
              icon: 'success',
              duration: 2000
            })
          },
          fail: function(err) {
            if (err.errMsg === "saveImageToPhotosAlbum:fail auth deny" || err.errMsg === "saveImageToPhotosAlbum:fail:auth denied") {
              wx.openSetting({
                success(settingdata) {
                  console.log(settingdata)
                  if (settingdata.authSetting['scope.writePhotosAlbum']) {
                    wx.showModal({
                      title: '提示',
                      content: '获取权限成功,再次点击图片即可保存',
                      showCancel: false,
                    })
                  } else {
                    wx.showModal({
                      title: '提示',
                      content: '获取权限失败，将无法保存到相册哦~',
                      showCancel: false,
                    })
                  }
                }
              })
            }
          }
        })
      }
    });
  },
  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function() {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function() {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function() {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function() {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function() {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function() {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function(e) {
    console.log(e)
    var that = this
    if (that.data.type == 0) {
      if (that.data.info1.type == 0) {
        var title = '合租-' + that.data.info1.xiaoquname + '-' + that.data.info1.huxing[0] + '室' + that.data.info1.huxing[1] + '厅' + that.data.info1.huxing[2] + '卫'
      } else if (that.data.info1.type == 1) {
        var title = '整租-' + that.data.info1.xiaoquname + '-' + that.data.info1.huxing[0] + '室' + that.data.info1.huxing[1] + '厅' + that.data.info1.huxing[2] + '卫'
      }
      var picurl = that.data.info1.picurl
      var path = '/pages/home_ex/home_ex?id=' + that.data.info1.id
    } else {
      if (that.data.info1.zt == 0) {
        var title = '求整租-' + that.data.info1.xiaoqu + '-' + that.data.info1.huxing[0] + '室' + that.data.info1.huxing[1] + '厅' + that.data.info1.huxing[2] + '卫'
      } else if (that.data.info1.zt == 1) {
        var title = '求合租-' + that.data.info1.xiaoqu + '-' + that.data.info1.huxing[0] + '室' + that.data.info1.huxing[1] + '厅' + that.data.info1.huxing[2] + '卫'
      }
      var picurl = that.data.picss[0]
      var path = '/pages/rent_ex/rent_ex?id=' + that.data.info1.id
    }
    if (e.from == 'menu') {
      return {
        title: title,
        path: path,
        imageUrl: picurl,
        success: function(shareTickets) {
          console.info(shareTickets + '成功');
          // 转发成功
        },
        fail: function(res) {
          console.log(res + '失败');
          // 转发失败
        },
        complete: function(res) {
          // 不管成功失败都会执行
        }
      }
    } else if (e.from == 'button') {
      return {
        title: title,
        path: path,
        imageUrl: picurl,
        success: function(shareTickets) {
          console.info(shareTickets + '成功');
          // 转发成功
        },
        fail: function(res) {
          console.log(res + '失败');
          // 转发失败
        },
        complete: function(res) {
          // 不管成功失败都会执行
        }
      }
    }
  }
})