// pages/home_personal/home_personal.js
const app = getApp()
Page({

  /**
   * 页面的初始数据
   */
  data: {
    yincang: true,
    yincang1: true,
    yincang2: true,
  },
  jianjie: function (e) {

    this.setData({
      yincang2: false,
    })
  },
  jianjieclose: function (e) {
    this.setData({
      yincang2: true,
    })
  },
  renzheng: function (e) {
    console.log(1)
    var that = this
    that.setData({
      yincang: false,
    })
  },
  renzhengclose: function (e) {
    this.setData({
      yincang: true,
    })
  },
  renzheng1: function (e) {
    console.log(2)
    var that = this
    that.setData({
      yincang1: false,
    })
  },
  renzhengclose1: function (e) {
    this.setData({
      yincang1: true,
    })
  },
  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (e) {
    var that = this
    var id = e.id
    var type = e.type
    var u_type = e.u_type
    var zt = e.zt
    wx.setNavigationBarTitle({
      title: '房东详情',
    })
    wx.request({
      url: app.globalData.url + 'api/person/show1',
      data:{
        id: id,
        type: type,
        fid: e.fid,
        url: app.globalData.url,
        lng: app.globalData.lng,
        lat: app.globalData.lat,
        tel: wx.getStorageSync('tel')
      },
      method: 'post',
      success: function(res){
        console.log(res)
        that.setData({
          user: res.data.user,
          list: res.data.list,
          type: type,
          url: app.globalData.url,
          bq_list: res.data.bq_list,
          xianshi1: res.data.xianshi1,
          xianshi2: res.data.xianshi2,
          u_type: u_type,
          zt: zt,
          pinpai: app.globalData.pinpai,
          wei: app.globalData.wei,
          bao: app.globalData.bao,
          youxuan: app.globalData.youxuan,
          pinpai1: app.globalData.pinpai1,
          wei1: app.globalData.wei1,
          bao1: app.globalData.bao1,
          youxuan1: app.globalData.youxuan1,
          gengxin: app.globalData.gengxin
        })
      }
    })
  },
  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function (e) {
    console.log(e)
    var that = this
    if (e.from == 'menu') {
      return {
        title: app.globalData.fenxiang1,
        path: '/pages/index/index',
        imageUrl: app.globalData.url + app.globalData.fenxiang,
        success: function (shareTickets) {
          console.info(shareTickets + '成功');
          // 转发成功
        },
        fail: function (res) {
          console.log(res + '失败');
          // 转发失败
        },
        complete: function (res) {
          // 不管成功失败都会执行
        }
      }
    }
  }
})