const app = getApp()
var QQMapWX = require('../../libs/qqmap-wx-jssdk.js');
var qqmapsdk = new QQMapWX({
  key: 'I4CBZ-FYL6G-X2LQD-I56ON-N6K7E-UQFK4' // 必填
});
Page({
  data: {
    leibie: [{
      title: "全部",
      id: 0
    },
    {
      title: "合租",
      id: 11
    },
    {
      title: "整租",
      id: 13
    }],
    yincang1: true,
    yincang2: true,
    yincang3: true,
    yincang4: true,
    yincang5: true,
    hidden: false,
    index: 1,
    index1: 0,
    index2: 0,
    index3: 0,
    index4: 0,
    fuwu: [],
    tese: [],
    tese1: [],
    fuwu1: [],
    hd: [],
    hd1: [],
    nav:0,
    nav1: 1,
    nav2: 1,
    nav3: 1,
    nav4: 1,
  },
  choose(e) {
    var that = this
    var arr = that.data.configure
    var fuwu = that.data.fuwu
    if (fuwu.length == 0) {
      for (var i = 0; i < arr.length; i++) {
        var fuwu = fuwu.concat(0)
      }
    }
    var id = e.currentTarget.dataset.id
    var index = e.currentTarget.dataset.index
    if (fuwu[index] == 0) {
      fuwu.splice(index, 1, id)
    }
    console.log(fuwu)
    app.globalData.fuwu = fuwu
    that.setData({
      fuwu: fuwu
    })
  },
  choose_1: function(e) {
    var that = this
    var fuwu = that.data.fuwu
    var index = e.currentTarget.dataset.index
    var id = e.currentTarget.dataset.id
    fuwu.splice(index, 1, 0)
    console.log(fuwu)
    that.setData({
      fuwu: fuwu
    })
    app.globalData.fuwu = fuwu
  },
  choose1(e) {
    var that = this
    var arr = that.data.configure1
    var tese = that.data.tese
    if (tese.length == 0) {
      for (var i = 0; i < arr.length; i++) {
        var tese = tese.concat(0)
      }
    }
    var id = e.currentTarget.dataset.id
    var index = e.currentTarget.dataset.index
    if (tese[index] == 0) {
      tese.splice(index, 1, id)
    }
    console.log(tese)
    app.globalData.tese = tese
    that.setData({
      tese: tese
    })
  },
  choose1_1: function(e) {
    var that = this
    var tese = that.data.tese
    var index = e.currentTarget.dataset.index
    var id = e.currentTarget.dataset.id
    tese.splice(index, 1, 0)
    console.log(tese)
    that.setData({
      tese: tese
    })
    app.globalData.tese = tese
  },
  choose2(e) {
    var that = this
    var index2 = e.currentTarget.dataset.index
    if (index2 == that.data.index2) {
      var index2 = 0
    }
    app.globalData.lx_id = index2
    that.setData({
      index2: index2,
      lx_id: index2,
    })
  },
  choose2_1(e) {
    var that = this
    var index2 = e.currentTarget.dataset.index
    if (index2 == that.data.lx_index2) {
      var index2 = 0
    }
    app.globalData.lb_id = index2
    that.setData({
      lb_index2: index2,
      lb_id: index2,
    })
  },
  choose3(e) {
    var that = this
    var index3 = e.currentTarget.dataset.index
    console.log(e)
    if (index3 == that.data.index3) {
      var index3 = 0
    }
    app.globalData.hx_id = index3
    that.setData({
      index3: index3
    })
  },
  choose4(e) {
    var that = this
    var index4 = e.currentTarget.dataset.index
    console.log(e)
    if (index4 == that.data.index4) {
      var index4 = 0
    }
    that.setData({
      index4: index4
    })
  },
  choose5(e) {
    var that = this
    var arr = that.data.huodong
    var fuwu = that.data.hd
    if (fuwu.length == 0) {
      for (var i = 0; i < arr.length; i++) {
        var fuwu = fuwu.concat(0)
      }
    }
    var id = e.currentTarget.dataset.id
    var index = e.currentTarget.dataset.index
    if (fuwu[index] == 0) {
      fuwu.splice(index, 1, id)
    }
    console.log(fuwu)
    app.globalData.hd = fuwu
    that.setData({
      hd: fuwu
    })
  },
  choose5_1: function (e) {
    var that = this
    var fuwu = that.data.hd
    var index = e.currentTarget.dataset.index
    var id = e.currentTarget.dataset.id
    fuwu.splice(index, 1, 0)
    console.log(fuwu)
    that.setData({
      hd: fuwu
    })
    app.globalData.hd = fuwu
  },
  liubtn5: function(e) {
    var that = this
    wx.createSelectorQuery().select('#box').boundingClientRect(function (rect) {
      console.log(rect)
      var height = Number(rect.height)+Number(20)
      // console.log(height,1)
      that.setData({
        height: height
      })
    }).exec()
    that.setData({
      
      yincang5: false,
      yincang1: true,
      yincang2: true,
      yincang3: true,
      yincang4: true,
      bottom: 0
    })
  },
  bakbtn7: function(e) {
    console.log('bakbtn7')
    this.setData({
      nav4: 1,
      yincang5: true,
      bottom: -100
    })
  },
  liubtn1: function(e) {
    var that = this
    wx.createSelectorQuery().select('#box').boundingClientRect(function (rect) {
      console.log(rect)
      var height = Number(rect.height)+Number(20)
      // console.log(height,1)
      that.setData({
        height: height
      })
    }).exec()
    that.setData({
      
      yincang1: false,
      yincang2: true,
      yincang3: true,
      yincang4: true,
      yincang5: true,
      bottom: 0
    })
  },
  bakbtn1: function(e) {
    var that = this
    that.setData({
      nav: 0,
      yincang1: true,
      bottom: -100
    })
  },
  submit: function(e) {
    var that = this
    // var lb_id = that.data.lb_index2
    // var lx_id = that.data.index2
    // var hx_id = that.data.index3
    var hd = app.globalData.hd
    var fuwu = app.globalData.fuwu
    var tese = app.globalData.tese
    if (hd) {
      for (var s = 0; s < hd.length; s++) {
        var hd1 = hd1 + ',' + hd[s]
      }
    }
    if (fuwu) {
      for (var i = 0; i < fuwu.length; i++) {
        var fuwu1 = fuwu1 + ',' + fuwu[i]
      }
    }
    if (tese) {
      for (var p = 0; p < tese.length; p++) {
        var tese1 = tese1 + ',' + tese[p]
      }
    }
    if (app.globalData.city_code) {
      var city_code = app.globalData.city_code
    } else {
      var city_code = 1;
    }
    app.globalData.hd_str = hd1
    app.globalData.fuwu_str = fuwu1
    // app.globalData.lb_id = lb_id
    // app.globalData.lx_id = lx_id
    // app.globalData.hx_id = hx_id
    app.globalData.tese_str = tese1
    if (app.globalData.ss_sq_longitude && app.globalData.ss_xq_latitude) {
      var lat = app.globalData.ss_xq_latitude
      var lng = app.globalData.ss_sq_longitude
    } else {
      var lat = app.globalData.lat
      var lng = app.globalData.lng
    }
    wx.request({
      url: app.globalData.url + 'api/tejia/glist',
      data: {
        hd: hd1,
        fuwu: fuwu1,
        tese: tese1,
        lat: lat,
        lng: lng,
        city_code: city_code,
        type: 21,
        url: app.globalData.url,

        pid: app.globalData.px_id,//排序
        
        lb_id: app.globalData.lb_id,//房源类型
        lx_id: app.globalData.lx_id,//房源类型
        hx_id: app.globalData.hx_id,//户型
        hd: app.globalData.hd_str,//活动
        fuwu: app.globalData.fuwu_str,//服务
        tese: app.globalData.tese_str,//特色
        x: app.globalData.x,
        y: app.globalData.y,

        zhan: app.globalData.zhan_str,//地铁

        jie: app.globalData.jie_str,//地区
      },
      method: 'post',
      success: function(res) {
        console.log(res)
        that.setData({
          plist: res.data.plist,
          plist1: res.data.plist1,
          plist2: res.data.plist2,
          count: res.data.count1,
          
          yincang5: true,
          nav4: 1,
        })
      }
    })
  },
  bakbtn: function(e) {
    var that = this
    wx.setNavigationBarTitle({
      title: '特价公寓',
    })
    if (that.data.zid == 0) {
      var zhan = that.data.dt_zhan.toString()
    } else {
      var zhan = that.data.kong_zhan.toString()
    }
    if (app.globalData.city_code) {
      var city_code = app.globalData.city_code
    } else {
      var city_code = 0
    }
    if (app.globalData.ss_sq_longitude && app.globalData.ss_xq_latitude) {
      var lat = app.globalData.ss_xq_latitude
      var lng = app.globalData.ss_sq_longitude
    } else {
      var lat = app.globalData.lat
      var lng = app.globalData.lng
    }
    console.log(zhan)
    wx.request({
      url: app.globalData.url + 'api/tejia/glist',
      data: {
        zhan: zhan,
        type: 21,
        url: app.globalData.url,
        city_code: city_code,


        pid: app.globalData.px_id,//排序
        lat: lat,//据当前距离
        lng: lng,//据当前距离
        lb_id: app.globalData.lb_id,//房源类型
        lx_id: app.globalData.lx_id,//房源类型
        hx_id: app.globalData.hx_id,//户型
        hd: app.globalData.hd_str,//活动
        fuwu: app.globalData.fuwu_str,//服务
        tese: app.globalData.tese_str,//特色
        x: app.globalData.x,
        y: app.globalData.y,

        jie: app.globalData.jie_str,//地区
      },
      method: 'post',
      success: function(res) {
        console.log(res)

        that.setData({
          plist: res.data.plist,
          plist1: res.data.plist1,
          plist2: res.data.plist2,
        })
      }
    })
    that.setData({
      nav: 1,
      yincang1: true,
      bottom: -100,
    })
  },
  liubtn2: function(e) {

    var that = this
    wx.createSelectorQuery().select('#box').boundingClientRect(function (rect) {
      console.log(rect)
      var height = Number(rect.height)+Number(20)
      // console.log(height,1)
      that.setData({
        height: height
      })
    }).exec()
    that.setData({
      
      yincang2: false,
      yincang1: true,
      yincang3: true,
      yincang4: true,
      yincang5: true,
      bottom: 0
    })
  },
  bakbtn2: function(e) {
    this.setData({
      nav1: 0,
      yincang2: true,
      bottom: -100
    })
  },
  liubtn3: function(e) {

    var that = this
    wx.createSelectorQuery().select('#box').boundingClientRect(function (rect) {
      console.log(rect)
      var height = Number(rect.height)+Number(20)
      // console.log(height,1)
      that.setData({
        height: height
      })
    }).exec()
    that.setData({
      
      yincang3: false,
      yincang1: true,
      yincang2: true,
      yincang4: true,
      yincang5: true,
      bottom: 0
    })
  },
  bakbtn5: function(e) {
    console.log('bakbtn5')
    this.setData({
      nav2: 0,
      yincang3: true,
      bottom: -100
    })
  },
  liubtn4: function(e) {

    var that = this
    wx.createSelectorQuery().select('#box').boundingClientRect(function (rect) {
      console.log(rect)
      var height = Number(rect.height)+Number(20)
      // console.log(height,1)
      that.setData({
        height: height
      })
    }).exec()
    that.setData({
      
      yincang4: false,
      yincang1: true,
      yincang2: true,
      yincang3: true,
      yincang5: true,
      bottom: 0
    })
  },
  bakbtn6: function(e) {
    this.setData({
      nav3: 0,
      yincang4: true,
      bottom: -100
    })
  },
  bakbtn3: function(e) {
    var that = this
    wx.setNavigationBarTitle({
      title: '特价公寓',
    })
    if (that.data.jid == 0) {
      var jie = that.data.jie_arr.toString()
    } else {
      var jie = that.data.kong_jie.toString()
    }
    if (app.globalData.ss_sq_longitude && app.globalData.ss_xq_latitude) {
      var lat = app.globalData.ss_xq_latitude
      var lng = app.globalData.ss_sq_longitude
    } else {
      var lat = app.globalData.lat
      var lng = app.globalData.lng
    }
    wx.request({
      url: app.globalData.url + 'api/tejia/glist',
      data: {
        type: 21,
        jie: jie,
        url: app.globalData.url,
        city_code: app.globalData.city_code,

        pid: app.globalData.px_id,//排序
        lat: lat,//据当前距离
        lng: lng,//据当前距离
        lb_id: app.globalData.lb_id,//房源类型
        lx_id: app.globalData.lx_id,//房源类型
        hx_id: app.globalData.hx_id,//户型
        hd: app.globalData.hd_str,//活动
        fuwu: app.globalData.fuwu_str,//服务
        tese: app.globalData.tese_str,//特色
        x: app.globalData.x,
        y: app.globalData.y,

        zhan: app.globalData.zhan_str,//地铁
      },
      method: 'post',
      success: function(res) {
        console.log(res)
        that.setData({
          plist: res.data.plist,
          plist1: res.data.plist1,
          plist2: res.data.plist2,
        })
      }
    })
    if (that.data.line_num == 0) {
      that.setData({
        nav: 1
      })
    } else {
      that.setData({
        nav1: 0
      })
    }
    that.setData({
      nav1: 0,
      yincang2: true,
      bottom: -100,
    })
  },
  bakbtn4: function(e) {
    var that = this
    var arr = that.data.configure1
    var tese = that.data.tese1
    if (tese.length == 0) {
      for (var i = 0; i < arr.length; i++) {
        var tese = tese.concat(0)
      }
    }
    var arr1 = that.data.configure
    var fuwu = that.data.fuwu1
    if (fuwu.length == 0) {
      for (var a = 0; a < arr1.length; a++) {
        var fuwu = fuwu.concat(0)
      }
    }
    var arr2 = that.data.huodong
    var hd = that.data.hd1
    if (hd.length == 0) {
      for (var s = 0; s < arr2.length; s++) {
        var hd = hd.concat(0)
      }
    }
    app.globalData.hd_str = ''
    app.globalData.hd = []
    app.globalData.fuwu = []
    app.globalData.tese = []
    app.globalData.lb_id = ''
    app.globalData.fuwu_str = ''
    app.globalData.lx_id = ''
    app.globalData.hx_id = ''
    app.globalData.tese_str = ''
    that.setData({
      yincang5: true,
      index2: '',
      index3: '',
      index4: '',
      tese: tese,
      fuwu: fuwu,
      hd: hd,
      nav4: 1,
      lx_index2: 0,
      hx_index3: 0,
      bottom: -100
    })

    that.onLoad()
  },
  bakbtn4_1: function(e) {
    var that = this
    var arr = that.data.configure1
    var tese = that.data.tese1
    if (tese.length == 0) {
      for (var i = 0; i < arr.length; i++) {
        var tese = tese.concat(0)
      }
    }
    var arr1 = that.data.configure
    var fuwu = that.data.fuwu1
    if (fuwu.length == 0) {
      for (var a = 0; a < arr1.length; a++) {
        var fuwu = fuwu.concat(0)
      }
    }
    that.setData({
      yincang2: true,
      bottom: -100,
      index2: '',
      index3: '',
      index4: '',
      nav1: 1,
      tese: tese,
      fuwu: fuwu,
    })
    that.onLoad()
  },
  bakbtn4_2: function(e) {
    var that = this
    that.setData({
      zid: 1,
      lid: 1,
      yincang1: true,
      nav: 0
    })
    var id = that.data.id

    that.onLoad(id)
  },
  zj1: function (e) {
    var that = this
    var id = e.currentTarget.dataset.id
    that.setData({
      zid: id
    })
  },
  zj1_1: function (e) {
    var that = this

    that.setData({
      yincang3: true,
      zid: 0,
      nav2: 1
    })
    var id = that.data.id

    that.onLoad(id)
  },
  zj: function(e) {
    var that = this
    wx.setNavigationBarTitle({
      title: '特价公寓',
    })
    if (app.globalData.city_code) {
      var city_code = app.globalData.city_code
    } else {
      var city_code = 1;
    }
    var id = e.currentTarget.dataset.id
    if (app.globalData.ss_sq_longitude && app.globalData.ss_xq_latitude) {
      var lat = app.globalData.ss_xq_latitude
      var lng = app.globalData.ss_sq_longitude
    } else {
      var lat = app.globalData.lat
      var lng = app.globalData.lng
    }
    wx.request({
      url: app.globalData.url + 'api/tejia/glist',
      data: {
        id: id,
        type: 21,
        url: app.globalData.url,
        city_code: city_code,
        pid: app.globalData.px_id,//排序
        lat: lat,//据当前距离
        lng: lng,//据当前距离
        lb_id: app.globalData.lb_id,//房源类型
        lx_id: app.globalData.lx_id,//房源类型
        hx_id: app.globalData.hx_id,//户型
        hd: app.globalData.hd_str,//活动
        fuwu: app.globalData.fuwu_str,//服务
        tese: app.globalData.tese_str,//特色
        x: app.globalData.x,
        y: app.globalData.y,

        zhan: app.globalData.zhan_str,//地铁

        jie: app.globalData.jie_str,//地区
      },
      method: 'post',
      success: function(res) {
        console.log(res)

        that.setData({
          zid: id,
          plist: res.data.plist,
          plist1: res.data.plist1,
          plist2: res.data.plist2,
          nav2:0,
          yincang3: true,
        })
      }
    })
  },
  px: function(e) {
    var that = this
    wx.setNavigationBarTitle({
      title: '特价公寓',
    })
    var id = e.currentTarget.dataset.id
    var type = 21
    if(id == 46){
      app.globalData.ss_sq_longitude = ''
      app.globalData.ss_xq_latitude = ''
    }
    if (app.globalData.ss_sq_longitude && app.globalData.ss_xq_latitude) {
      var lat = app.globalData.ss_xq_latitude
      var lng = app.globalData.ss_sq_longitude
    } else {
      var lat = app.globalData.lat
      var lng = app.globalData.lng
    }
    wx.request({
      url: app.globalData.url + 'api/tejia/glist',
      data: {
        pid: id,
        type: type,
        lat: lat,
        lng: lng,
        
        url: app.globalData.url,
        city_code: app.globalData.city_code,

        
        lb_id: app.globalData.lb_id,//房源类型
        lx_id: app.globalData.lx_id,//房源类型
        hx_id: app.globalData.hx_id,//户型
        hd: app.globalData.hd_str,//活动
        fuwu: app.globalData.fuwu_str,//服务
        tese: app.globalData.tese_str,//特色
        x: app.globalData.x,
        y: app.globalData.y,

        zhan: app.globalData.zhan_str,//地铁

        jie: app.globalData.jie_str,//地区
      },
      method: 'post',
      success: function(res) {
        console.log(res)
        that.setData({
          plist: res.data.plist,
          plist1: res.data.plist1,
          plist2: res.data.plist2,
          pid: id,
          nav3:1,
          yincang4: true,
        })
      }
    })
  },
  gongsi: function(e) {
    var that = this
    var id = e.currentTarget.dataset.id
    app.globalData.gongsi = id
    app.globalData.px_id = id
    wx.navigateTo({
      url: '../map/map',
    })
  },
  click: function(e) {
    var that = this
    var id = e.currentTarget.dataset.id
    qqmapsdk.getDistrictByCityId({
      id: id,
      success: function(rag) {
        console.log(rag);
        console.log('市/区：', rag.result[0]);
        that.setData({
          jie: rag.result[0],
          fid: id,
          jid: 0
        })
        that.reload()
      },
    });
  },
  reload: function() {
    var that = this
    console.log(that.data.jie)
    var arr = [];
    for (var i = 0; i < that.data.jie.length; i++) {
      var arr = arr.concat(that.data.jie[i].id)
    }
    var arr1 = [];
    for (var i = 0; i < that.data.jie.length; i++) {
      var arr1 = arr1.concat(0)
    }
    that.setData({
      kong_jie: arr1,
      jie_arr: arr
    })
  },
  click1: function(e) {
    var that = this
    var id = e.currentTarget.dataset.id
    wx.request({
      url: app.globalData.url + 'api/mokuai/zhan',
      data: {
        id: id
      },
      method: 'post',
      success: function(res) {
        console.log(res)
        var arr = []
        for (var i = 0; i < res.data.length; i++) {
          var arr = arr.concat(res.data[i].id)
        }
        var arr1 = []
        for (var a = 0; a < res.data.length; a++) {
          var arr1 = arr1.concat(0)
        }
        that.setData({
          zhan: res.data,
          lid: id,
          zid: 0,
          dt_zhan: arr,
          kong_zhan: arr1
        })
      }
    })
  },
  click2: function(e) {
    var that = this
    var id = e.currentTarget.dataset.id
    var index = e.currentTarget.dataset.index
    var dt_zhan = that.data.dt_zhan
    var kong_zhan = that.data.kong_zhan
    if (kong_zhan[index] == 0) {
      kong_zhan.splice(index, 1, id)
    }
    that.setData({
      kong_zhan: kong_zhan,
      zid: 1
    })
  },
  click2_1: function(e) {
    var that = this
    var kong_zhan = that.data.kong_zhan
    var index = e.currentTarget.dataset.index
    var id = e.currentTarget.dataset.id
    kong_zhan.splice(index, 1, 0)
    console.log(kong_zhan)
    that.setData({
      kong_zhan: kong_zhan,
      zid: 1
    })
  },
  click2_2: function(e) {
    var that = this
    var zhan1 = that.data.dt_zhan
    var id = e.currentTarget.dataset.id
    var arr = []

    for (var i = 0; i < zhan1.length; i++) {
      var arr = arr.concat(0)
    }
    that.setData({
      kong_zhan: arr,
      zid: id
    })
  },
  click3: function(e) {
    var that = this
    var id = e.currentTarget.dataset.id
    var index = e.currentTarget.dataset.index
    var jie_arr = that.data.jie_arr
    var kong_jie = that.data.kong_jie
    if (kong_jie[index] == 0) {
      kong_jie.splice(index, 1, id)
    }
    that.setData({
      kong_jie: kong_jie,
      jid: 1
    })
  },
  click3_1: function(e) {
    var that = this
    var kong_jie = that.data.kong_jie
    var index = e.currentTarget.dataset.index
    var id = e.currentTarget.dataset.id
    kong_jie.splice(index, 1, 0)
    console.log(kong_jie)
    that.setData({
      kong_jie: kong_jie,
      jid: 1
    })
  },
  click3_2: function(e) {
    var that = this
    var that = this
    var zhan1 = that.data.jie_arr
    var id = e.currentTarget.dataset.id
    var arr = []

    for (var i = 0; i < zhan1.length; i++) {
      var arr = arr.concat(0)
    }
    that.setData({
      kong_jie: arr,
      jid: id
    })
  },
  onLoad: function(e) {
    var that = this
    wx.setNavigationBarTitle({
      title: '特价公寓',
    })
    app.globalData.hd_str = ''
    app.globalData.lb_id = ''
    app.globalData.fuwu_str = ''
    app.globalData.lx_id = ''
    app.globalData.hx_id = ''
    app.globalData.tese_str = ''
    if (app.globalData.ss_sq_longitude && app.globalData.ss_xq_latitude) {
      var lat = app.globalData.ss_xq_latitude
      var lng = app.globalData.ss_sq_longitude
    } else {
      var lat = app.globalData.lat
      var lng = app.globalData.lng
    }
    wx.request({
      url: app.globalData.url + 'api/tejia/glist',
      data: {
        type: 21,
        url: app.globalData.url,
        city_code: app.globalData.city_code,

        pid: app.globalData.px_id,//排序
        lat1: lat,//据当前距离
        lng1: lng,//据当前距离
        lb_id: app.globalData.lb_id,//房源类型
        lx_id: app.globalData.lx_id,//房源类型
        hx_id: app.globalData.hx_id,//户型
        hd: app.globalData.hd_str,//活动
        fuwu: app.globalData.fuwu_str,//服务
        tese: app.globalData.tese_str,//特色
        x: app.globalData.x,
        y: app.globalData.y,

        zhan: app.globalData.zhan_str,//地铁

        jie: app.globalData.jie_str,//地区
      },
      method: 'post',
      success: function(res) {
        console.log(res)
        that.setData({
          t_info: res.data.t_info,
          plist: res.data.plist,
          plist1: res.data.plist1,
          plist2: res.data.plist2,
          fanwei: res.data.fanwei,
          paixu: res.data.paixu,
          huxing: res.data.hx_array,
          configure1: res.data.ts_arr,
          leixing: res.data.lx_arr,
          huodong: res.data.hd_arr,
          configure: res.data.fw_arr,
          url: app.globalData.url,
          lb_zt: res.data.lb_zt,
          pinpai: app.globalData.pinpai,
          wei: app.globalData.wei,
          bao: app.globalData.bao,
          youxuan: app.globalData.youxuan,
          pinpai1: app.globalData.pinpai1,
          wei1: app.globalData.wei1,
          bao1: app.globalData.bao1,
          youxuan1: app.globalData.youxuan1,
          gengxin: app.globalData.gengxin
        })
      }
    })
  },
  onShow: function() {
    var that = this;
    wx.setNavigationBarTitle({
      title: '特价公寓',
    })
    var city_name = app.globalData.city_name
    wx.request({
      url: app.globalData.url + 'api/mokuai/step',
      data: {
        city: city_name
      },
      method: 'post',
      success: function(res) {
        console.log(res)
        that.setData({
          line: res.data,
          line_num: res.data.length
        })
      }
    })
    qqmapsdk.getDistrictByCityId({
      id: app.globalData.city_code,
      success: function(rag) {
        console.log(rag);
        console.log('市/区：', rag.result[0]);
        that.setData({
          qu: rag.result[0]
        })
      },
    });
    if (app.globalData.ss_xq_latitude != '' && app.globalData.ss_sq_longitude != '') {
      wx.request({
        url: app.globalData.url + 'api/tejia/glist',
        data: {
          pid: app.globalData.gongsi,
          type: 21,
          lat: app.globalData.ss_xq_latitude,
          lng: app.globalData.ss_sq_longitude,
          url: app.globalData.url,
          city_code: app.globalData.city_code,

          pid: app.globalData.px_id,//排序
          
          lb_id: app.globalData.lb_id,//房源类型
          lx_id: app.globalData.lx_id,//房源类型
          hx_id: app.globalData.hx_id,//户型
          hd: app.globalData.hd_str,//活动
          fuwu: app.globalData.fuwu_str,//服务
          tese: app.globalData.tese_str,//特色
          x: app.globalData.x,
          y: app.globalData.y,

          zhan: app.globalData.zhan_str,//地铁

          jie: app.globalData.jie_str,//地区
        },
        method: 'post',
        success: function(res) {
          console.log(res)
          
          that.setData({
            plist: res.data.plist,
            plist1: res.data.plist1,
            plist2: res.data.plist2,
            pid: app.globalData.px_id,
            yincang4: true,
            pinpai: app.globalData.pinpai,
            wei: app.globalData.wei,
            bao: app.globalData.bao,
            youxuan: app.globalData.youxuan
          })
          app.globalData.ss_xq_latitude = ''
          app.globalData.ss_sq_longitude = ''
          app.globalData.px_id = ''
        }
      })
    }
  },
})