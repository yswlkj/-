const app = getApp()
// import WxParse from '../../wxParse/wxParse.js';
Page({
  data: {
    type: 0,
    array: [],
    name: [],
    tel: [],
    pass: [],
    u_name: [],
    u_tel: [],
    u_pass: [],
    arr: [],
    arr1: [],
    arr2: [],
    bu: [],
    yincang1: true,
    qymc: ''
  },
  map: function (e) {
    var that = this
    wx.navigateTo({
      url: '../map/map',
    })
  },
  huan_tel: function () {
    var that = this
    that.setData({
      u_tel: ''
    })
  },
  huan_zhi: function () {
    var that = this
    that.setData({
      yy_code: ''
    })
  },
  tan: function (e) {
    var that = this
    var id = e.currentTarget.dataset.id
    wx.request({
      url: app.globalData.url + 'api/gongyu/tishi_info',
      data: {
        id: id
      },
      method: 'post',
      success: function (res) {
        console.log(res)
        wx.showModal({
          title: '提示',
          content: res.data.content,
          showCancel: false,
          confirmText: "我知道了",
          success: function (res) {
            if (res.cancel) {

            } else {

            }
          },
        })
      }
    })

  },
  yan: function (e) {
    var that = this
    var index = e.currentTarget.dataset.idx
    var oldpass = that.data.u_pass
    var bu = that.data.bu
    if (bu[index] == 0) {
      bu[index] = 1;
    } else if (bu[index] == 1) {
      bu[index] = 0;
    }
    that.setData({
      bu: bu
    })
  },
  tan_close: function (e) {
    var that = this
    that.setData({
      yincang1: true,
      bottom: -100
    })
  },
  onLoad: function (e) {
    var that = this
    wx.setNavigationBarTitle({
      title: '公寓添加',
    })
    wx.setStorageSync('addr', null)
    that.setData({
      intro: null
    })
    wx.request({
      url: app.globalData.url + 'api/my/gongyu_check',
      data: {
        tel: wx.getStorageSync('tel')
      },
      method: 'post',
      success: function (res) {
        console.log(res)
        if (res.data.info) {
          that.setData({
            name: res.data.info.name,
            gongyu_yyzz_renzheng: res.data.gongyu_yyzz_renzheng,
            fangyuanfabutishi: res.data.fangyuanfabutishi
          })
        } else {
          that.setData({
            gongyu_yyzz_renzheng: res.data.gongyu_yyzz_renzheng,
            fangyuanfabutishi: res.data.fangyuanfabutishi
          })
        }
      }
    })
  },
  addInput: function () {
    var that = this
    var old = that.data.array;
    var oldpass = that.data.u_pass;
    var oldtel = that.data.u_tel;
    var oldname = that.data.u_name;
    var arr = that.data.arr
    var arr1 = that.data.arr1
    var arr2 = that.data.arr2
    var myreg = /^((1[0-9]{2})+\d{8})$/;
    var myreg1 = /^[a-zA-Z0-9]{6,18}$/;
    var bu = that.data.bu
    if (old.length != 0) {
      if (oldpass && oldtel && oldname) {
        for (var i = 0; i < oldpass.length; i++) {
          if (oldname[i] == '') {
            var num2 = i + 1
            wx.showToast({
              title: '第' + num2 + '条负责人名字未填写',
              duration: 2000,
              icon: 'none',
              mask: true
            })
            break;
          }
          if (oldtel[i] == '') {
            var num1 = i + 1
            wx.showToast({
              title: '第' + num1 + '条负责人手机号未填写',
              duration: 2000,
              icon: 'none',
              mask: true
            })
            break;
          }

          if (!myreg.test(oldtel[i])) {
            var num1 = i + 1
            wx.showToast({
              title: '第' + num1 + '条负责人手机号格式有误',
              duration: 2000,
              icon: 'none',
              mask: true
            })
            break;
          }
          if (oldpass[i] == '') {
            var num3 = i + 1
            wx.showToast({
              title: '第' + num3 + '条负责人密码未填写',
              duration: 2000,
              icon: 'none',
              mask: true
            })
            break;
          }
          if (!myreg1.test(oldpass[i])) {
            var num = i + 1
            wx.showToast({
              title: '第' + num + '条负责人密码格式有误，密码规则请见详情',
              duration: 2000,
              icon: 'none',
              mask: true
            })
            break;
          }
          if (myreg1.test(oldpass[i]) && myreg.test(oldtel[i])) {
            if (oldpass[i] != '' && oldtel[i] != '' && oldname[i] != '') {
              var arr = arr.concat(1)
            } else {
              var arr = arr.concat(0)
            }
          }
        }
        if (arr.length != 0) {
          for (var o = 0; o < arr.length; o++) {
            if (arr[o] == 0) {
              var echo = 1;
              break;
            } else {
              var echo = 0;
            }
          }
        }
        if (echo == 1) {
          that.jiazai(0)
        } else if (echo == 0) {
          that.jiazai(1)
        }
      } else {

        wx.showToast({
          title: '请填写完整',
          duration: 2000,
          icon: 'none',
          mask: true
        })
        return;
      }
    } else {
      that.jiazai(1)
    }
  },
  jiazai: function (i) {
    var that = this
    if (i == 1) {
      var old = that.data.array;
      var oldpass = that.data.u_pass;
      var oldtel = that.data.u_tel;
      var oldname = that.data.u_name;
      old.push(0);
      oldpass.push("");
      oldtel.push("");
      oldname.push("");
      for (var i = 0; i < oldpass.length; i++) {
        var bu = that.data.bu.concat(0)
      }
      that.setData({
        array: old,
        pass: oldpass,
        name: oldname,
        tel: oldtel,
        u_pass: oldpass,
        u_tel: oldtel,
        u_name: oldname,
        bu: bu
      })
    } else {

      wx.showToast({
        title: '请填写完整',
        duration: 2000,
        icon: 'none',
        mask: true
      })
      return;
    }
  },
  shan: function (e) {
    var that = this
    var index = e.currentTarget.dataset.index;
    var oldpass = that.data.u_pass;
    var oldtel = that.data.u_tel;
    var oldname = that.data.u_name;
    var oldarr = that.data.array;
    oldarr.splice(index, 1);
    oldpass.splice(index, 1);
    oldtel.splice(index, 1);
    oldname.splice(index, 1);
    if (oldarr.length < 1) {
      oldarr = []
    }
    that.setData({
      array: oldarr,
      pass: oldpass,
      tel: oldtel,
      name: oldname,
      u_pass: oldpass,
      u_tel: oldtel,
      u_name: oldname
    })
  },
  u_name: function (e) {
    var nowIdx = e.currentTarget.dataset.idx;
    var u_name = e.detail.value;
    var oldVal = this.data.name;
    oldVal[nowIdx] = u_name;
    this.setData({
      u_name: oldVal
    })
  },
  u_pass: function (e) {
    var nowIdx = e.currentTarget.dataset.idx;
    var u_pass = e.detail.value;
    var oldVal1 = this.data.pass;
    oldVal1[nowIdx] = u_pass;
    this.setData({
      u_pass: oldVal1
    })
  },
  u_tel: function (e) {
    var nowIdx = e.currentTarget.dataset.idx;
    var u_tel = e.detail.value;
    var oldVal2 = this.data.tel;
    oldVal2[nowIdx] = u_tel;
    this.setData({
      u_tel: oldVal2
    })
  },
  title: function (e) {
    var that = this
    that.setData({
      title: e.detail.value
    })
  },

  content: function (e) {
    var that = this
    that.setData({
      content: e.detail.value
    })
  },
  yy_code: function (e) {
    var that = this
    that.setData({
      yy_code: e.detail.value
    })
  },
  submit: function (e) {
    var that = this
    var title = that.data.title
    var intro = that.data.intro
    var content = that.data.content
    var u_name = that.data.u_name
    var u_tel = that.data.u_tel
    var u_pass = that.data.u_pass
    var gy_pic = app.globalData.gy_pic1
    var gy_logo = app.globalData.gy_logo1
    var yy_pic = app.globalData.yy_pic1
    var fuze_u_pic = app.globalData.fuze_u_pic1
    var yy_code = that.data.yy_code
    var lat = that.data.lat
    var lng = that.data.lng
    var gy_info = wx.getStorageSync('yy_code')
    if (!gy_pic) {
      wx.showToast({
        title: '请填写公寓图片',
        duration: 2000,
        icon: 'none',
        mask: true
      })
      return;
    }
    if (!gy_logo) {
      wx.showToast({
        title: '请填写公寓logo',
        duration: 2000,
        icon: 'none',
        mask: true
      })
      return;
    }
    if (!title) {
      wx.showToast({
        title: '请填写公寓名称',
        duration: 2000,
        icon: 'none',
        mask: true
      })
      return;
    }
    if (!intro) {
      wx.showToast({
        title: '请选择公寓地址',
        duration: 2000,
        icon: 'none',
        mask: true
      })
      return;
    }
    if (!content) {
      wx.showToast({
        title: '请填写公寓介绍',
        duration: 2000,
        icon: 'none',
        mask: true
      })
      return;
    }
    if (that.data.gongyu_yyzz_renzheng == 'Y') {
      if (!yy_pic) {
        wx.showToast({
          title: '请上传营业执照',
          duration: 2000,
          icon: 'none',
          mask: true
        })
        return;
      }
    }
    if (!yy_pic) {
      var yy_pic = ''
    } else {
      var yy_pic = yy_pic
    }

    var arr = []
    if (u_pass.length != 0) {
      for (var i = 0; i < u_pass.length; i++) {
        if (u_pass[i] != '' && u_tel[i] != '' && u_name[i] != '') {
          var arr = arr.concat(1)
        } else {
          var arr = arr.concat(0)
        }
      }
      for (var o = 0; o < arr.length; o++) {
        if (arr[o] == 0) {
          var echo = 1;
          break;
        } else {
          var echo = 0;
        }
      }
      for (var i = 0; i < u_name.length; i++) {
        if (!u_name[i]) {
          console.log('--名字--')
          var num = i + 1
          wx.showToast({
            title: '第' + num + '条请填写负责人姓名',
            duration: 2000,
            icon: 'none',
            mask: true
          })
          return;
        }
      }
      var myreg = /^((1[0-9]{2})+\d{8})$/;
      for (var o = 0; o < u_tel.length; o++) {
        if (!u_tel[o]) {
          var num1 = o + 1
          wx.showToast({
            title: '第' + num1 + '条负责人手机号未填写',
            duration: 2000,
            icon: 'none',
            mask: true
          })
          break;
        }
        if (!myreg.test(u_tel[o])) {
          var num2 = o + 1
          wx.showToast({
            title: "第" + num2 + "条负责人手机号格式有误",
            icon: 'none',
            duration: 2000,
            mask: true
          })
          break;
        }
      }
      for (var a = 0; a < u_pass.length; a++) {
        if (!u_pass[a]) {
          var num3 = a + 1
          wx.showToast({
            title: '第' + num3 + '条请填写负责人密码',
            duration: 2000,
            icon: 'none',
            mask: true
          })
          break;
        }
        var mareg1 = /^[a-zA-Z0-9]{6,18}$/
        if (!mareg1.test(u_pass[a])) {
          var num4 = a + 1
          wx.showToast({
            title: '第' + num4 + '条请填写负责人密码格式有误，密码规则请见详情',
            duration: 2000,
            icon: 'none',
            mask: true
          })
          break;
        }
      }
      if (u_pass || u_name || u_tel) {
        for (var i1 = 0; i1 < u_name.length; i1++) {
          var u_name1 = u_name1 + '@' + u_name[i1]
        }
        for (var y1 = 0; y1 < u_tel.length; y1++) {
          var u_tel1 = u_tel1 + '@' + u_tel[y1]
        }
        for (var o1 = 0; o1 < u_pass.length; o1++) {
          var u_pass1 = u_pass1 + '@' + u_pass[o1]
        }
      }
    } else {
      var u_pass1 = null;
      var u_tel1 = null;
      var u_name1 = null;
    }
    wx.request({
      url: app.globalData.url + 'api/fabu/check_title_content',
      data: {
        title: title,
        content: content,
      },
      method: 'post',
      success: function (ftc) {
        if (ftc.data.info != 1) {
          wx.showToast({
            title: '公寓名称存在敏感词，请重新输入',
            duration: 2000,
            icon: 'none',
            mask: true
          })
          that.setData({
            type: 0
          })
          return;
        } else if (ftc.data.info1 != 1) {
          wx.showToast({
            title: '公寓简介存在敏感词，请重新输入',
            duration: 2000,
            icon: 'none',
            mask: true
          })
          that.setData({
            type: 0
          })
          return;
        } else if (ftc.data.info1 == 1 && ftc.data.info == 1) {

          if (!yy_pic) {
            wx.showModal({
              title: '提示',
              content: '你未上传营业执照，请于7日内上传，否则将会影响你公寓身份的正常使用',
              showCancel: true,
              cancelText: "稍后上传",
              confirmText: "立即上传",
              success: function (res) {
                if (res.cancel) {
                  wx.showToast({
                    title: '提交中，请稍后',
                    duration: 20000,
                    icon: 'loading',
                    mask: true
                  })
                  wx.request({
                    url: app.globalData.url + 'api/gongyu/save',
                    data: {
                      yy_code: yy_code,
                      u_tel: u_tel1,
                      u_name: u_name1,
                      u_pass: u_pass1,
                      title: title,
                      yingye: yy_pic,
                      qymc: that.data.qymc,
                      logo: gy_logo,
                      bgpicture: gy_pic,
                      intro: intro,
                      content: content,
                      lat: lat,
                      lng: lng,
                      tel: wx.getStorageSync('tel')
                    },
                    method: 'post',
                    success: function (res) {
                      console.log(res)
                      app.globalData.ss_xq_name = undefined
                      app.globalData.ss_xq_latitude = ''
                      app.globalData.ss_sq_longitude = ''
                      app.globalData.ss_xq_addr = undefined
                      if (res.data.info == 1 || res.data.info == 0) {
                        wx.showToast({
                          title: '提交成功，正在前往添加门店',
                          duration: 2000,
                          icon: 'none',
                          mask: true
                        })
                        app.globalData.yy_pic1 = ''
                        app.globalData.yy_pic = ''
                        wx.setStorageSync('addr', '')
                        wx.setStorageSync('lat', '')
                        wx.setStorageSync('lng', '')
                        // that.setData({
                        //   array: [],

                        //   u_name: [],
                        //   u_tel: [],
                        //   u_pass: [],
                        // })
                        setTimeout(function () {
                          wx.navigateTo({
                            url: '../landlord/landlord?zt=2',
                          })
                        }, 2000)
                      } else if (res.data.info == 3) {
                        wx.showModal({
                          title: '提示',
                          content: '当前营业执照已绑定' + res.data.gy_title + '，如有问题请联系平台管理员',
                          showCancel: false,
                          confirmText: "我知道了",
                          success: function (res) {
                            if (res.cancel) {

                            } else {

                            }
                          },
                        })
                      } else if (res.data.info == 2) {
                        wx.showToast({
                          title: '',
                          duration: 2000,
                          icon: 'none'
                        })
                        wx.showModal({
                          title: '提示',
                          content: '您已添加同名公寓请勿重复创建，如有问题请联系平台管理员',
                          showCancel: false,
                          confirmText: "我知道了",
                          success: function (res) {
                            if (res.cancel) {

                            } else {

                            }
                          },
                        })
                      }
                    }
                  })
                } else if (res.confirm) {
                  that.upload1()
                }
              }
            })
          } else {
            wx.request({
              url: app.globalData.url + 'api/gongyu/save',
              data: {
                yy_code: yy_code,
                u_tel: u_tel1,
                u_name: u_name1,
                u_pass: u_pass1,
                title: title,
                yingye: yy_pic,
                qymc: that.data.qymc,
                logo: gy_logo,
                bgpicture: gy_pic,
                intro: intro,
                content: content,
                lat: lat,
                lng: lng,
                tel: wx.getStorageSync('tel')
              },
              method: 'post',
              success: function (res) {
                console.log(res)
                app.globalData.ss_xq_name = undefined
                app.globalData.ss_xq_latitude = ''
                app.globalData.ss_sq_longitude = ''
                app.globalData.ss_xq_addr = undefined
                if (res.data.info == 1 || res.data.info == 0) {
                  wx.showToast({
                    title: '提交成功，正在前往添加门店',
                    duration: 2000,
                    icon: 'none',
                    mask: true
                  })
                  app.globalData.yy_pic1 = ''
                  app.globalData.yy_pic = ''
                  that.setData({
                    array: [],

                    u_name: [],
                    u_tel: [],
                    u_pass: [],
                  })
                  setTimeout(function () {
                    wx.navigateTo({
                      url: '../landlord/landlord?zt=2',
                    })
                  }, 2000)
                } else if (res.data.info == 3) {
                  wx.showModal({
                    title: '提示',
                    content: '当前营业执照已绑定' + res.data.gy_title + '，如有问题请联系平台管理员',
                    showCancel: false,
                    confirmText: "我知道了",
                    success: function (res) {
                      if (res.cancel) {

                      } else {
                        that.setData({
                          type: 0
                        })
                      }
                    },
                  })
                } else if (res.data.info == 2) {
                  wx.showToast({
                    title: '',
                    duration: 2000,
                    icon: 'none'
                  })
                  wx.showModal({
                    title: '提示',
                    content: '您已添加同名公寓请勿重复创建，如有问题请联系平台管理员',
                    showCancel: false,
                    confirmText: "我知道了",
                    success: function (res) {
                      if (res.cancel) {

                      } else {
                        that.setData({
                          type: 0
                        })
                      }
                    },
                  })
                }else if (res.data.info == 3) {
                  wx.showToast({
                    title: '',
                    duration: 2000,
                    icon: 'none'
                  })
                  wx.showModal({
                    title: '提示',
                    content: '当前城市已有同名公寓请勿重复创建，如有问题请联系平台管理员',
                    showCancel: false,
                    confirmText: "我知道了",
                    success: function (res) {
                      if (res.cancel) {

                      } else {
                        that.setData({
                          type: 0
                        })
                      }
                    },
                  })
                }
              }
            })
          }
        }
      }
    })

  },
  upload: function () {
    let that = this;
    wx.chooseImage({
      count: 1,
      sizeType: ['original', 'compressed'],
      sourceType: ['album', 'camera'],
      success: res => {
        wx.showToast({
          title: '正在上传...',
          icon: 'loading',
          mask: true,
          duration: 1000
        })
        app.globalData.fuze_u_pic = res.tempFilePaths
        that.uploadimg();
        let tempFilePaths = res.tempFilePaths;
        that.setData({
          fuze_u_pic: tempFilePaths
        })
      }
    })
  },
  uploadimg: function () {
    var that = this
    that.setData({
      type: 1
    })
    var pics = app.globalData.fuze_u_pic
    for (var i = 0; i < pics.length; i++) {
      wx.uploadFile({
        url: app.globalData.url + 'api/yanzheng/img',
        filePath: pics[i],
        name: 'file',
        success: function (res) {
          console.log(res)
          app.globalData.fuze_u_pic1 = res.data
          wx.request({
            url: app.globalData.url + 'api/yanzheng/check_sf_pic',
            data: {
              pic: res.data
            },
            method: 'post',
            success: function (ras) {
              console.log(ras)
              app.globalData.fuze_u = ras
              if (ras.data.code == 1) {
                wx.showToast({
                  title: '身份证照片通过审核',
                  duration: 2000,
                  icon: 'none',
                  mask: true
                })
                that.setData({
                  type: 0,

                })
                return;
              } else {
                wx.showToast({
                  title: '身份证照片未通过审核',
                  duration: 2000,
                  icon: 'none',
                  mask: true
                })
                that.setData({
                  type: 1
                })
                return;
              }
            }
          })
        }
      })
    }
  },
  upload1: function () {
    let that = this;
    wx.chooseImage({
      count: 1,
      sizeType: ['compressed'],
      sourceType: ['album', 'camera'],
      success: res => {
        wx.showToast({
          title: '正在上传...',
          icon: 'loading',
          mask: true,
          duration: 1000
        })
        app.globalData.yy_pic = res.tempFilePaths
        that.uploadimg1();
        let tempFilePaths = res.tempFilePaths;
        that.setData({
          yy_pic: tempFilePaths
        })
      }
    })
  },

  uploadimg1: function () {
    var that = this
    var pics = app.globalData.yy_pic
    that.setData({
      type: 2
    })
    for (var i = 0; i < pics.length; i++) {
      wx.uploadFile({
        url: app.globalData.url + 'api/yanzheng/img',
        filePath: pics[i],
        name: 'file',
        success: function (res) {
          console.log(res)
          app.globalData.yy_pic1 = res.data
          wx.request({
            url: app.globalData.url + 'api/yanzheng/check_yy_pic',
            data: {
              pic: res.data
            },
            method: 'post',
            success: function (ras) {
              console.log(ras)
              if (ras.data.words != null) {
                app.globalData.yy_code = ras.data.out_put
                wx.setStorageSync('yy_code', ras.data.out_put)
              }
              if (ras.data.out_put) {
                if (ras.data.out_put['ENTERPRISE_TAXPAYER_REGISTER_ID'] != '') {
                  wx.showToast({
                    title: '营业执照照片通过审核',
                    duration: 2000,
                    icon: 'none',
                    mask: true
                  })
                  that.setData({
                    type: 0,
                    yy_code: ras.data.out_put['ENTERPRISE_TAXPAYER_REGISTER_ID'],
                    qymc: ras.data.out_put['ENTERPRISE_NAME_CH'],
                  })
                  return;
                } else {
                  wx.showToast({
                    title: '营业执照照片未通过审核',
                    duration: 2000,
                    icon: 'none',
                    mask: true
                  })
                  that.setData({
                    type: 0,
                    yy_pic: '',
                    yy_code: '',
                    qymc: ''
                  })
                  app.globalData.yy_pic1 = ''
                  return;
                }
              } else {
                wx.showToast({
                  title: '验证营业执照失败，请联系管理员',
                  duration: 2000,
                  icon: 'none',
                  mask: true
                })
                that.setData({
                  type: 0,
                  yy_pic: '',
                  yy_code: '',
                  qymc: ''
                })
                app.globalData.yy_pic1 = ''
                return;
              }
            }
          })
        }
      })
    }
  },
  //公寓图片
  upload2: function () {
    let that = this;
    wx.chooseImage({
      count: 1,
      sizeType: ['compressed'],
      sourceType: ['album', 'camera'],
      success: res => {
        wx.showToast({
          title: '正在上传...',
          icon: 'loading',
          mask: true,
          duration: 1000
        })
        app.globalData.gy_pic = res.tempFilePaths
        that.uploadimg2();
        let tempFilePaths = res.tempFilePaths;
        that.setData({
          gy_pic: tempFilePaths
        })
      }
    })
  },
  uploadimg2: function () {
    var that = this
    var pics = app.globalData.gy_pic
    for (var i = 0; i < pics.length; i++) {
      wx.uploadFile({
        url: app.globalData.url + 'api/yanzheng/img',
        filePath: pics[i],
        name: 'file',
        success: function (res) {
          console.log(res)
          app.globalData.gy_pic1 = res.data
        }
      })
    }
  },
  upload3: function () {
    let that = this;
    wx.chooseImage({
      count: 1,
      sizeType: ['compressed'],
      sourceType: ['album', 'camera'],
      success: res => {
        wx.showToast({
          title: '正在上传...',
          icon: 'loading',
          mask: true,
          duration: 1000
        })
        app.globalData.gy_logo = res.tempFilePaths
        that.uploadimg3();
        let tempFilePaths = res.tempFilePaths;
        that.setData({
          gy_logo: tempFilePaths
        })
      }
    })
  },
  uploadimg3: function () {
    var that = this
    var pics = app.globalData.gy_logo
    for (var i = 0; i < pics.length; i++) {
      wx.uploadFile({
        url: app.globalData.url + 'api/yanzheng/img',
        filePath: pics[i],
        name: 'file',
        success: function (res) {
          console.log(res)
          app.globalData.gy_logo1 = res.data
        }
      })
    }
  },
  onShow: function () {
    var that = this
    console.log(app.globalData.ss_xq_addr)
    that.setData({
      intro: wx.getStorageSync('addr'),
      lat: wx.getStorageSync('lat'),
      lng: wx.getStorageSync('lng')
    })
  },
})