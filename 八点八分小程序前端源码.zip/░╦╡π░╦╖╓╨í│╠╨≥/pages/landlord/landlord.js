// pages/landlord/landlord.js
const app = getApp()
Page({

  /**
   * 页面的初始数据
   */
  data: {
    yincang1: true,
    type: 0,
    shenhe: 0,
    array: [],
    name: [],
    tel: [],
    pass: [],
    u_name: [],
    u_tel: [],
    u_pass: [],
    bu: [],
    yincang2: true,
    md_pic:[]
  },
  tan: function (e) {
    var that = this
    var id = e.currentTarget.dataset.id
    wx.request({
      url: app.globalData.url + 'api/gongyu/tishi_info',
      data: {
        id: id
      },
      method: 'post',
      success: function (res) {
        console.log(res)
        wx.showModal({
          title: '提示',
          content: res.data.content,
          showCancel: false,
          confirmText: "我知道了",
          success: function (res) {
            if (res.cancel) {

            } else {

            }
          },
        })
      }
    })
  },
  yan: function (e) {
    var that = this
    var index = e.currentTarget.dataset.idx
    var oldpass = that.data.u_pass
    var bu = that.data.bu
    console.log(bu)
    if (bu[index] == 0) {
      bu[index] = 1;
    } else if (bu[index] == 1) {
      bu[index] = 0;
    }
    that.setData({
      bu: bu
    })
  },
  tan_close: function (e) {
    var that = this
    that.setData({
      yincang1: true,
      bottom: -100
    })
  },

  liubtn1: function (e) {
    var that = this
    var yincang1 = that.data.yincang1
    if (yincang1 == false) {
      that.setData({
        yincang1: true,
      })
    } else if (yincang1 == true) {
      that.setData({
        yincang1: false,
      })
    }

  },
  addInput: function () {
    var that = this
    var old = that.data.array;
    var oldpass = that.data.u_pass;
    var oldtel = that.data.u_tel;
    var oldname = that.data.u_name;
    var arr = []
    console.log(oldpass, oldtel, oldname)
    // console.log(oldtel)
    var myreg = /^((1[0-9]{2})+\d{8})$/;
    var myreg1 = /^[a-zA-Z0-9]{6,18}$/;
    if (old.length != 0) {
      if (oldpass && oldtel && oldname) {
        for (var i = 0; i < oldpass.length; i++) {
          if (oldname[i] == '') {
            var num2 = i + 1
            wx.showToast({
              title: '第' + num2 + '条对接人名字未填写',
              duration: 2000,
              icon: 'none'
            })
            break;
          }
          if (oldtel[i] == '') {
            var num1 = i + 1
            wx.showToast({
              title: '第' + num1 + '条对接人手机号未填写',
              duration: 2000,
              icon: 'none'
            })
            break;
          }

          if (!myreg.test(oldtel[i])) {
            var num1 = i + 1
            wx.showToast({
              title: '第' + num1 + '条对接人手机号格式错误',
              duration: 2000,
              icon: 'none'
            })
            break;
          }
          if (oldpass[i] == '') {
            var num3 = i + 1
            wx.showToast({
              title: '第' + num3 + '条对接人密码未填写',
              duration: 2000,
              icon: 'none'
            })
            break;
          }
          if (!myreg1.test(oldpass[i])) {
            var num = i + 1
            wx.showToast({
              title: '第' + num + '条对接人密码格式有误，密码规则请见详情',
              duration: 2000,
              icon: 'none'
            })
            break;
          }
          if (myreg1.test(oldpass[i]) && myreg.test(oldtel[i])) {
            if (oldpass[i] != '' && oldtel[i] != '' && oldname[i] != '') {
              var arr = arr.concat(1)
            } else {
              var arr = arr.concat(0)
            }
          }
        }
        if (arr.length != 0) {
          for (var o = 0; o < arr.length; o++) {
            if (arr[o] == 0) {
              var echo = 1;
              break;
            } else {
              var echo = 0;
            }
          }
        }
        if (echo == 1) {
          that.jiazai(0)
        } else if (echo == 0) {
          that.jiazai(1)
        }
      } else {
        wx.showToast({
          title: '请填写完整',
          duration: 2000,
          icon: 'none'
        })
        return;
      }
    } else {
      that.jiazai(1)
    }
  },
  jiazai: function (i) {
    var that = this
    if (i == 1) {
      var old = that.data.array;
      var oldpass = that.data.u_pass;
      var oldtel = that.data.u_tel;
      var oldname = that.data.u_name;
      old.push(0); //这里不管push什么，只要数组长度增加1就行
      oldpass.push("");
      oldtel.push("");
      oldname.push("");
      for (var i = 0; i < oldpass.length; i++) {
        var bu = that.data.bu.concat(0)
      }
      that.setData({
        array: old,
        bu: bu,
        pass: oldpass,
        name: oldname,
        tel: oldtel,
        u_pass: oldpass,
        u_tel: oldtel,
        u_name: oldname
      })
    } else {
      wx.showToast({
        title: '请填写完整',
        duration: 2000,
        icon: 'none'
      })
      return;
    }
  },
  shan: function (e) {
    var that = this
    var index = e.currentTarget.dataset.index; //当前索引
    console.log(index)
    var oldpass = that.data.u_pass; //所有的input值
    var oldtel = that.data.u_tel;
    var oldname = that.data.u_name;
    var oldarr = that.data.array; //循环内容
    oldarr.splice(index, 1); //删除当前索引的内容，这样就能删除view了
    oldpass.splice(index, 1); //view删除了对应的input值也要删掉
    oldtel.splice(index, 1);
    oldname.splice(index, 1);
    console.log(oldpass, oldtel, oldname)
    if (oldarr.length < 1) {
      oldarr = [] //如果循环内容长度为0即删完了，必须要留一个默认的。这里oldarr只要是数组并且长度为1，里面的值随便是什么
    }
    that.setData({
      array: oldarr,
      pass: oldpass,
      tel: oldtel,
      name: oldname,
      u_pass: oldpass,
      u_tel: oldtel,
      u_name: oldname
    })
  },
  u_name: function (e) {
    var nowIdx = e.currentTarget.dataset.idx; //获取当前索引
    var u_name = e.detail.value; //获取输入的值
    console.log(e)
    var oldVal = this.data.name;
    console.log(oldVal)
    oldVal[nowIdx] = u_name; //修改对应索引值的内容
    this.setData({
      u_name: oldVal
    })
  },
  u_pass: function (e) {
    var nowIdx = e.currentTarget.dataset.idx; //获取当前索引
    var u_pass = e.detail.value; //获取输入的值
    var oldVal1 = this.data.pass;
    oldVal1[nowIdx] = u_pass; //修改对应索引值的内容
    this.setData({
      u_pass: oldVal1
    })
  },
  u_tel: function (e) {
    var nowIdx = e.currentTarget.dataset.idx; //获取当前索引
    var u_tel = e.detail.value; //获取输入的值
    var oldVal2 = this.data.tel;
    oldVal2[nowIdx] = u_tel; //修改对应索引值的内容
    this.setData({
      u_tel: oldVal2
    })
  },
  huan: function (e) {
    var that = this
    var index = e.currentTarget.dataset.index
    var tel = that.data.u_tel
    tel.splice(index, 1, '')
    that.setData({
      tel: tel,
      u_tel: tel
    })
  },
  bakbtn1: function (e) {
    var that = this
    var id = e.currentTarget.dataset.id
    app.globalData.md_type = id
    wx.request({
      url: app.globalData.url + 'api/gongyu/mendian_show',
      data: {
        id: id,
      },
      method: 'post',
      success: function (res) {
        console.log(res)
        that.setData({
          title: res.data.title
        })
      }
    })
    that.setData({
      yincang1: true,
    })
  },
  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (e) {
    var that = this
    var tel = wx.getStorageSync('tel')
    wx.setNavigationBarTitle({
      title: '门店添加',
    })
    var zt = e.zt
    app.globalData.md_zt = zt
    app.globalData.md_type = ''
    app.globalData.md_pic1 = ''
    app.globalData.md_pic = []
    if (e.type) {
      that.setData({
        type2: e.type
      })
    }
    if (e.shenhe) {
      that.setData({
        shenhe: e.shenhe
      })
    }
    if (e.type_id) {
      that.setData({
        type_id: e.type_id
      })
    }
    wx.request({
      url: app.globalData.url + 'api/gongyu/mendian_list',
      data: {
        tel: tel,
      },
      method: 'post',
      success: function (res) {
        console.log(res)
        that.setData({
          list: res.data.list,
          pic_num: res.data.info
        })
      }
    })
  },
  tishi: function(){
    var that = this
    wx.showToast({
      title: '您已上传'+that.data.pic_num+'张，请删除后继续上传',
      duration: 2500,
      icon: 'none',
      mask: true
    })
    return
  },
  upload2: function () {
    let that = this;
    wx.chooseImage({
      count: that.data.pic_num-that.data.md_pic.length, // 默认9
      sizeType: ['compressed'], // 可以指定是原图还是压缩图，默认二者都有
      sourceType: ['album', 'camera'], // 可以指定来源是相册还是相机，默认二者都有
      success: res => {
        wx.showToast({
          title: '正在上传...',
          icon: 'loading',
          mask: true,
          duration: 1000
        })
        // 返回选定照片的本地文件路径列表，tempFilePath可以作为img标签的src属性显示图片
        if (app.globalData.md_pic.length < that.data.pic_num) {
          app.globalData.md_pic = app.globalData.md_pic.concat(res.tempFilePaths)
        } else {
          app.globalData.md_pic = app.globalData.md_pic
          console.log('超过9张')
          wx.showToast({
            title: '门店图片最多'+that.data.pic_num+'张',
            duration: 2000,
            icon: 'none'
          })
        }
        that.setData({
          md_pic:  app.globalData.md_pic
        })
      }
    })
  },
  aaa: function(e) {
    var that = this
    var imgs = app.globalData.md_pic;
    var index = e.currentTarget.dataset.index;
    imgs.splice(index, 1);
    app.globalData.md_pic = imgs
    that.setData({
      md_pic: imgs,
    });
    if (app.globalData.md_pic.length > that.data.pic_num) {
      wx.showToast({
        title: '门店图片最多上传'+that.data.pic_num+'张',
        duration: 2000,
        icon: 'none',
        mask: true
      })
    }
  },
  uploadimg2: function (data) { //这里触发图片上传的方法
    var that = this
    var pics = app.globalData.md_pic
    var i;

    i = data.i ? data.i : 0,//当前上传的哪张图片
      wx.uploadFile({
        url: app.globalData.url + 'api/yanzheng/img',
        filePath: pics[i],
        name: 'file',//这里根据自己的实际情况改
        formData: null,//这里是上传图片时一起上传的数据
        success: (resp) => {
          if(app.globalData.md_pic1){
            app.globalData.md_pic1 = app.globalData.md_pic1 + '@' + resp.data
          }else{
            app.globalData.md_pic1 = resp.data
          }
          console.log(app.globalData.md_pic1)
          var pic_str = app.globalData.md_pic1
          if (pic_str) {
            console.log('zoule')
            var pic_arr = pic_str.split('@')
            console.log(pic_arr)
            if (pic_arr.length == pics.length) {
              console.log('zoule1')
              that.save()
            }
          }
        },
        complete: (res) => {
          i++;//这个图片执行完上传后，开始上传下一张
          if (i == pics.length) {   //当图片传完时，停止调用          
            console.log('执行完毕');
          } else {//若图片还没有传完，则继续调用函数
            // console.log(i);
            data.i = i;
            that.uploadimg2(data);
          }

        }
      });
  },
  save: function(){
    var that = this
    var title1 = app.globalData.ss_xq_name
    var md_type = app.globalData.md_type
    var intro = app.globalData.ss_xq_addr
    var tel1 = that.data.tel1
    var content = that.data.content
    var u_name = that.data.u_name
    var u_tel = that.data.u_tel
    var u_pass = that.data.u_pass
    for (var i = 0; i < u_name.length; i++) {
      var u_name1 = u_name1 + '@' + u_name[i]
    }
    for (var y = 0; y < u_tel.length; y++) {
      var u_tel1 = u_tel1 + '@' + u_tel[y]
    }
    for (var o = 0; o < u_pass.length; o++) {
      var u_pass1 = u_pass1 + '@' + u_pass[o]
    }
    wx.request({
      url: app.globalData.url + 'api/gongyu/mendian_save',
      data: {
        md_logo: app.globalData.md_logo1,
        md_pic: app.globalData.md_pic1,
        md_type: md_type,
        title: title1,
        intro: intro,
        tel1: tel1,
        lat: app.globalData.ss_xq_latitude,
        lng: app.globalData.ss_sq_longitude,
        content: content,
        u_name1: u_name1,
        u_tel1: u_tel1,
        u_pass1: u_pass1,
        tel: wx.getStorageSync('tel'),
        u_lat: app.globalData.lat,
        u_lng: app.globalData.lng
      },
      method: 'post',
      success: function (res) {
        console.log(res)
        app.globalData.md_pic = []
        app.globalData.md_pic1 = ''
        if (res.data.inser == 1) {
          if (that.data.shenhe == 0) {
            if (res.data.mendian_shenhe_type == 'Y' && res.data.gongyu_fd_yanzheng == 'Y') {
              wx.showModal({
                title: '提示',
                content: '您的门店认证申请已提交，平台将于3个工作日内审核。审核通过后可发布房源，谢谢。',
                showCancel: false, //是否显示取消按钮
                confirmText: "我知道了", //默认是“确定”
                 //确定文字的颜色
                success: function (res) {
                  if (res.cancel) {
                    //点击取消,默认隐藏弹框
                  } else {
                    app.globalData.ss_sq_longitude = ''
                    app.globalData.ss_xq_latitude = ''
                    app.globalData.ss_xq_name = ''
                    app.globalData.ss_xq_addr = ''
                    if (app.globalData.md_zt == 0) {
                      setTimeout(function () {
                        wx.navigateTo({
                          url: '../rleaseone/rleaseone?type_id=' + that.data.type_id + '&type=' + that.data.type2,
                        })
                      }, 2000)
                    } else if (app.globalData.md_zt == 1) {
                      setTimeout(function () {
                        wx.navigateBack({

                        })
                      }, 2000)
                    } else if (app.globalData.md_zt == 2) {
                      setTimeout(function () {
                        wx.reLaunch({
                          url: '../rlease/rlease',
                        })
                      }, 2000)
                    }
                  }
                },
              })
            } else if (res.data.mendian_shenhe_type == 'N' && res.data.gongyu_fd_yanzheng == 'Y') {
              wx.showModal({
                title: '提示',
                content: '您的身份认证申请已提交，平台将于3个工作日内审核。审核通过后可发布房源，谢谢。',
                showCancel: false, //是否显示取消按钮
                confirmText: "我知道了", //默认是“确定”
                 //确定文字的颜色
                success: function (res) {
                  if (res.cancel) {
                    //点击取消,默认隐藏弹框
                  } else {
                    app.globalData.ss_sq_longitude = ''
                    app.globalData.ss_xq_latitude = ''
                    app.globalData.ss_xq_name = ''
                    app.globalData.ss_xq_addr = ''
                    if (app.globalData.md_zt == 0) {
                      setTimeout(function () {
                        wx.navigateTo({
                          url: '../rleaseone/rleaseone?type_id=' + that.data.type_id + '&type=' + that.data.type2,
                        })
                      }, 2000)
                    } else if (app.globalData.md_zt == 1) {
                      setTimeout(function () {
                        wx.navigateBack({

                        })
                      }, 2000)
                    } else if (app.globalData.md_zt == 2) {
                      setTimeout(function () {
                        wx.reLaunch({
                          url: '../rlease/rlease',
                        })
                      }, 2000)
                    }
                  }
                },
              })
            } else if (res.data.mendian_shenhe_type == 'Y' && res.data.gongyu_fd_yanzheng == 'N') {
              wx.showModal({
                title: '提示',
                content: '您的门店认证申请已提交，平台将于3个工作日内审核。审核通过后可发布房源，谢谢。',
                showCancel: false, //是否显示取消按钮
                confirmText: "我知道了", //默认是“确定”
                 //确定文字的颜色
                success: function (res) {
                  if (res.cancel) {
                    //点击取消,默认隐藏弹框
                  } else {
                    app.globalData.ss_sq_longitude = ''
                    app.globalData.ss_xq_latitude = ''
                    app.globalData.ss_xq_name = ''
                    app.globalData.ss_xq_addr = ''
                    if (app.globalData.md_zt == 0) {
                      setTimeout(function () {
                        wx.navigateTo({
                          url: '../rleaseone/rleaseone?type_id=' + that.data.type_id + '&type=' + that.data.type2,
                        })
                      }, 2000)
                    } else if (app.globalData.md_zt == 1) {
                      setTimeout(function () {
                        wx.navigateBack({

                        })
                      }, 2000)
                    } else if (app.globalData.md_zt == 2) {
                      setTimeout(function () {
                        wx.reLaunch({
                          url: '../rlease/rlease',
                        })
                      }, 2000)
                    }
                  }
                },
              })
            } else if (res.data.mendian_shenhe_type == 'N' && res.data.gongyu_fd_yanzheng == 'N') {
              wx.showToast({
                title: '提交成功',
                duration: 2000,
                icon: 'none',
                mask: true
              })
              app.globalData.ss_sq_longitude = ''
              app.globalData.ss_xq_latitude = ''
              app.globalData.ss_xq_name = ''
              app.globalData.ss_xq_addr = ''
              if (app.globalData.md_zt == 0) {
                setTimeout(function () {
                  wx.navigateTo({
                    url: '../rleaseone/rleaseone?type_id=' + that.data.type_id + '&type=' + that.data.type2,
                  })
                }, 2000)
              } else if (app.globalData.md_zt == 1) {
                setTimeout(function () {
                  wx.navigateBack({

                  })
                }, 2000)
              } else if (app.globalData.md_zt == 2) {
                setTimeout(function () {
                  wx.reLaunch({
                    url: '../rlease/rlease',
                  })
                }, 2000)
              }
            }
          } else if (that.data.shenhe == 1) {
            if (res.data.mendian_shenhe_type == 'Y') {
              wx.showModal({
                title: '提示',
                content: '您的门店认证申请已提交，平台将于3个工作日内审核。审核通过后可发布房源，谢谢。',
                showCancel: false, //是否显示取消按钮
                confirmText: "我知道了", //默认是“确定”
                 //确定文字的颜色
                success: function (res) {
                  if (res.cancel) {
                    //点击取消,默认隐藏弹框
                  } else {
                    app.globalData.ss_sq_longitude = ''
                    app.globalData.ss_xq_latitude = ''
                    app.globalData.ss_xq_name = ''
                    app.globalData.ss_xq_addr = ''
                    if (app.globalData.md_zt == 0) {
                      setTimeout(function () {
                        wx.navigateTo({
                          url: '../rleaseone/rleaseone?type_id=' + that.data.type_id + '&type=' + that.data.type2,
                        })
                      }, 2000)
                    } else if (app.globalData.md_zt == 1) {
                      setTimeout(function () {
                        wx.navigateBack({

                        })
                      }, 2000)
                    } else if (app.globalData.md_zt == 2) {
                      setTimeout(function () {
                        wx.reLaunch({
                          url: '../rlease/rlease',
                        })
                      }, 2000)
                    }
                  }
                },
              })
            } else if (res.data.mendian_shenhe_type == 'N') {
              wx.showToast({
                title: '提交成功',
                duration: 2000,
                icon: 'none',
                mask: true
              })
              app.globalData.ss_sq_longitude = ''
              app.globalData.ss_xq_latitude = ''
              app.globalData.ss_xq_name = ''
              app.globalData.ss_xq_addr = ''
              if (app.globalData.md_zt == 0) {
                setTimeout(function () {
                  wx.navigateTo({
                    url: '../rleaseone/rleaseone?type_id=' + that.data.type_id + '&type=' + that.data.type2,
                  })
                }, 2000)
              } else if (app.globalData.md_zt == 1) {
                setTimeout(function () {
                  wx.navigateBack({

                  })
                }, 2000)
              } else if (app.globalData.md_zt == 2) {
                setTimeout(function () {
                  wx.reLaunch({
                    url: '../rlease/rlease',
                  })
                }, 2000)
              }
            }
          }
        } else if (res.data.inser == 2) {
          wx.showModal({
            title: '提示',
            content: '您已添加同名门店请勿重复创建，如有问题请联系平台管理员',
            showCancel: false,
            confirmText: "我知道了",
            success: function (res) {
              if (res.cancel) {

              } else {
                that.setData({
                  type: 0
                })
              }
            },
          })
        }else if (res.data.inser == 3) {
          wx.showModal({
            title: '提示',
            content: '当前城市已有同名门店请勿重复创建，如有问题请联系平台管理员',
            showCancel: false,
            confirmText: "我知道了",
            success: function (res) {
              if (res.cancel) {

              } else {
                that.setData({
                  type: 0
                })
              }
            },
          })
        }
      }
    })
  },
  //公寓图片
  upload3: function () {
    let that = this;
    wx.chooseImage({
      count: 1, // 默认9
      sizeType: ['compressed'], // 可以指定是原图还是压缩图，默认二者都有
      sourceType: ['album', 'camera'], // 可以指定来源是相册还是相机，默认二者都有
      success: res => {
        wx.showToast({
          title: '正在上传...',
          icon: 'loading',
          mask: true,
          duration: 1000
        })
        // 返回选定照片的本地文件路径列表，tempFilePath可以作为img标签的src属性显示图片
        app.globalData.md_logo = res.tempFilePaths
        console.log(app.globalData.md_logo)


        let tempFilePaths = res.tempFilePaths;
        that.setData({
          md_logo: tempFilePaths
        })
      }
    })
  },
  uploadimg3: function () { //这里触发图片上传的方法
    var that = this
    var pics = app.globalData.md_logo
    for (var i = 0; i < pics.length; i++) {
      wx.uploadFile({
        url: app.globalData.url + 'api/yanzheng/img',
        filePath: pics[i],
        name: 'file',
        success: function (res) {
          //打印
          console.log(res)
          app.globalData.md_logo1 = res.data

          console.log(app.globalData.md_logo1)
        }
      })
    }
  },
  title1: function (e) {
    var that = this
    var title1 = e.detail.value
    that.setData({
      title1: title1
    })
  },
  intro: function (e) {
    var that = this
    var intro = e.detail.value
    that.setData({
      intro: intro
    })
  },
  tel1: function (e) {
    var that = this
    var tel1 = e.detail.value
    that.setData({
      tel1: tel1
    })
  },
  content: function (e) {
    var that = this
    var content = e.detail.value
    that.setData({
      content: content
    })
  },
  map: function (e) {
    wx.navigateTo({
      url: '../map/map',
    })
  },
  submit: function (e) {
    var that = this
    var title1 = app.globalData.ss_xq_name
    var md_type = app.globalData.md_type
    var intro = app.globalData.ss_xq_addr
    var tel1 = that.data.tel1
    var content = that.data.content
    var u_name = that.data.u_name
    var u_tel = that.data.u_tel
    var u_pass = that.data.u_pass
    var md_logo = app.globalData.md_logo
    var md_pic = app.globalData.md_pic

    if (!md_logo) {
      wx.showToast({
        title: '请上传公寓logo',
        duration: 2000,
        icon: 'none'
      })
      return;
    }
    if (!md_pic) {
      wx.showToast({
        title: '请上传门店图片',
        duration: 2000,
        icon: 'none'
      })
      return;
    }
    console.log(md_type)
    // return
    if (!md_type) {
      wx.showToast({
        title: '请选择所属公寓',
        duration: 2000,
        icon: 'none'
      })
      return;
    }
    if (!title1) {
      wx.showToast({
        title: '请填写门店名称',
        duration: 2000,
        icon: 'none'
      })
      return;
    }
    if (!intro) {
      wx.showToast({
        title: '请填写门店地址',
        duration: 2000,
        icon: 'none'
      })
      return;
    }
    if (!tel1) {
      wx.showToast({
        title: '请填写门店电话',
        duration: 2000,
        icon: 'none'
      })
      return;
    }
    if (!content) {
      wx.showToast({
        title: '请填写门店介绍',
        duration: 2000,
        icon: 'none'
      })
      return;
    }
    if (!u_name) {
      wx.showToast({
        title: '请填写对接人',
        duration: 2000,
        icon: 'none'
      })
      return;
    }
    if (!u_tel) {
      wx.showToast({
        title: '请填写手机账号',
        duration: 2000,
        icon: 'none'
      })
      return;
    }
    if (!u_pass) {
      wx.showToast({
        title: '请填写密码',
        duration: 2000,
        icon: 'none'
      })
      return;
    }
    var mareg = /^[a-zA-Z0-9]{6,18}$/

    for (var k = 0; k < u_pass.length; k++) {
      if (!mareg.test(u_pass[k])) {
        wx.showToast({
          title: '密码由6-18位数字字母组成',
          duration: 2000,
          icon: 'none'
        })
        return;
      }
    }
    for (var i = 0; i < u_name.length; i++) {
      var u_name1 = u_name1 + '@' + u_name[i]
    }
    for (var y = 0; y < u_tel.length; y++) {
      var u_tel1 = u_tel1 + '@' + u_tel[y]
    }
    for (var o = 0; o < u_pass.length; o++) {
      var u_pass1 = u_pass1 + '@' + u_pass[o]
    }
    that.setData({
      type: 1
    })
    wx.request({
      url: app.globalData.url + 'api/fabu/check_title_content',
      data: {
        title: intro,
        content: content,
      },
      method: 'post',
      success: function (ftc) {
        if (ftc.data.info != 1) {
          wx.showToast({
            title: '门店地址存在敏感词,请重新输入',
            duration: 2000,
            icon: 'none'
          })
          that.setData({
            type: 0
          })
          return;
        } else if (ftc.data.info1 != 1) {
          wx.showToast({
            title: '门店介绍存在敏感词,请重新输入',
            duration: 2000,
            icon: 'none'
          })
          that.setData({
            type: 0
          })
          return;
        } else if (ftc.data.info1 == 1 && ftc.data.info == 1) {
          that.uploadimg3();
          setTimeout(function () {
            var data = []
            that.uploadimg2(data);
          }, 1000)
          wx.showToast({
            title: '上传中,请稍后...',
            duration: 2000,
            icon: 'none'
          })
          setTimeout(function () {
            

          }, 2000)
        }
      }
    })
  },
  onShow: function () {
    var that = this
    console.log(1)
    that.setData({
      title1: app.globalData.ss_xq_name,
      intro: app.globalData.ss_xq_addr,
      type: 0
    })
  },
})