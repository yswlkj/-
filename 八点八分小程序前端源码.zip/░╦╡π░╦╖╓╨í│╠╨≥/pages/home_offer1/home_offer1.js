// pages/home_offer/home_offer.js
const app = getApp()
const date = new Date();
const years = [];
const months = [];
const days = [];
const hours = [];
const minutes = [];
for (let i = 0; i <= date.getFullYear() + 5; i++) {
  years.push("" + i);
}
//获取月份
for (let i = 0; i <= 12; i++) {
  if (i < 10) {
    i = "0" + i;
  }
  months.push("" + i);
}
//获取日期
for (let i = 0; i <= 31; i++) {
  if (i < 10) {
    i = "0" + i;
  }
  days.push("" + i);
}
//获取小时
for (let i = 0; i < 24; i++) {
  if (i < 10) {
    i = "0" + i;
  }
  hours.push("" + i);
}
//获取分钟
for (let i = 0; i < 60; i++) {
  if (i < 10) {
    i = "0" + i;
  }
  minutes.push("" + i);
}
let uploadimg = require('../../utils/util.js');
var dateTimePicker = require('../../utils/dateTimePicker.js');
Page({

  /**
   * 页面的初始数据
   */
  data: {
    second: 60,
    change: 0,
    dateTimeArray1: null,
    dateTime1: null,
    a1: '请选择看房时间',
    a2: '请选择人数',
    countryList: ['1', '2', '3', '4', '5', '6', '7'],
    multiArray: [years, months, days, hours, minutes],
    multiIndex: [2019, 8, 27, 16, 7],
    navlist: [
      {
        id: '0',
        value: '有宠物'
      },
      {
        id: '1',
        value: '无宠物'
      },
    ],
    nav: 0,
    type: 0
  },
  check: function (e) {
    var that = this
    var id = e.currentTarget.dataset.id
    app.globalData.chong = id
    that.setData({
      nav: id
    })
  },
  changeCountry(e) {
    var that = this
    var countryList = that.data.countryList
    var countryIndex = e.detail.value
    console.log(countryList[countryIndex])
    app.globalData.ren = countryList[countryIndex]
    that.setData({ countryIndex: e.detail.value });
    if (e.detail.value) {
      var val1 = 2;
    } else {
      var val1 = 3;
    }
    that.setData({
      val1: val1
    })
  },
  onLoad: function (e) {
    var that = this
    var id = e.id
    var fid = e.fid
    wx.setNavigationBarTitle({
      title: '预约房源',
    })
    app.globalData.f_id = id
    app.globalData.y_id = fid
    var tel = wx.getStorageSync('tel')
    var ntime = Date.parse(new Date()) / 1000;
    console.log(ntime)
    var notime = uploadimg.formatTimeTwo(ntime)
    console.log(notime);
    that.setData({
      multiIndex: notime
    })
    wx.request({
      url: app.globalData.url + 'api/offer/show1',
      data: {
        id: id,
        fid: fid,
        tel: tel
      },
      method: 'post',
      success: function (res) {
        console.log(res)
        app.globalData.u_tel = res.data.user.mobile
        app.globalData.u_name = res.data.user.name
        that.setData({
          user: res.data.user,
          info: res.data.info,
          url: app.globalData.url,
          y_info: res.data.y_info,
          nav: res.data.y_info.chong,
          multiIndex: res.data.y_info.shijian,
          pinpai: app.globalData.pinpai,
          wei: app.globalData.wei,
          bao: app.globalData.bao,
          youxuan: app.globalData.youxuan,
          pinpai1: app.globalData.pinpai1,
          wei1: app.globalData.wei1,
          bao1: app.globalData.bao1,
          youxuan1: app.globalData.youxuan1
        })
      }
    })
    // 获取完整的年月日 时分秒，以及默认显示的数组
    var obj = dateTimePicker.dateTimePicker(that.data.startYear, that.data.endYear);
    var obj1 = dateTimePicker.dateTimePicker(that.data.startYear, that.data.endYear);
    // 精确到分的处理，将数组的秒去掉
    var lastArray = obj1.dateTimeArray.pop();
    var lastTime = obj1.dateTime.pop();
    console.log(that.data),
      that.setData({
        dateTimeArray1: obj1.dateTimeArray,
        dateTime1: obj1.dateTime,
        a1: that.data.a1,
      });
  },
  tel: function (e) {
    var that = this
    that.setData({
      tel: e.detail.value
    })
    var tel = e.detail.value
    var u_tel = that.data.user.mobile
    if (tel != u_tel) {
      that.setData({
        change: 1
      })
    } else {
      that.setData({
        change: 0
      })
    }
  },
  content: function (e) {
    var that = this
    that.setData({
      content: e.detail.value
    })
  },
  yzm: function (e) {
    var that = this
    var tel = that.data.tel
    if (!tel) {
      var tel1 = app.globalData.u_tel
      if (!tel1) {
        wx.showToast({
          title: '请填写手机号',
          duration: 2000,
          icon: 'none'
        })
        return;
      }
      var mareg = /^((13[0-9])|(14[0-9])|(15[0-9])|(17[0-9])|(18[0-9]))\d{8}$/
      if (!mareg.test(tel1)) {
        wx.showToast({
          title: '手机号格式错误',
          duration: 2000,
          icon: 'none'
        })
        return;
      }
      app.globalData.r_tel = tel1
      wx.request({
        url: app.globalData.url + 'api/offer/yzm',
        data: {
          tel: tel1
        },
        method: 'post',
        success: function (res) {
          console.log(res)
          that.setData({
            success: 1
          })
          let promise = new Promise((resolve, reject) => {
            let setTimer = setInterval(
              () => {
                that.setData({
                  second: that.data.second - 1,
                })
                if (that.data.second <= 0) {
                  that.setData({
                    second: 60,
                    alreadySend: false,
                    send: true,
                  })
                  resolve(setTimer)
                }
              }, 1000)
            that.setData({
              disabled: 'disabled'
            })
          })
          promise.then((setTimer) => {
            clearInterval(setTimer)
            that.setData({
              success: 2,
              disabled: ''
            })
          })
        }
      })
    } else {
      var myreg = /^((1[0-9]{2})+\d{8})$/;
      if (!myreg.test(tel)) {
        wx.showToast({
          title: "手机号格式有误",
          icon: 'none',
          duration: 2000
        })
        return false;
      }
      app.globalData.r_tel = tel
      wx.request({
        url: app.globalData.url + 'api/offer/yzm',
        data: {
          tel: tel
        },
        method: 'post',
        success: function (res) {
          that.setData({
            success: 1
          })
          console.log(res)
          let promise = new Promise((resolve, reject) => {
            let setTimer = setInterval(
              () => {
                that.setData({
                  second: that.data.second - 1,
                })
                if (that.data.second <= 0) {
                  that.setData({
                    second: 60,
                    alreadySend: false,
                    send: true,
                  })
                  resolve(setTimer)
                }
              }, 1000)
            that.setData({
              disabled: 'disabled'
            })
          })
          promise.then((setTimer) => {
            clearInterval(setTimer)
            that.setData({
              success: 2,
              disabled: ''
            })
          })
        }
      })
    }
  },
  code: function (e) {
    var that = this
    that.setData({
      code: e.detail.value
    })
  },
  name: function (e) {
    var that = this
    that.setData({
      name: e.detail.value
    })
  },
  submit: function (e) {
    var that = this
    var code = that.data.code
    var content = that.data.content
    var tel = app.globalData.r_tel
    var name = that.data.name
    var time = app.globalData.etime
    var ren = app.globalData.ren
    var chong = that.data.chong
    console.log(time)
    var time1 = uploadimg.formatTime(new Date());
    // 再通过setData更改Page()里面的data，动态更新页面的数据
    console.log(time1)

    // return;
    if (!name) {
      var name1 = app.globalData.u_name
    } else {
      var name1 = name
    }

    if (!tel) {
      if (that.data.change == 1) {
        wx.showToast({
          title: "请获取验证码",
          icon: 'none',
          duration: 2000
        })
        return false;
      } else {
        var tel = app.globalData.u_tel
      }
    } else {
      var myreg = /^((1[0-9]{2})+\d{8})$/;
      if (!myreg.test(tel)) {
        wx.showToast({
          title: "手机号格式有误",
          icon: 'none',
          duration: 2000
        })
        return false;
      }
    }
    if (that.data.change == 1) {
      if (!code) {
        wx.showToast({
          title: '请填写验证码',
          duration: 2000,
          icon: 'none'
        })
        return;
      }
    }
    if (!time) {
      wx.showToast({
        title: '请选择看房时间',
        duration: 2000,
        icon: 'none'
      })
      return;
    } else {
      if (time1 > time) {
        wx.showToast({
          title: '请选择正确的看房时间，请勿小于当前时间',
          duration: 2000,
          icon: 'none'
        })
        return;
      } else {
        console.log(2)
      }
    }
    if (!ren) {
      var ren = that.data.y_info.ren
    }
    if (!chong) {
      var chong1 = that.data.y_info.chong
    } else {
      var chong1 = chong
    }
    wx.request({
      url: app.globalData.url + 'api/offer/update',
      data: {
        ren: ren,
        time: time,
        chong: chong1,
        code: code,
        tel: tel,
        name: name1,
        content: content,
        fid: app.globalData.f_id,
        yid: app.globalData.y_id,
        mobile: wx.getStorageSync('tel')
      },
      method: 'post',
      success: function (res) {
        console.log(res)
        if (res.data.info == 1) {
          wx.showToast({
            title: '提交成功',
            duration: 2000,
            icon: 'none'
          })
          setTimeout(function () {
            wx.navigateBack({

            })
          }, 2000)
        }
      }
    })
  },
  changeDateTime1(e) {
    console.log(e)
    this.setData({ dateTime1: e.detail.value });
    if (e.detail.value) {
      var val = 0;
    } else {
      var val = 1;
    }
    this.setData({
      val: val
    })
  },
  changeDateTimeColumn1(e) {
    var arr = this.data.dateTime1, dateArr = this.data.dateTimeArray1;

    arr[e.detail.column] = e.detail.value;
    dateArr[2] = dateTimePicker.getMonthDay(dateArr[0][arr[0]], dateArr[1][arr[1]]);

    this.setData({
      dateTimeArray1: dateArr
    });
  },
  bindMultiPickerChange: function (e) {
    // console.log('picker发送选择改变，携带值为', e.detail.value)
    this.setData({
      multiIndex: e.detail.value
    })
    const index = this.data.multiIndex;
    const year = this.data.multiArray[0][index[0]];
    const month = this.data.multiArray[1][index[1]];
    const day = this.data.multiArray[2][index[2]];
    const hour = this.data.multiArray[3][index[3]];
    const minute = this.data.multiArray[4][index[4]];
    // console.log(`${year}-${month}-${day}-${hour}-${minute}`);
    this.setData({
      time: year + '-' + month + '-' + day + ' ' + hour + ':' + minute
    })
    // console.log(this.data.time);
    var time = this.data.time
    console.log(time)
    app.globalData.etime = time
  },
  //监听picker的滚动事件
  bindMultiPickerColumnChange: function (e) {
    //获取年份
    if (e.detail.column == 0) {
      let choose_year = this.data.multiArray[e.detail.column][e.detail.value];
      console.log(choose_year);
      this.setData({
        choose_year
      })
    }
    //console.log('修改的列为', e.detail.column, '，值为', e.detail.value);
    if (e.detail.column == 1) {
      let num = parseInt(this.data.multiArray[e.detail.column][e.detail.value]);
      let temp = [];
      if (num == 1 || num == 3 || num == 5 || num == 7 || num == 8 || num == 10 || num == 12) { //判断31天的月份
        for (let i = 1; i <= 31; i++) {
          if (i < 10) {
            i = "0" + i;
          }
          temp.push("" + i);
        }
        this.setData({
          ['multiArray[2]']: temp
        });
      } else if (num == 4 || num == 6 || num == 9 || num == 11) { //判断30天的月份
        for (let i = 1; i <= 30; i++) {
          if (i < 10) {
            i = "0" + i;
          }
          temp.push("" + i);
        }
        this.setData({
          ['multiArray[2]']: temp
        });
      } else if (num == 2) { //判断2月份天数
        let year = parseInt(this.data.choose_year);
        console.log(year);
        if (((year % 400 == 0) || (year % 100 != 0)) && (year % 4 == 0)) {
          for (let i = 1; i <= 29; i++) {
            if (i < 10) {
              i = "0" + i;
            }
            temp.push("" + i);
          }
          this.setData({
            ['multiArray[2]']: temp
          });
        } else {
          for (let i = 1; i <= 28; i++) {
            if (i < 10) {
              i = "0" + i;
            }
            temp.push("" + i);
          }
          this.setData({
            ['multiArray[2]']: temp
          });
        }
      }
      console.log(this.data.multiArray[2]);
    }
    var data = {
      multiArray: this.data.multiArray,
      multiIndex: this.data.multiIndex
    };
    data.multiIndex[e.detail.column] = e.detail.value;
    this.setData(data);
  },
  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {
    this.setData({
      val: 1
    })
    this.setData({
      val1: 3
    })
  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function (e) {
    console.log(e)
    var that = this
    if (e.from == 'menu') {
      return {
        title: app.globalData.fenxiang1,
        path: '/pages/index/index',
        imageUrl: app.globalData.url + app.globalData.fenxiang,
        success: function (shareTickets) {
          console.info(shareTickets + '成功');
          // 转发成功
        },
        fail: function (res) {
          console.log(res + '失败');
          // 转发失败
        },
        complete: function (res) {
          // 不管成功失败都会执行
        }
      }
    }
  }
})