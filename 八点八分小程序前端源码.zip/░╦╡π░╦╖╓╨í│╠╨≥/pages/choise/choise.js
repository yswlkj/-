const app = getApp()
var QQMapWX = require('../../libs/qqmap-wx-jssdk.js');
// 实例化API核心类
var qqmapsdk = new QQMapWX({
  key: 'I4CBZ-FYL6G-X2LQD-I56ON-N6K7E-UQFK4' // 必填
});
Page({
  data: {},
  tiao: function(e) {
    var that = this
    var til = e.currentTarget.dataset.til
    var type = that.data.type
    if (type == 0) {
      wx.navigateTo({
        url: '../home/home?id=' + 0 + '&key=' + til,
      })
    } else if (type == 1) {
      wx.navigateTo({
        url: '../home/home?id=' + that.data.id + '&key=' + til,
      })
    } else if (type == 2) {
      wx.navigateTo({
        url: '../pinpai/pinpai?id=' + that.data.id + '&key=' + til,
      })
    } else if (type == 3) {
      wx.navigateTo({
        url: '/collect/yang/yang?id=' + that.data.id + '&key=' + til,
      })
    }
  },
  shanchu: function(){
    var that = this

    wx.showModal({
      title: '提示',
      content: '是否清空历史搜索',
      showCancel: true,
      cancelText: '我再想想',
      confirmText: '立即清除',
      success: function(res) {
        if (res.confirm){
          wx.request({
            url: app.globalData.url + 'api/about/lishi_del',
            data: {
              tel: wx.getStorageSync('tel')
            },
            method: 'post',
            success: function (res) {
              console.log(res)
              if (res.data.info == 1) {
                wx.showToast({
                  title: '清空成功',
                  duration: 2000,
                  icon: 'none',
                  mask: true
                })
                setTimeout(function () {
                  that.reload()
                }, 2000)
              } else if (res.data.info == 0) {
                wx.showToast({
                  title: '暂无历史搜索',
                  duration: 2000,
                  icon: 'none',
                  mask: true
                })
              }
            }
          })
        }
      },
    })
  },
  reload: function(){
    var that = this
    wx.request({
      url: app.globalData.url + 'api/about/lishi',
      data: {
        tel: wx.getStorageSync('tel')
      },
      method: 'post',
      success: function (res) {
        console.log(res)
        that.setData({
          list: res.data.arr,
        })
      }
    })
  },
  onLoad: function(e) {
    var that = this
    wx.setNavigationBarTitle({
      title: '搜索',
    })
    var type = e.type
    var id = e.id
    app.globalData.choise_id = id
    app.globalData.choise_type = type
    wx.request({
      url: app.globalData.url + 'api/about/lishi',
      data: {
        tel: wx.getStorageSync('tel')
      },
      method: 'post',
      success: function(res) {
        console.log(res)
        that.setData({
          list: res.data.arr,
          type: type,
          id: id
        })
      }
    })
  },
  key: function(e) {
    var that = this
    that.setData({
      key: e.detail.value
    })
  },
  submit: function(e) {
    var that = this
    var key = that.data.key
    if (!key) {
      wx.showToast({
        title: '请输入关键字',
        duration: 2000,
        icon: 'none',
        mask: true
      })
      return;
    }
    var type = that.data.type
    if (type == 0) {
      wx.navigateTo({
        url: '../home/home?id=' + 0 + '&key=' + key,
      })
    } else if (type == 1) {
      wx.navigateTo({
        url: '../home/home?id=' + that.data.id + '&key=' + key,
      })
    } else if (type == 2) {
      wx.navigateTo({
        url: '../pinpai/pinpai?id=' + that.data.id + '&key=' + key,
      })
    } else if (type == 3) {
      wx.navigateTo({
        url: '/collect/yang/yang?id=' + that.data.id + '&key=' + key,
      })
    }
  },
  onShow: function(){
    var that = this
    wx.request({
      url: app.globalData.url + 'api/about/lishi',
      data: {
        tel: wx.getStorageSync('tel')
      },
      method: 'post',
      success: function (res) {
        console.log(res)
        that.setData({
          list: res.data.arr,
          type: app.globalData.choise_type,
          id: app.globalData.choise_id
        })
      }
    })
  },
  onUnload: function () {
    wx.navigateBack({
      delta: 2,
    })
  },
})