// pages/rlease_post/rlease_post.js
const app = getApp()
var QQMapWX = require('../../utils/qqmap-wx-jssdk.js');
var qqmapsdk = new QQMapWX({
  key: 'I4CBZ-FYL6G-X2LQD-I56ON-N6K7E-UQFK4' // 必填
});
var dateTimePicker = require('../../utils/dateTimePicker.js');

const date = new Date()
const years = []
const months = []
const days = []

for (let i = date.getFullYear(); i <= 2100; i++) {
  years.push(i)
}

for (let i = 1; i <= 12; i++) {
  months.push(i)
}

for (let i = 1; i <= 31; i++) {
  days.push(i)
}

function search(arr, dst) {
  var i = arr.length;
  while (i -= 1) {
    if (arr[i] == dst) {
      return i;
    }
  }
  return false;
}
Page({

  /**
   * 页面的初始数据
   */
  data: {
    years: years,
    year: date.getFullYear(),
    months: months,
    month: 2,
    days: days,
    day: 2,
    value: [1, 0, 1],
    region: ["四川省", "广元市", "苍溪县"],
    time: '12:00',
    dateTimeArray: null,
    dateTime: null,
    dateTimeArray1: null,
    dateTime1: null,
    startYear: 2000,
    endYear: 2050,
    zu:[],
    res: 0,
    suishi: 0,
    yincang2: true,
    multiArray: [[1, 2, 3, 4, 5, 6, 7, 8, 9], '室', [0, 1, 2, 3, 4, 5, 6, 7, 8, 9], '厅', [0, 1, 2, 3, 4, 5, 6, 7, 8, 9], '卫'],
    // multiIndex: [0,0,0,0,1],
    multiIndex2: [0, 0, 0, 0, 1],
    shi: '室',
    ting: '厅',
    wei: '卫',
    navlist:[
      {
        id:0,
        title:"男女不限"
      },
      {
        id:1,
        title: "限女生"
      },
      {
        id:2,
        title: "限男生"
      }
    ],
    nav: 0,
    navlist1:[
      {
        id: 0,
        title: "整租"
      },
      {
        id: 1,
        title: "合租"
      },
    ],
    
  },
  area: function (e) {
    var that = this
    wx.navigateTo({
      url: '../map/map',
    })
  },
  suishi: function(e) {
    var that = this
    that.setData({
      suishi: 1,
      yincang2: true,
      bottom: -100
    })
    app.globalData.time = '随时入住'
  },
  bakbtn2: function(e) {
    this.setData({
      yincang2: true,
      bottom: -100
    })
  },
  bindChange: function(e) {
    var val = e.detail.value
    var that = this
    console.log(e)
    var days = []
    var months = e.detail.value[1] + 1
    console.log(months)
    if (months == 1) {
      for (let o = 1; o <= 31; o++) {
        days.push(o)
      }
    } else if (months == 2) {
      for (let o = 1; o <= 29; o++) {
        days.push(o)
      }
    } else if (months == 3) {
      for (let o = 1; o <= 31; o++) {
        days.push(o)
      }
    } else if (months == 4) {
      for (let o = 1; o <= 30; o++) {
        days.push(o)
      }
    } else if (months == 5) {
      for (let o = 1; o <= 31; o++) {
        days.push(o)
      }
    } else if (months == 6) {
      for (let o = 1; o <= 30; o++) {
        days.push(o)
      }
    } else if (months == 7) {
      for (let o = 1; o <= 31; o++) {
        days.push(o)
      }
    } else if (months == 8) {
      for (let o = 1; o <= 31; o++) {
        days.push(o)
      }
    } else if (months == 9) {
      for (let o = 1; o <= 30; o++) {
        days.push(o)
      }
    } else if (months == 10) {
      for (let o = 1; o <= 31; o++) {
        days.push(o)
      }
    } else if (months == 11) {
      for (let o = 1; o <= 30; o++) {
        days.push(o)
      }
    } else if (months == 12) {
      for (let o = 1; o <= 31; o++) {
        days.push(o)
      }
    }
    console.log(days)
    that.setData({
      days: days
    })

    that.setData({
      year: that.data.years[val[0]],
      month: that.data.months[val[1]],
      day: that.data.days[val[2]],
      suishi: 0,
      rzsj1: that.data.years[val[0]] + '-' + that.data.months[val[1]] + '-' + that.data.days[val[2]]
    })
    var year = that.data.years[val[0]]
    var month = that.data.months[val[1]]
    var day = that.data.days[val[2]]
    app.globalData.time = year + '-' + month + '-' + day
  },
  liubtn2: function(e) {

    this.setData({
      yincang2: false,
      bottom: 0
    })
  },
  listenerButtonPreviewImage: function (e) {
    let index = e.target.dataset.index;
    let that = this;
    wx.previewImage({
      current: that.data.tempFilePaths[index],
      urls: that.data.tempFilePaths,
      success: function (res) {
      },
      fail: function () {
      }
    })
  },
  changeMultiPicker1(e) {
    console.log(e)
    var that = this
    that.setData({ multiIndex: e.detail.value })
    var multiIndex = that.data.multiIndex
    console.log(multiIndex)
    app.globalData.huxing = multiIndex.toString()
    console.log(app.globalData.huxing)
  },
  changeCountry(e) {
    var countryList = this.data.countryList
    app.globalData.huxing = countryList[e.detail.value]
    this.setData({ countryIndex: e.detail.value });
  },
  changeRegin(e) {
    console.log(e)
    app.globalData.dizhi = []
    app.globalData.dz_code = []
    app.globalData.dz_code = e.detail.code
    app.globalData.dizhi = e.detail.value
    this.setData({ region: e.detail.value });
  },
  // 选择二级联动
  changeMultiPicker(e) {
    this.setData({ multiIndex: e.detail.value })
  },
  // 选择三级联动
  changeMultiPicker3(e) {
    this.setData({ multiIndex3: e.detail.value })
  },
  changeDate(e) {
    console.log(e)
    app.globalData.time = e.detail.value
    this.setData({ date: e.detail.value });
  },
  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (e) {
    var that = this
    var zt = e.zt
    wx.setNavigationBarTitle({
      title: '求租贴发布',
    })
    app.globalData.zt = zt
    app.globalData.pics = []
    app.globalData.hugong = ''
    wx.request({
      url: app.globalData.url + 'api/qiuzu/index',
      success: function(res){
        console.log(res)
        var years = that.data.years
        var months = that.data.months
        var days = that.data.days
        var years_index = search(years, date.getFullYear())
        var months_index = search(months, res.data.month)
        var days_index = search(days, res.data.day)
        console.log(years_index, months_index, days_index)
        var value = that.data.value
        value.splice(0, 1, years_index);
        value.splice(1, 1, months_index);
        value.splice(2, 1, days_index);
        that.setData({
          countryList: res.data.huxing,
          qiuzu: res.data.qiuzu,
          zt: zt,
          date: res.data.time,
          year: res.data.year,
          month: res.data.month,
          day: res.data.day,
          value: value,
        })
      }
    })
    wx.getLocation({
      type: 'gcj02',
      altitude: true,
      success: function (res) {
        console.log("获取当前城市名...");
        console.log(res);
        if (res && res.longitude && res.latitude) {
          var longitude = res.longitude;
          var latitude = res.latitude;
          that.getLocate(latitude, longitude)
          
        } else {
          that.setData({
            city: '获取失败',
            addre: 1
          })
        }
      }
    })
  },
  getLocate(latitude, longitude) {
    var that = this;
    var locationString = latitude + "," + longitude;
    wx.request({
      url: 'https://apis.map.qq.com/ws/geocoder/v1/?location=',
      data: {
        "key": "I4CBZ-FYL6G-X2LQD-I56ON-N6K7E-UQFK4",
        "location": locationString
      },
      method: 'GET',
      success: function (res) {
        console.log(res)
        app.globalData.adcode = res.data.result.ad_info.adcode
        var citycode = res.data.result.ad_info.city_code
        app.globalData.city_name = res.data.result.ad_info.city
        app.globalData.city_code = citycode.slice(3, 9)
        var val = res.data.result.address_component.city
        // if (val.indexOf('市') !== -1) {//这里是去掉“市”这个字
        //   val = val.slice(0, val.indexOf('市'));
        // }
        var province = res.data.result.address_component.province
        var city = res.data.result.address_component.city
        var district = res.data.result.address_component.district
        app.globalData.locateCity = val
        app.globalData.dizhi = [province, city, district]
        that.setData({
          locateCity: val,
          region: [province, city, district]
        });
      },
    })
  },
  change: function(e){
    var that = this
    var id = e.currentTarget.dataset.id
    that.setData({
      nav: id
    })
    app.globalData.setsex = id
  },
  change1: function(e){
    var that = this
    var arr = that.data.qiuzu
    var zu = that.data.zu
    if(zu.length == 0){
      for(var i=0; i<arr.length; i++){
        var zu = zu.concat(0)
      }
    }
    console.log(zu)
    var id = e.currentTarget.dataset.id
    var index = e.currentTarget.dataset.index
    
    if(zu[index] == 0){
      zu.splice(index, 1, id)
    }
    console.log(zu)
    app.globalData.zu = zu
    that.setData({
      zu: zu
    })
  },
  change3: function(e){
    var that = this
    var zu = that.data.zu
    var index = e.currentTarget.dataset.index
    var id = e.currentTarget.dataset.id
    zu.splice(index, 1 , 0)
    console.log(zu)
    that.setData({
      zu: zu
    })
    app.globalData.zu = zu
  },
  change2: function(e){
    var that = this
    var id = e.currentTarget.dataset.id
    that.setData({
      zt: id
    })
    app.globalData.zt = id
  },
  upload: function () {
    let that = this; 
    wx.chooseImage({
      count: 9 - app.globalData.pics.length, // 默认9
      sizeType: ['compressed'], // 可以指定是原图还是压缩图，默认二者都有
      sourceType: ['album', 'camera'], // 可以指定来源是相册还是相机，默认二者都有
      success: res => {
        wx.showToast({
          title: '正在上传...',
          icon: 'loading',
          mask: true,
          duration: 1000
        })
        // 返回选定照片的本地文件路径列表，tempFilePath可以作为img标签的src属性显示图片
        if (app.globalData.pics.length < 9) {
          app.globalData.pics = app.globalData.pics.concat(res.tempFilePaths)
        } else {
          app.globalData.pics = app.globalData.pics
          wx.showToast({
            title: '互动图片最多9张',
            duration: 2000,
            icon: 'none'
          })
          that.setData({
            res: 0
          })
        }
        console.log(app.globalData.pics)
        let tempFilePaths = res.tempFilePaths;
        that.setData({
          tempFilePaths: app.globalData.pics
        })
      }
    })
  },
  aaa: function (e) {
    var that = this
    // console.log(app.globalData.zt)
    
    var imgs = app.globalData.pics;
    // console.log(code1)
    var index = e.currentTarget.dataset.index;
    imgs.splice(index, 1);
    app.globalData.pics = imgs
    console.log(imgs)
    that.setData({
      tempFilePaths: imgs,
    });
  },
  
  uploadimg: function (data) { //这里触发图片上传的方法
    var that = this
    var pics = app.globalData.pics
    var i;

    i = data.i ? data.i : 0,//当前上传的哪张图片
      wx.uploadFile({
      url: app.globalData.url + 'api/qiuzu/img',
        filePath: pics[i],
        name: 'file',//这里根据自己的实际情况改
        formData: null,//这里是上传图片时一起上传的数据
        success: (resp) => {
          app.globalData.hugong = app.globalData.hugong + '@' + resp.data
          console.log(app.globalData.hugong)
          var pic_str = app.globalData.hugong
          if (pic_str) {
            console.log('zoule')
            var pic_arr = pic_str.split('@')
            if ((pic_arr.length - 1) == pics.length) {
              console.log('zoule1')
              that.save()
            }
          }
        },
        complete: (res) => {
          i++;//这个图片执行完上传后，开始上传下一张
          if (i == pics.length) {   //当图片传完时，停止调用          
            console.log('执行完毕');
          } else {//若图片还没有传完，则继续调用函数
            // console.log(i);
            data.i = i;
            that.uploadimg(data);
          }

        }
      });

  },
  content: function(e){
    var that = this
    that.setData({
      content: e.detail.value
    })
  },
  price: function(e){
    var that = this
    that.setData({
      price: e.detail.value
    })
  },
  backfill: function (e) {
    var that = this
    var id = e.currentTarget.id;
    for (var i = 0; i < that.data.suggestion.length; i++) {
      if (i == id) {
        that.setData({
          backfill: that.data.suggestion[i].title,
          lng: that.data.suggestion[i].longitude,
          lat: that.data.suggestion[i].latitude,
          zt1: 0
        });
      }
    }
  },
  title: function(e){
    var that = this
    that.setData({
      title: e.detail.value
    })
  },
  xiaoqu: function (e) {
    // console.log(2)
    var _this = this;
    _this.setData({
      xiaoqu: e.detail.value
    });
    // console.log(e.detail.value)
    if(e.detail.value == ''){
      _this.setData({
        zt1:0
      })
    }
    //调用关键词提示接口
    qqmapsdk.getSuggestion({
      //获取输入框值并设置keyword参数
      keyword: e.detail.value, //用户输入的关键词，可设置固定值,如keyword:'KFC'
      //region:'北京', //设置城市名，限制关键词所示的地域范围，非必填参数
      success: function (res) { //搜索成功后的回调
        console.log(res);
        var sug = [];
        for (var i = 0; i < res.data.length; i++) {
          sug.push({ // 获取返回结果，放到sug数组中
            title: res.data[i].title,
            id: res.data[i].id,
            addr: res.data[i].address,
            city: res.data[i].city,
            district: res.data[i].district,
            latitude: res.data[i].location.lat,
            longitude: res.data[i].location.lng
          });
        }
        _this.setData({ //设置suggestion属性，将关键词搜索结果以列表形式展示
          suggestion: sug,
          zt1: 1
        });
      },
      fail: function (error) {
        // console.error(error);
      },
    });
    _this.setData({
      xiaoqu: e.detail.value
    })
  },
  submit: function(e){
    var that = this
    var dizhi = app.globalData.dizhi
    var price = that.data.price
    var zt = app.globalData.zt
    var pic = app.globalData.pics
    var huxing = app.globalData.huxing
    var time = app.globalData.time
    var setsex = app.globalData.setsex
    var title = that.data.title
    var content = that.data.content
    var zu = app.globalData.zu
    var tel = wx.getStorageSync('tel')
    var lat = app.globalData.ss_xq_latitude
    var lng = app.globalData.ss_sq_longitude
    // var jianjie = that.data.jianjie
    var xiaoqu = app.globalData.ss_xq_name
    // that.setData({
    //   res: 1
    // })
    if(pic.length == 0){
      wx.showToast({
        title: '请上传互动图片',
        duration: 2000,
        icon: 'none'
      })
      that.setData({
        res: 0
      })
      return;
    }else if(pic.length > 9){
      wx.showToast({
        title: '互动图片最多9张',
        duration: 2000,
        icon: 'none'
      })
      that.setData({
        res: 0
      })
      return;
    }
    if(!zt){
      wx.showToast({
        title: '请选择类型',
        duration: 2000,
        icon: 'none'
      })
      that.setData({
        res: 0
      })
      return;
    }
    if (!dizhi) {
      wx.showToast({
        title: '请选择地址',
        duration: 2000,
        icon: 'none'
      })
      that.setData({
        res: 0
      })
      return;
    }
    if (!price) {
      wx.showToast({
        title: '请填写预算',
        duration: 2000,
        icon: 'none'
      })
      that.setData({
        res: 0
      })
      return;
    }
    if (!huxing) {
      wx.showToast({
        title: '请选择户型',
        duration: 2000,
        icon: 'none'
      })
      that.setData({
        res: 0
      })
      return;
    }
    if (!time) {
      var time1 = that.data.date
      that.setData({
        time2: time1
      })
    }else{
      var time1 = time
      that.setData({
        time2: time1
      })
    }
    if (!setsex) {
      var setsex1 = 0
      that.setData({
        setsex2: setsex1
      })
    }else{
      var setsex1 = setsex
      that.setData({
        setsex2: setsex1
      })
    }
    if (!xiaoqu) {
      wx.showToast({
        title: '请填写目标小区',
        duration: 2000,
        icon: 'none'
      })
      that.setData({
        res: 0
      })
      return;
    }
    if (!title) {
      wx.showToast({
        title: '请填写求租标题',
        duration: 2000,
        icon: 'none'
      })
      that.setData({
        res: 0
      })
      return;
    }
    if (!content) {
      wx.showToast({
        title: '请填写求组描述',
        duration: 2000,
        icon: 'none'
      })
      that.setData({
        res: 0
      })
      return;
    }
    if (!zu) {
      wx.showToast({
        title: '请选择求租要求',
        duration: 2000,
        icon: 'none'
      })
      that.setData({
        res: 0
      })
      return;
    }
    for(var y=0; y<dizhi.length; y++){
      var dz = dz +'@'+dizhi[y]
      that.setData({
        dz1: dz
      })
    }
    for(var o=0; o<zu.length; o++){
      var yq = yq +'@'+zu[o]
      that.setData({
        yq1: yq
      })
    }
    wx.request({
      url: app.globalData.url + 'api/fabu/check_title_content',
      data:{
        title: title,
        content: content
      },
      method: 'post',
      success: function(ftc){
        console.log(ftc)
        if(ftc.data.info != 1){
          wx.showToast({
            title: '标题存在敏感词,请重新上传',
            duration: 2000,
            icon: 'none'
          })
          return;
        }else if(ftc.data.info1 != 1){
          wx.showToast({
            title: '描述存在敏感词,请重新上传',
            duration: 2000,
            icon: 'none'
          })
          return;
        }else if(ftc.data.info == 1 && ftc.data.info1 == 1){
          var data = []
          that.uploadimg(data)
          that.setData({
            type2: 0
          })
          that.xianshi()
        }
      }
    })
  },
  xianshi: function () {
    var that = this
    if (that.data.type2 == 0) {
      wx.showToast({
        title: '提交中,请稍后...',
        duration: 10000000000000000,
        icon: 'none'
      })
    }
  },
  save: function(){
    var that = this
    wx.request({
      url: app.globalData.url + 'api/qiuzu/save',
      data: {
        pic: app.globalData.hugong,
        zt: app.globalData.zt,
        dizhi: that.data.dz1,
        price: that.data.price,
        huxing: app.globalData.huxing,
        time: that.data.time2,
        setsex: that.data.setsex2,
        title: that.data.title,
        content: that.data.content,
        zu: that.data.yq1,
        tel: wx.getStorageSync('tel'),
        lng: app.globalData.ss_sq_longitude, 
        lat: app.globalData.ss_xq_latitude,
        // jianjie: jianjie,
        xiaoqu: app.globalData.ss_xq_name
      },
      method: 'post',
      success: function (res) {
        console.log(res)
        if (res.data.info == 1) {
          that.setData({
            type2: 1
          })
          app.globalData.pics = []
          app.globalData.hugong = ''
          app.globalData.tempFilePaths2 = []
          app.globalData.huxing = ''
          app.globalData.ss_xq_latitude = ''
          app.globalData.ss_sq_longitude = ''
          app.globalData.ss_xq_name = undefined
          app.globalData.ss_xq_addr = undefined
          wx.reLaunch({
            url: '../fs1/fs1?id=' + res.data.id + '&lat=' + app.globalData.ss_xq_latitude + '&lng=' + app.globalData.ss_sq_longitude,
          })
        }
      }
    })
  },
  onShow: function () {
    var that = this
    that.setData({
      ss_xq_name1: app.globalData.ss_xq_name
    })
  },
})