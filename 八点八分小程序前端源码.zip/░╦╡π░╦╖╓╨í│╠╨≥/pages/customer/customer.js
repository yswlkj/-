const app = getApp()
Page({
  data: {

  },
  onLoad: function (e) {
    var that = this
    wx.setNavigationBarTitle({
      title: '联系客服',
    })
    wx.request({
      url: app.globalData.url + 'api/my/jianyi',
      data:{
        url: app.globalData.url
      },
      method:'post',
      success: function(res){
        console.log(res)
        app.globalData.tel = res.data.tel.varvalue
        that.setData({
          list: res.data.list
        })
      }
    })
  },
  call: function(){
    wx.makePhoneCall({
      phoneNumber: app.globalData.tel,
    })
  },
})