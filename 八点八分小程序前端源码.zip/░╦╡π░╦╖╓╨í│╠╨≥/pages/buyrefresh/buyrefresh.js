const app = getApp()
Page({
  data: {
    yincang: false,
    hidden: false,
  },
  bakbtn: function (e) {
    this.setData({
      yincang: true,
      bottom: -100
    })
  },
  checkboxChange: function (e) {
    var that = this
    var value = e.detail.value[0]
    if (value == 1) {
      that.setData({
        xieyi: 1
      })
    } else {
      that.setData({
        xieyi: 0
      })
    }
  },
  onLoad: function (e) {
    var that = this
    wx.setNavigationBarTitle({
      title: '购买刷新',
    })
    var id = e.id
    var type = e.type
    console.log(type)
    var tel = wx.getStorageSync('tel')
    wx.request({
      url: app.globalData.url + 'api/shuaxin/index',
      data: {
        tel: tel,
      },
      method: 'post',
      success: function (res) {
        console.log(res)
        that.setData({
          u_cishu: res.data.u_cishu,
          list: res.data.list,
          price: res.data.price,
          id: res.data.id,
          fid: id,
          z_type: type,
          goumaitishi: res.data.goumaitishi,
          fangxieyi: res.data.xieyi,
          qiugoumaitishi: res.data.qiugoumaitishi,
          qiuxieyi: res.data.qiuxieyi,
        })
      }
    })
  },
  radioChange: function (e) {
    var that = this
    var id = e.detail.value
    that.reload(id)
  },
  reload: function (id) {
    var that = this
    var id = id
    wx.setNavigationBarTitle({
      title: '购买刷新',
    })
    app.globalData.shua_id = id
    wx.request({
      url: app.globalData.url + 'api/shuaxin/price_show',
      data: {
        id: id
      },
      method: 'post',
      success: function (res) {
        console.log(res)
        that.setData({
          price: res.data.price,
          id: id
        })
      }
    })
  },
  zhifu: function (e) {
    var that = this
    var id = e.currentTarget.dataset.id
    var price = e.currentTarget.dataset.price
    var openid = wx.getStorageSync('openid')
    var tel = wx.getStorageSync('tel')
    var xieyi = that.data.xieyi
    if (xieyi == 0 || xieyi === undefined) {
      if (that.data.z_type == 0) {
        wx.showToast({
          title: '请先阅读并同意' + that.data.fangxieyi,
          duration: 2000,
          icon: 'none',
          mask: true
        })
      } else {
        wx.showToast({
          title: '请先阅读并同意' + that.data.qiuxieyi,
          duration: 2000,
          icon: 'none',
          mask: true
        })
      }
    } else if (xieyi == 1) {
      wx.showToast({
        title: '正在前往支付',
        duration: 200000,
        icon: 'loading',
        mask: true
      })
      wx.request({
        url: app.globalData.url + 'api/zhifu/payOrder',
        data: {
          openid: openid,
          total_fee: price,
        },
        method: 'post',
        success: function (rag) {
          console.log(rag)
          // wx.requestPayment({
          //   'timeStamp': rag.data.timeStamp,
          //   'nonceStr': rag.data.nonceStr,
          //   'package': rag.data.package,
          //   'signType': rag.data.signType,
          //   'paySign': rag.data.paySign,
          //   'success': function (res) {
              wx.request({
                url: app.globalData.url + 'api/shuaxin/save',
                data: {
                  tel: tel,
                  id: id,
                  fid: that.data.fid,
                  z_type: that.data.z_type
                },
                method: 'post',
                success: function (ras) {
                  console.log(ras)
                  if (ras.data.update == 1) {
                    wx.showToast({
                      title: '购买成功，正在跳转',
                      duration: 2000,
                      icon: 'none',
                      mask: true
                    })
                    setTimeout(function () {
                      wx.navigateBack({

                      })
                    }, 2000)
                  }
                }
              })
        //     },
        //     'fail': function (res) {

        //     },
        //   })
        }
      })
    }
  },
})