// pages/login_zhang/login_zhang.js
const app = getApp()
Page({

  /**
   * 页面的初始数据
   */
  data: {
    type: 1,
    res: 0,
    pic: '../../images/yin.png'
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (w) {
    wx.setNavigationBarTitle({
      title: '账号登录',
    })
    this.setData({
      login_logo: app.globalData.login_logo
    })
  },
  password: function(e){
    var that = this
    that.setData({
      password: e.detail.value
    }) 
  },
  tel: function(e){
    var that = this
    that.setData({
      tel: e.detail.value
    })
  },
  submit: function(){
    var that = this
    var tel = that.data.tel
    var password = that.data.password
    if(!tel){
      wx.showToast({
        title: '请输入手机号',
        duration: 2000,
        icon:'none'
      })
      return;
    }
    if(!password){
      wx.showToast({
        title: '请输入密码',
        duration: 2000,
        icon: 'none'
      })
      return;
    }
    var myreg = /^((1[0-9]{2})+\d{8})$/;
    if (!myreg.test(tel)) {
      wx.showToast({
        title: "手机号格式有误",
        icon: 'none',
        duration: 2000
      })
      return false;
    }
    var openid = wx.getStorageSync('openid')
    wx.request({
      url: app.globalData.url + 'api/my/login',
      data:{
        tel: tel,
        password: password,
        openid: openid,
        lat: app.globalData.lat,
        lng: app.globalData.lng
      },
      method: 'post',
      success: function(res){
        console.log(res)
        that.setData({
          res:1
        })
        if(res.data.info == 0){
          wx.showToast({
            title: '当前账号不存在。',
            duration: 2000,
            icon:'none'
          })
          that.setData({
            res: 0
          })
          return;
        }else if(res.data.info == 2){
          wx.showToast({
            title: '账号密码不匹配，请重新输入。',
            duration: 2000,
            icon: 'none'
          })
          that.setData({
            res: 0
          })
          return;
        }else if(res.data.info == 1){
          wx.setStorageSync('tel', tel)
          wx.showToast({
            title: '恭喜，登录成功！',
            duration: 2000,
            icon:'none'
          })
          setTimeout(function(){
            wx.reLaunch({
              url: '../index/index',
            })
          },2000)
          
        }else if(res.data.info == 3){
          wx.showToast({
            title: '账号已停用',
            duration: 2000,
            icon: 'none'
          })
          that.setData({
            res: 0
          })
          return;
        }
      }
    })
  },
  yin: function (e) {
    var that = this
    var type = that.data.type
    var pass = that.data.password
    if (type == 1) {
      that.setData({
        type: 0,
        pass: pass,
        pic: '../../images/ico7.png'
      })
    } else if (type == 0) {
      that.setData({
        type: 1,
        pass: pass,
        pic: '../../images/yin.png'
      })
    }
  },
  wechatsub: function (e) {
    var that = this
    var openid = wx.getStorageSync('openid')
    console.log(openid)
    wx.request({
      url: app.globalData.url + 'api/my/welogin',
      data: {
        openid: openid,
      },
      method: 'post',
      success: function (res) {
        console.log(res)
        if (res.data.info == 1) {
          wx.showToast({
            title: '当前微信并未绑定账号，请前往注册',
            duration: 2000,
            icon: 'none'
          })
        } else {
          wx.setStorageSync('tel', res.data.info)
          wx.showToast({
            title: '登录成功，正在跳转',
            duration: 2000,
            icon: 'none'
          })
          that.setData({
            type: 2
          })
          setTimeout(function () {
            wx.reLaunch({
              url: '../index/index',
            })
          }, 2000)
        }
      }
    })
  },
  getPhoneNumber: function (e) {
    console.log(e)
    var that = this
    if (e.detail.errMsg === 'getPhoneNumber:ok') {
      wx.request({
        url: app.globalData.url + 'api/wechat/jiemi',
        data: {
          errMsg: e.detail.errMsg,
          encryptedData: e.detail.encryptedData,
          iv: e.detail.iv,
          sessionKey: wx.getStorageSync('sessionkey'),
        },
        method: 'post',
        header: {
          'content-type': 'application/x-www-form-urlencoded'
        },
        success: function (res) {
          console.log(res)
          that.setData({
            tel: res.data.purePhoneNumber
          })
          wx.request({
            url: app.globalData.url + 'api/wechat/kuaijie',
            data: {
              openid: wx.getStorageSync('openid'),
              tel: res.data.purePhoneNumber,
              uid: wx.getStorageSync('uid'),
              lat: app.globalData.lat,
              lng: app.globalData.lng,
              nickname: app.globalData.user_info.nickName,
              picture: app.globalData.user_info.avatarUrl
            },
            method: 'post',
            success: function (rag) {
              console.log(rag)
              if (rag.data.info == 1) {
                wx.showToast({
                  title: '快速登录成功',
                  duration: 2000,
                  icon: 'none'
                })
                wx.setStorageSync('tel', res.data.purePhoneNumber)
                setTimeout(function () {
                  wx.reLaunch({
                    url: '../index/index',
                  })
                }, 2000)
              }else{
                wx.showToast({
                  title: '账号已停用',
                  duration: 2000,
                  icon: 'none'
                })
              }
            }
          })
        },
        fail: function (err) {
          console.log(err);
        }
      })
    } else if (e.detail.errMsg === 'getPhoneNumber:fail user deny'){
      wx.showToast({
        title: '用户已取消快捷登录',
        icon: 'none',
        mask: true,
        duration: 2000
      })
    }
  },
  onShow: function () {
    wx.login({
      success: res => {
        app.globalData.user_code = res.code;
        console.log(app.globalData.user_code)
        // 发送 res.code 到后台换取 openId, sessionKey, unionId
      }
    })
  },
})