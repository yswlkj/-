// pages/xt_ex/xt_ex.js
const app = getApp()
Page({

  /**
   * 页面的初始数据
   */
  data: {

  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (e) {
    var that = this
    var tel = wx.getStorageSync('tel')
    var id = e.id
    var zt = e.zt
    wx.setNavigationBarTitle({
      title: '评论内容',
    })
    wx.request({
      url: app.globalData.url + 'api/xitong/ly_ex',
      data: {
        id: id,
        url: app.globalData.url,
        tel: tel,
        zt: zt
      },
      method: 'post',
      success: function (res) {
        console.log(res)
        that.setData({
          info: res.data.info,
          u_info: res.data.u_info,
          f_user: res.data.f_user,
          uid: res.data.uid
        })
      }
    })
  },
})