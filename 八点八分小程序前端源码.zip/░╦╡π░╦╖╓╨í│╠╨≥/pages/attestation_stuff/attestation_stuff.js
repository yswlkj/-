// pages/attestation_stuff/attestation_stuff.js
const app = getApp()
// // import WxParse from '../../wxParse/wxParse.js';
Page({

  /**
   * 页面的初始数据
   */
  data: {
    navlist: [{
      id: 1,
      title: '房东'
    }, {
      id: 2,
      title: '租客'
    }],
    nav: 1,
    tempFilePaths: [],
    index_arr:[]
  },
  upload: function () {
    let that = this;
    wx.chooseImage({
      count: 3 - app.globalData.cailiao.length, // 默认9
      sizeType: ['compressed'], // 可以指定是原图还是压缩图，默认二者都有
      sourceType: ['album', 'camera'], // 可以指定来源是相册还是相机，默认二者都有
      success: res => {
        wx.showToast({
          title: '正在上传...',
          icon: 'loading',
          mask: true,
          duration: 1000
        })
        // 返回选定照片的本地文件路径列表，tempFilePath可以作为img标签的src属性显示图片
        if (app.globalData.cailiao.length < 3) {
          app.globalData.cailiao = app.globalData.cailiao.concat(res.tempFilePaths)
        } else {
          app.globalData.cailiao = app.globalData.cailiao
          wx.showToast({
            title: '房屋材料图片最多3张',
            duration: 2000,
            icon: 'none',
            mask: true
          })
          that.setData({
            res: 0
          })
        }
        console.log(app.globalData.cailiao)
        let tempFilePaths = res.tempFilePaths;
        that.setData({
          tempFilePaths: app.globalData.cailiao
        })
      }
    })
  },
  aaa: function (e) {
    var that = this
    // console.log(app.globalData.zt)

    var imgs = app.globalData.cailiao;
    // console.log(code1)
    var index = e.currentTarget.dataset.index;
    var index_arr = that.data.index_arr
    // for(var i=0;i<imgs.length;i++){
      if(imgs[index].indexOf("uploads") != -1){
        var index_arr = index_arr.concat(imgs[index])
      }
    // }
    console.log(index_arr)
    // return
    imgs.splice(index, 1);
    app.globalData.cailiao = imgs
    console.log(imgs)
    that.setData({
      tempFilePaths: imgs,
      index_arr: index_arr
    });
  },

  change: function (e) {
    var that = this
    that.setData({
      nav: e.currentTarget.dataset.id
    })
  },
  uploadimg: function (data) { //这里触发图片上传的方法
    var that = this
    var pics = app.globalData.cailiao
    var i;

    i = data.i ? data.i : 0, //当前上传的哪张图片
      wx.uploadFile({
        url: app.globalData.url + 'api/qiuzu/img',
        filePath: pics[i],
        name: 'file', //这里根据自己的实际情况改
        formData: null, //这里是上传图片时一起上传的数据
        success: (resp) => {
          app.globalData.cailiaos = app.globalData.cailiaos + '@' + resp.data
          console.log(app.globalData.cailiaos)
          var pic_str = app.globalData.cailiaos
          if (pic_str) {
            console.log('zoule')
            var pic_arr = pic_str.split('@')
            if ((pic_arr.length - 1) == pics.length) {
              console.log('zoule1')
              that.save()
            }
          }
        },
        complete: (res) => {
          i++; //这个图片执行完上传后，开始上传下一张
          if (i == pics.length) { //当图片传完时，停止调用          
            console.log('执行完毕');
            // that.save();
          } else { //若图片还没有传完，则继续调用函数
            // console.log(i);
            data.i = i;
            that.uploadimg(data);
          }

        }
      });
  },
  submit: function(){
    var that = this
    var nav = that.data.nav
    var cailiao = app.globalData.cailiao
    if(cailiao.length == 0){
      wx.showToast({
        title: '请上传房屋认证材料',
        duration: 2000,
        icon:'none',
        mask: true
      })
      return
    }
    wx.showToast({
      title: '上传中，请稍后',
      duration: 2000000,
      icon:'none',
      mask: true
    })
    var data = []
    that.uploadimg(data)
  },
  save: function(){
    var that = this
    var pics = app.globalData.cailiaos
    var nav = that.data.nav
    var index_arr = that.data.index_arr.toString()
    console.log(index_arr)
    // return
    var tel = wx.getStorageSync('tel')
    wx.request({
      url: app.globalData.url + 'api/about/cailiao_save',
      data:{
        tel: tel,
        nav: nav,
        pics: pics,
        id: that.data.id,
        index_arr: index_arr
      },
      method: 'post',
      success: function(res){
        console.log(res)
        if(res.data.info == 1){
          wx.showToast({
            title: '提交成功',
            duration: 2000,
            icon: 'none',
            mask: true
          })
          app.globalData.cailiao = []
          app.globalData.cailiaos = ''
          setTimeout(function(){
            wx.navigateBack({
              delta: 1,
            })
          },2000)
        }
      }
    })
  },
  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (e) {
    var that = this
    wx.setNavigationBarTitle({
      title: '认证材料',
    })
    app.globalData.cailiao = []
    app.globalData.cailiaos = ''
    wx.request({
      url: app.globalData.url + 'api/about/cailiao',
      data: {
        id: e.id,
        tel: wx.getStorageSync('tel')
      },
      method: 'post',
      success: function (res) {
        console.log(res)
        // var content = res.data.cailiao.content;
        // WxParse.wxParse('content', 'html', content, that, 5)
        if(res.data.info){
          app.globalData.cailiao = res.data.info.picarr
          that.setData({
            nav: res.data.info.nav,
            tempFilePaths: res.data.info.picarr
          })
        }
        that.setData({
          info: res.data.info,
          html: res.data.cailiao.content,
          cailiao: res.data.cailiao,
          id: e.id
        })
      }
    })
  },
  listenerButtonPreviewImage: function (e) {
    let index = e.target.dataset.index;
    let that = this;
    wx.previewImage({
      current: that.data.tempFilePaths[index],
      urls: that.data.tempFilePaths,
      success: function (res) {
      },
      fail: function () {
      }
    })
  },
  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  }
})