const app = getApp()
// // import WxParse from '../../wxParse/wxParse.js';
Page({
  data: {

  },
  onLoad: function (e) {
    var that = this
    
    
    wx.request({
      url: app.globalData.url + 'api/about/tuiguang1',
      data:{
        url: app.globalData.url,
        id: e.id
      },
      method: 'post',
      success: function(res){
        // var content = res.data.info.content;
        // WxParse.wxParse('content', 'html', content, that, 5)
        console.log(res)
        wx.setNavigationBarTitle({
          title: res.data.info.title,
        })
        that.setData({
          info: res.data.info,
          html: res.data.info.content,
        })
      }
    })
  },
})