const app = getApp()
// // import WxParse from '../../wxParse/wxParse.js';
Page({
  data: {
    countryList: ['公寓房东', '职业房东', '个人房东'],
    countryIndex: 0,
    a1: '请选择',
    type: 0,
    name: '',
    code: '',
  },
  changeCountry(e) {
    console.log('222', e)
    this.setData({
      countryIndex: e.detail.value
    });
    app.globalData.val1 = e.detail.value
    var list = this.data.countryList
    if (e.detail.value == 0) {
      var val1 = '公寓房东';
    }
    if (e.detail.value == 1) {
      var val1 = '职业房东';
    }
    if (e.detail.value == 2) {
      var val1 = '个人房东';
    }
    this.setData({
      val1: list[app.globalData.val1],
      val2: e.detail.value
    })
  },
  onLoad: function (options) {
    var that = this
    wx.setNavigationBarTitle({
      title: '房东认证',
    })
    wx.request({
      url: app.globalData.url + 'api/yanzheng/show',
      data:{
        tel: wx.getStorageSync('tel')
      },
      method: 'post',
      success: function (res) {
        // var content = res.data.info.content;
        // WxParse.wxParse('content', 'html', content, that, 5)
        console.log(res)
        // app.globalData.val1 = res.data.
        that.setData({
          info_sfz: res.data.info_sfz,
          html: res.data.info.content,
          gongyu_yyzz_renzheng: res.data.gongyu_yyzz_renzheng,
          zhiye_yyzz_renzheng: res.data.zhiye_yyzz_renzheng,
          info_yyzz: res.data.info_yyzz,
          url: app.globalData.url,
          rz_person: res.data.rz_person,
          zhanshi_rz_person: res.data.zhanshi_rz_person,
          rz_gongyu: res.data.rz_gongyu,
          rz_zhiye: res.data.rz_zhiye,
          geren: res.data.geren,
          zizhi: res.data.zizhi,
          wen: res.data.wen,
          geren_fd_yanzheng: res.data.geren_fd_yanzheng,
          zhiye_fd_yanzheng: res.data.zhiye_fd_yanzheng,
          gongyu_fd_yanzheng: res.data.gongyu_fd_yanzheng,
          user: res.data.user
          // val1: 
        })
      }
    })
    wx.request({
      url: app.globalData.url + 'api/xinyong/fangdong',
      data: {
        tel: wx.getStorageSync('tel')
      },
      method: 'post',
      success: function (ras) {
        console.log(ras)
        if (ras.data.u_info) {
          if (ras.data.u_info.yy_pic) {
            var ewmImg1 = app.globalData.url + ras.data.u_info.yy_pic
          } else {
            var ewmImg1 = null
          }
          if (ras.data.u_info.sfz_pic) {
            var ewmImg = app.globalData.url + ras.data.u_info.sfz_pic
          } else {
            var ewmImg = null
          }
          app.globalData.shenfen = ras.data.u_info.sfz_pic
          app.globalData.yingye = ras.data.u_info.yy_pic
          that.setData({
            name: ras.data.u_info.name,
            code: ras.data.u_info.code,
            u_info: ras.data.u_info,
          })
        }
        app.globalData.val1 = ras.data.user.type
        that.setData({
          info: ras.data.user,
          val1: that.data.countryList[ras.data.user.type],
          a1: that.data.countryList[ras.data.user.type],
          val2: ras.data.user.type,
          url: app.globalData.url,
          ewmImg: ewmImg,
          ewmImg1: ewmImg1,
        })
      }
    })
  },
  code: function (e) {
    var that = this
    that.setData({
      code: e.detail.value
    })
  },
  name: function (e) {
    var that = this
    that.setData({
      name: e.detail.value
    })
  },
  upload: function () {
    let that = this;
    wx.chooseImage({
      count: 1,
      sizeType: ['original', 'compressed'],
      sourceType: ['album', 'camera'],
      success: res => {
        wx.showToast({
          title: '正在上传...',
          icon: 'loading',
          mask: true,
          duration: 1000
        })
        app.globalData.pictures2 = res.tempFilePaths
        that.uploadimg();
        let tempFilePaths = res.tempFilePaths;
        that.setData({
          ewmImg: tempFilePaths,
          type: 1
        })
      }
    })
  },
  uploadimg: function () {
    var that = this
    var pics = app.globalData.pictures2
    var code = that.data.code
    var name = that.data.name
    for (var i = 0; i < pics.length; i++) {
      wx.uploadFile({
        url: app.globalData.url + 'api/yanzheng/img',
        filePath: pics[i],
        name: 'file',
        success: function (res) {
          app.globalData.shenfen = res.data
          wx.request({
            url: app.globalData.url + 'api/yanzheng/check_sf_pic',
            data: {
              pic: res.data
            },
            method: 'post',
            success: function (ras) {
              app.globalData.sfz = ras
              if (ras.data.code == 1) {
                wx.showToast({
                  title: '身份证照片通过审核',
                  duration: 2000,
                  icon: 'none',
                  mask: true
                })
                that.setData({
                  type: 0
                })
                return;
              } else {
                wx.showToast({
                  title: '身份证照片未通过审核',
                  duration: 2000,
                  icon: 'none',
                  mask: true
                })
                that.setData({
                  type: 1
                })
                return;
              }
            }
          })
        }
      })
    }
  },
  upload1: function () {
    let that = this;
    wx.chooseImage({
      count: 1,
      sizeType: ['original', 'compressed'],
      sourceType: ['album', 'camera'],
      success: res => {
        wx.showToast({
          title: '正在上传...',
          icon: 'loading',
          mask: true,
          duration: 1000
        })
        app.globalData.pictures1 = res.tempFilePaths
        that.uploadimg1();
        let tempFilePaths = res.tempFilePaths;
        that.setData({
          ewmImg1: tempFilePaths,
          type: 1
        })
      }
    })
  },
  uploadimg1: function () {
    var that = this
    var pics = app.globalData.pictures1
    for (var i = 0; i < pics.length; i++) {
      wx.uploadFile({
        url: app.globalData.url + 'api/yanzheng/img',
        filePath: pics[i],
        name: 'file',
        success: function (res) {
          app.globalData.yingye = res.data
          wx.showToast({
            title: '审核中，请稍后',
            duration: 300000,
            icon: 'loading',
            mask: true
          })
          wx.request({
            url: app.globalData.url + 'api/yanzheng/check_yy_pic',
            data: {
              pic: res.data
            },
            method: 'post',
            success: function (ras) {
              console.log(ras)

              app.globalData.yyzz = ras.data.out_put
              wx.setStorageSync('yyzz', ras.data.out_put)
              if (ras.data.out_put.ENTERPRISE_TAXPAYER_REGISTER_ID != '' && ras.data.out_put.ENTERPRISE_NAME_CH != '') {
                wx.showToast({
                  title: '营业执照照片通过审核',
                  duration: 2000,
                  icon: 'none',
                  mask: true
                })
                that.setData({
                  type: 0
                })
                return;
              } else {
                wx.showToast({
                  title: '营业执照照片未通过审核',
                  duration: 2000,
                  icon: 'none',
                  mask: true
                })
                that.setData({
                  type: 1
                })
                return;
              }
            }
          })
        }
      })
    }
  },
  submit: function () {
    var that = this
    var tel = wx.getStorageSync('tel');
    var sfz = app.globalData.sfz
    var name = that.data.name
    var code = that.data.code
    var sfz_pic = app.globalData.shenfen
    var yyzz = app.globalData.yingye
    var val2 = that.data.val2
    if (val2 == '' || val2 == null) {
      wx.showToast({
        title: '请选择身份',
        duration: 2000,
        icon: 'none',
        mask: true
      })
      return;
    }

    if (val2 == 0) {
      if (that.data.gongyu_yyzz_renzheng == 'Y') {
        if (!yyzz) {
          wx.showToast({
            title: '请上传营业执照',
            duration: 2000,
            icon: 'none',
            mask: true
          })
          return;
        }
      }
      if (that.data.rz_gongyu == 'Y') {
        if (!name) {
          var name = that.data.u_info.name
        }
        if (!code) {
          var code = that.data.u_info.code
        }
        var myreg = /^[1-9]\d{5}(18|19|20|(3\d))\d{2}((0[1-9])|(1[0-2]))(([0-2][1-9])|10|20|30|31)\d{3}[0-9Xx]$/;;
        if (!myreg.test(code)) {
          wx.showToast({
            title: "身份证号格式有误",
            icon: 'none',
            duration: 2000,
            mask: true
          })
          return;
        }
        if (!sfz_pic) {
          var sfz_pic = that.data.u_info.sfz_pic
        } else {
          if (sfz) {
            if (sfz.data.result.code != code) {
              wx.showToast({
                title: "身份证号与图片不符",
                icon: 'none',
                duration: 2000,
                mask: true
              })
              return;
            }
            if (sfz.data.result.name != name) {
              wx.showToast({
                title: "真实姓名与图片不符",
                icon: 'none',
                duration: 2000,
                mask: true
              })
              return;
            }
          } else {
            if (that.data.u_info.code != code) {
              wx.showToast({
                title: "身份证号与图片不符",
                icon: 'none',
                duration: 2000,
                mask: true
              })
              return;
            }
            if (that.data.u_info.name != name) {
              wx.showToast({
                title: "真实姓名与图片不符",
                icon: 'none',
                duration: 2000,
                mask: true
              })
              return;
            }
          }
        }
      } else {

        if (name.length!=0&&name==undefined) {
          if (!name) {
            var name = that.data.u_info.name
          }
          if (!code) {
            var code = that.data.u_info.code
          }
          var myreg = /^[1-9]\d{5}(18|19|20|(3\d))\d{2}((0[1-9])|(1[0-2]))(([0-2][1-9])|10|20|30|31)\d{3}[0-9Xx]$/;;
          if (!myreg.test(code)) {
            wx.showToast({
              title: "身份证号格式有误",
              icon: 'none',
              duration: 2000,
              mask: true
            })
            return;
          }
          if (!sfz_pic) {
            var sfz_pic = that.data.u_info.sfz_pic
          } else {

            if (sfz) {
              if (sfz.data.result.code != code) {
                wx.showToast({
                  title: "身份证号与图片不符",
                  icon: 'none',
                  duration: 2000,
                  mask: true
                })
                return;
              }
              if (sfz.data.result.name != name) {
                wx.showToast({
                  title: "真实姓名与图片不符",
                  icon: 'none',
                  duration: 2000,
                  mask: true
                })
                return;
              }
            } else {
              if (that.data.u_info.code != code) {
                wx.showToast({
                  title: "身份证号与图片不符",
                  icon: 'none',
                  duration: 2000,
                  mask: true
                })
                return;
              }
              if (that.data.u_info.name != name) {
                wx.showToast({
                  title: "真实姓名与图片不符",
                  icon: 'none',
                  duration: 2000,
                  mask: true
                })
                return;
              }
            }
          }
        }
      }
    }
    if (val2 == 1) {
      if (that.data.zhiye_yyzz_renzheng == 'Y') {
        if (!yyzz) {
          wx.showToast({
            title: '请上传营业执照',
            duration: 2000,
            icon: 'none',
            mask: true
          })
          return;
        }
      }
      if (that.data.rz_zhiye == 'Y') {
        if (!name) {
          var name = that.data.u_info.name
        }
        if (!code) {
          var code = that.data.u_info.code
        }
        var myreg = /^[1-9]\d{5}(18|19|20|(3\d))\d{2}((0[1-9])|(1[0-2]))(([0-2][1-9])|10|20|30|31)\d{3}[0-9Xx]$/;;
        if (!myreg.test(code)) {
          wx.showToast({
            title: "身份证号格式有误",
            icon: 'none',
            duration: 2000,
            mask: true
          })
          return;
        }
        if (!sfz_pic) {
          var sfz_pic = that.data.u_info.sfz_pic
        } else {
          if (sfz) {
            if (sfz.data.result.code != code) {
              wx.showToast({
                title: "身份证号与图片不符",
                icon: 'none',
                duration: 2000,
                mask: true
              })
              return;
            }
            if (sfz.data.result.name != name) {
              wx.showToast({
                title: "真实姓名与图片不符",
                icon: 'none',
                duration: 2000,
                mask: true
              })
              return;
            }
          } else {
            if (that.data.u_info.code != code) {
              wx.showToast({
                title: "身份证号与图片不符",
                icon: 'none',
                duration: 2000,
                mask: true
              })
              return;
            }
            if (that.data.u_info.name != name) {
              wx.showToast({
                title: "真实姓名与图片不符",
                icon: 'none',
                duration: 2000,
                mask: true
              })
              return;
            }
          }
        }
      } else {
        if (name.length != 0 && name == undefined) {
          if (!name) {
            var name = that.data.u_info.name
          }
          if (!code) {
            var code = that.data.u_info.code
          }
          var myreg = /^[1-9]\d{5}(18|19|20|(3\d))\d{2}((0[1-9])|(1[0-2]))(([0-2][1-9])|10|20|30|31)\d{3}[0-9Xx]$/;;
          if (!myreg.test(code)) {
            wx.showToast({
              title: "身份证号格式有误",
              icon: 'none',
              duration: 2000,
              mask: true
            })
            return;
          }
          if (!sfz_pic) {
            var sfz_pic = that.data.u_info.sfz_pic
          } else {
            if (sfz) {
              if (sfz.data.result.code != code) {
                wx.showToast({
                  title: "身份证号与图片不符",
                  icon: 'none',
                  duration: 2000,
                  mask: true
                })
                return;
              }
              if (sfz.data.result.name != name) {
                wx.showToast({
                  title: "真实姓名与图片不符",
                  icon: 'none',
                  duration: 2000,
                  mask: true
                })
                return;
              }
            } else {
              if (that.data.u_info.code != code) {
                wx.showToast({
                  title: "身份证号与图片不符",
                  icon: 'none',
                  duration: 2000,
                  mask: true
                })
                return;
              }
              if (that.data.u_info.name != name) {
                wx.showToast({
                  title: "真实姓名与图片不符",
                  icon: 'none',
                  duration: 2000,
                  mask: true
                })
                return;
              }
            }
          }
        }
      }
    }
    if (val2 == 2) {
      if (that.data.rz_person == 'Y') {
        if (!name) {
          var name = that.data.u_info.name
        }
        if (!code) {
          var code = that.data.u_info.code
        }
        var myreg = /^[1-9]\d{5}(18|19|20|(3\d))\d{2}((0[1-9])|(1[0-2]))(([0-2][1-9])|10|20|30|31)\d{3}[0-9Xx]$/;;
        if (!myreg.test(code)) {
          wx.showToast({
            title: "身份证号格式有误",
            icon: 'none',
            duration: 2000,
            mask: true
          })
          return;
        }
        if (!sfz_pic) {
          var sfz_pic = that.data.u_info.sfz_pic
        } else {
          if (sfz) {
            if (sfz.data.result.code != code) {
              wx.showToast({
                title: "身份证号与图片不符",
                icon: 'none',
                duration: 2000,
                mask: true
              })
              return;
            }
            if (sfz.data.result.name != name) {
              wx.showToast({
                title: "真实姓名与图片不符",
                icon: 'none',
                duration: 2000,
                mask: true
              })
              return;
            }
          } else {
            if (that.data.u_info.code != code) {
              wx.showToast({
                title: "身份证号与图片不符",
                icon: 'none',
                duration: 2000,
                mask: true
              })
              return;
            }
            if (that.data.u_info.name != name) {
              wx.showToast({
                title: "真实姓名与图片不符",
                icon: 'none',
                duration: 2000,
                mask: true
              })
              return;
            }
          }
        }
      } else {
        if (name.length !=0 && name != undefined) {
          if (!name) {
            var name = that.data.u_info.name
          }
          if (!code) {
            var code = that.data.u_info.code
          }
          var myreg = /^[1-9]\d{5}(18|19|20|(3\d))\d{2}((0[1-9])|(1[0-2]))(([0-2][1-9])|10|20|30|31)\d{3}[0-9Xx]$/;;
          if (!myreg.test(code)) {
            wx.showToast({
              title: "身份证号格式有误",
              icon: 'none',
              duration: 2000,
              mask: true
            })
            return;
          }
          if (!sfz_pic) {
            var sfz_pic = that.data.u_info.sfz_pic
          } else {
            if (sfz) {
              if (sfz.data.result.code != code) {
                wx.showToast({
                  title: "身份证号与图片不符",
                  icon: 'none',
                  duration: 2000,
                  mask: true
                })
                return;
              }
              if (sfz.data.result.name != name) {
                wx.showToast({
                  title: "真实姓名与图片不符",
                  icon: 'none',
                  duration: 2000,
                  mask: true
                })
                return;
              }
            } else {
              if (that.data.u_info.code != code) {
                wx.showToast({
                  title: "身份证号与图片不符",
                  icon: 'none',
                  duration: 2000,
                  mask: true
                })
                return;
              }
              if (that.data.u_info.name != name) {
                wx.showToast({
                  title: "真实姓名与图片不符",
                  icon: 'none',
                  duration: 2000,
                  mask: true
                })
                return;
              }
            }
          }
        }
      }
    }


    if (val2 == 0) {
      if (!yyzz) {
        var yyzz = that.data.u_info.yy_pic
      }
    }
    if (app.globalData.yyzz) {
      var yy_code1 = app.globalData.yyzz['ENTERPRISE_TAXPAYER_REGISTER_ID']
      var qiye_title1 = app.globalData.yyzz['ENTERPRISE_NAME_CH']
    } else {
      var yy_code1 = undefined
      var qiye_title1 = undefined
    }
    wx.request({
      url: app.globalData.url + 'api/yanzheng/save1',
      data: {
        tel: tel,
        name: name,
        code: code,
        yyzz: yyzz,
        sfz_pic: sfz_pic,
        yy_code: yy_code1,
        val2: val2,
        qiye_title: qiye_title1
      },
      method: 'post',
      success: function (res) {
        console.log(res)
        if (res.data.update == 1) {
          if (val2 == 2) {
            if(that.data.geren_fd_yanzheng == 'Y'){
              wx.showModal({
                title: '提示',
                content: '您的身份认证申请已提交，平台将于3个工作日内审核。审核通过后可发布房源，谢谢。',
                showCancel: false, //是否显示取消按钮
                confirmText: "我知道了", //默认是“确定”
                 //确定文字的颜色
                success: function (res) {
                  if (res.cancel) {
                    //点击取消,默认隐藏弹框
                  } else {
                    wx.request({
                      url: app.globalData.url + 'api/my/xinxi_check',
                      data: {
                        tel: wx.getStorageSync('tel')
                      },
                      method: 'post',
                      success: function (rag) {
                        console.log(rag)
                        if (rag.data.info == 1) {
                          setTimeout(function () {
                            wx.navigateBack({
        
                            })
                          }, 2000)
                        } else if (rag.data.info == 0) {
                          
                          setTimeout(function () {
                            wx.navigateBack({
        
                            })
                          }, 2000)
                        }
                      }
                    })
                  }
                }
              })
            }else{
              wx.showToast({
                title: '提交成功',
                duration: 2000,
                icon: 'none',
                mask: true
              })
              wx.request({
                url: app.globalData.url + 'api/my/xinxi_check',
                data: {
                  tel: wx.getStorageSync('tel')
                },
                method: 'post',
                success: function (rag) {
                  console.log(rag)
                  if (rag.data.info == 1) {
                    setTimeout(function () {
                      wx.navigateBack({
  
                      })
                    }, 2000)
                  } else if (rag.data.info == 0) {
                    
                    setTimeout(function () {
                      wx.navigateBack({
  
                      })
                    }, 2000)
                  }
                }
              })
            }       
          }else if (val2 == 1) {
            if(that.data.zhiye_fd_yanzheng == 'Y'){
              wx.showModal({
                title: '提示',
                content: '您的身份认证申请已提交，平台将于3个工作日内审核。审核通过后可发布房源，谢谢。',
                showCancel: false, //是否显示取消按钮
                confirmText: "我知道了", //默认是“确定”
                 //确定文字的颜色
                success: function (res) {
                  if (res.cancel) {
                    //点击取消,默认隐藏弹框
                  } else {
                    wx.request({
                      url: app.globalData.url + 'api/my/xinxi_check',
                      data: {
                        tel: wx.getStorageSync('tel')
                      },
                      method: 'post',
                      success: function (rag) {
                        console.log(rag)
                        if (rag.data.info == 1) {
                          setTimeout(function () {
                            wx.navigateBack({
        
                            })
                          }, 2000)
                        } else if (rag.data.info == 0) {
                          
                          setTimeout(function () {
                            wx.navigateBack({
        
                            })
                          }, 2000)
                        }
                      }
                    })
                  }
                }
              })
            }else{
              wx.showToast({
                title: '提交成功',
                duration: 2000,
                icon: 'none',
                mask: true
              })
              wx.request({
                url: app.globalData.url + 'api/my/xinxi_check',
                data: {
                  tel: wx.getStorageSync('tel')
                },
                method: 'post',
                success: function (rag) {
                  console.log(rag)
                  if (rag.data.info == 1) {
                    setTimeout(function () {
                      wx.navigateBack({
  
                      })
                    }, 2000)
                  } else if (rag.data.info == 0) {
                    // wx.showToast({
                    //   title: '正在前往填写个人信息',
                    //   duration: 2000,
                    //   icon: 'none',
                    //   mask: true
                    // })
                    // setTimeout(function () {
                    //   wx.navigateTo({
                    //     url: '../personal/personal',
                    //   })
                    // }, 2000)
                    setTimeout(function () {
                      wx.navigateBack({
  
                      })
                    }, 2000)
                  }
                }
              })
            }
          } else if (val2 == 0) {
            if(that.data.gongyu_fd_yanzheng == 'Y' && that.data.user.gongyu_once == 1){
              wx.showModal({
                title: '提示',
                content: '您的身份认证申请已提交，平台将于3个工作日内审核。审核通过后可发布房源，谢谢。',
                showCancel: false, //是否显示取消按钮
                confirmText: "我知道了", //默认是“确定”
                 //确定文字的颜色
                success: function (res) {
                  if (res.cancel) {
                    //点击取消,默认隐藏弹框
                  } else {
                    wx.request({
                      url: app.globalData.url + 'api/my/mendian_check',
                      data: {
                        tel: wx.getStorageSync('tel')
                      },
                      method: 'post',
                      success: function (rag) {
                        console.log(rag)
                        if (rag.data.info == 1) {
                          setTimeout(function () {
                            wx.navigateBack({
        
                            })
                          }, 2000)
                        } else if (rag.data.info == 0) {
                          wx.showToast({
                            title: '正在前往填写公寓信息',
                            duration: 2000,
                            icon: 'none',
                            mask: true
                          })
                          setTimeout(function () {
                            wx.navigateTo({
                              url: '../gongyu/gongyu',
                            })
                          }, 2000)
                        }
                      }
                    })
                  }
                }
              })
            }else{
              wx.showToast({
                title: '提交成功',
                duration: 2000,
                icon: 'none',
                mask: true
              })
              wx.request({
                url: app.globalData.url + 'api/my/mendian_check',
                data: {
                  tel: wx.getStorageSync('tel')
                },
                method: 'post',
                success: function (rag) {
                  console.log(rag)
                  if (rag.data.info == 1) {
                    setTimeout(function () {
                      wx.navigateBack({
  
                      })
                    }, 2000)
                  } else if (rag.data.info == 0) {
                    wx.showToast({
                      title: '正在前往填写公寓信息',
                      duration: 2000,
                      icon: 'none',
                      mask: true
                    })
                    setTimeout(function () {
                      wx.navigateTo({
                        url: '../gongyu/gongyu',
                      })
                    }, 2000)
                  }
                }
              })
            }
          }
        } else if (res.data.update == 0) {
          wx.showToast({
            title: '认证成功',
            duration: 2000,
            icon: 'none',
            mask: true
          })
          setTimeout(function () {
            wx.navigateBack({

            })
          }, 2000)
        } else if (res.data.update == 2){
          wx.showModal({
            title: '提示',
            content: '您的身份认证申请已提交，平台将于3个工作日内审核。审核通过后可发布房源，谢谢。',
            showCancel: false, //是否显示取消按钮
            confirmText: "我知道了", //默认是“确定”
             //确定文字的颜色
            success: function (res) {
              if (res.cancel) {
                //点击取消,默认隐藏弹框
              } else {
                setTimeout(function () {
                  wx.navigateBack({

                  })
                }, 1500)
              }
            }
          })
        }
      }
    })
  },

  onShow: function () {
    var that = this
    var list = that.data.countryList
    that.setData({
      val1: list[app.globalData.val1],
    })
  },
})