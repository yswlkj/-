// pages/report/report.js
const app = getApp()
Page({

  /**
   * 页面的初始数据
   */
  data: {
    yincang1: true,
    hidden: false,
  },
  liubtn1: function (e) {

    this.setData({
      yincang1: false,
      bottom: 0
    })
  },
  bakbtn1: function (e) {
    var that = this
    var id = e.currentTarget.dataset.id
    app.globalData.jbid = id
    that.reload(id)
    that.setData({
      yincang1: true,
      bottom: -100
    })
  },
  bakbtn2: function (e) {
    this.setData({
      yincang1: true,
      bottom: -100
    })
  },
  reload: function(id){
    var that = this
    wx.setNavigationBarTitle({
      title: '举报',
    })
    wx.request({
      url: app.globalData.url + 'api/jubao/jb_select',
      data:{
        id: id
      },
      method: 'post',
      success: function(res){
        console.log(res)
        that.setData({
          title: res.data.title
        })
      }
    })
  },
  upload: function () {
    let that = this;
    wx.chooseImage({
      count: 9 - app.globalData.pictures1.length, // 默认9
      sizeType: ['compressed'], // 可以指定是原图还是压缩图，默认二者都有
      sourceType: ['album', 'camera'], // 可以指定来源是相册还是相机，默认二者都有
      success: res => {
        wx.showToast({
          title: '正在上传...',
          icon: 'loading',
          mask: true,
          duration: 1000
        })
        // 返回选定照片的本地文件路径列表，tempFilePath可以作为img标签的src属性显示图片
        if (app.globalData.pictures1.length < 9) {
          app.globalData.pictures1 = app.globalData.pictures1.concat(res.tempFilePaths)
        } else {
          app.globalData.pictures1 = app.globalData.pictures1
          console.log('超过9张')
          wx.showToast({
            title: '图片最多9张',
            duration: 2000,
            icon: 'none'
          })
        }
        that.setData({
          tempFilePaths: app.globalData.pictures1
        })
      }
    })
  },
  aaa: function (e) {
    var that = this
    // console.log(app.globalData.zt)
    var imgs = app.globalData.pictures1;
    // console.log(code1)
    var index = e.currentTarget.dataset.index;
    imgs.splice(index, 1);
    app.globalData.pictures1 = imgs
    that.setData({
      tempFilePaths: imgs,
    });
  },
  uploadimg: function () { //这里触发图片上传的方法
    var pics = app.globalData.pictures1
    for (var i = 0; i < pics.length; i++) {
      wx.uploadFile({
        url: app.globalData.url + 'api/jubao/img',
        filePath: pics[i],
        name: 'file',
        success: function (res) {
          console.log(res)
          app.globalData.tupian1 = app.globalData.tupian1 + '@' + res.data
          console.log(app.globalData.tupian1)
        }
      })
    }
  },
  listenerButtonPreviewImage: function (e) {
    let index = e.target.dataset.index; //预览图片的编号
    let that = this;
    wx.previewImage({
      current: that.data.tempFilePaths[index], //预览图片链接
      urls: that.data.tempFilePaths, //图片预览list列表
      success: function (res) {
        //console.log(res);
      },
      fail: function () {
        //console.log('fail')
      }
    })
  },
  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (e) {
    var that = this
    var fid = e.fid
    wx.setNavigationBarTitle({
      title: app.globalData.webname,
    })
    var id = e.id
    var zt = e.zt
    app.globalData.f_id = fid
    app.globalData.l_id = id
    app.globalData.l_type = zt
    app.globalData.pictures1 = []
    wx.request({
      url: app.globalData.url + 'api/jubao/type_list',
      success: function(res){
        console.log(res)
        that.setData({
          type: res.data.type
        })
      }
    })
  },
  content: function (e) {
    var that = this
    that.setData({
      content: e.detail.value
    })
  },
  submit: function (e) {
    var that = this
    var openid = 1
    var jbid = app.globalData.jbid
    var content = that.data.content
    if (!jbid) {
      wx.showToast({
        title: '请选择举报原因',
        duration: 2000,
        icon: 'none'
      })
      return;
    }
    if (!content) {
      wx.showToast({
        title: '请选择填写补充说明',
        duration: 2000,
        icon: 'none'
      })
      return;
    }
    wx.request({
      url: app.globalData.url + 'api/jubao/check',
      data: {
        reason: content
      },
      method: 'post',
      success: function (res) {
        console.log(res)
        if (res.data == 1) {
          that.setData({
            type: 1
          })
          that.uploadimg();
          wx.showToast({
            title: '提交中，请稍后...',
            duration: 2000,
            icon: 'none'
          })
          setTimeout(function () {
            wx.request({
              url: app.globalData.url + 'api/jubao/save1',
              data: {
                jbid: jbid,
                tel: wx.getStorageSync('tel'),
                content: content,
                picurl: app.globalData.tupian1,
                fid: app.globalData.f_id,
                id: app.globalData.l_id,
                type: app.globalData.l_type
              },
              method: 'post',
              success: function (ras) {
                console.log(ras)
                if (ras.data.info == 1) {
                  wx.showToast({
                    title: '提交成功，正在返回',
                    duration: 2000,
                    icon: 'none'
                  })
                  app.globalData.pictures1 = []
                  app.globalData.tupian1 = ''
                  setTimeout(function () {
                    wx.navigateBack({
                      
                    })
                  }, 2000)
                }
              }
            })
          }, 2000)
        } else {
          wx.showToast({
            title: '您所填写的内容存在敏感词，请重新编辑后重新提交。',
            duration: 2000,
            icon: 'none'
          })
          return;
        }
      }
    })
  },
})