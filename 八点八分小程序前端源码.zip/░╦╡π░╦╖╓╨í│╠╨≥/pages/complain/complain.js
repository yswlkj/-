const app = getApp()
Page({
  data: {

  },
  onLoad: function (options) {
    wx.setNavigationBarTitle({
      title: '投诉建议',
    })
  },
})