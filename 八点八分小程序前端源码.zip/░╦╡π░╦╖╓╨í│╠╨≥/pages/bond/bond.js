const app = getApp()
// // import WxParse from '../../wxParse/wxParse.js';
Page({
  data: {
    type: 0
  },
  onLoad: function (e) {
    var that = this
    app.globalData.id = e.id
    wx.setNavigationBarTitle({
      title: '保证金',
    })
    wx.request({
      url: app.globalData.url + 'api/about/bao',
      data: {
        url: app.globalData.url
      },
      method: 'post',
      success: function (res) {
        // var content = res.data.info.content;
        // WxParse.wxParse('content', 'html', content, that, 5)
        console.log(res)
        that.setData({
          info: res.data.info,
          html: res.data.info.content,
          id: app.globalData.id
        })
      }
    })
    wx.request({
      url: app.globalData.url + 'api/about/bao_money',
      success: function (res) {
        console.log(res)
        app.globalData.money = res.data.money
      }
    })
  },
  zhifu: function(e){
    var that = this
    var id = e.currentTarget.dataset.id
    var tel = wx.getStorageSync('tel')
    wx.request({
      url: app.globalData.url + 'api/about/tuihui',
      data:{
        id: id,
        tel: tel
      },
      method: 'post',
      success: function(res){
        console.log(res)
        if(res.data.info == 1){
          wx.showToast({
            title: '恭喜，您的申请已提交成功',
            duration: 2000,
            icon: 'none',
            mask: true
          })
          setTimeout(function(){
            wx.navigateBack({
              
            })
          },2000)
        }else if(res.data.info == 2){
          wx.showToast({
            title: '当前房源并未支付保证金',
            duration: 2000,
            icon: 'none',
            mask: true
          })
        } else if (res.data.info == 0){
          wx.showToast({
            title: '当前房源已申请退回保证金，不可重复申请',
            duration: 2000,
            icon: 'none',
            mask: true
          })
        }
      }
    })
  },
})