const app = getApp()
Page({
  data: {

  },
  onLoad: function (e) {
    var that = this
    wx.setNavigationBarTitle({
      title: '投诉公示',
    })
    wx.request({
      url: app.globalData.url + 'api/tousu/jylist',
      success: function(res){
        console.log(res)
        that.setData({
          list: res.data.list,
        })
      }
    })
  },
  onShareAppMessage: function () {
    return {
      title: app.globalData.fenxiang1,
      path: '/pages/publicity/publicity',
      imageUrl: app.globalData.url + that.data.fenxiang,
      success: function (shareTickets) {
        console.info(shareTickets + '成功');
        // 转发成功
      },
      fail: function (res) {
        console.log(res + '失败');
        // 转发失败
      },
      complete: function (res) {
        // 不管成功失败都会执行
      }
    }
  }
})