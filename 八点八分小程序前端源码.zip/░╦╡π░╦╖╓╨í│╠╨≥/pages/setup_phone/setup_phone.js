const app = getApp()
Page({
  data: {
    type: 0,
    info_tel: 2,
    second: 60,
    success: 0
  },
  onLoad: function(e) {
    var that = this
    wx.setNavigationBarTitle({
      title: "修改手机号",
    })
  },
  mima: function(e) {
    var that = this
    that.setData({
      mima: e.detail.value
    })
   
  },
  yzm: function(e) {
    var that = this
    that.setData({
      yzm: e.detail.value
    })
  },
  tel: function(e) {
    var that = this
    that.setData({
      tel: e.detail.value
    })
    
  },
  huoqu: function(e) {
    var that = this
    var tel = that.data.tel
    if (!tel) {
      wx.showToast({
        title: '请填写手机号',
        duration: 2000,
        icon: 'none',
        mask: true
      })
      return;
    }
    var reg = /^((13[0-9])|(14[0-9])|(15[0-9])|(17[0-9])|(18[0-9]))\d{8}$/
    if (!reg.test(tel)) {
      wx.showToast({
        title: '手机号格式错误',
        duration: 2000,
        icon: 'none',
        mask: true
      })
      return;
    }
    wx.request({
      url: app.globalData.url + 'api/my/tel_check',
      data:{
        tel: tel,
        openid: wx.getStorageSync('openid')
      },
      method: 'post',
      success: function (rag){
        console.log(rag)
        if(rag.data == 1){
          wx.request({
            url: app.globalData.url + 'api/sms/send_yzm2',
            data: {
              tel: tel
            },
            method: 'post',
            success: function (res) {
              console.log(res)
              that.setData({
                success: 1
              })
              let promise = new Promise((resolve, reject) => {
                let setTimer = setInterval(
                  () => {
                    that.setData({
                      second: that.data.second - 1,
                    })
                    if (that.data.second <= 0) {
                      that.setData({
                        second: 60,
                        alreadySend: false,
                        send: true,
                      })
                      resolve(setTimer)
                    }
                  }, 1000)
                that.setData({
                  disabled: 'disabled'
                })
              })
              promise.then((setTimer) => {
                clearInterval(setTimer)
                that.setData({
                  success: 2,
                  disabled: ''
                })
              })
            }
          })
        }else if(rag.data == 2){
          wx.showToast({
            title: '手机号与原手机号一致，请修改后重新获取验证码',
            duration: 2000,
            icon: 'none',
            mask: true
          })
        }
      }
    })
    
  },
  submit: function(e) {
    var that = this
    var yzm = that.data.yzm
    var tel = that.data.tel
    var mima = that.data.mima
    if (!mima) {
      wx.showToast({
        title: '请填写密码',
        duration: 2000,
        icon: 'none',
        mask: true
      })
      return;
    }
    if (!tel) {
      wx.showToast({
        title: '请填写手机号',
        duration: 2000,
        icon: 'none',
        mask: true
      })
      return;
    }
    var reg = /^((13[0-9])|(14[0-9])|(15[0-9])|(17[0-9])|(18[0-9]))\d{8}$/
    if (!reg.test(tel)) {
      wx.showToast({
        title: '手机号格式错误，请重新输入',
        duration: 2000,
        icon: 'none',
        mask: true
      })
      return;
    }
    if (!yzm) {
      wx.showToast({
        title: '请填写验证码',
        duration: 2000,
        icon: 'none',
        mask: true
      })
      return;
    }
    wx.request({
      url: app.globalData.url + 'api/my/tel_update',
      data:{
        tel: tel,
        yzm: yzm,
        pass: mima,
        tel1: wx.getStorageSync('tel')
      },
      method: 'post',
      success: function(res){
        console.log(res)
        if(res.data.info == 1){
          wx.showToast({
            title: '修改成功',
            duration: 2000,
            icon: 'none'
          })
          wx.setStorageSync('tel', tel)
          setTimeout(function(){
            wx.navigateBack({
              
            })
          },2000)
          return;
        }else if(res.data.info == 2){
          wx.showToast({
            title: '验证码不正确，请重新输入',
            duration: 2000,
            icon: 'none',
            mask: true
          })
          return;
        } else if (res.data.info == 3) {
          wx.showToast({
            title: '密码不正确，请重新输入',
            duration: 2000,
            icon: 'none',
            mask: true
          })
          return;
        }
      }
    })
  },
})