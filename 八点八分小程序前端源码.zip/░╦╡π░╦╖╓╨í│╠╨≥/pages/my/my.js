// pages/my/my.js
const app = getApp()
Page({

  /**
   * 页面的初始数据
   */
  data: {
    statu: 'open',
    canIUseGetUserProfile: false,
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (e) {
    var that = this
    wx.setNavigationBarTitle({
      title: '个人中心',
    })
    if (wx.getUserProfile) {
      that.setData({
        canIUseGetUserProfile: true
      })
    }
    var tel = wx.getStorageSync('tel');
    var openid = wx.getStorageSync('openid')
    if (tel){
      var login = 0;
    }else{
      var login = 1;
    }
    that.setData({
      login: login
    })
    wx.request({
      url: app.globalData.url + 'api/my/index',
      data:{
        tel: tel,
        url: app.globalData.url,
        openid: openid
      },
      method: 'post',
      success: function(res){
        console.log(res)
        that.setData({
          user: res.data.user,
          tishi_logo: app.globalData.tishi_logo,
        })
      }
    })
  },
  getUserProfile(e) {
    var that = this
    // 推荐使用wx.getUserProfile获取用户信息，开发者每次通过该接口获取用户个人信息均需用户确认
    // 开发者妥善保管用户快速填写的头像昵称，避免重复弹窗
    wx.getUserProfile({
      desc: '用于完善会员资料', // 声明获取用户个人信息后的用途，后续会展示在弹窗中，请谨慎填写
      success: (res) => {
        console.log(res)
        app.globalData.user_info = res.userInfo
        wx.login({
          success: res1 => {
            app.globalData.user_code = res1.code;
            wx.request({
              url: app.globalData.url + 'api/wechat/login',
              headers: {
                "Content-Type": "application/x-www-form-urlencoded"
              },
              data: {
                user_code: app.globalData.user_code,
                url: app.globalData.url,
                ip: wx.getStorageSync('ip')
              },
              method: 'POST',
              dataType: 'json',
              responseType: 'Text',
              success: function(res){
                console.log(res)
                var openid = res.data.info.openid
                var sessionkey = res.data.info.session_key
                wx.setStorageSync('sessionkey', sessionkey)
                wx.setStorageSync('openid', openid)
                wx.reLaunch({
                  url: '../login/login',
                })
              }
            })
          }
        })

        that.setData({
          userInfo: res.userInfo,
          hasUserInfo: true
        })
      }
    })
  },
  getUserInfo(e) {
    // 不推荐使用getUserInfo获取用户信息，预计自2021年4月13日起，getUserInfo将不再弹出弹窗，并直接返回匿名的用户个人信息
    this.setData({
      userInfo: e.detail.userInfo,
      hasUserInfo: true
    })
  },
  powerDrawer: function (e) {
    console.log(1)
    var that = this
    
      var currentStatu1 = e.currentTarget.dataset.statu;
    
    this.util(currentStatu1)
  },
  util: function (currentStatu1) {
    /* 动画部分 */
    // 第1步：创建动画实例
    var animation1 = wx.createAnimation({
      duration: 1, //动画时长
      timingFunction: "linear", //线性
      delay: 0 //0则不延迟
    });
    // 第2步：这个动画实例赋给当前的动画实例
    this.animation1 = animation1;
    // 第3步：执行第一组动画：Y轴偏移240px后(盒子高度是240px)，停
    animation1.translateX(240).step();
    // 第4步：导出动画对象赋给数据对象储存
    this.setData({
      animationData1: animation1.export()
    })
    // 第5步：设置定时器到指定时候后，执行第二组动画
    setTimeout(function () {
      // 执行第二组动画：Y轴不偏移，停
      animation1.translateX(0).step()
      // 给数据对象储存的第一组动画，更替为执行完第二组动画的动画对象
      this.setData({
        animationData1: animation1
      })
      //关闭抽屉
      if (currentStatu1 == "close") {
        this.setData(
          {
            showModalStatus1: false
          }
        );
      }
    }.bind(this), 1)
    // 显示抽屉
    if (currentStatu1 == "open") {
      this.setData(
        {
          showModalStatus1: true
        }
      );
    }
  },
  // getUserInfo(e) {
  //   // 把用户信息设置成全局变量
  //   console.log(e)
  //   var that = this
  //   if (e.detail.errMsg === 'getUserInfo:ok') {
  //     app.globalData.user_info = e.detail.userInfo
  //     wx.login({
  //       success: res => {
  //         app.globalData.user_code = res.code;
  //       }
  //     })
  //     console.log(app.globalData.user_code)
  //     app.globalData.iv = e.detail.iv
  //     app.globalData.encryptedData = e.detail.encryptedData
  //     app.globalData.errMsg = e.detail.errMsg
  //     wx.request({
  //       url: app.globalData.url + 'api/wechat/login',
  //       headers: {
  //         "Content-Type": "application/x-www-form-urlencoded"
  //       },
  //       data: {
  //         user_code: app.globalData.user_code,
  //         url: app.globalData.url,
  //         ip: wx.getStorageSync('ip')
  //       },
  //       method: 'POST',
  //       dataType: 'json',
  //       responseType: 'Text',
  //       success: function(res){
  //         console.log(res)
  //         var openid = res.data.info.openid
  //         var sessionkey = res.data.info.session_key
  //         wx.setStorageSync('sessionkey', sessionkey)
  //         wx.setStorageSync('openid', openid)
  //         wx.reLaunch({
  //           url: '../login/login',
  //         })
  //       }
  //     })
  //   } else if (e.detail.errMsg === 'getUserInfo:fail auth deny') {
  //     wx.showToast({
  //       title: '取消授权将无法正常使用小程序',
  //       icon: 'none',
  //       duration: 5000
  //     })
  //     that.setData({
  //       warning: false,
  //     })
  //   }
  // },
  onShow: function () {
    var that = this
    wx.setNavigationBarTitle({
      title: '个人中心',
    })
    wx.login({
      success: res => {
        app.globalData.user_code = res.code;
        console.log(app.globalData.user_code)
        // 发送 res.code 到后台换取 openId, sessionKey, unionId
      }
    })
    var tel = wx.getStorageSync('tel');
    var openid = wx.getStorageSync('openid')
    if (tel) {
      var login = 0;
    } else {
      var login = 1;
    }
    that.setData({
      login: login
    })
    wx.request({
      url: app.globalData.url + 'api/my/index',
      data: {
        tel: tel,
        openid: openid,
        url: app.globalData.url
      },
      method: 'post',
      success: function (res) {
        console.log(res)
        that.setData({
          user: res.data.user
        })
      }
    })
    var tel = wx.getStorageSync('tel')
    wx.request({
      url: app.globalData.url + 'api/index/check_status',
      data: {
        tel: tel
      },
      method: 'post',
      success: function (res) {
        console.log(res)
        if (res.data.info == 0) {
          wx.showModal({
            title: '提示',
            content: '账号已停用',
            showCancel: false, //是否显示取消按钮

            confirmText: "我知道了", //默认是“确定”
            success: function (res) {
              if (res.cancel) {
                //点击取消,默认隐藏弹框
              } else {
                console.log('封号')
                wx.removeStorageSync('tel')
                that.onLoad()
              }
            },
          })
        }
      }
    })
  },
  submit: function(e){
    var that = this
    wx.showToast({
      title: '请登录',
      duration: 2000,
      icon: 'none'
    })
  },

  onShareAppMessage: function (e) {
    console.log(e)
    var that = this
    if (e.from == 'menu') {
      return {
        title: app.globalData.fenxiang1,
        path: '/pages/index/index',
        imageUrl: app.globalData.url + app.globalData.fenxiang,
        success: function (shareTickets) {
          console.info(shareTickets + '成功');
          // 转发成功
        },
        fail: function (res) {
          console.log(res + '失败');
          // 转发失败
        },
        complete: function (res) {
          // 不管成功失败都会执行
        }
      }
    }
  }
})