// pages/message/message.js
const app = getApp()
Page({

  /**
   * 页面的初始数据
   */
  data: {
    zt: 0,
    type1: 0,
    zt1: 1
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (e) {
    var that = this
    wx.setNavigationBarTitle({
      title: '留言',
    })
    var id = e.id
    var tel = wx.getStorageSync('tel')
    wx.request({
      url: app.globalData.url + 'api/liuyan/index',
      data: {
        id: id,
        tel: tel
      },
      method: 'post',
      success: function (res) {
        console.log(res)
        that.setData({
          user: res.data.user,
          u_info: res.data.u_info,
          id: id
        })
      }
    })
  },
  xianshi: function (e) {
    var that = this
    var zt = e.currentTarget.dataset.zt
    if (zt == 0) {
      that.setData({
        zt: 1
      })
    } else if (zt == 1) {
      that.setData({
        zt: 0
      })
    }
  },
  content: function (e) {
    var that = this
    that.setData({
      content: e.detail.value
    })
  },
  submit: function (e) {
    var that = this
    var zt = that.data.zt
    var content = that.data.content
    var id = e.currentTarget.dataset.id
    if (!content) {
      wx.showToast({
        title: '请填写详情',
        duration: 2000,
        icon: 'none'
      })
      return;
    }
    if (content.lengh > 100) {
      wx.showToast({
        title: '详情字数100字以内',
        duration: 2000,
        icon: 'none'
      })
      return;
    }
    that.setData({
      type1: 1
    })
    wx.request({
      url: app.globalData.url + 'api/liuyan/save1',
      data: {
        id: id,
        content: content,
        zt: zt,
        zt1: that.data.zt1,
        type: 1,
        tel: wx.getStorageSync('tel')
      },
      method: 'post',
      success: function (res) {
        console.log(res)
        if (res.data.info == 1) {
          wx.showToast({
            title: '恭喜留言成功',
            duration: 2000,
            icon: 'none'
          })
          setTimeout(function () {
            wx.navigateBack({

            })
          }, 2000)
        }else if(res.data.info == 2){
          wx.showToast({
            title: '留言内容存在敏感词，请重新输入',
            duration: 2000,
            icon: 'none'
          })
        }
      }
    })
  },
  niming: function(e){
    var that = this
    var zt = e.currentTarget.dataset.zt
    if(zt == 0){
      that.setData({
        zt1: 1
      })
    }else{
      that.setData({
        zt1: 0
      })
    }
  },
})