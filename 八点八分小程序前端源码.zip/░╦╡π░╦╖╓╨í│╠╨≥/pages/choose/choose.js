const app = getApp()
var QQMapWX = require('../../libs/qqmap-wx-jssdk.js');
// 实例化API核心类
var qqmapsdk = new QQMapWX({
  key: 'I4CBZ-FYL6G-X2LQD-I56ON-N6K7E-UQFK4' // 必填
});
Page({
  data: {
    len: [],
    code: null,
    codeY: 'A',
    codeHeight: null,
    cityHeight: null,
    scrollTop: 0,
    cityList: [
      { code: 'A' },
      { code: 'B' },
      { code: 'C' },
      { code: 'D' },
      { code: 'E' },
      { code: 'F' },
      { code: 'G' },
      { code: 'H' },
      { code: 'I' },
      { code: 'J' },
      { code: 'K' },
      { code: 'L' },
      { code: 'M' },
      { code: 'N' },
      { code: 'O' },
      { code: 'P' },
      { code: 'Q' },
      { code: 'R' },
      { code: 'S' },
      { code: 'T' },
      { code: 'U' },
      { code: 'V' },
      { code: 'W' },
      { code: 'X' },
      { code: 'Y' },
      { code: 'Z' },
    ],
    link: 1
  },
  tiao: function(e){
    var that = this
    var name = e.currentTarget.dataset.name

    var id = e.currentTarget.dataset.id
    app.globalData.chengshi = 1
    app.globalData.city_code = id
    app.globalData.city_name = name
    app.globalData.locateCity = name
    wx.navigateBack({
      delta: 1,
    })
  },
  onLoad: function (options) {
    var that = this
    wx.setNavigationBarTitle({
      title: '选择城市',
    })
    var windowHeight = wx.getSystemInfoSync().windowHeight;
    var arr = [];
    that.setData({
      cityHeight: windowHeight,
    })
    that.setData({
      locateCity: app.globalData.locateCity.replace('市','')
    })
    wx.getLocation({
      type: 'gcj02',
      altitude: true,
      success: function (res) {
        console.log("获取当前城市名...");
        console.log(res);
        if (res && res.longitude && res.latitude) {
          var longitude = res.longitude;
          var latitude = res.latitude;
          app.globalData.lng = longitude
          app.globalData.lat = latitude
          that.getLocate(latitude, longitude)
        } else {
          that.setData({
            city: '获取失败',
            addre: 1
          })
        }
      }
    })
    wx.request({
      url: app.globalData.url + 'api/city/clist',
      success: function (res) {
        console.log(res)
        for(var i=0;i<res.data.list.length;i++){
          res.data.list[i].name = res.data.list[i].name.replace('市','')
        }
        that.setData({
          list: res.data.list,
          status: res.data.status
        })
      }
    })
    wx.request({
      url: app.globalData.url + 'api/city/citys',
      success: function (rag) {
        console.log(rag)
        
        that.setData({
          list1: rag.data.city
        })
      }
    })
  },
  getCurrentCode(e) {
    console.log(e)
    this.setData({
      codeY: e.currentTarget.dataset.code,
      chooseIndex: e.target.dataset.index,
      isShowLayer: true
    })
  },
  jumpTo: function (e) {
    // 获取标签元素上自定义的 data-opt 属性的值
    console.log(e)
    var that = this
    let target = e.target.dataset.opt;
    that.setData({
      toView: target
    })
  },
  getLocate(latitude, longitude) {
    var that = this;
    wx.request({
      url: 'https://apis.map.qq.com/ws/geocoder/v1/?location=' + latitude + ',' + longitude + '&key=I4CBZ-FYL6G-X2LQD-I56ON-N6K7E-UQFK4',
      success: function (res) {
        console.log(res)
        app.globalData.adcode = res.data.result.ad_info.adcode
        var citycode = res.data.result.ad_info.city_code
        var citycode = citycode.slice(3, 9)
        wx.request({
          url: app.globalData.url + 'api/about/check_city',
          data: {
            id: citycode
          },
          method: 'post',
          success: function (res1) {
            console.log(res1)
            if (res1.data.status == 1) {
              app.globalData.city_name = res.data.result.ad_info.city
              app.globalData.city_code = citycode
              var val = res.data.result.address_component.city
              app.globalData.locateCity = val
              that.setData({
                locateCity: val.replace('市',''),
                city_code: app.globalData.city_code
              });
              
            } else {
              wx.showModal({
                title: '提示',
                content: res1.data.tishi,
                showCancel: false,//是否显示取消按钮
                confirmText: "我知道了",//默认是“确定”
                success: function (res) {
                  app.globalData.city_name = '上海'
                  app.globalData.city_code = '310000'
                  var val = '上海'
                  app.globalData.locateCity = val
                  that.setData({
                    locateCity: val
                  });
                },
              })
            }
          }
        })
      },
    })
  },
  check: function (e) {
    var that = this
    var id = e.currentTarget.dataset.id
    wx.request({
      url: app.globalData.url + 'api/about/check_city',
      data:{
        id: id
      },
      method: 'post',
      success: function(res){
        console.log(res)
        if(res.data.status == 1){
          var name = e.currentTarget.dataset.name
          app.globalData.city_code = id
          app.globalData.city_name = name
          app.globalData.locateCity = name
          app.globalData.chengshi = 1
          wx.navigateBack({
            delta: 1,
          })
        }else{
          wx.showModal({
            title: '提示',
            content: res.data.tishi,
            showCancel: false,//是否显示取消按钮
            confirmText: "我知道了",//默认是“确定”
            success: function (res) {
             
            },
          })
        }
      }
    })
  },
  getChooseCity: function(e){
    var that = this
    console.log(e)
    var id = e.currentTarget.dataset.id
    wx.request({
      url: app.globalData.url + 'api/about/check_city',
      data: {
        id: id
      },
      method: 'post',
      success: function (res) {
        console.log(res)
        if(res.data.status == 1){
          var name = e.currentTarget.dataset.name
          app.globalData.city_code = id
          app.globalData.city_name = name
          app.globalData.locateCity = name
          wx.navigateBack({
            delta: 1,
          })
        }else{
          wx.showModal({
            title: '提示',
            content: res.data.tishi,
            showCancel: false,//是否显示取消按钮
            confirmText: "我知道了",//默认是“确定”
            success: function (res) {

            },
          })
        }
      }
    })
  },
  key: function(e){
    var that = this
    that.setData({
      key: e.detail.value
    })
    if(e.detail.value){
      that.setData({
        link: 0
      })
      wx.request({
        url: app.globalData.url + 'api/city/city_list',
        data: {
          key: e.detail.value
        },
        method: 'post',
        success: function (res) {
          console.log(res)
          for(var i=0;i<res.data.c_list.length;i++){
            res.data.c_list[i].name = res.data.c_list[i].name.replace('市','')
          }
          that.setData({
            ss_list: res.data.c_list,
            
          })
        }
      })
    }else{
      that.setData({
        link: 1
      })
    }
  },
  submit: function(e){
    var that = this
    var key = that.data.key
    if(!key){
      wx.showToast({
        title: '请输入关键字',
        duration: 2000,
        icon: 'none',
        mask: true
      })
      return;
    }
    
  },
})