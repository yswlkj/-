// pages/modular_ex/modular_ex.js
const app = getApp()
// 引入SDK核心类
var QQMapWX = require('../../libs/qqmap-wx-jssdk.js');

// 实例化API核心类
var qqmapsdk = new QQMapWX({
  key: 'I4CBZ-FYL6G-X2LQD-I56ON-N6K7E-UQFK4' // 必填
});
Page({

  /**
   * 页面的初始数据
   */
  data: {
    leibie: [{
      title: "全部",
      id: 0
    },
    {
      title: "合租",
      id: 11
    },
    {
      title: "整租",
      id: 13
    }],
    index: 1,
    index1: 0,
    index2: 0,
    index3: 0,
    index4: 0,
    nav: 0,
    yincang1: true,
    yincang2: true,
    yincang3: true,
    yincang4: true,
    yincang5: true,
    hidden: false,
    fuwu: [],
    tese: [],
    tese1: [],
    fuwu1: [],
    hd: [],
    hd1: [],
    lx_index2: 0,
    hx_index3: 0,
  },
  choose(e) {
    var that = this
    var arr = that.data.configure
    var fuwu = that.data.fuwu
    if (fuwu.length == 0) {
      for (var i = 0; i < arr.length; i++) {
        var fuwu = fuwu.concat(0)
      }
    }
    var id = e.currentTarget.dataset.id
    var index = e.currentTarget.dataset.index
    if (fuwu[index] == 0) {
      fuwu.splice(index, 1, id)
    }
    console.log(fuwu)
    app.globalData.fuwu = fuwu
    that.setData({
      fuwu: fuwu
    })
  },
  choose_1: function(e) {
    var that = this
    var fuwu = that.data.fuwu
    var index = e.currentTarget.dataset.index
    var id = e.currentTarget.dataset.id
    fuwu.splice(index, 1, 0)
    console.log(fuwu)
    that.setData({
      fuwu: fuwu
    })
    app.globalData.fuwu = fuwu
  },
  choose1(e) {
    var that = this
    var arr = that.data.configure1
    var tese = that.data.tese
    if (tese.length == 0) {
      for (var i = 0; i < arr.length; i++) {
        var tese = tese.concat(0)
      }
    }
    var id = e.currentTarget.dataset.id
    var index = e.currentTarget.dataset.index
    if (tese[index] == 0) {
      tese.splice(index, 1, id)
    }
    console.log(tese)
    app.globalData.tese = tese
    that.setData({
      tese: tese
    })
  },
  choose1_1: function(e) {
    var that = this
    var tese = that.data.tese
    var index = e.currentTarget.dataset.index
    var id = e.currentTarget.dataset.id
    tese.splice(index, 1, 0)
    console.log(tese)
    that.setData({
      tese: tese
    })
    app.globalData.tese = tese
  },
  choose2_1(e) {
    var that = this
    var index2 = e.currentTarget.dataset.index
    if (index2 == that.data.lx_index2) {
      var index2 = 0
    }
    app.globalData.lb_id = index2
    that.setData({
      lb_index2: index2,
      lb_id: index2,
    })
  },
  submit: function(e) {
    var that = this
    // var lb_id = that.data.lb_index2
    // var lx_id = that.data.lx_index2
    // var hx_id = that.data.hx_index3
    var hd = app.globalData.hd
    var fuwu = app.globalData.fuwu
    var tese = app.globalData.tese
    if (hd) {
      for (var s = 0; s < hd.length; s++) {
        var hd1 = hd1 + ',' + hd[s]
      }
    }
    if (fuwu) {
      for (var i = 0; i < fuwu.length; i++) {
        var fuwu1 = fuwu1 + ',' + fuwu[i]
      }
    }
    if (tese) {
      for (var p = 0; p < tese.length; p++) {
        var tese1 = tese1 + ',' + tese[p]
      }
    }
    if (app.globalData.city_code) {
      var city_code = app.globalData.city_code
    } else {
      var city_code = 1;
    }
    app.globalData.hd_str = hd1
    app.globalData.fuwu_str = fuwu1
    // app.globalData.lb_id = lb_id
    // app.globalData.lx_id = lx_id
    // app.globalData.hx_id = hx_id
    app.globalData.tese_str = tese1
    if (app.globalData.ss_sq_longitude && app.globalData.ss_xq_latitude) {
      var lat = app.globalData.ss_xq_latitude
      var lng = app.globalData.ss_sq_longitude
    } else {
      var lat = app.globalData.lat
      var lng = app.globalData.lng
    }
    console.log(hd1,fuwu1)
    wx.request({
      url: app.globalData.url + 'api/mokuai/mlist',
      data: {
        lx_id: app.globalData.lx_id,
        lb_id: app.globalData.lb_id,
        hx_id: app.globalData.hx_id,
        hd: hd1,
        fuwu: fuwu1,
        tese: tese1,
        x: app.globalData.x,
        y: app.globalData.y,
        city_code: city_code,
        cid: app.globalData.cid,
        url: app.globalData.url,
        tel: wx.getStorageSync('tel'),
        
        id: app.globalData.zj_id,//租金

        pid: app.globalData.px_id,//排序
        lat1: lat,//据当前距离
        lng1: lng,//据当前距离

        zhan: app.globalData.zhan_str,//地铁

        jie: app.globalData.jie_str,//地区
      },
      method: 'post',
      success: function(res) {
        console.log(res)
        that.setData({
          p_list: res.data.plist,
          p_list1: res.data.plist1,
          p_list2: res.data.plist2,
          count: res.data.count1,
          yincang5: true,
          nav4: 0
        })
      }
    })
  },
  choose2(e) {
    var that = this
    var index2 = e.currentTarget.dataset.index
    if (index2 == that.data.lx_index2) {
      var index2 = 0
    }
    app.globalData.lx_id = index2
    that.setData({
      lx_index2: index2,
      lx_id: index2,
    })
  },
  choose3(e) {
    var that = this
    var index3 = e.currentTarget.dataset.index
    console.log(e)
    if (index3 == that.data.hx_index3) {
      var index3 = 0
    }
    app.globalData.hx_id = index3
    that.setData({
      hx_index3: index3
    })
  },
  choose4(e) {
    var that = this
    var index4 = e.currentTarget.dataset.index
    console.log(e)
    if (index4 == that.data.index4) {
      var index4 = 0
    }
    that.setData({
      index4: index4
    })
  },
  choose5(e) {
    var that = this
    var arr = that.data.huodong
    var fuwu = that.data.hd
    if (fuwu.length == 0) {
      for (var i = 0; i < arr.length; i++) {
        var fuwu = fuwu.concat(0)
      }
    }
    var id = e.currentTarget.dataset.id
    var index = e.currentTarget.dataset.index
    if (fuwu[index] == 0) {
      fuwu.splice(index, 1, id)
    }
    console.log(fuwu)
    app.globalData.hd = fuwu
    that.setData({
      hd: fuwu
    })
  },
  choose5_1: function(e) {
    var that = this
    var fuwu = that.data.hd
    var index = e.currentTarget.dataset.index
    var id = e.currentTarget.dataset.id
    fuwu.splice(index, 1, 0)
    console.log(fuwu)
    that.setData({
      hd: fuwu
    })
    app.globalData.hd = fuwu
  },
  liubtn5: function(e) {
    var that = this
    wx.createSelectorQuery().select('#box').boundingClientRect(function (rect) {
      console.log(rect)
      var height = Number(rect.height)+Number(20)
      // console.log(height,1)
      that.setData({
        height: height
      })
    }).exec()
    that.setData({
      // nav4: 1,
      yincang5: false,
      yincang1: true,
      yincang2: true,
      yincang3: true,
      yincang4: true,
      bottom: 0
    })
    
  },
  bakbtn7: function(e) {
    console.log('bakbtn7')
    this.setData({
      // nav4: 0,
      yincang5: true,
      bottom: -100
    })
  },
  liubtn1: function(e) {
    var that = this
    wx.createSelectorQuery().select('#box').boundingClientRect(function (rect) {
      console.log(rect)
      var height = Number(rect.height)+Number(20)
      // console.log(height,1)
      that.setData({
        height: height
      })
    }).exec()
    that.setData({
      // nav: 1,
      yincang1: false,
      yincang5: true,
      yincang2: true,
      yincang3: true,
      yincang4: true,
      bottom: 0
    })
  },
  bakbtn1: function(e) {
    var that = this
    that.setData({
      yincang1: true,
      bottom: -100
    })
  },
  bakbtn: function(e) {
    var that = this

    wx.setNavigationBarTitle({
      title: '房源列表',
    })
    if (that.data.zid == 0) {
      var zhan = that.data.dt_zhan.toString()
    } else {
      var zhan = that.data.kong_zhan.toString()
    }
    app.globalData.zhan_str = zhan
    if (app.globalData.city_code) {
      var city_code = app.globalData.city_code
    } else {
      var city_code = 0
    }
    if (app.globalData.ss_sq_longitude && app.globalData.ss_xq_latitude) {
      var lat = app.globalData.ss_xq_latitude
      var lng = app.globalData.ss_sq_longitude
    } else {
      var lat = app.globalData.lat
      var lng = app.globalData.lng
    }
    wx.request({
      url: app.globalData.url + 'api/mokuai/mlist',
      data: {
        zhan: zhan,

        id: app.globalData.zj_id,//租金

        pid: app.globalData.px_id,//排序
        lat1: lat,//据当前距离
        lng1: lng,//据当前距离
        lb_id: app.globalData.lb_id,//房源类型
        lx_id: app.globalData.lx_id,//房源类型
        hx_id: app.globalData.hx_id,//户型
        hd: app.globalData.hd_str,//活动
        fuwu: app.globalData.fuwu_str,//服务
        tese: app.globalData.tese_str,//特色
        x: app.globalData.x,
        y: app.globalData.y,

        jie: app.globalData.jie_str,//地区

        city_code: city_code,
        cid: app.globalData.cid,
        url: app.globalData.url
      },
      method: 'post',
      success: function(res) {
        console.log(res)

        that.setData({
          p_list: res.data.plist,
          p_list1: res.data.plist1,
          p_list2: res.data.plist2,
        })
      }
    })
    that.setData({
      yincang1: true,
      bottom: -100,
      nav:1
    })
  },
  liubtn2: function(e) {
    var that = this
    wx.createSelectorQuery().select('#box').boundingClientRect(function (rect) {
      console.log(rect)
      var height = Number(rect.height)+Number(20)
      // console.log(height,1)
      that.setData({
        height: height
      })
    }).exec()
    that.setData({
      // nav1: 1,
      yincang2: false,
      yincang1: true,
      yincang5: true,
      yincang3: true,
      yincang4: true,
      bottom: 0
    })
  },
  bakbtn2: function(e) {
    this.setData({
      yincang2: true,
      bottom: -100
    })
  },
  liubtn3: function(e) {
    var that = this
    wx.createSelectorQuery().select('#box').boundingClientRect(function (rect) {
      console.log(rect)
      var height = Number(rect.height)+Number(20)
      // console.log(height,1)
      that.setData({
        height: height
      })
    }).exec()
    that.setData({
      // nav2: 1,
      yincang3: false,
      yincang1: true,
      yincang2: true,
      yincang5: true,
      yincang4: true,
      bottom: 0
    })
  },
  bakbtn5: function(e) {
    this.setData({
      yincang3: true,
      bottom: -100
    })
  },
  liubtn4: function(e) {
    var that = this
    wx.createSelectorQuery().select('#box').boundingClientRect(function (rect) {
      console.log(rect)
      var height = Number(rect.height)+Number(20)
      // console.log(height,1)
      that.setData({
        height: height
      })
    }).exec()
    that.setData({
      // nav3: 1,
      yincang4: false,
      yincang1: true,
      yincang2: true,
      yincang3: true,
      yincang5: true,
      bottom: 0
    })
  },
  bakbtn6: function(e) {
    this.setData({
      yincang4: true,
      bottom: -100
    })
  },
  gongsi: function(e) {
    var that = this
    var id = e.currentTarget.dataset.id
    app.globalData.gongsi = id
    app.globalData.px_id = id
    wx.navigateTo({
      url: '../map/map',
    })
  },
  bakbtn3: function(e) {
    var that = this
    wx.setNavigationBarTitle({
      title: '房源列表',
    })
    if (that.data.jid == 0) {
      var jie = that.data.jie_arr.toString()
    } else {
      var jie = that.data.kong_jie.toString()
    }
    app.globalData.jie_str = jie
    if (app.globalData.city_code) {
      var city_code = app.globalData.city_code
    } else {
      var city_code = 0
    }
    if (app.globalData.ss_sq_longitude && app.globalData.ss_xq_latitude) {
      var lat = app.globalData.ss_xq_latitude
      var lng = app.globalData.ss_sq_longitude
    } else {
      var lat = app.globalData.lat
      var lng = app.globalData.lng
    }
    wx.request({
      url: app.globalData.url + 'api/mokuai/mlist',
      data: {
        cid: app.globalData.cid,
        jie: jie,

        id: app.globalData.zj_id,//租金

        pid: app.globalData.px_id,//排序
        lat1: lat,//据当前距离
        lng1: lng,//据当前距离
        lb_id: app.globalData.lb_id,
        lx_id: app.globalData.lx_id,//房源类型
        hx_id: app.globalData.hx_id,//户型
        hd: app.globalData.hd_str,//活动
        fuwu: app.globalData.fuwu_str,//服务
        tese: app.globalData.tese_str,//特色
        x: app.globalData.x,
        y: app.globalData.y,

        zhan: app.globalData.zhan_str,//地铁

        city_code: city_code,
        url: app.globalData.url
      },
      method: 'post',
      success: function(res) {
        console.log(res)

        that.setData({
          p_list: res.data.plist,
          p_list1: res.data.plist1,
          p_list2: res.data.plist2,
        })
      }
    })
    if (that.data.line_num == 0){
      that.setData({
        nav: 1
      })
    }else{
      that.setData({
        nav1: 0
      })
    }
    that.setData({
      yincang2: true,
      yincang1: true,
      bottom: -100,
    })
  },
  bakbtn4: function(e) {
    var that = this
    var arr = that.data.configure1
    var tese = that.data.tese1
    if (tese.length == 0) {
      for (var i = 0; i < arr.length; i++) {
        var tese = tese.concat(0)
      }
    }
    var arr1 = that.data.configure
    var fuwu = that.data.fuwu1
    if (fuwu.length == 0) {
      for (var a = 0; a < arr1.length; a++) {
        var fuwu = fuwu.concat(0)
      }
    }
    var arr2 = that.data.huodong
    var hd = that.data.hd1
    if (hd.length == 0) {
      for (var s = 0; s < arr2.length; s++) {
        var hd = hd.concat(0)
      }
    }
    that.setData({
      yincang5: true,
      lb_index2: 3,
      tese: tese,
      fuwu: fuwu,
      hd: hd,
      nav4: 1,
      lx_index2: 0,
      // lb_index2: 0,
      hx_index3: 0,
      bottom: -100
    })
    var id = that.data.id
    app.globalData.hd = []
    app.globalData.fuwu = []
    app.globalData.tese = []
    app.globalData.hd_str = ''
    app.globalData.fuwu_str = ''
    app.globalData.lb_id = ''
    app.globalData.lx_id = ''
    app.globalData.hx_id = ''
    app.globalData.tese_str = ''
    that.zaiload(id)
  },
  bakbtn4_1: function(e) {
    var that = this
    that.setData({
      jid: 1,
      fid: 1,
      yincang2: true,
      nav1: 1,
      kong_jie:[]
    })
    var id = that.data.id
    app.globalData.jie_str = ''
    that.zaiload(id)
  },
  bakbtn1_1: function(e) {
    var that = this
    that.setData({
      lid: 1,
      zid: 1,
      yincang1: true,
      nav: 0,
      kong_zhan: []
    })
    app.globalData.zhan_str = ''
    var id = that.data.id
    that.zaiload(id)
  },
  onLoad: function(e) {
    var that = this
    var cid = e.cid

    wx.setNavigationBarTitle({
      title: '房源列表',
    })
    app.globalData.cid = cid
    app.globalData.gongsi = ''
    app.globalData.zj_id = ''
    app.globalData.lb_id = ''
    app.globalData.lx_id = ''
    app.globalData.hx_id = ''
    app.globalData.hd = []
    app.globalData.fuwu = []
    app.globalData.tese = []
    app.globalData.hd_str = ''
    app.globalData.fuwu_str = ''
    app.globalData.tese_str = ''

    app.globalData.zhan_str = ''

    app.globalData.jie_str = ''
    if (app.globalData.city_code) {
      var city_code = app.globalData.city_code
    } else {
      var city_code = 1
    }
    app.globalData.ss_sq_longitude = ''
    app.globalData.ss_xq_latitude = ''
    wx.request({
      url: app.globalData.url + 'api/mokuai/mlist',
      data: {
        cid: cid,
        city_code: city_code,
        url: app.globalData.url
      },
      method: 'post',
      success: function(res) {
        console.log(res)

        that.setData({
          url: app.globalData.url,
          m_info: res.data.m_info,
          p_list: res.data.plist,
          p_list1: res.data.plist1,
          p_list2: res.data.plist2,
          fanwei: res.data.fanwei,
          huxing: res.data.hx_array,
          configure1: res.data.ts_arr,
          leixing: res.data.lx_arr,
          huodong: res.data.hd_arr,
          configure: res.data.fw_arr,
          paixu: res.data.paixu,
          id: cid,
          lb_zt: res.data.lb_zt,
          pinpai: app.globalData.pinpai,
          wei: app.globalData.wei,
          bao: app.globalData.bao,
          youxuan: app.globalData.youxuan,
          pinpai1: app.globalData.pinpai1,
          wei1: app.globalData.wei1,
          bao1: app.globalData.bao1,
          youxuan1: app.globalData.youxuan1,
          gengxin: app.globalData.gengxin
        })
      }
    })
  },
  zj1: function (e) {
    var that = this
    var id = e.currentTarget.dataset.id
    that.setData({
      zid: id
    })
  },
  zj1_1: function (e) {
    var that = this

    that.setData({
      yincang3: true,
      zid: 0,
      nav2: 1
    })
    var id = that.data.id
    app.globalData.zj_id = ''
    that.zaiload(id)
  },
  zj: function(e) {
    var that = this
    wx.setNavigationBarTitle({
      title: '房源列表',
    })
    var id = e.currentTarget.dataset.id
    var cid = app.globalData.cid
    if (app.globalData.city_code) {
      var city_code = app.globalData.city_code
    } else {
      var city_code = 1
    }
    if (app.globalData.ss_sq_longitude && app.globalData.ss_xq_latitude) {
      var lat = app.globalData.ss_xq_latitude
      var lng = app.globalData.ss_sq_longitude
    } else {
      var lat = app.globalData.lat
      var lng = app.globalData.lng
    }
    app.globalData.zj_id = id
    wx.request({
      url: app.globalData.url + 'api/mokuai/mlist',
      data: {
        id: id,
        cid: cid,

        pid: app.globalData.px_id,//排序
        lat1: lat,//据当前距离
        lng1: lng,//据当前距离
        lb_id: app.globalData.lb_id,
        lx_id: app.globalData.lx_id,//房源类型
        hx_id: app.globalData.hx_id,//户型
        hd: app.globalData.hd_str,//活动
        fuwu: app.globalData.fuwu_str,//服务
        tese: app.globalData.tese_str,//特色
        x: app.globalData.x,
        y: app.globalData.y,

        zhan: app.globalData.zhan_str,//地铁

        jie: app.globalData.jie_str,//地区


        city_code: city_code,
        url: app.globalData.url
      },
      method: 'post',
      success: function(res) {
        console.log(res)
        that.setData({
          zid: id,
          p_list: res.data.plist,
          p_list1: res.data.plist1,
          p_list2: res.data.plist2,
          yincang3: true,
          nav2: 0
        })
      }
    })
  },
  px: function(e) {
    var that = this
    var id = e.currentTarget.dataset.id
    var cid = app.globalData.cid
    wx.setNavigationBarTitle({
      title: '房源列表',
    })
    if (app.globalData.city_code) {
      var city_code = app.globalData.city_code
    } else {
      var city_code = 1
    }
    app.globalData.px_id = id
    if(id == 46){
      app.globalData.ss_sq_longitude = ''
      app.globalData.ss_xq_latitude = ''
    }
    if (app.globalData.ss_sq_longitude && app.globalData.ss_xq_latitude) {
      var lat = app.globalData.ss_xq_latitude
      var lng = app.globalData.ss_sq_longitude
    } else {
      var lat = app.globalData.lat
      var lng = app.globalData.lng
    }
    wx.request({
      url: app.globalData.url + 'api/mokuai/mlist',
      data: {
        pid: id,
        cid: cid,
        
        lat1: lat,
        lng1: lng,

        id: app.globalData.zj_id,//租金
        lb_id: app.globalData.lb_id,
        lx_id: app.globalData.lx_id,//房源类型
        hx_id: app.globalData.hx_id,//户型
        hd: app.globalData.hd_str,//活动
        fuwu: app.globalData.fuwu_str,//服务
        tese: app.globalData.tese_str,//特色
        x: app.globalData.x,
        y: app.globalData.y,

        zhan: app.globalData.zhan_str,//地铁

        jie: app.globalData.jie_str,//地区
        city_code: city_code,
        url: app.globalData.url
      },
      method: 'post',
      success: function(res) {
        console.log(res)
        that.setData({
          p_list: res.data.plist,
          p_list1: res.data.plist1,
          p_list2: res.data.plist2,
          pid: id,
          yincang4: true,
          nav3:0
        })
      }
    })
  },
  click1: function(e) {
    var that = this
    var id = e.currentTarget.dataset.id
    wx.request({
      url: app.globalData.url + 'api/mokuai/zhan',
      data: {
        id: id
      },
      method: 'post',
      success: function(res) {
        console.log(res)
        var arr = []
        for (var i = 0; i < res.data.length; i++) {
          var arr = arr.concat(res.data[i].id)
        }
        var arr1 = []
        for (var a = 0; a < res.data.length; a++) {
          var arr1 = arr1.concat(0)
        }
        that.setData({
          zhan: res.data,
          lid: id,
          zid: 0,
          dt_zhan: arr,
          kong_zhan: arr1
        })
      }
    })
  },
  click2: function(e) {
    var that = this
    var id = e.currentTarget.dataset.id
    var index = e.currentTarget.dataset.index
    var dt_zhan = that.data.dt_zhan
    var kong_zhan = that.data.kong_zhan
    if (kong_zhan[index] == 0) {
      kong_zhan.splice(index, 1, id)
    }
    that.setData({
      kong_zhan: kong_zhan,
      zid: 1
    })
  },
  click2_1: function(e) {
    var that = this
    var kong_zhan = that.data.kong_zhan
    var index = e.currentTarget.dataset.index
    var id = e.currentTarget.dataset.id
    kong_zhan.splice(index, 1, 0)
    console.log(kong_zhan)
    that.setData({
      kong_zhan: kong_zhan,
      zid: 1
    })
  },
  click2_2: function(e) {
    var that = this
    var zhan1 = that.data.dt_zhan
    var id = e.currentTarget.dataset.id
    var arr = []

    for (var i = 0; i < zhan1.length; i++) {
      var arr = arr.concat(0)
    }
    that.setData({
      kong_zhan: arr,
      zid: id
    })

  },
  click3: function(e) {
    var that = this
    var id = e.currentTarget.dataset.id
    var index = e.currentTarget.dataset.index
    var jie_arr = that.data.jie_arr
    var kong_jie = that.data.kong_jie
    if (kong_jie[index] == 0) {
      kong_jie.splice(index, 1, id)
    }
    that.setData({
      kong_jie: kong_jie,
      jid: 1
    })
  },
  click3_1: function(e) {
    var that = this
    var kong_jie = that.data.kong_jie
    var index = e.currentTarget.dataset.index
    var id = e.currentTarget.dataset.id
    kong_jie.splice(index, 1, 0)
    console.log(kong_jie)
    that.setData({
      kong_jie: kong_jie,
      jid: 1
    })
  },
  click3_2: function(e) {
    var that = this
    var that = this
    var zhan1 = that.data.jie_arr
    var id = e.currentTarget.dataset.id
    var arr = []

    for (var i = 0; i < zhan1.length; i++) {
      var arr = arr.concat(0)
    }
    that.setData({
      kong_jie: arr,
      jid: id
    })
  },
  onShow: function() {
    var that = this;
    wx.setNavigationBarTitle({
      title: '房源列表',
    })
    var city_name = app.globalData.city_name
    wx.request({
      url: app.globalData.url + 'api/mokuai/step',
      data: {
        city: city_name
      },
      method: 'post',
      success: function(res) {
        console.log(res)
        that.setData({
          line: res.data,
          line_num: res.data.length
        })
      }
    })
    console.log(app.globalData.city_code)
    qqmapsdk.getDistrictByCityId({
      id: app.globalData.city_code, 
      success: function(rag) { 
        console.log(rag);
        console.log('市/区：', rag.result[0]);
        that.setData({
          qu: rag.result[0]
        })
      },
      fail: function(error) {
        console.error(error);
      },
      complete: function(ras) {
        console.log(ras);
      }
    });
    var cid = app.globalData.cid
    if (app.globalData.ss_xq_latitude != '' && app.globalData.ss_sq_longitude != '') {
      if (app.globalData.city_code) {
        var city_code = app.globalData.city_code
      } else {
        var city_code = 1
      }
      wx.request({
        url: app.globalData.url + 'api/mokuai/mlist',
        data: {
          pid: app.globalData.gongsi,
          cid: cid,
          lat1: app.globalData.ss_xq_latitude,
          lng1: app.globalData.ss_sq_longitude,

          id: app.globalData.zj_id,//租金
          lb_id: app.globalData.lb_id,
          lx_id: app.globalData.lx_id,//房源类型
          hx_id: app.globalData.hx_id,//户型
          hd: app.globalData.hd_str,//活动
          fuwu: app.globalData.fuwu_str,//服务
          tese: app.globalData.tese_str,//特色
          x: app.globalData.x,
          y: app.globalData.y,

          zhan: app.globalData.zhan_str,//地铁

          jie: app.globalData.jie_str,//地区
          city_code: city_code,
          url: app.globalData.url
        },
        method: 'post',
        success: function(res) {
          console.log(res)
          
          that.setData({
            p_list: res.data.plist,
            p_list1: res.data.plist1,
            p_list2: res.data.plist2,
            pid: app.globalData.gongsi,
            yincang4: true,
            nav3: 0
          })
        }
      })
    }
  },
  click: function(e) {
    var that = this
    var id = e.currentTarget.dataset.id
    qqmapsdk.getDistrictByCityId({
      // 传入对应省份ID获得城市数据，传入城市ID获得区县数据,依次类推
      id: id, //对应接口getCityList返回数据的Id，如：北京是'110000'
      success: function(rag) { //成功后的回调
        console.log(rag);
        console.log('市/区：', rag.result[0]);
        that.setData({
          jie: rag.result[0],
          fid: id,
          jid: 0
        })
        that.reload()
      },
    });
  },
  reload: function() {
    var that = this
    console.log(that.data.jie)
    var arr = [];
    for (var i = 0; i < that.data.jie.length; i++) {
      var arr = arr.concat(that.data.jie[i].id)
    }
    var arr1 = [];
    for (var i = 0; i < that.data.jie.length; i++) {
      var arr1 = arr1.concat(0)
    }
    that.setData({
      kong_jie: arr1,
      jie_arr: arr
    })
  },
  zaiload: function (id) {
    var that = this

    wx.setNavigationBarTitle({
      title: '房源列表',
    })
    app.globalData.cid = id
    if (app.globalData.city_code) {
      var city_code = app.globalData.city_code
    } else {
      var city_code = 1
    }
    if (app.globalData.ss_sq_longitude && app.globalData.ss_xq_latitude) {
      var lat = app.globalData.ss_xq_latitude
      var lng = app.globalData.ss_sq_longitude
    } else {
      var lat = app.globalData.lat
      var lng = app.globalData.lng
    }
    wx.request({
      url: app.globalData.url + 'api/mokuai/mlist',
      data: {
        cid: id,

        id: app.globalData.zj_id,//租金

        pid: app.globalData.px_id,//排序
        lat1: lat,//据当前距离
        lng1: lng,//据当前距离
        lb_id: app.globalData.lb_id,
        lx_id: app.globalData.lx_id,//房源类型
        hx_id: app.globalData.hx_id,//户型
        hd: app.globalData.hd_str,//活动
        fuwu: app.globalData.fuwu_str,//服务
        tese: app.globalData.tese_str,//特色
        x: app.globalData.x,
        y: app.globalData.y,

        zhan: app.globalData.zhan_str,//地铁

        jie: app.globalData.jie_str,//地区

        city_code: city_code,
        url: app.globalData.url,
        tel: wx.getStorageSync('tel')

      },
      method: 'post',
      success: function (res) {
        console.log(res)

        that.setData({
          url: app.globalData.url,
          m_info: res.data.m_info,
          p_list: res.data.plist,
          p_list1: res.data.plist1,
          p_list2: res.data.plist2,
          fanwei: res.data.fanwei,
          huxing: res.data.hx_array,
          configure1: res.data.ts_arr,
          leixing: res.data.lx_arr,
          huodong: res.data.hd_arr,
          configure: res.data.fw_arr,
          paixu: res.data.paixu,
          id: id
        })
      }
    })
  },
  
})