const app = getApp()
// // import WxParse from '../../wxParse/wxParse.js';
Page({
  data: {
    isChecked2: true,
    time: '12:00',
    countryIndex: 0,
    countryIndex1: 0,
  },
  changeRegin1(e) {
    this.setData({ region: e.detail.value });
  },
  changeRegin(e) {
    this.setData({ region: e.detail.value });
  },
  changeTime(e) {
    var that = this
    app.globalData.s_time = e.detail.value
    that.setData({ time: e.detail.value });
    wx.request({
      url: app.globalData.url + 'api/about/check_cishu',
      data:{
        jiange: that.data.countryList[that.data.countryIndex],
        kaishi: that.data.time
      },
      method: 'post',
      success: function(res){
        console.log(res)
        that.setData({
          countryList1: res.data.arr
        })

      }
    })
  },
  changeCountry(e) {
    var that = this
    var countryList = that.data.countryList
    app.globalData.s_jiange = countryList[e.detail.value]
    that.setData({
      countryIndex: e.detail.value
    })
    wx.request({
      url: app.globalData.url + 'api/about/check_cishu',
      data:{
        jiange: countryList[e.detail.value],
        kaishi: that.data.time
      },
      method: 'post',
      success: function(res){
        console.log(res)
        that.setData({
          countryList1: res.data.arr
        })

      }
    })
  },
  changeCountry1(e) {
    var that = this
    var countryList1 = that.data.countryList1
    app.globalData.s_cishu = countryList1[e.detail.value]
    that.setData({
      countryIndex1: e.detail.value
    })
  },
  onLoad: function (e) {
    var that = this
    var id = e.id
    var type = e.type
    wx.setNavigationBarTitle({
      title: '推广刷新',
    })
    var tel = wx.getStorageSync('tel')
    var yuyue = app.globalData.yuyue
    wx.request({
      url: app.globalData.url + 'api/shuaxin/yuyue_show',
      data: {
        tel: tel,
      },
      method: 'post',
      success: function (res) {
        wx.request({
          url: app.globalData.url + 'api/about/check_cishu',
          data:{
            jiange: res.data.list[0],
            kaishi: res.data.time
          },
          method: 'post',
          success: function(res){
            console.log(res)
            that.setData({
              countryList1: res.data.arr
            })
    
          }
        })
        // var content = res.data.content;
        // WxParse.wxParse('content', 'html', content, that, 5)
        console.log(res)
        var num = res.data.num
        var arr = [];
        for(var i=1; i<=num; i++){
          var arr = arr.concat(i)
        }
        var temp = [];
        if(arr.length<=36){
          for (var y=arr.length-1; y>=0; y--) {
            var temp = temp.concat(arr[y]);
          }
        }else{
          for (var y = 35 ; y >= 0; y--) {
            var temp = temp.concat(arr[y]);
          }
        }
        console.log(temp)
        that.setData({
          num: res.data.num,
          html: res.data.content,
          yuyue: yuyue,
          id: id,
          countryList1: temp,
          countryList: res.data.list,
          time: res.data.time,
          z_type: type
        })
      }
    })
  },
  changeSwitch2: function(e){
    console.log(e)
    if(e.detail.value == false){
      app.globalData.s_shifou = 0
    }else if(e.detail.value == true){
      app.globalData.s_shifou = 1
    }
  },
  submit: function(e){
    var that = this
    var id = e.currentTarget.dataset.id
    var tel = wx.getStorageSync('tel')
    var kaishi = app.globalData.s_time
    var jiange = app.globalData.s_jiange
    var cishu = app.globalData.s_cishu
    var shifou = app.globalData.s_shifou
    if(!kaishi){
      var s_time = that.data.time
    }else{
      var s_time = app.globalData.s_time
    }
    if(!jiange){
      var s_timelag = that.data.countryList[0]
    }else{
      var s_timelag = app.globalData.s_jiange
    }
    if (!cishu){
      var s_num = that.data.countryList1[0]
    }else{
      var s_num = app.globalData.s_cishu
    }
    if (!shifou){
      var s_day = 1
    }else{
      var s_day = app.globalData.s_shifou
    }
    wx.request({
      url: app.globalData.url + 'api/shuaxin/yuyue_save',
      data:{
        s_day: s_day,
        s_num: s_num,
        s_timelag: s_timelag,
        s_time: s_time,
        id: id,
        tel: tel,
      },
      method: 'post',
      success: function(res){
        console.log(res)
        if(res.data.info == 1){
          wx.showToast({
            title: '提交成功',
            duration: 2000,
            icon:'none'
          })
          var num = that.data.num
          that.setData({
            num: num-s_num
          })
          setTimeout(function(){
            wx.navigateBack({
              
            })
          },2000)
        }else if(res.data.info == 2){
          wx.showToast({
            title: '刷新次数为0,请前往购买',
            duration: 2000,
            icon: 'none'
          })
        } else if (res.data.info == 3) {
          wx.showToast({
            title: '当前求租贴已被刷新，请勿重复刷新',
            duration: 2000,
            icon: 'none'
          })
        }
      }
    })
  },
})