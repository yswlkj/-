const app = getApp()
Page({

  data: {

  },
  onLoad: function (e) {
    var that = this
    wx.setNavigationBarTitle({
      title: "账号设置",
    })
  },
  logout: function(e){
    wx.removeStorageSync('tel')
    wx.reLaunch({
      url: '../my/my',
    })
  },
})