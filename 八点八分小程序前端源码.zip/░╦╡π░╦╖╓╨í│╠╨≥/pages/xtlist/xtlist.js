const app = getApp()
Page({
  data: {
    shan_zt: 0,
    yincang: true,
    yincang2: true,
    batchIds_o_pl: [],
    batchIds_o_ly: [],
    batchIds_m_pl: [],
    batchIds_m_ly: [],
    select_all: ''
  },
  liubtn: function (e) {
    this.setData({
      yincang: false,
      yincang2: false,
      bottom: 0,
      shan_zt: 1
    })
  },
  liubtn1: function (e) {
    var that = this

    that.setData({
      yincang: true,
      yincang2: true,
      bottom: 0,
      shan_zt: 0,
      zzt: 0,
      select_all: '',
      batchIds_o_pl: [],
      batchIds_o_ly: [],
      batchIds_m_pl: [],
      batchIds_m_ly: [],
    })
  },
  quanxuan: function (e) {
    console.log(e)
    var that = this;
    that.setData({
      yincang: false,
      yincang2: false,
      bottom: 0,
      shan_zt: 1
    })
    if(that.data.select_all == ''){
      that.setData({
        select_all: 'checked'
      })
    }else{
      that.setData({
        select_all: ''
      })
    }
    var batchIds_o_pl = that.data.batchIds_o_pl
    var batchIds_o_ly = that.data.batchIds_o_ly
    var batchIds_m_pl = that.data.batchIds_m_pl
    var batchIds_m_ly = that.data.batchIds_m_ly
    var length = that.data.list.length
    var length_o_pl = 0
    var length_o_ly = 0
    var length_m_pl = 0
    var length_m_ly = 0
    var list_o_pl = []
    var list_o_ly = []
    var list_m_pl = []
    var list_m_ly = []
    for (var i = 0; i < length; i++) {
      if (that.data.list[i].zztt == 0) {
        length_o_pl++
        var list_o_pl = list_o_pl.concat(that.data.list[i].id)
      }
      if (that.data.list[i].zztt == 1) {
        length_o_ly++
        var list_o_ly = list_o_ly.concat(that.data.list[i].id)
      }
      if (that.data.list[i].zztt == 2) {
        length_m_pl++
        var list_m_pl = list_m_pl.concat(that.data.list[i].id)
      }
      if (that.data.list[i].zztt == 3) {
        length_m_ly++
        var list_m_ly = list_m_ly.concat(that.data.list[i].id)
      }
    }
    that.setData({
      list_o_pl: list_o_pl,
      list_o_ly: list_o_ly,
      list_m_pl: list_m_pl,
      list_m_ly: list_m_ly
    })
    if (length_o_pl == batchIds_o_pl.length) {
      that.setData({
        batchIds_o_pl: [],
      })
    } else {
      if (batchIds_o_pl.length == 0) {
        for (var j = 0; j < length_o_pl; j++) {
          var batchIds_o_pl = batchIds_o_pl.concat(that.data.list_o_pl[j])
        }
      } else {
        for (var j = 0; j < length_o_pl; j++) {
          if (!batchIds_o_pl.includes(that.data.list_o_pl[j])) {
            var batchIds_o_pl = batchIds_o_pl.concat(that.data.list_o_pl[j])
          }
        }
      }
      that.setData({
        batchIds_o_pl: batchIds_o_pl,
      })
    }
    console.log('别人的评论', that.data.batchIds_o_pl, length_o_pl)
    if (length_o_ly == batchIds_o_ly.length) {
      that.setData({
        batchIds_o_ly: [],
      })
    } else {
      if (batchIds_o_ly.length == 0) {
        for (var k = 0; k < length_o_ly; k++) {
          var batchIds_o_ly = batchIds_o_ly.concat(that.data.list_o_ly[k])
        }
      } else {
        for (var k = 0; k < length_o_ly; k++) {
          if (!batchIds_o_ly.includes(that.data.list_o_ly[k])) {
            var batchIds_o_ly = batchIds_o_ly.concat(that.data.list_o_ly[k])
          }
        }
      }
      that.setData({
        batchIds_o_ly: batchIds_o_ly,
      })
    }
    console.log('别人的留言', that.data.batchIds_o_ly, length_o_ly)
    if (length_m_pl == batchIds_m_pl.length) {
      that.setData({
        batchIds_m_pl: [],
      })
    } else {
      if (batchIds_m_pl.length == 0) {
        for (var l = 0; l < length_m_pl; l++) {
          var batchIds_m_pl = batchIds_m_pl.concat(that.data.list_m_pl[l])
        }
      } else {
        for (var l = 0; l < length_m_pl; l++) {
          if (!batchIds_m_pl.includes(that.data.list_m_pl[l])) {
            var batchIds_m_pl = batchIds_m_pl.concat(that.data.list_m_pl[l])
          }
        }
      }
      that.setData({
        batchIds_m_pl: batchIds_m_pl,
      })
    }
    console.log('我的评论', that.data.batchIds_m_pl, length_m_pl)
    if (length_m_ly == batchIds_m_ly.length) {
      that.setData({
        batchIds_m_ly: [],
      })
    } else {
      if (batchIds_m_ly.length == 0) {
        for (var o = 0; o < length_m_ly; o++) {
          var batchIds_m_ly = batchIds_m_ly.concat(that.data.list_m_ly[o])
        }
      } else {
        for (var o = 0; o < length_m_ly; o++) {
          if (!batchIds_m_ly.includes(that.data.list_m_ly[o])) {
            var batchIds_m_ly = batchIds_m_ly.concat(that.data.list_m_ly[o])
          }
        }
      }
      that.setData({
        batchIds_m_ly: batchIds_m_ly,
      })
    }
    console.log('我的留言', that.data.batchIds_m_ly, length_m_ly)

    if (that.data.batchIds_o_pl.length == length_o_pl && that.data.batchIds_o_ly.length == length_o_ly && that.data.batchIds_m_pl.length == length_m_pl && that.data.batchIds_m_ly.length == length_m_ly) {
      that.setData({
        zzt: 1
      })
    } else {
      that.setData({
        zzt: 0
      })
    }
  },
  danxuan: function (e) {
    // console.log(e)
    var that = this
    var id = e.currentTarget.dataset.id
    var zztt = e.currentTarget.dataset.zztt
    var batchIds_o_pl = that.data.batchIds_o_pl
    var batchIds_o_ly = that.data.batchIds_o_ly
    var batchIds_m_pl = that.data.batchIds_m_pl
    var batchIds_m_ly = that.data.batchIds_m_ly
    var length = that.data.list.length
    if (zztt == 0) {
      if (batchIds_o_pl.length == 0) {
        var batchIds_o_pl = batchIds_o_pl.concat(id)
        console.log(batchIds_o_pl)

      } else {
        if (batchIds_o_pl.includes(id)) {
          var idx = batchIds_o_pl.indexOf(id)
          batchIds_o_pl.splice(idx, 1)
        } else {
          var batchIds_o_pl = batchIds_o_pl.concat(id)
        }
        console.log(batchIds_o_pl)
      }
    } else if (zztt == 1) {
      if (batchIds_o_ly.length == 0) {
        var batchIds_o_ly = batchIds_o_ly.concat(id)
        console.log(batchIds_o_ly)

      } else {
        if (batchIds_o_ly.includes(id)) {
          var idx = batchIds_o_ly.indexOf(id)
          batchIds_o_ly.splice(idx, 1)
        } else {
          var batchIds_o_ly = batchIds_o_ly.concat(id)
        }
        console.log(batchIds_o_ly)
      }
    } else if (zztt == 2) {
      if (batchIds_m_pl.length == 0) {
        var batchIds_m_pl = batchIds_m_pl.concat(id)
        console.log(batchIds_m_pl)

      } else {
        if (batchIds_m_pl.includes(id)) {
          var idx = batchIds_m_pl.indexOf(id)
          batchIds_m_pl.splice(idx, 1)
        } else {
          var batchIds_m_pl = batchIds_m_pl.concat(id)
        }
        console.log(batchIds_m_pl)
      }
    } else if (zztt == 3) {
      if (batchIds_m_ly.length == 0) {
        var batchIds_m_ly = batchIds_m_ly.concat(id)
        console.log(batchIds_m_ly)

      } else {
        if (batchIds_m_ly.includes(id)) {
          var idx = batchIds_m_ly.indexOf(id)
          batchIds_m_ly.splice(idx, 1)
        } else {
          var batchIds_m_ly = batchIds_m_ly.concat(id)
        }
        console.log(batchIds_m_ly)
      }
    }



    if (length == (batchIds_o_pl.length + batchIds_o_ly.length + batchIds_m_pl.length + batchIds_m_ly.length)) {
      that.setData({
        select_all: 'checked'
      })
    } else {
      that.setData({
        select_all: ''
      })
    }
    that.setData({
      batchIds_o_pl: batchIds_o_pl,
      batchIds_o_ly: batchIds_o_ly,
      batchIds_m_pl: batchIds_m_pl,
      batchIds_m_ly: batchIds_m_ly,
    })
  },
  shan: function (e) {
    var that = this
    // var type = that.data.type
    var batchIds = that.data.batchIds

    var batchIds_o_pl = that.data.batchIds_o_pl
    var batchIds_o_ly = that.data.batchIds_o_ly
    var batchIds_m_pl = that.data.batchIds_m_pl
    var batchIds_m_ly = that.data.batchIds_m_ly
    if ((batchIds_o_pl.length + batchIds_o_ly.length + batchIds_m_pl.length + batchIds_m_ly.length) == 0) {
      wx.showToast({
        title: '请选择需要删除的评论/留言消息',
        duration: 2000,
        icon: 'none',
        mask: true
      })
      return;
    }

    wx.request({
      url: app.globalData.url + 'api/xitong/fw_shan_pl',
      data: {
        tel: wx.getStorageSync('tel'),
        batchIds_o_pl: batchIds_o_pl.toString(),
        batchIds_o_ly: batchIds_o_ly.toString(),
        batchIds_m_pl: batchIds_m_pl.toString(),
        batchIds_m_ly: batchIds_m_ly.toString(),
      },
      method: 'post',
      success: function (res) {
        console.log(res)
        if (res.data.info == 1) {
          wx.showToast({
            title: '删除成功',
            duration: 2000,
            icon: 'none',
            mask: true
          })
          that.onLoad()
        }
      }
    })
  },
  onLoad: function (e) {
    var that = this
    var tel = wx.getStorageSync('tel')
    wx.setNavigationBarTitle({
      title: '评论消息',
    })
    wx.request({
      url: app.globalData.url + 'api/xitong/pj_list',
      data: {
        tel: tel,
        url: app.globalData.url
      },
      method: 'post',
      success: function (res) {
        console.log(res)
        that.setData({
          list: res.data.list_zong,
          select_all: '',
          batchIds_o_pl: [],
          batchIds_o_ly: [],
          batchIds_m_pl: [],
          batchIds_m_ly: [],
          zzt: 0,
          shan_zt: 0,
          yincang: true,
          yincang2: true
        })
      }
    })
  },
  onShow: function () {
    var that = this
    var tel = wx.getStorageSync('tel')
    wx.request({
      url: app.globalData.url + 'api/xitong/pj_list',
      data: {
        tel: tel,
        url: app.globalData.url
      },
      method: 'post',
      success: function (res) {
        console.log(res)
        that.setData({
          list: res.data.list_zong
        })
      }
    })
  }
})