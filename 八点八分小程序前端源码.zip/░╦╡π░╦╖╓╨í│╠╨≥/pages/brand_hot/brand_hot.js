const app = getApp()

Page({
  data: {
    navlist: [
      { title: "热门房型", id: "0" },
      { title: "其他门店", id: "1" },
    ],
    navlist1: [
      { title: "热门房型", id: "0" },
      { title: "公寓门店", id: "1" },
    ],
    nav: 0,
    yincang4: true, 
    gao: 60,
  },
  change: function(e){
    var that = this
    wx.setNavigationBarTitle({
      title: '公寓详情',
    })
    var id = e.currentTarget.dataset.id
    var type = e.currentTarget.dataset.type
    wx.request({
      url: app.globalData.url + 'api/gongyu/index',
      data:{
        cid: app.globalData.g_id,
        tid: id,
        type: type,
        url: app.globalData.url,
        city_code: app.globalData.city_code,
        lat:  app.globalData.lat,
        lng:  app.globalData.lng
      },
      method:'post',
      success: function(res){
        console.log(res)
        that.setData({
          nav: id,
          min_price: res.data.min_price,
          max_price: res.data.max_price,
          rz_list: res.data.rz_list,
          rz_info: res.data.rz_info,
          danye_info: res.data.danye_info,
          type: type,
        })
      }
    })
  },
  renzheng4: function (e) {
    this.setData({
      yincang4: false,
    })
  },
  renzhengclose4: function (e) {
    this.setData({
      yincang4: true,
    })
  },
  onLoad: function (e) {
    var that = this
    wx.setNavigationBarTitle({
      title: '公寓详情',
    })
    var id = e.id
    var type = e.type
    app.globalData.g_id = id
    wx.request({
      url: app.globalData.url + 'api/gongyu/index',
      data:{
        cid: id,
        tid: 0,
        type: type,
        url: app.globalData.url,
        city_code: app.globalData.city_code,
        lat: app.globalData.lat,
        lng:  app.globalData.lng
      },
      method: 'post',
      success: function(res){
        console.log(res)
        console.log(app.globalData.url+res.data.rz_info.logo)
        that.setData({
          rz_info: res.data.rz_info,
          html: res.data.rz_info.content,
          logo: app.globalData.url + res.data.rz_info.logo,
          url: app.globalData.url,
          rz_list: res.data.rz_list,
          danye_info: res.data.danye_info,
          type: type,
          pinpai: app.globalData.pinpai,
          wei: app.globalData.wei,
          bao: app.globalData.bao,
          youxuan: app.globalData.youxuan,
          pinpai1: app.globalData.pinpai1,
          wei1: app.globalData.wei1,
          bao1: app.globalData.bao1,
          youxuan1: app.globalData.youxuan1,
          gengxin: app.globalData.gengxin
        })
      }
    })
  },
  onReady: function(){
    var that = this
    var query = wx.createSelectorQuery()
    query.select('#test').boundingClientRect(function (res) {
      that.setData({
        gao: res.height
      })
    }).exec();
  }
})