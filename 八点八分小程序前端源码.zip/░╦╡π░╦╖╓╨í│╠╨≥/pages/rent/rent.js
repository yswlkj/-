// pages/rent/rent.js
const app = getApp()
// 引入SDK核心类
var QQMapWX = require('../../libs/qqmap-wx-jssdk.js');

// 实例化API核心类
var qqmapsdk = new QQMapWX({
  key: 'I4CBZ-FYL6G-X2LQD-I56ON-N6K7E-UQFK4' // 必填
});
Page({

  /**
   * 页面的初始数据
   */
  data: {
    index: 1,
    nav: 0,
    yincang1: true,
    yincang2: true,
    yincang3: true,
    yincang4: true,
    yincang5: true,
    hidden: false,
    leixing: [
      { title: '求整租', id: '1'},
      { title: '求合租', id: '2'}
      ],
    huodong:[
      {title:'限男生',id:'3'},
      {title:'限女生',id:'2'},
      {title:'男女不限',id:'1'}
      ],
    fuwu: [],
    fuwu1: [],
    fuwu2: [],
    zid:0,
    jid:0
  },
  choose(e) {
    var that = this
    var arr = that.data.configure
    var fuwu = that.data.fuwu
    if (fuwu.length == 0) {
      for (var i = 0; i < arr.length; i++) {
        var fuwu = fuwu.concat(0)
      }
    }
    var id = e.currentTarget.dataset.id
    var index = e.currentTarget.dataset.index
    if (fuwu[index] == 0) {
      fuwu.splice(index, 1, id)
    }
    console.log(fuwu)
    app.globalData.fuwu = fuwu
    that.setData({
      fuwu: fuwu
    })
  },
  choose_1: function (e) {
    var that = this
    var fuwu = that.data.fuwu
    var index = e.currentTarget.dataset.index
    var id = e.currentTarget.dataset.id
    fuwu.splice(index, 1, 0)
    console.log(fuwu)
    that.setData({
      fuwu: fuwu
    })
    app.globalData.fuwu = fuwu
  },
  submit: function (e) {
    var that = this
    var fuwu = app.globalData.fuwu
    if (fuwu) {
      for (var i = 0; i < fuwu.length; i++) {
        var fuwu1 = fuwu1 + ',' + fuwu[i]
      }
    }
    if (app.globalData.city_code) {
      var city_code = app.globalData.city_code
    } else {
      var city_code = 1;
    }
    if (app.globalData.ss_sq_longitude && app.globalData.ss_xq_latitude) {
      var lat = app.globalData.ss_xq_latitude
      var lng = app.globalData.ss_sq_longitude
    } else {
      var lat = app.globalData.lat
      var lng = app.globalData.lng
    }
    app.globalData.fuwu_str = fuwu1
  
    // app.globalData.lx_id = that.data.lx_id
    // app.globalData.xb_id = that.data.xingbie
    // app.globalData.hx_id = that.data.hx_id
    console.log(app.globalData.lx_id,)
    wx.request({
      url: app.globalData.url + 'api/qiuzu/qlist',
      data: {
        huxing: app.globalData.hx_id,
        xingbie: app.globalData.xb_id,
        leibie: app.globalData.lx_id,
        fuwu: fuwu1,
        x: app.globalData.x,
        y: app.globalData.y,
        lat: lat,
        lng: lng,
        city_code: city_code,
        cid: app.globalData.cid,
        url: app.globalData.url,
        tel: wx.getStorageSync('tel'),

        jie: app.globalData.jie,
        zhan: app.globalData.zhan,
        pid: app.globalData.px_id,
        z_id: app.globalData.zj_id,
        

      },
      method: 'post',
      success: function (res) {
        console.log(res)
        that.setData({
          list: res.data.list,
          list1: res.data.list1,
          list2: res.data.list2,
          count: res.data.count1,

          yincang5: true,
          nav4: 1
        })
      }
    })
  },
  bakbtn1_1: function (e) {
    var that = this

    that.setData({
      nav: 0,
      lid: 0,
      zid: 1,
      yincang1: true,
      bottom: -100
    })
    app.globalData.zhan = ''
    that.zaiLoad()
  },
  bakbtn4_1: function (e) {
    var that = this

    that.setData({
      jid: 1,
      fid: 1,
      yincang2: true,
      nav1: 0,
      kong_jie: []
    })
    app.globalData.jie = ''
    that.zaiLoad()
  },
  choose1(e) {
    var that = this
    var arr = that.data.configure1
    var tese = that.data.tese
    if (tese.length == 0) {
      for (var i = 0; i < arr.length; i++) {
        var tese = tese.concat(0)
      }
    }
    var id = e.currentTarget.dataset.id
    var index = e.currentTarget.dataset.index
    if (tese[index] == 0) {
      tese.splice(index, 1, id)
    }
    console.log(tese)
    app.globalData.tese = tese
    that.setData({
      tese: tese
    })
  },
  choose1_1: function (e) {
    var that = this
    var tese = that.data.tese
    var index = e.currentTarget.dataset.index
    var id = e.currentTarget.dataset.id
    tese.splice(index, 1, 0)
    console.log(tese)
    that.setData({
      tese: tese
    })
    app.globalData.tese = tese
  },
  choose2(e) {
    var that = this
    var index2 = e.currentTarget.dataset.index
    console.log(e)
    if (index2 == that.data.index2) {
      var index2 = 0
    }
    app.globalData.lx_id = index2
    that.setData({
      index2: index2,
      lx_id: index2
    })
  },
  choose3(e) {
    var that = this
    var index3 = e.currentTarget.dataset.index
    console.log(e)
    if(index3 == that.data.index3){
      var index3 = 0
    }
    app.globalData.hx_id = index3
    that.setData({
      index3: index3,
      hx_id: index3,
    })
  },
  choose4(e) {
    var that = this
    var index4 = e.currentTarget.dataset.index
    console.log(e)
    if (index4 == that.data.index4) {
      var index4 = 0
    }
    app.globalData.xb_id = index4
    that.setData({
      index4: index4,
      xingbie: index4
    })
  },
  liubtn5: function (e) {
    var that = this
    wx.createSelectorQuery().select('#box').boundingClientRect(function (rect) {
      console.log(rect)
      var height = Number(rect.height)+Number(20)
      // console.log(height,1)
      that.setData({
        height: height
      })
    }).exec()
    that.setData({
      
      yincang5: false,
      yincang1: true,
      yincang2: true,
      yincang3: true,
      yincang4: true,
      bottom: 0
    })
  },
  bakbtn7: function (e) {
    console.log('bakbtn7')
    this.setData({
      
      yincang5: true,
      bottom: -100
    })
  },
  liubtn1: function (e) {
    var that = this
    wx.createSelectorQuery().select('#box').boundingClientRect(function (rect) {
      console.log(rect)
      var height = Number(rect.height)+Number(20)
      // console.log(height,1)
      that.setData({
        height: height
      })
    }).exec()
    that.setData({
      
      yincang1: false,
      yincang2: true,
      yincang3: true,
      yincang4: true,
      yincang5: true,
      bottom: 0
    })
  },
  bakbtn1: function(e) {
    var that = this
    that.setData({
      yincang1: true,
      bottom: -100
    })
  },
  bakbtn: function (e) {
    var that = this
    
    if (app.globalData.city_code) {
      var city_code = app.globalData.city_code
    } else {
      var city_code = 0
    }
    if (that.data.zid == 0) {
      var zhan = that.data.dt_zhan.toString()
      console.log(zhan+'1')
    } else {
      var zhan = that.data.kong_zhan.toString()
      console.log(zhan + '2')
    }
    if (app.globalData.ss_sq_longitude && app.globalData.ss_xq_latitude) {
      var lat = app.globalData.ss_xq_latitude
      var lng = app.globalData.ss_sq_longitude
    } else {
      var lat = app.globalData.lat
      var lng = app.globalData.lng
    }
    app.globalData.zhan = zhan
    wx.request({
      url: app.globalData.url + 'api/qiuzu/qlist',
      data: {
        
        zhan: zhan,
        url:app.globalData.url,
        lat: lat,
        lng: lng,
        city_code: app.globalData.city_code,
        jie: app.globalData.jie,
        pid: app.globalData.px_id,
        z_id: app.globalData.zj_id,
        fuwu: app.globalData.fuwu_str,
        leibie: app.globalData.lx_id,
        xingbie: app.globalData.xb_id,
        huxing: app.globalData.hx_id,
        x: app.globalData.x,
        y: app.globalData.y,


      },
      method: 'post',
      success: function (res) {
        console.log(res)
        that.setData({
          list: res.data.list,
          list1: res.data.list1,
          list2: res.data.list2
        })
      }
    })
    that.setData({
      yincang1: true,
      bottom: -100,
      nav: 1,
      zid:0
    })
  },
  gongsi: function (e) {
    var that = this
    var id = e.currentTarget.dataset.id
    app.globalData.gongsi = id
    wx.navigateTo({
      url: '../map/map',
    })
  },
  liubtn2: function (e) {
    var that = this
    wx.createSelectorQuery().select('#box').boundingClientRect(function (rect) {
      console.log(rect)
      var height = Number(rect.height)+Number(20)
      // console.log(height,1)
      that.setData({
        height: height
      })
    }).exec()
    that.setData({
      
      yincang2: false,
      yincang1: true,
      yincang3: true,
      yincang4: true,
      yincang5: true,
      bottom: 0
    })
  },
  bakbtn2: function (e) {
    this.setData({
      
      yincang2: true,
      bottom: -100
    })
  },
  liubtn3: function (e) {
    var that = this
    wx.createSelectorQuery().select('#box').boundingClientRect(function (rect) {
      console.log(rect)
      var height = Number(rect.height)+Number(20)
      // console.log(height,1)
      that.setData({
        height: height
      })
    }).exec()
    that.setData({
      
      yincang3: false,
      yincang1: true,
      yincang2: true,
      yincang4: true,
      yincang5: true,
      bottom: 0
    })
  },
  bakbtn5: function (e) {
    this.setData({
      
      yincang3: true,
      bottom: -100
    })
  },
  liubtn4: function (e) {
    var that = this
    wx.createSelectorQuery().select('#box').boundingClientRect(function (rect) {
      console.log(rect)
      var height = Number(rect.height)+Number(20)
      // console.log(height,1)
      that.setData({
        height: height
      })
    }).exec()
    that.setData({
      nav3: 1,
      nav: 0,
      nav1: 0,
      nav2: 0,
      nav4: 0,
      yincang4: false,
      yincang1: true,
      yincang2: true,
      yincang3: true,
      yincang5: true,
      bottom: 0
    })
  },
  bakbtn6: function (e) {
    this.setData({
      
      yincang4: true,
      bottom: -100
    })
  },
  bakbtn3: function (e) {
    var that = this
    
    if (that.data.jid == 0) {
      var jie = that.data.jie_arr.toString()
    } else {
      var jie = that.data.kong_jie.toString()
    }
    console.log(jie)
    app.globalData.jie = jie
    if (app.globalData.ss_sq_longitude && app.globalData.ss_xq_latitude) {
      var lat = app.globalData.ss_xq_latitude
      var lng = app.globalData.ss_sq_longitude
    } else {
      var lat = app.globalData.lat
      var lng = app.globalData.lng
    }
    wx.request({
      url: app.globalData.url + 'api/qiuzu/qlist',
      data: {
        jie:jie,
        lat: lat,
        url: app.globalData.url,
        lng: lng,
        city_code: app.globalData.city_code,
        zhan: app.globalData.zhan,
        pid: app.globalData.px_id,
        z_id: app.globalData.zj_id,
        fuwu: app.globalData.fuwu_str,
        leibie: app.globalData.lx_id,
        xingbie: app.globalData.xb_id,
        huxing: app.globalData.hx_id,
        x: app.globalData.x,
        y: app.globalData.y,
      },
      method: 'post',
      success: function (res) {
        console.log(res)
        that.setData({
          list: res.data.list,
          list1: res.data.list1,
          list2: res.data.list2
        })
      }
    })

    that.setData({
      yincang2: true,
      bottom: -100,
      nav1: 1,
      jid: 0
    })
  },
  bakbtn4: function (e) {
    var that = this
    wx.setNavigationBarTitle({
      title: '求租贴',
    })
    app.globalData.zhan = ''
    app.globalData.px_id = ''
    app.globalData.jie = ''
    app.globalData.hd_str = ''
    app.globalData.fuwu_str = ''
    app.globalData.fuwu = []
    app.globalData.lx_id = ''
    app.globalData.xb_id = ''
    app.globalData.hx_id = ''
    app.globalData.zj_id = ''
    app.globalData.x = ''
    app.globalData.y = ''
    if (app.globalData.ss_sq_longitude && app.globalData.ss_xq_latitude) {
      var lat = app.globalData.ss_xq_latitude
      var lng = app.globalData.ss_sq_longitude
    } else {
      var lat = app.globalData.lat
      var lng = app.globalData.lng
    }
    wx.request({
      url: app.globalData.url + 'api/qiuzu/qlist',
      data: {
        url: app.globalData.url,
        lat: lat,
        lng: lng,
        city_code: app.globalData.city_code
      },
      method: 'post',
      success: function (res) {
        console.log(res)
        
        that.setData({
          list: res.data.list,
          list1: res.data.list1,
          list2: res.data.list2,
          url: app.globalData.url,
          lat: res.data.lat,
          fanwei: res.data.fanwei,
          paixu: res.data.paixu,
          fid: 0,
          jid: 0,
        })
      }
    })
    var arr = that.data.configure
    var fuwu = that.data.fuwu2
    if (fuwu.length == 0) {
      for (var i = 0; i < arr.length; i++) {
        var fuwu = fuwu.concat(0)
      }
    }
    that.setData({
      yincang5: true,
      bottom: -100,
      index2:0,
      index3: 0,
      index4:0,
      fuwu: fuwu,
      nav4: 0
    })
    app.globalData.hd_str = ''
    app.globalData.fuwu_str = ''
    app.globalData.lx_id = ''
    app.globalData.xb_id = ''
    app.globalData.hx_id = ''
    // that.zaiLoad()
  },
  /**
   * 生命周期函数--监听页面加载
   */
  onShow: function () {
    var that = this;
    
    var city_name = app.globalData.city_name
    wx.request({
      url: app.globalData.url + 'api/mokuai/step',
      data: {
        city: city_name
      },
      method: 'post',
      success: function (res) {
        console.log(res)
        that.setData({
          line: res.data,
          line_num: res.data.length
        })
      }
    })
    console.log(app.globalData.city_code)
    qqmapsdk.getDistrictByCityId({
      id: app.globalData.city_code, 
      success: function (rag) {
        console.log(rag);
        console.log('市/区：', rag.result[0]);
        that.setData({
          qu: rag.result[0]
        })
      },
      fail: function (error) {
        console.error(error);
      },
      complete: function (ras) {
        console.log(ras);
      }
    });

    if (app.globalData.ss_xq_latitude != '' && app.globalData.ss_sq_longitude != '') {
      console.log('地理位置')
      if (app.globalData.city_code) {
        var city_code = app.globalData.city_code
      } else {
        var city_code = 1;
      }

      wx.request({
        url: app.globalData.url + 'api/qiuzu/qlist',
        data: {
          pid: app.globalData.gongsi,
          lat: app.globalData.ss_xq_latitude,
          url: app.globalData.url,
          lng: app.globalData.ss_sq_longitude,
          city_code: app.globalData.city_code,
          jie: app.globalData.jie,
          zhan: app.globalData.zhan,
          pid: app.globalData.px_id,
          z_id: app.globalData.zj_id,
          fuwu: app.globalData.fuwu_str,
          leibie: app.globalData.lx_id,
          xingbie: app.globalData.xb_id,
          huxing: app.globalData.hx_id,
          x: app.globalData.x,
          y: app.globalData.y,
        },
        method: 'post',
        success: function (res) {
          console.log(res)
          that.setData({
            list: res.data.list,
            list1: res.data.list1,
            list2: res.data.list2,
            pid: app.globalData.gongsi,
            yincang4: true
          })
        }
      })
    } else{
      that.zaiLoad()
    }
    that.setData({
      nav: 0,
      yincang1: true,
      yincang2: true,
      yincang3: true,
      yincang4: true,
      yincang5: true,
      hidden: false,
    })
    var tel = wx.getStorageSync('tel')
    wx.request({
      url: app.globalData.url + 'api/index/check_status',
      data: {
        tel: tel
      },
      method: 'post',
      success: function (res) {
        console.log(res)
        if (res.data.info == 0) {
          wx.showModal({
            title: '提示',
            content: '账号已停用',
            showCancel: false, //是否显示取消按钮

            confirmText: "我知道了", //默认是“确定”
            success: function (res) {
              if (res.cancel) {
                //点击取消,默认隐藏弹框
              } else {
                console.log('封号')
                wx.removeStorageSync('tel')
                that.onLoad()
              }
            },
          })
        }
      }
    })
  },
  onLoad: function (e) {
    var that = this
    wx.setNavigationBarTitle({
      title: '求租贴',
    })
    if (app.globalData.ss_sq_longitude && app.globalData.ss_xq_latitude) {
      var lat = app.globalData.ss_xq_latitude
      var lng = app.globalData.ss_sq_longitude
    } else {
      var lat = app.globalData.lat
      var lng = app.globalData.lng
    }
    console.log(lat, lng)
    app.globalData.zhan = ''
    app.globalData.px_id = ''
    app.globalData.jie = ''
    app.globalData.fuwu = []
    app.globalData.hd_str = ''
    app.globalData.fuwu_str = ''
    app.globalData.lx_id = ''
    app.globalData.xb_id = ''
    app.globalData.hx_id = ''
    app.globalData.zj_id = ''
    app.globalData.x = ''
    app.globalData.y = ''
    wx.request({
      url: app.globalData.url + 'api/qiuzu/qlist',
      data: {
        url: app.globalData.url,
        lat: lat,
        lng: lng,
        city_code: app.globalData.city_code,
        
      },
      method: 'post',
      success: function (res) {
        console.log(res)
        
        that.setData({
          list: res.data.list,
          list1: res.data.list1,
          list2: res.data.list2,
          url: app.globalData.url,
          lat: res.data.lat,
          fanwei: res.data.fanwei,
          paixu: res.data.paixu,
          huxing: res.data.hx_array,
          configure1: res.data.ts_arr,
          leixing: res.data.lx_arr,
          huodong: res.data.hd_arr,
          configure: res.data.fw_arr,
          gengxin: app.globalData.gengxin
        })
      }
    })
  },
  zj1: function (e) {
    var that = this
    var id = e.currentTarget.dataset.id
    that.setData({
      zid: id
    })
  },
  zj1_1: function (e) {
    var that = this

    that.setData({
      yincang3: true,
      zid: 0,
      nav2: 0
    })
    app.globalData.zj_id = ''
    that.zaiLoad()
  },
  zj: function (e) {
    var that = this
    wx.setNavigationBarTitle({
      title: '求租贴',
    })
    if (app.globalData.ss_sq_longitude && app.globalData.ss_xq_latitude) {
      var lat = app.globalData.ss_xq_latitude
      var lng = app.globalData.ss_sq_longitude
    } else {
      var lat = app.globalData.lat
      var lng = app.globalData.lng
    }
    var id = e.currentTarget.dataset.id
    app.globalData.zj_id = id
    wx.request({
      url: app.globalData.url + 'api/qiuzu/qlist',
      data: {
        z_id: id,
        lat: lat,
        url: app.globalData.url,
        lng: lng,
        city_code: app.globalData.city_code,
        zhan: app.globalData.zhan,
        jie: app.globalData.jie,
        fuwu: app.globalData.fuwu_str,
        leibie: app.globalData.lx_id,
        xingbie: app.globalData.xb_id,
        huxing: app.globalData.hx_id,
        x: app.globalData.x,
        y: app.globalData.y,
      },
      method: 'post',
      success: function (res) {
        console.log(res)
        that.setData({
          zid: id,
          list: res.data.list,
          list1: res.data.list1,
          list2: res.data.list2,
          yincang3: true,
          nav2: 1
        })
      }
    })
  },
  px: function (e) {
    var that = this
    wx.setNavigationBarTitle({
      title: app.globalData.webname,
    })
    var id = e.currentTarget.dataset.id
    if(id == 46){
      app.globalData.ss_sq_longitude = ''
      app.globalData.ss_xq_latitude = ''
    }
    if (app.globalData.ss_sq_longitude && app.globalData.ss_xq_latitude) {
      var lat = app.globalData.ss_xq_latitude
      var lng = app.globalData.ss_sq_longitude
    } else {
      var lat = app.globalData.lat
      var lng = app.globalData.lng
    }
    app.globalData.px_id = id
    wx.request({
      url: app.globalData.url + 'api/qiuzu/qlist',
      data: {
        pid: id,
        lat_px: app.globalData.lat,
        lng_px: app.globalData.lng,
        lat: lat,
        url: app.globalData.url,
        lng: lng,
        city_code: app.globalData.city_code,
        jie: app.globalData.jie,
        z_id: app.globalData.zj_id,
        fuwu: app.globalData.fuwu_str,
        leibie: app.globalData.lx_id,
        xingbie: app.globalData.xb_id,
        huxing: app.globalData.hx_id,
        x: app.globalData.x,
        y: app.globalData.y,
      },
      method: 'post',
      success: function (res) {
        console.log(res)
        that.setData({
          list: res.data.list,
          list1: res.data.list1,
          list2: res.data.list2,
          pid: id,
          yincang4: true
        })
      }
    })
  },
  click1: function (e) {
    var that = this
    var id = e.currentTarget.dataset.id
    wx.request({
      url: app.globalData.url + 'api/mokuai/zhan',
      data: {
        id: id
      },
      method: 'post',
      success: function (res) {
        console.log(res)
        var arr = []
        for (var i = 0; i < res.data.length; i++) {
          var arr = arr.concat(res.data[i].id)
        }
        var arr1 = []
        for (var a = 0; a < res.data.length; a++) {
          var arr1 = arr1.concat(0)
        }
        that.setData({
          zhan: res.data,
          lid: id,
          zid:0,
          dt_zhan: arr,
          kong_zhan: arr1
        })
      }
    })
  },
  click2: function (e) {
    var that = this
    var id = e.currentTarget.dataset.id
    var index = e.currentTarget.dataset.index
    var dt_zhan = that.data.dt_zhan
    var kong_zhan = that.data.kong_zhan
    if (kong_zhan[index] == 0) {
      kong_zhan.splice(index, 1, id)
    }
    that.setData({
      kong_zhan: kong_zhan,
      zid: 1
    })
  },
  click2_1: function (e) {
    var that = this
    var kong_zhan = that.data.kong_zhan
    var index = e.currentTarget.dataset.index
    var id = e.currentTarget.dataset.id
    kong_zhan.splice(index, 1, 0)
    console.log(kong_zhan)
    that.setData({
      kong_zhan: kong_zhan,
      zid: 1
    })
  },
  click2_2: function (e) {
    var that = this
    var zhan1 = that.data.dt_zhan
    var id = e.currentTarget.dataset.id
    var arr = []

    for (var i = 0; i < zhan1.length; i++) {
      var arr = arr.concat(0)
    }
    that.setData({
      kong_zhan: arr,
      zid: id
    })

  },
  click3: function (e) {
    var that = this
    var id = e.currentTarget.dataset.id
    var index = e.currentTarget.dataset.index
    var jie_arr = that.data.jie_arr
    var kong_jie = that.data.kong_jie
    if (kong_jie[index] == 0) {
      kong_jie.splice(index, 1, id)
    }
    that.setData({
      kong_jie: kong_jie,
      jid: 1
    })
  },
  click3_1: function (e) {
    var that = this
    var kong_jie = that.data.kong_jie
    var index = e.currentTarget.dataset.index
    var id = e.currentTarget.dataset.id
    kong_jie.splice(index, 1, 0)
    console.log(kong_jie)
    that.setData({
      kong_jie: kong_jie,
      jid: 1
    })
  },
  click3_2: function (e) {
    var that = this
    var that = this
    var zhan1 = that.data.jie_arr
    var id = e.currentTarget.dataset.id
    var arr = []

    for (var i = 0; i < zhan1.length; i++) {
      var arr = arr.concat(0)
    }
    that.setData({
      kong_jie: arr,
      jid: id
    })
  },
  
  click: function (e) {
    var that = this
    var id = e.currentTarget.dataset.id
    qqmapsdk.getDistrictByCityId({
      id: id, 
      success: function (rag) {
        console.log(rag);
        console.log('市/区：', rag.result[0]);
        that.setData({
          jie: rag.result[0],
          fid: id,
          jid: 0
        })
        that.reload()
      },
    });
  },
  reload: function () {
    var that = this
    console.log(that.data.jie)
    var arr = [];
    for (var i = 0; i < that.data.jie.length; i++) {
      var arr = arr.concat(that.data.jie[i].id)
    }
    var arr1 = [];
    for (var i = 0; i < that.data.jie.length; i++) {
      var arr1 = arr1.concat(0)
    }
    that.setData({
      kong_jie: arr1,
      jie_arr: arr
    })
  },
  zaiLoad: function(){
    var that = this
    if (app.globalData.ss_sq_longitude && app.globalData.ss_xq_latitude) {
      var lat = app.globalData.ss_xq_latitude
      var lng = app.globalData.ss_sq_longitude
    } else {
      var lat = app.globalData.lat
      var lng = app.globalData.lng
    }
    console.log(1111)
    if (app.globalData.city_code) {
      var city_code = app.globalData.city_code
    } else {
      var city_code = 1;
    }
    app.globalData.zhan = ''
    app.globalData.px_id = ''
    app.globalData.jie = ''
    app.globalData.fuwu = []
    app.globalData.hd_str = ''
    app.globalData.fuwu_str = ''
    app.globalData.lx_id = ''
    app.globalData.xb_id = ''
    app.globalData.hx_id = ''
    app.globalData.zj_id = ''
    app.globalData.x = ''
    app.globalData.y = ''
    wx.request({
      url: app.globalData.url + 'api/qiuzu/qlist',
      data: {
        pid: app.globalData.gongsi,
        lat: lat,
        url: app.globalData.url,
        lng: lng,
        city_code: app.globalData.city_code,
        jie: app.globalData.jie,
        zhan: app.globalData.zhan,
        pid: app.globalData.px_id,
        z_id: app.globalData.zj_id,
        fuwu: app.globalData.fuwu_str,
        leibie: app.globalData.lx_id,
        xingbie: app.globalData.xb_id,
        huxing: app.globalData.hx_id,
        x: app.globalData.x,
        y: app.globalData.y,
      },
      method: 'post',
      success: function (res) {
        console.log(res)
        that.setData({
          list: res.data.list,
          list1: res.data.list1,
          list2: res.data.list2,
          pid: app.globalData.gongsi,
        })
      }
    })
  }
})