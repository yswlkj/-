const app = getApp()
Page({
  data: {

  },
  onLoad: function (e) {
    var that = this
    wx.setNavigationBarTitle({
      title: '发布成功',
    })
    that.setData({
      id: e.id
    })
    wx.request({
      url: app.globalData.url + 'api/fabu/save_ditie',
      data: {
        id: e.id,
        city: app.globalData.locateCity,
        lng: app.globalData.ss_sq_longitude,
        lat: app.globalData.ss_xq_latitude
      },
      method: 'post',
      success: function (rag) {
        console.log(rag)
        app.globalData.ss_sq_longitude = ''
        app.globalData.ss_xq_latitude = ''
        app.globalData.xq_name = ''
        app.globalData.xq_addr = ''
        app.globalData.ss_xq_name = undefined
        app.globalData.ss_xq_addr = undefined
      }
    })
    wx.request({
      url: app.globalData.url + 'api/mokuai/show1',
      data: {
        id: e.id,
        url: app.globalData.url,
      },
      method: 'post',
      success: function (res) {
        console.log(res)
        that.setData({
          info: res.data.info,
          picss: res.data.picss,
          tishi: res.data.tishi
        })
      }
    })
    
  },
 
  onShareAppMessage: function (e) {
    console.log(e)
    var that = this
    var id = that.data.id
    if (that.data.info.type == 0) {
      var title = '合租-' + that.data.info.xiaoquname + '-' + that.data.info.huxing[0] + '室' + that.data.info.huxing[1] + '厅' + that.data.info.huxing[2] + '卫'
    } else if (that.data.info.type == 1) {
      var title = '整租-' + that.data.info.xiaoquname + '-' + that.data.info.huxing[0] + '室' + that.data.info.huxing[1] + '厅' + that.data.info.huxing[2] + '卫'
    }
    return {
      title: title,
      path: '/pages/home_ex/home_ex?id=' + id,
      imageUrl: that.data.info.picurl,
    }
  }
})