// pages/lf_ex/lf_ex.js
const app = getApp()
// import WxParse from '../../wxParse/wxParse.js';
Page({

  /**
   * 页面的初始数据
   */
  data: {

  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (e) {
    var that = this
    var id = e.id
    wx.setNavigationBarTitle({
      title: '广告消息',
    })
    wx.request({
      url: app.globalData.url + 'api/xitong/ggshow',
      data:{
        id: id,
        tel: wx.getStorageSync('tel'),
        url: app.globalData.url
      },
      method: 'post',
      success: function(res){
        // var content = res.data.info.content;
        // WxParse.wxParse('content', 'html', content, that, 5)
        // var intro = res.data.info.intro;
        // WxParse.wxParse('intro', 'html', intro, that, 5)
        console.log(res)
        that.setData({
          info: res.data.info,
          html: res.data.info.content,
          url: app.globalData.url,
          config:res.data.config.intro*1000
        })
        setTimeout(function () {
          console.log(that.data.config)
          that.huoqu(id)
        }, that.data.config)
      }
    })
    
  },
  huoqu: function(id){
    var that = this
    wx.request({
      url: app.globalData.url + 'api/xitong/huoqu',
      data: {
        id: id,
        tel: wx.getStorageSync('tel'),
        url: app.globalData.url
      },
      method: 'post',
      success: function (res) {
        console.log(res)
        that.setData({
          
        })
      }
    })
  },
})