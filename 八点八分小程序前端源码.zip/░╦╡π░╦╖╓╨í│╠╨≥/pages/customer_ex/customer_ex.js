const app = getApp()
// // import WxParse from '../../wxParse/wxParse.js';
Page({
  data: {

  },
  onLoad: function (e) {
    var that = this
    var id = e.id
    wx.setNavigationBarTitle({
      title: '常见问题',
    })
    wx.request({
      url: app.globalData.url + 'api/my/jyshow',
      data:{
        id: id,
        url: app.globalData.url
      },
      method:'post',
      success: function(res){
        // var content = res.data.show.content;
        // WxParse.wxParse('content', 'html', content, that, 5)
        console.log(res)
        that.setData({
          show: res.data.show,
          html: res.data.show.content,
        })
      }
    })
  },
})