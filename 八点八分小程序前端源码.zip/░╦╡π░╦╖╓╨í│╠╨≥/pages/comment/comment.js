const app = getApp()
Page({
  data: {
    items:[
      {
        name:'0',
        value: '私密评论（仅房东可见）',
        checked: false
      },
      {
        name: '1',
        value: '公开评论',
        checked: true
      }
    ],
    itemss: [
      {
        name: '0',
        value: '私密评论（仅贴主可见）',
        checked: false
      },
      {
        name: '1',
        value: '公开评论',
        checked: true
      }
    ],
    nav: 0,
    nav1: 1
  },
  bindtap1: function (e) {
    var items = this.data.items;
    for (var i = 0; i < items.length; i++) {
      if (items[i].name == this.data.aa) {
        for (var j = 0; j < items.length; j++) {
          if (items[j].checked && j != i) {
            items[j].checked = false;
          }
        }
        items[i].checked = !(items[i].checked);
      }
    }
    this.setData({
      items: items
    });
  },
  click: function(){
    var that = this
    var nav = that.data.nav
    if(nav == 0){
      that.setData({
        nav: 1
      })
    }else if(nav == 1){
      that.setData({
        nav: 0
      })
    }
  },
  click1: function(){
    var that = this
    var nav1 = that.data.nav1
    if(nav1 == 0){
      that.setData({
        nav1: 1
      })
    }else if(nav1 == 1){
      that.setData({
        nav1: 0
      })
    }
  },
  radioChange: function (e) {
    this.data.aa = e.detail.value;
    app.globalData.pj_type = e.detail.value
    console.log(this.data.aa);
  },
  content: function(e){
    var that = this
    that.setData({
      content: e.detail.value
    })
  },
  submit: function(e){
    var that = this
    var pj_type = app.globalData.pj_type
    var content = that.data.content
    // console.log(content);return;
    var nav1 = that.data.nav1
    if(pj_type === undefined || pj_type == ''){
      wx.showToast({
        title: '请选择评论方式',
        duration: 2000,
        icon: 'none',
        mask: true
      })
      return;
    }
    if(!content){
      wx.showToast({
        title: '请填写评论详情',
        duration: 2000,
        icon: 'none',
        mask: true
      })
      return;
    }else{
      if(content.length > 100){
        wx.showToast({
          title: '详情最多填写100字',
          duration: 2000,
          icon: 'none',
          mask: true
        })
        return;
      }
    }
    wx.request({
      url: app.globalData.url + 'api/my/pingjia',
      data: {
        id: app.globalData.f_id,
        pj_type: pj_type,
        tel: wx.getStorageSync('tel'),
        content: content,
        type: app.globalData.type,
        nav: that.data.nav,
        nav1: nav1,
      },
      method: 'post',
      success: function (res) {
        if (res.data.info == 1) {
          app.globalData.pj_type = ''
          app.globalData.huan = 2
          wx.showToast({
            title: '评论成功',
            duration: 2000,
            icon: 'none',
            mask: true
          })
          setTimeout(function () {
            wx.navigateBack({

            })
          }, 2000)
        } else if (res.data.info == 2) {
          wx.showToast({
            title: '内容中存在敏感词,请重新输入',
            duration: 2000,
            icon: 'none',
            mask: true
          })
        }
      }
    })
    // return;
    // if (nav1 == 0) {
    //   wx.showModal({
    //     title: '提示',
    //     content: '是否对房东显示个人信息',
    //     cancelText: '否',
    //     confirmText: '是',
    //     success(res) {
    //       if (res.cancel) {
            
    //       } else if (res.confirm) {
    //         wx.request({
    //           url: app.globalData.url + 'api/my/pingjia',
    //           data: {
    //             id: app.globalData.f_id,
    //             pj_type: pj_type,
    //             tel: wx.getStorageSync('tel'),
    //             content: content,
    //             type: app.globalData.type,
    //             nav: that.data.nav,
    //             nav1: 1
    //           },
    //           method: 'post',
    //           success: function (res) {
    //             console.log(res)
    //             if (res.data.info == 1) {
    //               app.globalData.pj_type = ''
    //               wx.showToast({
    //                 title: '评论成功',
    //                 duration: 2000,
    //                 icon: 'none',
    //                 mask: true
    //               })
    //               setTimeout(function () {
    //                 wx.navigateBack({

    //                 })
    //               }, 2000)
    //             } else if (res.data.info == 2) {
    //               wx.showToast({
    //                 title: '内容中存在敏感词,请重新输入',
    //                 duration: 2000,
    //                 icon: 'none',
    //                 mask: true
    //               })
    //             }
    //           }
    //         })
    //       }
    //     }
    //   })
    // }else{
    //   wx.request({
    //     url: app.globalData.url + 'api/my/pingjia',
    //     data: {
    //       id: app.globalData.f_id,
    //       pj_type: pj_type,
    //       tel: wx.getStorageSync('tel'),
    //       content: content,
    //       type: app.globalData.type,
    //       nav: that.data.nav,
    //       nav1: that.data.nav1
    //     },
    //     method: 'post',
    //     success: function (res) {
    //       console.log(res)
    //       if (res.data.info == 1) {
    //         app.globalData.pj_type = ''
    //         wx.showToast({
    //           title: '评论成功',
    //           duration: 2000,
    //           icon: 'none',
    //           mask: true
    //         })
    //         setTimeout(function () {
    //           wx.navigateBack({

    //           })
    //         }, 2000)
    //       } else if (res.data.info == 2) {
    //         wx.showToast({
    //           title: '内容中存在敏感词,请重新输入',
    //           duration: 2000,
    //           icon: 'none',
    //           mask: true
    //         })
    //       }
    //     }
    //   })
    // }
  },
  onLoad: function (e) {
    var that = this
    var id = e.id
    var zt = e.zt
    app.globalData.f_id = id
    app.globalData.type = zt
    app.globalData.pj_type = 1
    wx.setNavigationBarTitle({
      title: '评论',
    })
    wx.request({
      url: app.globalData.url + 'api/about/pinglun',
      data:{
        tel: wx.getStorageSync('tel')
      },
      method: 'post',
      success: function(res){
        console.log(res)
        that.setData({
          u_info: res.data.u_info,
          user: res.data.user,
          zt: zt
        })
      }
    })
  },
})