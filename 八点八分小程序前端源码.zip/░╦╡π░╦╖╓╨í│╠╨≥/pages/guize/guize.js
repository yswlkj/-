const app = getApp()
// import WxParse from '../../wxParse/wxParse.js';
Page({
  data: {

  },
  onLoad: function (options) {
    var that = this
    wx.setNavigationBarTitle({
      title: app.globalData.webname,
    })
    wx.request({
      url: app.globalData.url + 'api/xitong/guize',
      success: function(res){
        // var content = res.data.info.content;
        // WxParse.wxParse('content', 'html', content, that, 5)
        console.log(res)
        that.setData({
          html: res.data.info.content,
        })
      }
    })
  },
})