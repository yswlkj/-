const app = getApp()
Page({
  data: {
    type: 0,
    type1: 3
  },
  onLoad: function (e) {
    var that = this
    var tel = wx.getStorageSync('tel')
    wx.setNavigationBarTitle({
      title: '邮箱认证',
    })
    wx.request({
      url: app.globalData.url + 'api/xinyong/email',
      data:{
        tel: tel,
      },
      method: 'post',
      success: function(res){
        console.log(res)
        that.setData({
          info: res.data.u_info,
          email: res.data.u_info.email
        })
      }
    })
  },
  email: function(e){
    var that = this
    that.setData({
      email: e.detail.value
    })
  },
  huoqu: function(e){
    var that = this
    var email = that.data.email
    if(!email){
      var email = that.data.info.email
      if(!email){
        wx.showToast({
          title: '请输入邮箱号',
          duration: 2000,
          icon: 'none',
          mask: true
        })
        return;
      }
    }
    var mgras = /^[a-zA-Z0-9_.-]+@[a-zA-Z0-9-]+(\.[a-zA-Z0-9-]+)*\.[a-zA-Z0-9]{2,6}$/;
    if(!mgras.test(email)){
      wx.showToast({
        title: '邮箱号格式有误',
        duration: 2000,
        icon: 'none',
        mask: true
      })
      return;
    }
    that.setData({
      type: 1
    })
    wx.request({
      url: app.globalData.url + 'api/xinyong/sendemail',
      data:{
        email: email
      },
      method: 'post',
      success: function(res){
        console.log(res)
        if(res.data.info == 1){
          wx.showToast({
            title: '发送成功',
            duration: 2000,
            icon: 'none',
            mask: true
          })
          that.setData({
            type: 0
          })
        }
      }
    })
  },
  yzm: function(e){
    var that = this
    that.setData({
      yzm: e.detail.value
    })
  },
  submit: function(e){
    var that = this
    var yzm = that.data.yzm
    that.setData({
      type: 1
    })
    if(!yzm){
      wx.showToast({
        title: '请填写验证码',
        duration: 2000,
        icon: 'none',
        mask: true
      })
      that.setData({
        type: 0
      })
      return;
    }
    var email = that.data.email
    if(!email){
      wx.showToast({
        title: '请填写邮箱号码',
        duration: 2000,
        icon: 'none',
        mask: true
      })
      that.setData({
        type: 0
      })
      return;
    }
    wx.request({
      url: app.globalData.url + 'api/xinyong/email_save',
      data:{
        tel: wx.getStorageSync('tel'),
        yzm: yzm,
        email: email
      },
      method: 'post',
      success: function(res){
        console.log(res)
        if(res.data.info == 0){
          wx.showToast({
            title: '验证码与邮箱不一致',
            duration: 2000,
            icon: 'none',
            mask: true
          })
          that.setData({
            type: 0
          })
          return;
        }else{
          wx.showToast({
            title: '验证成功',
            duration: 2000,
            icon: 'none',
            mask: true
          })
          setTimeout(function(){
            wx.navigateBack({
              
            })
          },2000)
        }
      }
    })
  },
})