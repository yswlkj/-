const app = getApp()
Page({
  data: {

  },
  onLoad: function(e) {
    var that = this
    var cid = e.cid
    var type = e.type
    if (type == 1) {
      wx.setNavigationBarTitle({
        title: '认证公寓',
      })
      wx.request({
        url: app.globalData.url + 'api/gongyu/rz_list',
        data: {
          cid: cid,
          city_code: app.globalData.city_code
        },
        method: 'post',
        success: function(res) {
          console.log(res)
          that.setData({
            rz_info: res.data.rz_info,
            rz_count: res.data.rz_count,
            rz_list: res.data.rz_list,
            min_price: res.data.min_price,
            max_price: res.data.max_price,
            url: app.globalData.url,
            count: res.data.count
          })
        }
      })
    }else if(type == 0){
      wx.setNavigationBarTitle({
        title: '品牌公寓',
      })
      wx.request({
        url: app.globalData.url + 'api/gongyu/rz_list1',
        data: {
          cid: cid,
          city_code: app.globalData.city_code
        },
        method: 'post',
        success: function (res) {
          console.log(res)
          that.setData({
            rz_info: res.data.rz_info,
            rz_count: res.data.rz_count,
            rz_list: res.data.rz_list,
            min_price: res.data.min_price,
            max_price: res.data.max_price,
            url: app.globalData.url,
            count: res.data.count
          })
        }
      })
    }
  },
})