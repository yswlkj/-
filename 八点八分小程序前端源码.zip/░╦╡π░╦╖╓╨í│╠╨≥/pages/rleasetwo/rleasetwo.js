// pages/rleasetwo/rleasetwo.js
let uploadimg = require('../../utils/util.js');
var dateTimePicker = require('../../utils/dateTimePicker.js');

const date = new Date()
const years = []
const months = []
const days = []

for (let i = date.getFullYear(); i <= 2100; i++) {
  years.push(i)
}

for (let i = 1; i <= 12; i++) {
  months.push(i)
}

for (let i = 1; i <= 31; i++) {
  days.push(i)
}

function search(arr, dst) {
  var i = arr.length;
  while (i -= 1) {
    if (arr[i] == dst) {
      return i;
    }
  }
  return false;
}
const app = getApp()
Page({

  /**
   * 页面的初始数据
   */
  data: {
    years: years,
    year: date.getFullYear(),
    months: months,
    month: 2,
    days: days,
    day: 2,
    value: [0, 0, 0],
    dateTimeArray1: null,
    dateTime1: null,
    dateTimeArray2: null,
    dateTime2: null,
    _num: 1,
    nav: 0,
    yincang1: true,
    yincang2: true,
    peizhi: [],
    yaoqiu: [],
    tese: [],
    type1: 0,
    suishi: 0,
    arr: [],
    countryList14: ['1', '2', '3', '4', '5人以上'],
  },
  bindChange: function(e) {
    var val = e.detail.value
    var that = this
    console.log(e)
    var days = []
    var months = e.detail.value[1] + 1
    console.log(months)
    if (months == 1) {
      for (let o = 1; o <= 31; o++) {
        days.push(o)
      }
    } else if (months == 2) {
      for (let o = 1; o <= 29; o++) {
        days.push(o)
      }
    } else if (months == 3) {
      for (let o = 1; o <= 31; o++) {
        days.push(o)
      }
    } else if (months == 4) {
      for (let o = 1; o <= 30; o++) {
        days.push(o)
      }
    } else if (months == 5) {
      for (let o = 1; o <= 31; o++) {
        days.push(o)
      }
    } else if (months == 6) {
      for (let o = 1; o <= 30; o++) {
        days.push(o)
      }
    } else if (months == 7) {
      for (let o = 1; o <= 31; o++) {
        days.push(o)
      }
    } else if (months == 8) {
      for (let o = 1; o <= 31; o++) {
        days.push(o)
      }
    } else if (months == 9) {
      for (let o = 1; o <= 30; o++) {
        days.push(o)
      }
    } else if (months == 10) {
      for (let o = 1; o <= 31; o++) {
        days.push(o)
      }
    } else if (months == 11) {
      for (let o = 1; o <= 30; o++) {
        days.push(o)
      }
    } else if (months == 12) {
      for (let o = 1; o <= 31; o++) {
        days.push(o)
      }
    }
    console.log(days)
    that.setData({
      days: days
    })

    that.setData({
      year: that.data.years[val[0]],
      month: that.data.months[val[1]],
      day: that.data.days[val[2]],
      suishi: 0,
      rzsj1: that.data.years[val[0]] + '-' + that.data.months[val[1]] + '-' + that.data.days[val[2]]
    })
    var year = that.data.years[val[0]]
    var month = that.data.months[val[1]]
    var day = that.data.days[val[2]]
    app.globalData.zhu_time = year + '-' + month + '-' + day
  },
  suishi: function(e) {
    var that = this
    that.setData({
      suishi: 1,
      yincang2: true,
      bottom: -100
    })
    app.globalData.zhu_time = '随时入住'
  },
  bakbtn2: function(e) {
    this.setData({
      yincang2: true,
      bottom: -100
    })
  },
  liubtn1: function(e) {

    this.setData({
      yincang1: false,
      bottom: 0
    })
  },
  bakbtn1: function(e) {
    this.setData({
      yincang1: true,
      bottom: -100
    })
  },
  liubtn2: function(e) {

    this.setData({
      yincang2: false,
      bottom: 0
    })
  },

  bindcancel1: function(e) {
    var that = this
    console.log(e)
  },
  bindMultiPickerChange: function(e) {
    // console.log('picker发送选择改变，携带值为', e.detail.value)
    this.setData({
      multiIndex: e.detail.value
    })
    const index = this.data.multiIndex;
    const year = this.data.multiArray[0][index[0]];
    const month = this.data.multiArray[1][index[1]];
    const day = this.data.multiArray[2][index[2]];
    // console.log(`${year}-${month}-${day}-${hour}-${minute}`);
    this.setData({
      kan_time: year + '-' + month + '-' + day
    })
    // console.log(this.data.time);
    var kan_time = this.data.kan_time
    console.log(kan_time)
    app.globalData.kan_time = kan_time
  },
  bindMultiPickerChange1: function(e) {
    this.setData({
      multiIndex1: e.detail.value
    })
    const index = this.data.multiIndex1;
    const year = this.data.multiArray1[0][index[0]];
    const month = this.data.multiArray1[1][index[1]];
    const day = this.data.multiArray1[2][index[2]];
    this.setData({
      zhu_time: year + '-' + month + '-' + day
    })
    var zhu_time = this.data.zhu_time
    console.log(zhu_time)
    app.globalData.zhu_time = zhu_time
  },
  choose(e) {
    var that = this
    var arr = that.data.fwpz
    var peizhi = that.data.peizhi
    if (peizhi.length == 0) {
      for (var i = 0; i < arr.length; i++) {
        var peizhi = peizhi.concat(0)
      }
    }
    var id = e.currentTarget.dataset.id
    var index = e.currentTarget.dataset.index
    if (peizhi[index] == 0) {
      peizhi.splice(index, 1, id)
    }
    console.log(peizhi)
    app.globalData.peizhi = peizhi
    that.setData({
      peizhi: peizhi
    })
  },
  choose1: function(e) {
    var that = this
    var peizhi = that.data.peizhi
    var index = e.currentTarget.dataset.index
    var id = e.currentTarget.dataset.id
    peizhi.splice(index, 1, 0)
    console.log(peizhi)
    that.setData({
      peizhi: peizhi
    })
    app.globalData.peizhi = peizhi
  },
  change: function(e) {
    var that = this
    var arr = that.data.czyq
    var yaoqiu = that.data.yaoqiu
    if (yaoqiu.length == 0) {
      for (var i = 0; i < arr.length; i++) {
        var yaoqiu = yaoqiu.concat(0)
      }
    }
    var id = e.currentTarget.dataset.id
    var index = e.currentTarget.dataset.index
    if (yaoqiu[index] == 0) {
      yaoqiu.splice(index, 1, id)
    }
    console.log(yaoqiu)
    app.globalData.yaoqiu = yaoqiu
    that.setData({
      yaoqiu: yaoqiu
    })
  },
  change2: function(e) {
    var that = this
    var yaoqiu = that.data.yaoqiu
    var index = e.currentTarget.dataset.index
    var id = e.currentTarget.dataset.id
    yaoqiu.splice(index, 1, 0)
    console.log(yaoqiu)
    that.setData({
      yaoqiu: yaoqiu
    })
    app.globalData.yaoqiu = yaoqiu
  },
  change1: function(e) {
    var that = this
    var arr = that.data.fwts
    var tese = that.data.tese
    if (tese.length == 0) {
      for (var i = 0; i < arr.length; i++) {
        var tese = tese.concat(0)
      }
    }
    var id = e.currentTarget.dataset.id
    var index = e.currentTarget.dataset.index
    if (tese[index] == 0) {
      tese.splice(index, 1, id)
    }
    console.log(tese)
    app.globalData.tese = tese
    that.setData({
      tese: tese
    })
  },
  change3: function(e) {
    var that = this
    var tese = that.data.tese
    var index = e.currentTarget.dataset.index
    var id = e.currentTarget.dataset.id
    tese.splice(index, 1, 0)
    console.log(tese)
    that.setData({
      tese: tese
    })
    app.globalData.tese = tese
  },
  onclick: function(e) {
    this.setData({
      nav: e.currentTarget.dataset.index
    })
  },
  clickNum: function(e) {
    console.log(e.target.dataset.num)
    this.setData({
      _num: e.target.dataset.num
    })
  },
  checkboxChange: function(e) {
    console.log('checkbox发生change事件，携带value值为：', e.detail.value[0])
    app.globalData.chengnuo = e.detail.value[0]
  },
  checkboxChange1: function(e) {
    console.log('checkbox1发生change事件，携带value值为：', e.detail.value[0])
    app.globalData.weituo = e.detail.value[0]
  },
  checkboxChange_bz: function(e) {
    console.log('checkbox_bz发生change事件，携带value值为：', e.detail.value[0])
    app.globalData.baozheng = e.detail.value[0]
  },
  /**
   * 生命周期函数--监听页面加载
   */
  changeCountry1(e) {
    this.setData({
      countryIndex1: e.detail.value
    });
  },
  changeCountry2(e) {
    this.setData({
      countryIndex2: e.detail.value
    });
  },
  changeCountry(e) {
    this.setData({
      countryIndex: e.detail.value
    });
  },
  changeCountry14(e) {
    this.setData({
      countryIndex14: e.detail.value
    });
  },

  onLoad: function(e) {
    var that = this
    wx.setNavigationBarTitle({
      title: '发布房源',
    })
    // 获取完整的年月日 时分秒，以及默认显示的数组
    var obj = dateTimePicker.dateTimePicker(that.data.startYear, that.data.endYear);
    var obj1 = dateTimePicker.dateTimePicker(that.data.startYear, that.data.endYear);
    // 精确到分的处理，将数组的秒去掉
    var lastArray = obj1.dateTimeArray.pop();
    var lastTime = obj1.dateTime.pop();
    that.setData({
      dateTime: obj.dateTime,
      dateTimeArray: obj.dateTimeArray,
      dateTimeArray1: obj1.dateTimeArray,
      dateTime1: obj1.dateTime,
      dateTimeArray2: obj1.dateTimeArray,
      dateTime2: obj1.dateTime
    });
    var type_id = e.type_id
    var type = e.type
    console.log(type)
    that.setData({
      type: type,
      type_id: type_id
    })
    var ntime = Date.parse(new Date()) / 1000;
    console.log(ntime)
    var notime = uploadimg.formatTimeTwo(ntime)
    console.log(notime);
    that.setData({
      multiIndex: notime,
      multiIndex1: notime
    })
    wx.request({
      url: app.globalData.url + 'api/fabu/index2',
      success: function(res) {
        console.log(res)
        var countryList = [];
        var countryList_id = [];
        for (var g = 0; g < res.data.kfsj.length; g++) {
          var countryList_id = countryList_id.concat(res.data.kfsj[g].id)
          var countryList = countryList.concat(res.data.kfsj[g].title)
        }
        var countryList1 = [];
        var countryList1_id = [];
        for (var h = 0; h < res.data.rzsj.length; h++) {
          var countryList1_id = countryList1_id.concat(res.data.rzsj[h].id)
          var countryList1 = countryList1.concat(res.data.rzsj[h].title)
        }
        var countryList2 = [];
        var countryList2_id = [];
        for (var j = 0; j < res.data.qzq.length; j++) {
          var countryList2_id = countryList2_id.concat(res.data.qzq[j].id)
          var countryList2 = countryList2.concat(res.data.qzq[j].title)
        }
        var countryList14 = []
        for (var j = 0; j < res.data.yizhu.length; j++) {
          // var countryList2_id = countryList2_id.concat(res.data.qzq[j].id)
          var countryList14 = countryList14.concat(res.data.yizhu[j].title)
        }
        var years = that.data.years
        var months = that.data.months
        var days = that.data.days
        var years_index = search(years, date.getFullYear())
        var months_index = search(months, res.data.month)
        var days_index = search(days, res.data.day)
        console.log(years_index, months_index, days_index)
        var value = that.data.value
        value.splice(0, 1, years_index);
        value.splice(1, 1, months_index);
        value.splice(2, 1, days_index);
        app.globalData.zhu_time = res.data.year + '-' + res.data.month + '-' + res.data.day
        that.setData({
          fwpz: res.data.fwpz,
          url: app.globalData.url,
          czyq: res.data.czyq,
          fwts: res.data.fwts,
          kan_time: res.data.kan_time,
          zhu_time: res.data.zhu_time,
          countryList: countryList,
          countryList_id: countryList_id,
          countryList1: countryList1,
          countryList1_id: countryList1_id,
          countryList2: countryList2,
          countryList14: countryList14,
          countryList2_id: countryList2_id,
          year: res.data.year,
          month: res.data.month,
          day: res.data.day,
          value: value,
          intro1: res.data.intro,
          guize: res.data.guize,
          hong: res.data.hong,
          xieyi: res.data.xieyi,
          fangyuanfabutishi: res.data.fangyuanfabutishi
        })
      }
    })
  },


  laji: function(e) {

    this.setData({
      yincang: false,
      bottom: 0
    })
  },

  changeDateTimeColumn1(e) {
    console.log(e)
    var arr = this.data.dateTime1,
      dateArr = this.data.dateTimeArray1;

    arr[e.detail.column] = e.detail.value;
    dateArr[2] = dateTimePicker.getMonthDay(dateArr[0][arr[0]], dateArr[1][arr[1]]);
    console.log(dateArr)
    this.setData({
      dateTimeArray1: dateArr
    });
  },
  changeDateTimeColumn2(e) {
    console.log(e)
    var arr = this.data.dateTime2,
      dateArr = this.data.dateTimeArray2;

    arr[e.detail.column] = e.detail.value;
    dateArr[2] = dateTimePicker.getMonthDay(dateArr[0][arr[0]], dateArr[1][arr[1]]);
    console.log(dateArr)
    this.setData({
      dateTimeArray2: dateArr
    });
  },
  changeDateTime1(e) {
    console.log('111', e)
    var that = this

    that.setData({
      dateTime1: e.detail.value
    });
  },
  changeDateTime2(e) {
    console.log('111', e)
    var that = this
    that.setData({
      dateTime2: e.detail.value
    });
  },
  yizhu: function(e) {
    var that = this
    that.setData({
      yizhu: e.detail.value
    })
  },
  qizu: function(e) {
    var that = this
    that.setData({
      qizu: e.detail.value
    })
  },
  title: function(e) {
    var that = this
    that.setData({
      title: e.detail.value
    })
  },
  intro: function(e) {
    var that = this
    that.setData({
      intro: e.detail.value
    })
  },
  submit: function(e) {
    var that = this
    console.log(e)
    var kan_time = that.data.countryIndex
    var yizhu = that.data.countryIndex14
    var zhu_time = app.globalData.zhu_time
    var qizu = that.data.countryIndex2
    var peizhi = that.data.peizhi
    var yaoqiu = that.data.yaoqiu
    var tese = that.data.tese
    var title = that.data.title
    var intro = e.detail.value.intro
    var cailiao = app.globalData.cailiao
    var chengnuo = app.globalData.chengnuo
    var weituo = app.globalData.weituo
    console.log(app.globalData.weituo)
    // return;
    if (!kan_time) {
      wx.showToast({
        title: '请选择看房时间',
        duration: 2000,
        icon: 'none'
      })
      return;
    }
    if (!yizhu) {
      wx.showToast({
        title: '请选择宜住人数',
        duration: 2000,
        icon: 'none'
      })
      return;
    }
    if (!zhu_time) {
      var zhu_time = that.data.value
    }
    if (!qizu) {
      wx.showToast({
        title: '请选择起租期',
        duration: 2000,
        icon: 'none'
      })
      return;
    }
    for (var i = 0; i < peizhi.length; i++) {
      if (peizhi[i] != 0) {
        var pz = 1;
        break;
      }
    }
    if (!pz) {
      wx.showToast({
        title: '请选择房屋配置',
        duration: 2000,
        icon: 'none'
      })
      return;
    }
    for (var y = 0; y < yaoqiu.length; y++) {
      if (yaoqiu[y] != 0) {
        var yq = 1;
        break;
      }
    }
    if (!yq) {
      wx.showToast({
        title: '请选择出租要求',
        duration: 2000,
        icon: 'none'
      })
      return;
    }
    for (var o = 0; o < tese.length; o++) {
      if (tese[o] != 0) {
        var ts = 1;
        break;
      }
    }
    if (!ts) {
      wx.showToast({
        title: '请选择房屋特色',
        duration: 2000,
        icon: 'none'
      })
      return;
    }
    if (!title) {
      wx.showToast({
        title: '请填写房屋标题',
        duration: 2000,
        icon: 'none'
      })
      return;
    }
    if (!intro) {
      wx.showToast({
        title: '请填写房屋描述',
        duration: 2000,
        icon: 'none'
      })
      return;
    }
    if (!chengnuo) {
      wx.showToast({
        title: "请勾选'"+that.data.intro1+"'",
        duration: 2000,
        icon: 'none'
      })
      return;
    }
    that.setData({
      type1: 1
    })
    for (var a = 0; a < peizhi.length; a++) {
      var pz = pz + ',' + peizhi[a]
    }
    for (var s = 0; s < yaoqiu.length; s++) {
      var yq = yq + ',' + yaoqiu[s]
    }
    for (var d = 0; d < tese.length; d++) {
      var ts = ts + ',' + tese[d]
    }


    wx.request({
      url: app.globalData.url + 'api/fabu/check_title_content',
      data: {
        title: title,
        content: intro,
      },
      method: 'post',
      success: function(ftc) {
        console.log(ftc)
        if (ftc.data.info != 1) {
          wx.showToast({
            title: '标题存在敏感词,请重新输入',
            duration: 2000,
            icon: 'none'
          })
          return;
        } else if (ftc.data.info1 != 1) {
          wx.showToast({
            title: '描述存在敏感词,请重新输入',
            duration: 2000,
            icon: 'none'
          })
          return;
        } else if (ftc.data.info1 == 1 && ftc.data.info == 1) {
          var data = []
          that.uploadimg(data);
          that.setData({
            pz: pz,
            yq: yq,
            ts: ts,
            title: title,
            intro: intro,
            qizu: qizu,
            yizhu: yizhu,
            kan_time: kan_time
          })
          // that.uploadimg1();
          

          that.setData({
            type2: 0
          })
          that.xianshi()
          console.log(app.globalData.ss_xq_latitude, app.globalData.ss_sq_longitude)
          setTimeout(function() {

          }, 3000)
        }
      }
    })


  },
  save: function() {
    var that = this
    wx.request({
      url: app.globalData.url + 'api/fabu/save',
      data: {
        // city_code: app.globalData.city_code,
        fengmian: app.globalData.fengmian,
        menpai: app.globalData.menpai,
        tel: wx.getStorageSync('tel'),
        fabu_pic: app.globalData.fabu1,
        fabu_video: app.globalData.shipin1,
        fylx: app.globalData.fylx_id,
        mendian: app.globalData.suoshugy,
        u_tel: app.globalData.u_tel,
        xq_name: app.globalData.xq_name,
        addr: app.globalData.addr,
        mianji: app.globalData.mianji,
        huxing: app.globalData.huxing,
        cx: app.globalData.cx,
        // cn: app.globalData.cn,
        rq: app.globalData.rq,
        yd: app.globalData.yd,
        ys: app.globalData.ys,
        ws: app.globalData.ws,
        cw: app.globalData.cw,
        // fyly: app.globalData.fyly,
        high: app.globalData.louceng,
        zxqk: app.globalData.zxqk,
        setsex: app.globalData.setsex,
        lflx: app.globalData.lflx,
        // zlc: app.globalData.louceng,
        price: app.globalData.price,
        yjfs: app.globalData.yjfs,
        intro1: app.globalData.intro1,
        lat: app.globalData.ss_xq_latitude,
        lng: app.globalData.ss_sq_longitude,
        kan_time: that.data.countryList_id[that.data.kan_time],
        yizhu: that.data.countryList14[that.data.yizhu],
        zhu_time: app.globalData.zhu_time,
        qizu: that.data.countryList2[that.data.qizu],
        fwpz: that.data.pz,
        czyq: that.data.yq,
        fwts: that.data.ts,
        title: that.data.title,
        content: that.data.intro,
        shenfen: app.globalData.shenfen,
        cailiao: app.globalData.cailiao1,
        chengnuo: app.globalData.chengnuo,
        weituo: app.globalData.weituo,
        type: that.data.type,
        type_id: that.data.type_id,
        zhiding_id: app.globalData.fabu_zhiding_id,
        bz_status: 0,
        xiaoqu_addr: app.globalData.ss_xq_addr
      },
      method: 'post',
      success: function(res) {
        console.log(res)
        if (res.data.info == 1) {
          // wx.showToast({
          //   title: '提交成功',
          //   duration: 2000,
          //   icon: 'none'
          // })
          that.setData({
            type2: 1
          })

          app.globalData.fabu = []
          app.globalData.tempFilePaths = []
          app.globalData.shipin = []
          app.globalData.shipin1 = ''
          app.globalData.fabu1 = ''
          app.globalData.cailiao = ''
          app.globalData.baozheng = undefined
          app.globalData.weituo = undefined
          app.globalData.louceng = ''
          app.globalData.huxing = ''
          app.globalData.zhu_time = ''
          app.globalData.fengmian = 0
          
          // setTimeout(function() {
          wx.reLaunch({
            url: '../fs/fs?id=' + res.data.id,
          })
          // }, 2000)

        } else if (res.data.info == 0) {
          wx.showToast({
            title: '您的发布次数已用尽',
            duration: 2000,
            icon: 'none'
          })
          app.globalData.fabu = []
          app.globalData.shipin = []
          app.globalData.cailiao = ''
          app.globalData.fabu1 = ''
          app.globalData.baozheng = undefined
        }
      }
    })
  },
  xianshi: function() {
    var that = this
    if (that.data.type2 == 0) {
      wx.showToast({
        title: '提交中,请稍后...',
        duration: 10000000000000000,
        icon: 'loading'
      })
    }
  },
  uploadimg: function (data) { //这里触发图片上传的方法
    var that = this
    var pics = app.globalData.fabu
    var i;

    i = data.i ? data.i : 0,//当前上传的哪张图片
      wx.uploadFile({
        url: app.globalData.url + 'api/fabu/img',
        filePath: pics[i],
        name: 'file',//这里根据自己的实际情况改
        formData: null,//这里是上传图片时一起上传的数据
        success: (resp) => {
          app.globalData.fabu1 = app.globalData.fabu1 + '@' + resp.data
          console.log(app.globalData.fabu1)
          var pic_str = app.globalData.fabu1
          if (pic_str) {
            console.log('zoule')
            var pic_arr = pic_str.split('@')
            if ((pic_arr.length - 1) == pics.length) {
              console.log('zoule1')
              // console.log(app.globalData.shipin)
              if (app.globalData.shipin.length != 0) {
                that.uploadvideo();
              }else{
                that.save()
              }
            }
          }
        },
        complete: (res) => {
          i++;//这个图片执行完上传后，开始上传下一张
          if (i == pics.length) {   //当图片传完时，停止调用          
            console.log('执行完毕');
          } else {//若图片还没有传完，则继续调用函数
            // console.log(i);
            data.i = i;
            that.uploadimg(data);
          }

        }
      });

  },
  uploadimg1: function() { //这里触发图片上传的方法
    var pics = app.globalData.fengmian
    for (var i = 0; i < pics.length; i++) {
      wx.uploadFile({
        url: app.globalData.url + 'api/fabu/img',
        filePath: pics[i],
        name: 'file',
        success: function(res) {
          //打印
          // console.log(res)
          app.globalData.fengmian1 = res.data
          console.log(app.globalData.fengmian1)
        }
      })
    }
  },
  uploadvideo: function() {
    var that = this
    var shipin = app.globalData.shipin
    console.log(shipin)
    for (var i = 0; i < shipin.length; i++) {
      wx.uploadFile({
        url: app.globalData.url + 'api/fabu/video',
        filePath: shipin[i],
        name: 'file',
        method: 'post',
        success: function(res) {
          //打印
          console.log(res)
          app.globalData.shipin1 = res.data
          that.save()
        }
      })
    }
  },
  onShow: function() {
    var that = this
    if (app.globalData.fabu_zhiding_id) {
      wx.request({
        url: app.globalData.url + 'api/fabu/fabu_zhiding_show',
        data: {
          id: app.globalData.fabu_zhiding_id
        },
        method: 'post',
        success: function(res) {
          console.log(res)
          that.setData({
            zhiding: 1,
            zd_title: res.data.info.title,
            zd_price: res.data.info.discount
          })
        }
      })
    }
    that.setData({
      zhu_time1: app.globalData.zhu_time
    })
  },
})