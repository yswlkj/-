// pages/idea/idea.js
const app = getApp()
Page({

  /**
   * 页面的初始数据
   */
  data: {

  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    var that = this
    wx.setNavigationBarTitle({
      title: '消息中心',
    })
    wx.request({
      url: app.globalData.url + 'api/xitong/idea',
      data:{
        tel: wx.getStorageSync('tel')
      },
      method: 'post',
      success: function(res){
        console.log(res)
        that.setData({
          count: res.data.count,
          count_pj: res.data.count_pj,
          count_fw: res.data.count_fw,
          xianshi: res.data.xianshi,
          laifang: res.data.laifang,
          pinglun: res.data.pinglun,
          xitong: res.data.xitong
        })
      }
    })
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {
    var that = this
    wx.setNavigationBarTitle({
      title: '消息中心',
    })
    wx.request({
      url: app.globalData.url + 'api/xitong/idea',
      data: {
        tel: wx.getStorageSync('tel')
      },
      method: 'post',
      success: function (res) {
        console.log(res)
        that.setData({
          count: res.data.count,
          count_pj: res.data.count_pj,
          count_fw: res.data.count_fw
        })
      }
    })
  },

})