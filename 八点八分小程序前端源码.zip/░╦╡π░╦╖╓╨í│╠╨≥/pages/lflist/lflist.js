// pages/lflist/lflist.js
const app = getApp()
Page({

  /**
   * 页面的初始数据
   */
  data: {
    shan_zt: 0,
    yincang: true,
    yincang2: true,
    batchIds: [],
    select_all: ''
  },
  liubtn: function(e) {
    this.setData({
      yincang: false,
      yincang2: false,
      bottom: 0,
      shan_zt: 1
    })
  },
  liubtn1: function(e) {
    var that = this
    
    that.setData({
      yincang: true,
      yincang2: true,
      bottom: 0,
      shan_zt: 0,
      zzt: 0,
      select_all: '',
      batchIds: [],
      batchIds1: [],
    })
  },
  quanxuan: function(e) {
    console.log(e)
    var that = this;
    var batchIds = that.data.batchIds
    var length = that.data.u_huifu.length
    that.setData({
      yincang: false,
      yincang2: false,
      bottom: 0,
      shan_zt: 1
    })
    if(that.data.select_all == ''){
      that.setData({
        select_all: 'checked'
      })
    }else{
      that.setData({
        select_all: ''
      })
    }
    if(length == batchIds.length){
      that.setData({
        batchIds: [],
        zzt: 0
      })
    }else{
      if(batchIds.length == 0){
        for(var i=0;i<length;i++){
          var batchIds = batchIds.concat(that.data.u_huifu[i].id)
        }
      }else{
        for(var i=0;i<length;i++){
          if(!batchIds.includes(that.data.u_huifu[i].id)){
            var batchIds = batchIds.concat(that.data.u_huifu[i].id)
          }
        }
      }
      that.setData({
        batchIds: batchIds,
        zzt: 1
      })
    }
    console.log(batchIds)
    // that.setData({
    //   list: that.data.list,
      
    // })
  },
  danxuan: function(e) {
    // console.log(e)
    var that = this
    var id = e.currentTarget.dataset.id
    var batchIds = that.data.batchIds
    var length = that.data.u_huifu.length
    console.log(batchIds)
    if(batchIds.length == 0){
      var batchIds = batchIds.concat(id)
      console.log(batchIds)
      
    }else{
      if(batchIds.includes(id)){
        var idx = batchIds.indexOf(id)
        batchIds.splice(idx,1)
      }else{
        var batchIds = batchIds.concat(id)
      }
      console.log(batchIds)
    }
    if(length == batchIds.length){
      that.setData({
        select_all: 'checked'
      })
    }else{
      that.setData({
        select_all: ''
      })
    }
    that.setData({
      batchIds: batchIds
    })
  },
  shan: function(e){
    var that = this
    // var type = that.data.type
    var batchIds = that.data.batchIds
    if (batchIds.length == 0) {
      wx.showToast({
        title: '请选择需要删除的系统消息',
        duration: 2000,
        icon: 'none',
        mask: true
      })
      return;
    }
    wx.request({
      url: app.globalData.url + 'api/xitong/fw_shan_xt',
      data:{
        tel: wx.getStorageSync('tel'),
        batchIds: batchIds.toString()
      },
      method: 'post',
      success: function(res){
        console.log(res)
        if(res.data.info == 1){
          wx.showToast({
            title: '删除成功',
            duration: 2000,
            icon: 'none',
            mask: true
          })
          that.onLoad()
        }
      }
    })
  },
  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (e) {
    var that = this
    wx.setNavigationBarTitle({
      title: '系统消息',
    })
    wx.request({
      url: app.globalData.url + 'api/xitong/xtlist',
      data:{
        url: app.globalData.url,
        tel: wx.getStorageSync('tel')
      },
      method: 'post',
      success: function(res){
        console.log(res)
        that.setData({
          gg_list: res.data.gg_list,
          goga_list: res.data.goga_list,
          tj_list: res.data.tj_list,
          url: app.globalData.url,
          u_huifu: res.data.u_huifu,
          zhanwei: res.data.zhanwei.picurl,
          
          select_all: '',
          batchIds:[],
          zzt: 0,
          shan_zt: 0,
          yincang: true,
          yincang2: true
        })
      }
    })
  },
  getLocate1(lat) {
    var that = this;
    var length = lat.length
    var locateCity1 = []
    var locateQu1 = []
    var locatetown = []
    var locatetownname = []
    for (var i = 0; i < length; i++) {
      wx.request({
        url: 'https://apis.map.qq.com/ws/geocoder/v1/?location=' + lat[i].lat + ',' + lat[i].lng + '&key=I4CBZ-FYL6G-X2LQD-I56ON-N6K7E-UQFK4',
        success: function (res) {
          console.log(res)
          var val1 = res.data.result.address_component.district
          var val = res.data.result.address_component.street_number
          var val2 = res.data.result.address_reference.town.id
          var val3 = res.data.result.address_reference.town.title
          locateCity1.push(val)
          locateQu1.push(val1)
          locatetown.push(val2)
          locatetownname.push(val3)
          that.setData({
            locateQu1: locateQu1,
            locateCity1: locateCity1,
            locatetown: locatetown,
            locatetownname: locatetownname
          })
        },
      })
    }
  }, 
  onShow: function () {
    var that = this
    wx.request({
      url: app.globalData.url + 'api/xitong/xtlist',
      data: {
        url: app.globalData.url,
        tel: wx.getStorageSync('tel')
      },
      method: 'post',
      success: function (res) {
        console.log(res)
        that.setData({
          gg_list: res.data.gg_list,
          goga_list: res.data.goga_list,
          tj_list: res.data.tj_list,
          url: app.globalData.url,
          u_huifu: res.data.u_huifu,
          zhanwei: res.data.zhanwei.picurl
        })
      }
    })
  },
})