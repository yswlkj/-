// pages/nowroof/nowroof.js
const app = getApp()
Page({

  /**
   * 页面的初始数据
   */
  data: {
    items: [{
      name: '2',
      value: '',
      checked: false
    }, ],
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function(e) {
    var that = this
    var id = e.id
    app.globalData.f_id = id
    wx.setNavigationBarTitle({
      title: '推广置顶',
    })
    wx.request({
      url: app.globalData.url + 'api/zhiding/index2',
      data: {
        id: id
      },
      method: 'post',
      success: function(res) {
        console.log(res)
        that.setData({
          info: res.data.info,
          id: id,
          f_id: res.data.id,
          list: res.data.list,
          discount: res.data.discount,
          lijixieyi: res.data.xieyi,
          mianfei: res.data.mianfei,
          lijizhidingtishi: res.data.lijizhidingtishi
        })
      }
    })
  },
  zhiya1: function(e) {
    var items = this.data.items;
    for (var i = 0; i < items.length; i++) {
      if (items[i].name == this.data.aa) {
        for (var j = 0; j < items.length; j++) {
          console.log('----------------')
          console.log(items[j].checked)
          app.globalData.check1 = items[j].checked
          if (items[j].checked && j != i) {
            items[j].checked = false;
            app.globalData.check2 = false;
          }
        }
        items[i].checked = !(items[i].checked);
        this.setData(this.data.items[i]);
      }
    }
    this.setData({
      items: items
    });
  },
  radioChange2: function(e) {
    // for(var i = 0;i<this.data.items.length;i++){
    //   if (this.data.items[i].checked){
    //     // console.log('radio发生change事件，携带value值为：', this.data.items[i].name)
    //   }
    // }
    console.log(e)
    // console.log(app.globalData.check2)
    // console.log(11)
    this.data.aa = e.detail.value;
    app.globalData.xieyi = e.detail.value;

    console.log(app.globalData.xieyi)
    // console.log(this.data.aa);
  },
  radioChange: function(e) {
    var that = this
    console.log(e)
    var id = e.detail.value
    that.reload(id)
  },
  reload: function(id) {
    var that = this
    wx.setNavigationBarTitle({
      title: '推广置顶',
    })
    var id = id
    app.globalData.zhi_id = id
    wx.request({
      url: app.globalData.url + 'api/zhiding/price_show',
      data: {
        id: id
      },
      method: 'post',
      success: function(res) {
        console.log(res)
        that.setData({
          discount: res.data.discount,
          id: id
        })
      }
    })
  },
  zhifu: function(e) {
    var that = this
    var id = e.currentTarget.dataset.id
    var price = e.currentTarget.dataset.price
    var openid = wx.getStorageSync('openid')
    var tel = wx.getStorageSync('tel')
    var xieyi = app.globalData.check1
    var zhi_id = app.globalData.zhi_id
    if (!zhi_id) {
      var zhi_id = that.data.list[0].id
    } else {
      var zhi_id = zhi_id
    }
    console.log(xieyi)
    console.log(that.data.fid)
    if (xieyi === undefined || xieyi == true) {
      wx.showToast({
        title: '请先阅读并同意'+that.data.lijixieyi,
        duration: 2000,
        icon: 'none'
      })
      return;
    } else {
      wx.request({
        url: app.globalData.url + 'api/zhiding/zhiding_check',
        data: {
          id: app.globalData.f_id,
          type: 1
        },
        method: 'post',
        success: function(res1) {
          console.log(res1)
          if (res1.data.res == 1) {
            wx.showToast({
              title: '当前房源置顶中，请勿重复置顶',
              duration: 2000,
              icon: 'none'
            })
          } else if (res1.data.res == 0) {
            wx.request({
              url: app.globalData.url + 'api/zhifu/payOrder',
              data: {
                openid: openid,
                total_fee: price,
              },
              method: 'post',
              success: function(rag) {
                console.log(rag)
                wx.requestPayment({
                  'timeStamp': rag.data.timeStamp,
                  'nonceStr': rag.data.nonceStr,
                  'package': rag.data.package,
                  'signType': rag.data.signType,
                  'paySign': rag.data.paySign,
                  'success': function(res) {
                    console.log(res)
                    wx.request({
                      url: app.globalData.url + 'api/zhiding/liji_zhiding2',
                      data: {
                        tel: tel,
                        id: app.globalData.f_id,
                        zhi_id: zhi_id
                      },
                      method: 'post',
                      success: function(ras) {
                        console.log(ras)
                        if (ras.data.info == 1) {
                          wx.showToast({
                            title: '购买成功，正在跳转',
                            duration: 2000,
                            icon: 'none'
                          })
                          setTimeout(function () {
                            wx.navigateBack({

                            })
                          }, 2000)
                        }
                      }
                    })
                  },
                  'fail': function(res) {

                  },
                })
              }
            })
          }
        }
      })

    }
  },
  onShow: function() {
    app.globalData.check1 = true
  },
})