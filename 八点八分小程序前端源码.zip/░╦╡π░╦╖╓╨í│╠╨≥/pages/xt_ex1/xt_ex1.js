const app = getApp()
Page({
  data: {

  },
  onLoad: function (e) {
    var that = this
    var tel = wx.getStorageSync('tel')
    var id = e.id
    app.globalData.xt_id = id
    wx.setNavigationBarTitle({
      title: '留言内容',
    })
    wx.request({
      url: app.globalData.url + 'api/xitong/pj_show1',
      data:{
        id: id,
        url: app.globalData.url,
        lng: app.globalData.lng,
        lat: app.globalData.lat
      },
      method: 'post',
      success: function(res){
        console.log(res)
        
        that.setData({
          info: res.data.info,
          f_info: res.data.f_info,
          url: app.globalData.url,
          user_info: res.data.user_info,
          u_info: res.data.u_info,
          pinpai: app.globalData.pinpai,
          wei: app.globalData.wei,
          bao: app.globalData.bao,
          youxuan: app.globalData.youxuan,
          pinpai1: app.globalData.pinpai1,
          wei1: app.globalData.wei1,
          bao1: app.globalData.bao1,
          youxuan1: app.globalData.youxuan1,
          gengxin: app.globalData.gengxin
        })
      }
    })
  },
  onShow: function(){
    var that = this
    var tel = wx.getStorageSync('tel')
    var id = app.globalData.xt_id
    wx.setNavigationBarTitle({
      title: '留言内容',
    })
    wx.request({
      url: app.globalData.url + 'api/xitong/pj_show1',
      data:{
        id: id,
        url: app.globalData.url,
        lng: app.globalData.lng,
        lat: app.globalData.lat
      },
      method: 'post',
      success: function(res){
        console.log(res)
        
        that.setData({
          info: res.data.info,
          f_info: res.data.f_info,
          url: app.globalData.url,
          user_info: res.data.user_info,
          u_info: res.data.u_info,
          pinpai: app.globalData.pinpai,
          wei: app.globalData.wei,
          bao: app.globalData.bao,
          youxuan: app.globalData.youxuan,
          pinpai1: app.globalData.pinpai1,
          wei1: app.globalData.wei1,
          bao1: app.globalData.bao1,
          youxuan1: app.globalData.youxuan1
        })
      }
    })
  },
  call: function (e) {
    var that = this
    var zt = e.currentTarget.dataset.zt
    var tel = e.currentTarget.dataset.tel
    if (zt == 1) {
      wx.showToast({
        title: '因当前评论人未向您展示联系方式，故无法联系',
        duration: 2000,
        icon: 'none'
      })
    } else if (zt == 0) {
      wx.makePhoneCall({
        phoneNumber: tel,
      })
    }
  },

})