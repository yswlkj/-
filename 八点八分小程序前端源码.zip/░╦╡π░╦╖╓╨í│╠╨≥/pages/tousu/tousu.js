const app = getApp()
Page({
  data: {
    yincang1: true,
    hidden: false,
    type:0
  },
  liubtn1: function (e) {

    this.setData({
      yincang1: false,
      bottom: 0
    })
  },
  bakbtn2: function (e) {
    this.setData({
      yincang1: true,
      bottom: 0
    })
  },
  bakbtn1: function (e) {
    var that = this
    var id = e.currentTarget.dataset.id
    app.globalData.tsid = id
    that.reload(id)
    that.setData({
      yincang1: true,
      bottom: -100
    })
  },
  reload: function(id){
    var that = this
    wx.setNavigationBarTitle({
      title: '投诉',
    })
    wx.request({
      url: app.globalData.url + 'api/my/jy_select',
      data:{
        id: id
      },
      method: 'post',
      success: function(res){
        console.log(res)
        that.setData({
          ts_title: res.data.title
        })
      }
    })
  },
  onLoad: function (e) {
    var that = this
    wx.setNavigationBarTitle({
      title: '投诉',
    })
    app.globalData.pictures = []
    app.globalData.tupian = ''
    wx.request({
      url: app.globalData.url + 'api/my/jy_type',
      success: function(res){
        console.log(res)
        that.setData({
          list: res.data.list
        })
      }
    })
  },
  upload: function () {
    let that = this;

    
    wx.chooseImage({
      count: 9 - app.globalData.pictures.length, // 默认9
      sizeType: ['compressed'],
      sourceType: ['album', 'camera'],
      success: res => {
        wx.showToast({
          title: '正在上传...',
          icon: 'loading',
          mask: true,
          duration: 1000
        })
        if (app.globalData.pictures.length < 9) {
          app.globalData.pictures = app.globalData.pictures.concat(res.tempFilePaths)
        } else {
          app.globalData.pictures = app.globalData.pictures
          console.log('超过9张')
          wx.showToast({
            title: '图片最多9张',
            duration: 2000,
            icon: 'none'
          })
        }
        that.setData({
          tempFilePaths: app.globalData.pictures
        })
      }
    })
  },
  aaa: function (e) {
    var that = this
    var imgs = app.globalData.pictures;
    var index = e.currentTarget.dataset.index;
    imgs.splice(index, 1);
    app.globalData.pictures = imgs
    that.setData({
      tempFilePaths: imgs,
    });
  },
  uploadimg: function () { 
    var pics = app.globalData.pictures
    for (var i = 0; i < pics.length; i++) {
      wx.uploadFile({
        url: app.globalData.url + 'api/tousu/img',
        filePath: pics[i],
        name: 'file',
        success: function (res) {
          console.log(res)
          app.globalData.tupian = app.globalData.tupian + '@' + res.data
          console.log(app.globalData.tupian)
        }
      })
    }
  },
  listenerButtonPreviewImage: function (e) {
    let index = e.target.dataset.index; 
    let that = this;
    wx.previewImage({
      current: that.data.tempFilePaths[index], 
      urls: that.data.tempFilePaths,
      success: function (res) {
      },
      fail: function () {
      }
    })
  },
  content: function(e){
    var that = this
    that.setData({
      content: e.detail.value
    })
  },
  submit: function(e){
    var that = this
    var openid = 1
    var tsid = app.globalData.tsid
    var content = that.data.content
    if(!tsid){
      wx.showToast({
        title: '请选择投诉类型',
        duration: 2000,
        icon:'none'
      })
      return;
    }
    if(!content){
      wx.showToast({
        title: '请选择填写事件经过',
        duration: 2000,
        icon: 'none'
      })
      return;
    }
    wx.request({
      url: app.globalData.url + 'api/tousu/check',
      data:{
        reason: content
      },
      method: 'post',
      success: function(res){
        console.log(res)
        if(res.data == 1){
          that.setData({
            type: 1
          })
          if (app.globalData.pictures){
          that.uploadimg();
          }
          wx.showToast({
            title: '提交中，请稍后...',
            duration: 3000,
            icon:'none'
          })
          setTimeout(function(){
            wx.request({
              url: app.globalData.url + 'api/tousu/jy_save',
              data: {
                tsid: tsid,
                tel:wx.getStorageSync('tel'),
                content: content,
                picurl: app.globalData.tupian
              },
              method: 'post',
              success: function (ras) {
                console.log(ras)
                if(ras.data.info == 1){
                  wx.showToast({
                    title: '提交成功，正在返回个人中心',
                    duration: 2000,
                    icon: 'none'
                  })
                  app.globalData.pictures = []
                  app.globalData.tupian = ''
                  setTimeout(function(){
                    wx.reLaunch({
                      url: '../my/my',
                    })
                  },2000)
                }
              }
            })
          },3000)
        }else{
          wx.showToast({
            title: '您所填写的内容存在敏感词，请重新编辑后重新提交。',
            duration: 2000,
            icon: 'none'
          })
          return;
        }
      }
    })
  },
})