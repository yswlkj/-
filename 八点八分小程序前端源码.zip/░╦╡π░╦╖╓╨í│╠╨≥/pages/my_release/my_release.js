const app = getApp()
Page({
  data: {
    xianshi: 2,
    dedao: 0
  },
  tianjia_gongyu: function(){
    var that = this
    wx.navigateTo({
      url: '../gongyu/gongyu',
    })
  },
  tianjia: function(e){
    var that = this
    wx.navigateTo({
      url: '../landlord/landlord?zt=1',
    })
  },
  tishi_bu: function(e){
    var that = this
    wx.showModal({
      title: "提示",
      content: '您好，您暂时没有编辑权限，可联系管理员编辑门店信息。',
      showCancel: false,
      confirmText: "我知道了",
      success: function (res) {
        console.log(res)
        if (res.confirm) {
          
        }
      }
    })
  },
  tishi_bu1: function(e){
    var that = this
    wx.showModal({
      title: "提示",
      content: '您好，您暂时没有编辑权限，可联系管理员编辑公寓信息。',
      showCancel: false,
      confirmText: "我知道了",
      success: function (res) {
        console.log(res)
        if (res.confirm) {
          
        }
      }
    })
  },
  onLoad: function(e) {
    var that = this
    wx.setNavigationBarTitle({
      title: '我的发布',
    })
    var dedao = e.dedao
    var type = e.type
    app.globalData.dedao = dedao
    if (dedao == 0) {
      var tel = wx.getStorageSync('tel')
      wx.request({
        url: app.globalData.url + 'api/my/fabu_list',
        data: {
          tel: tel
        },
        method: 'post',
        success: function(res) {
          console.log(res)
          that.setData({
            plist: res.data.plist,
            plist1: res.data.plist1,
            url: app.globalData.url,
            user: res.data.user,
            dedao: dedao,
            gongyu_num: res.data.gongyu_num,
            fenxiang: res.data.fenxiang.picurl,
            pinpai: app.globalData.pinpai,
            wei: app.globalData.wei,
            bao: app.globalData.bao,
            youxuan: app.globalData.youxuan,
            pinpai1: app.globalData.pinpai1,
            wei1: app.globalData.wei1,
            bao1: app.globalData.bao1,
            youxuan1: app.globalData.youxuan1,
            gongyu_tss: res.data.gongyu_tss,
            gongyu_ts: res.data.gongyu_ts,
            mendian_tss: res.data.mendian_tss,
            mendian_ts: res.data.mendian_ts,
            baozhengjintishi: res.data.baozhengjintishi,
            xieyi1: res.data.xieyi,
            tui_tishi: res.data.tui_tishi,
            gengxin: app.globalData.gengxin
          })
        }
      })
    } else if (dedao == 2) {
      wx.setNavigationBarTitle({
        title: '公寓管理',
      })
      if (e.zt) {
        var zt = e.zt
      } else {
        var zt = e
      }
      var tel = wx.getStorageSync('tel')
      app.globalData.gy_zt = zt
      wx.request({
        url: app.globalData.url + 'api/my/gongyu_list1',
        data: {
          tel: tel
        },
        method: 'post',
        success: function(res) {
          console.log(res)

          var arr = res.data.user.gongyu.split(",")

          that.setData({
            list: res.data.info,
            url: app.globalData.url,
            type: res.data.type,
            user: res.data.user,
            fenxiang: res.data.fenxiang.picurl,
            zt: zt,
            dedao: dedao,
            num: arr.length,
            gongyu_tss: res.data.gongyu_tss,
            gongyu_ts: res.data.gongyu_ts,
            mendian_tss: res.data.mendian_tss,
            mendian_ts: res.data.mendian_ts,
          })
        }
      })
    }
    
  },
  tishi: function(e) {
    var that = this
    var type = e.currentTarget.dataset.type
    if (type == 0) {
      wx.showModal({
        title: '提示',
        content: '当前房源已委托给平台，如需退保证金请先取消委托或联系客服。',
        showCancel: false, //是否显示取消按钮-----》false去掉取消按钮
        confirmText: "我知道了", //默认是“确定”
        success: function(res) {
          if (res.cancel) {
            //点击取消
            console.log("您点击了取消")
          } else if (res.confirm) {
            //点击确定
            console.log("您点击了确定")
          }
        }
      })
    } else if (type == 1) {
      wx.showModal({
        title: '提示',
        content: '当前房源已委托给平台，如需缴保证金请先取消委托或联系客服。',
        showCancel: false, //是否显示取消按钮-----》false去掉取消按钮
        confirmText: "我知道了", //默认是“确定”
        success: function(res) {
          if (res.cancel) {
            //点击取消
            console.log("您点击了取消")
          } else if (res.confirm) {
            //点击确定
            console.log("您点击了确定")
          }
        }
      })
    } else if (type == 2) {
      wx.showModal({
        title: '提示',
        content: '当前房源已委托给平台，如需刷新请先取消委托或联系客服。',
        showCancel: false, //是否显示取消按钮-----》false去掉取消按钮
        confirmText: "我知道了", //默认是“确定”
        success: function(res) {
          if (res.cancel) {
            //点击取消
            console.log("您点击了取消")
          } else if (res.confirm) {
            //点击确定
            console.log("您点击了确定")
          }
        }
      })
    } else if (type == 3) {
      wx.showModal({
        title: '提示',
        content: '当前房源已委托给平台，如需置顶请先取消委托或联系客服。',
        showCancel: false, //是否显示取消按钮-----》false去掉取消按钮
        confirmText: "我知道了", //默认是“确定”
        success: function(res) {
          if (res.cancel) {
            //点击取消
            console.log("您点击了取消")
          } else if (res.confirm) {
            //点击确定
            console.log("您点击了确定")
          }
        }
      })
    }
  },
  xia_bao: function(e) {
    var that = this
    wx.showModal({
      title: '提示',
      content: '当前房源已下架，不支持缴纳保证金',
      showCancel: false,
      confirmText: "我知道了",
      success: function(res) {
        if (res.cancel) {
          console.log("您点击了取消")
        } else if (res.confirm) {
          console.log("您点击了确定")
        }
      }
    })
  },
  xia_shua: function(e) {
    var that = this
    wx.showModal({
      title: '提示',
      content: '当前房源已下架，不支持刷新',
      showCancel: false,
      confirmText: "我知道了",
      success: function(res) {
        if (res.cancel) {
          console.log("您点击了取消")
        } else if (res.confirm) {
          console.log("您点击了确定")
        }
      }
    })
  },
  xia_zhi: function(e) {
    var that = this
    wx.showModal({
      title: '提示',
      content: '当前房源已下架，不支持置顶',
      showCancel: false,
      confirmText: "我知道了",
      success: function(res) {
        if (res.cancel) {
          console.log("您点击了取消")
        } else if (res.confirm) {
          console.log("您点击了确定")
        }
      }
    })
  },
  qiehuan: function(e) {
    var that = this
    var id = e.currentTarget.dataset.dedao
    that.setData({
      dedao: id
    })
    app.globalData.dedao = id
    if (id == 0) {
      wx.setNavigationBarTitle({
        title: '我的发布',
      })
      var tel = wx.getStorageSync('tel')
      wx.request({
        url: app.globalData.url + 'api/my/fabu_list',
        data: {
          tel: tel
        },
        method: 'post',
        success: function(res) {
          console.log(res)
          that.setData({
            plist: res.data.plist,
            plist1: res.data.plist1,
            url: app.globalData.url,
            user: res.data.user,
            gongyu_num: res.data.gongyu_num,
            fenxiang: res.data.fenxiang.picurl,
            gongyu_tss: res.data.gongyu_tss,
            gongyu_ts: res.data.gongyu_ts,
            mendian_tss: res.data.mendian_tss,
            mendian_ts: res.data.mendian_ts,
          })
        }
      })
    } else if (id == 1) {
      wx.setNavigationBarTitle({
        title: '门店管理',
      })
      var tel = wx.getStorageSync('tel')
      wx.request({
        url: app.globalData.url + 'api/my/gongyu_list',
        data: {
          tel: tel
        },
        method: 'post',

        success: function(res) {
          console.log(res)
          var arr = []
          if (res.data.info != null) {
            for (var i = 0; i < res.data.info.length; i++) {
              var arr = arr.concat(res.data.info[i].type)
            }
            console.log(arr)
            var arr2 = []
            var arr1 = res.data.user.gongyu.split(",")
            for (var s = 0; s < arr1.length; s++) {
              var arr2 = arr2.concat(parseInt(arr1[s]))
            }
            console.log(arr2)
            for (var o = 0; o < arr.length; o++) {
              // console.log(arr.includes(arr2[o]))
              if (arr2.includes(arr[o])) {
                res.data.info[o].you = 1
              } else {
                res.data.info[o].you = 0
              }
            }
          }
          that.setData({
            list: res.data.info,
            url: app.globalData.url,
            type: res.data.type,
            user: res.data.user,
            gongyu_num: res.data.gongyu_num,
            fenxiang: res.data.fenxiang.picurl,
            gongyu_tss: res.data.gongyu_tss,
            gongyu_ts: res.data.gongyu_ts,
            mendian_tss: res.data.mendian_tss,
            mendian_ts: res.data.mendian_ts,
          })
        }
      })
    } else if (id == 2) {
      wx.setNavigationBarTitle({
        title: '公寓管理',
      })
      if (e.zt) {
        var zt = e.zt
      } else {
        var zt = e
      }
      var tel = wx.getStorageSync('tel')
      app.globalData.gy_zt = zt
      wx.request({
        url: app.globalData.url + 'api/my/gongyu_list1',
        data: {
          tel: tel
        },
        method: 'post',
        success: function(res) {
          console.log(res)

          var arr = res.data.user.gongyu.split(",")
          var gongyu_num = arr.length
          console.log(gongyu_num)
          that.setData({
            list: res.data.info,
            url: app.globalData.url,
            type: res.data.type,
            user: res.data.user,
            fenxiang: res.data.fenxiang.picurl,
            zt: zt,
            gongyu_num: arr.length,
            gongyu_tss: res.data.gongyu_tss,
            gongyu_ts: res.data.gongyu_ts,
            mendian_tss: res.data.mendian_tss,
            mendian_ts: res.data.mendian_ts,
          })
        }
      })
    }
  },
  //门店
  warnModalTrue(e) {
    var that = this;
    var id = e.currentTarget.dataset.id
    wx.request({
      url: app.globalData.url + 'api/yanzheng/mendian_check',
      data: {
        id: id
      },
      method: 'post',
      success: function(res1) {
        console.log(res1)
        if (res1.data.count == 1) {
          wx.showModal({
            title: '是否删除',
            content: that.data.mendian_ts,
            confirmText: '确认删除',
            cancelText: '我再想想',
            success: function(res) {
              if (res.confirm) {
                console.log(id)
                wx.request({
                  url: app.globalData.url + 'api/gongyu/mendian_delete',
                  data: {
                    id: id,
                    tel: wx.getStorageSync('tel')
                  },
                  method: 'post',
                  success: function(res) {
                    console.log(res)
                    if (res.data.delete == 1) {
                      that.reload();
                    }
                  }
                })
              } else if (res.cancel) {
                console.log(id)
              }
            }
          })
        } else {
          wx.showModal({
            title: '是否删除',
            content: that.data.mendian_tss,
            confirmText: '确认删除',
            cancelText: '我再想想',
            success: function(res) {
              if (res.confirm) {
                console.log(id)
                wx.request({
                  url: app.globalData.url + 'api/gongyu/mendian_delete',
                  data: {
                    id: id,
                    tel: wx.getStorageSync('tel')
                  },
                  method: 'post',
                  success: function(res) {
                    console.log(res)
                    if (res.data.delete == 1) {
                      that.reload();
                    }
                  }
                })
              } else if (res.cancel) {
                console.log(id)
              }
            }
          })
        }
      }
    })

  },
  jiechu: function(e) {
    var that = this
    var id = e.currentTarget.dataset.id
    var tel = wx.getStorageSync('tel')
    wx.showModal({
      title: '提示',
      content: '是否确定解除绑定',
      confirmText: '立即解除',
      cancelText: '我再想想',
      success: function(res) {
        if (res.confirm) {
          wx.request({
            url: app.globalData.url + 'api/my/jiechu',
            data: {
              tel: tel,
              id: id
            },
            method: 'post',
            success: function(res) {
              console.log(res)
              wx.showToast({
                title: '解除成功',
                duration: 2000,
                icon: 'none'
              })
              setTimeout(function() {
                wx.navigateBack({

                })
              }, 2000)
            }
          })
        } else if (res.cancel) {
          console.log(id)
        }
      }
    })

  },
  //公寓
  warnModalTrue1(e) {
    var that = this;
    var id = e.currentTarget.dataset.id

    wx.showModal({
      title: '是否解除',
      content: '解除后您将失去管理当前公寓下门店以及房源的权利',
      confirmText: '是',
      cancelText: '否',
      success: function(res) {
        if (res.confirm) {
          console.log(id)
          wx.request({
            url: app.globalData.url + 'api/gongyu/gongyu_jiechu',
            data: {
              id: id,
              tel: wx.getStorageSync('tel')
            },
            method: 'post',
            success: function(res) {
              console.log(res)
              if (res.data.info == 1) {
                that.reload();
              }
            }
          })
        } else if (res.cancel) {
          console.log(id)
        }
      }
    })
  },

  warnModalTrue2(e) {
    var that = this;
    var id = e.currentTarget.dataset.id
    wx.request({
      url: app.globalData.url + 'api/yanzheng/gongyu_check',
      data: {
        id: id
      },
      method: 'post',
      success: function(res1) {
        console.log(res1)
        if (res1.data.count == 1) {
          wx.showModal({
            title: '是否删除',
            content: that.data.gongyu_ts,
            confirmText: '确认删除',
            cancelText: '我再想想',
            success: function(res) {
              if (res.confirm) {
                console.log(id)
                wx.request({
                  url: app.globalData.url + 'api/gongyu/gongyu_delete',
                  data: {
                    id: id,
                    tel: wx.getStorageSync('tel')
                  },
                  method: 'post',
                  success: function(res) {
                    console.log(res)
                    if (res.data.delete == 1) {
                      that.reload();
                    }
                  }
                })
              } else if (res.cancel) {
                console.log(id)
              }
            }
          })
        } else {
          wx.showModal({
            title: '是否删除',
            content: that.data.gongyu_tss,
            confirmText: '确认删除',
            cancelText: '我再想想',
            success: function(res) {
              if (res.confirm) {
                console.log(id)
                wx.request({
                  url: app.globalData.url + 'api/gongyu/gongyu_delete',
                  data: {
                    id: id,
                    tel: wx.getStorageSync('tel')
                  },
                  method: 'post',
                  success: function(res) {
                    console.log(res)
                    if (res.data.delete == 1) {
                      that.reload();
                    }
                  }
                })
              } else if (res.cancel) {
                console.log(id)
              }
            }
          })
        }
      }
    })
  },
  zhifu1: function(e) {
    var that = this
    var id = e.currentTarget.dataset.id
    that.setData({
      xianshi: 1,
      id: id
    })
  },
  tui: function(e) {
    var that = this
    var id = e.currentTarget.dataset.id
    wx.request({
      url: app.globalData.url + 'api/about/tuibao',
      data: {
        id: id
      },
      method: 'post',
      success: function(res) {
        console.log(res)
        if (res.data.info == 2) {
          wx.showToast({
            title: '已申请退回，请等待平台审核',
            duration: 2000,
            icon: 'none'
          })
        } else if (res.data.info == 3) {
          wx.showToast({
            title: '当前房源保证金退回申请已被拒绝',
            duration: 2000,
            icon: 'none'
          })
        } else if (res.data.info == 1) {
          wx.showModal({
            title: '提示',
            content: that.data.tui_tishi,
            showCancel: true,
            cancelText: "我再想想",
            confirmText: "确定退回",
            success: function(res) {
              if (res.cancel) {

              } else {
                wx.request({
                  url: app.globalData.url + 'api/about/tuihui',
                  data: {
                    id: id,
                    tel: wx.getStorageSync('tel')
                  },
                  method: 'post',
                  success: function (res) {
                    console.log(res)
                    if (res.data.info == 1) {
                      wx.showToast({
                        title: '恭喜，您的申请已提交成功',
                        duration: 2000,
                        icon: 'none'
                      })
                      setTimeout(function () {
                        wx.navigateBack({

                        })
                      }, 2000)
                    } else if (res.data.info == 2) {
                      wx.showToast({
                        title: '当前房源并未支付保证金',
                        duration: 2000,
                        icon: 'none'
                      })
                    } else if (res.data.info == 0) {
                      wx.showToast({
                        title: '当前房源已申请退回保证金，不可重复申请',
                        duration: 2000,
                        icon: 'none'
                      })
                    }
                  }
                })
              }
            },
          })
        }
      }
    })
  },
  checkboxChange_wz1: function(e) {
    var that = this
    console.log('checkboxChange_wz1发生change事件，携带value值为：', e.detail.value[0])
    that.setData({
      xieyi: e.detail.value[0]
    })
  },
  close: function(e) {
    var that = this
    that.setData({
      xianshi: 2
    })
  },
  zhifu: function(e) {
    var that = this
    var id = e.currentTarget.dataset.id
    var xieyi = that.data.xieyi
    if (xieyi == 1) {
      wx.request({
        url: app.globalData.url + 'api/fabu/check_baozheng',
        data: {
          id: id
        },
        method: 'post',
        success: function(ui) {
          console.log(ui)
          if (ui.data.info == 1) {
            wx.showToast({
              title: '该房源已经支付过保证金',
              duration: 2000,
              icon: 'none'
            })
          } else if (ui.data.info == 0) {
            wx.request({
              url: app.globalData.url + 'api/fabu/baozheng',
              success: function(res) {
                console.log(res)
                wx.request({
                  url: app.globalData.url + 'api/zhifu/payOrder',
                  data: {
                    openid: wx.getStorageSync('openid'),
                    total_fee: res.data.money
                  },
                  method: 'post',
                  success: function(rag) {
                    console.log(rag)
                    wx.requestPayment({
                      'timeStamp': rag.data.timeStamp,
                      'nonceStr': rag.data.nonceStr,
                      'package': rag.data.package,
                      'signType': rag.data.signType,
                      'paySign': rag.data.paySign,
                      'success': function(ras) {
                        wx.request({
                          url: app.globalData.url + 'api/fabu/save_baozheng',
                          data: {
                            id: id,
                            bz_status: 1,
                            tel: wx.getStorageSync('tel')
                          },
                          method: 'post',
                          success: function(rad) {
                            console.log(rad)
                            if (rad.data.info == 1) {
                              wx.showToast({
                                title: '恭喜担保成功',
                                duration: 2000,
                                icon: 'none'
                              })
                              that.setData({
                                xianshi: 2
                              })
                              that.reload()
                            }
                          }
                        })
                      },
                      'fail': function(ras) {

                      }
                    })
                  }
                })
              }
            })
          }
        }
      })
    } else {
      wx.showToast({
        title: '请阅读并同意房源推广服务协议',
        duration: 2000,
        icon: 'none'
      })
    }
  },
  reload: function() {
    var that = this
    var tel = wx.getStorageSync('tel')
    var dedao = app.globalData.dedao
    console.log(dedao)
    if (dedao == 0) {
      wx.setNavigationBarTitle({
        title: '我的发布',
      })
      var tel = wx.getStorageSync('tel')
      wx.request({
        url: app.globalData.url + 'api/my/fabu_list',
        data: {
          tel: tel
        },
        method: 'post',
        success: function(res) {
          console.log(res)
          that.setData({
            plist: res.data.plist,
            plist1: res.data.plist1,
            url: app.globalData.url,
            user: res.data.user,
            gongyu_num: res.data.gongyu_num,
            fenxiang: res.data.fenxiang.picurl,
            tui_tishi: res.data.tui_tishi
          })
        }
      })
    } else if (dedao == 1) {
      wx.setNavigationBarTitle({
        title: '门店管理',
      })
      var tel = wx.getStorageSync('tel')
      wx.request({
        url: app.globalData.url + 'api/my/gongyu_list',
        data: {
          tel: tel
        },
        method: 'post',

        success: function(res) {
          console.log(res)
          var arr = []
          if (res.data.info != null) {
            for (var i = 0; i < res.data.info.length; i++) {
              var arr = arr.concat(res.data.info[i].type)
            }
            console.log(arr)
            var arr2 = []
            var arr1 = res.data.user.gongyu.split(",")
            for (var s = 0; s < arr1.length; s++) {
              var arr2 = arr2.concat(parseInt(arr1[s]))
            }
            console.log(arr2)
            for (var o = 0; o < arr.length; o++) {
              // console.log(arr.includes(arr2[o]))
              if (arr2.includes(arr[o])) {
                res.data.info[o].you = 1
              } else {
                res.data.info[o].you = 0
              }
            }
          }
          that.setData({
            list: res.data.info,
            url: app.globalData.url,
            type: res.data.type,
            user: res.data.user,
            gongyu_num: res.data.gongyu_num,
            fenxiang: res.data.fenxiang.picurl,
          })
        }
      })
    } else if (dedao == 2) {
      wx.setNavigationBarTitle({
        title: '公寓管理',
      })

      var tel = wx.getStorageSync('tel')
      wx.request({
        url: app.globalData.url + 'api/my/gongyu_list1',
        data: {
          tel: tel
        },
        method: 'post',
        success: function(res) {
          console.log(res)

          var arr = res.data.user.gongyu.split(",")

          that.setData({
            list: res.data.info,
            url: app.globalData.url,
            type: res.data.type,
            user: res.data.user,
            fenxiang: res.data.fenxiang.picurl,

            num: arr.length
          })
        }
      })
    }
  },
  onShow: function(e){
    var that = this
    that.reload()
  },
  onShareAppMessage: function(e) {
    console.log(e)
    var that = this
    if (e.from == 'menu') {
      return {
        title: app.globalData.fenxiang1,
        path: '/pages/index/index',
        imageUrl: app.globalData.url + that.data.fenxiang,
        success: function(shareTickets) {
          console.info(shareTickets + '成功');
          // 转发成功
        },
        fail: function(res) {
          console.log(res + '失败');
          // 转发失败
        },
        complete: function(res) {
          // 不管成功失败都会执行
        }
      }
    }
  },
  // onUnload: function() {
  //   wx.reLaunch({
  //     url: '../my/my'
  //   })
  // },
})