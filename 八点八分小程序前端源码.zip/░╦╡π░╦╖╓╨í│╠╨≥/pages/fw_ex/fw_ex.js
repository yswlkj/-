const app = getApp()
Page({
  data: {

  },
  onLoad: function (e) {
    var that = this
    var tel = wx.getStorageSync('tel')
    wx.setNavigationBarTitle({
      title: '评论内容',
    })
    var id = e.id
    wx.request({
      url: app.globalData.url + 'api/xitong/pj_show',
      data:{
        id: id,
        url: app.globalData.url,
        lng: app.globalData.lng,
        lat: app.globalData.lat
      },
      method: 'post',
      success: function(res){
        console.log(res)
        that.setData({
          info: res.data.info,
          f_info: res.data.f_info,
          url: app.globalData.url,
          pinpai: app.globalData.pinpai,
          wei: app.globalData.wei,
          bao: app.globalData.bao,
          youxuan: app.globalData.youxuan,
          pinpai1: app.globalData.pinpai1,
          wei1: app.globalData.wei1,
          bao1: app.globalData.bao1,
          youxuan1: app.globalData.youxuan1,
          gengxin: app.globalData.gengxin
        })
      }
    })
  },
})