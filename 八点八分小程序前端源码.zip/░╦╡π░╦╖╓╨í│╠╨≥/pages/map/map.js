var QQMapWX = require('../../utils/qqmap-wx-jssdk.js');
var qqmapsdk = new QQMapWX({
  key: 'I4CBZ-FYL6G-X2LQD-I56ON-N6K7E-UQFK4' // 必填
});
const app = getApp()
Page({

  /**
   * 页面的初始数据
   */
  data: {

  },

  /**
   * 生命周期函数--监听页面加载
   */
  getLocate(latitude, longitude) {
    var that = this;
    wx.request({
      url: 'https://apis.map.qq.com/ws/geocoder/v1/?location=' + latitude + ',' + longitude + '&key=I4CBZ-FYL6G-X2LQD-I56ON-N6K7E-UQFK4',
      success: function (res) {
        console.log(res)
        var val = res.data.result.address_component.city
        // if (val.indexOf('市') !== -1) {//这里是去掉“市”这个字
        //   val = val.slice(0, val.indexOf('市'));
        // }
        that.setData({
          locateCity: val
        });
      },
    })
  },
  onLoad: function (options) {
    var that = this
    wx.setNavigationBarTitle({
      title: '选择位置',
    })
    
    that.moveToLocation();
  },

  dizhi: function () {
    var that = this
    console.log('有经纬度')
    console.log(that.data.lng, that.data.lat)
    that.setData({
      longitude: that.data.lng,
      latitude: that.data.lat,
      zt: 0,
      markers: [{
        longitude: that.data.lng,
        latitude: that.data.lat,
        label: {
          bgColor: '#fff',
          anchorX: -60,
          anchorY: 10,
          padding: 5,
          borderRadius: 5,
        },
      }],
    })
  },
  backfill: function (e) {
    console.log(1)
    var that = this
    var id = e.currentTarget.id;
    for (var i = 0; i < that.data.suggestion.length; i++) {
      if (i == id) {
        app.globalData.xq_lng = that.data.suggestion[i].longitude
        app.globalData.xq_lat = that.data.suggestion[i].latitude
        app.globalData.xq_title = that.data.suggestion[i].title
        app.globalData.xq_address = that.data.suggestion[i].address
        that.setData({
          backfill: that.data.suggestion[i].title,
          longitude: that.data.suggestion[i].longitude,
          latitude: that.data.suggestion[i].latitude,
          markers: [{
            longitude: that.data.suggestion[i].longitude,
            latitude: that.data.suggestion[i].latitude,
            label: {
              bgColor: '#fff',
              anchorX: -60,
              anchorY: 10,
              padding: 5,
              borderRadius: 5,
            },
          }],
          zt: 0
        });
      }
    }
  },
  area: function (e) {
    console.log(1)
    var that = this
    that.setData({
      area: e.detail.value
    });
    wx.request({
      url: 'https://apis.map.qq.com/ws/geocoder/v1/',
      data: {
        "key": 'I4CBZ-FYL6G-X2LQD-I56ON-N6K7E-UQFK4',
        "address": that.data.area
      },
      method: 'GET',
      success: function (res) {
        console.log(res)
        if (res.data.result) {
          var addressLocation = res.data.result.location;
          var courseLat = addressLocation.lat; //获取目的地的纬度
          var courseLng = addressLocation.lng; //获取目的地的经度
        }
        that.setData({
          courseLng: courseLng,
          courseLat: courseLat
        })
      }
    })
  },

  area: function (e) {
    // console.log(2)
    var _this = this;
    //调用关键词提示接口
    qqmapsdk.getSuggestion({
      //获取输入框值并设置keyword参数
      keyword: e.detail.value, //用户输入的关键词，可设置固定值,如keyword:'KFC'
      //region:'北京', //设置城市名，限制关键词所示的地域范围，非必填参数
      success: function (res) { //搜索成功后的回调
        console.log(res);
        var sug = [];
        for (var i = 0; i < res.data.length; i++) {
          sug.push({ // 获取返回结果，放到sug数组中
            title: res.data[i].title,
            id: res.data[i].id,
            addr: res.data[i].address,
            city: res.data[i].city,
            district: res.data[i].district,
            latitude: res.data[i].location.lat,
            longitude: res.data[i].location.lng
          });
        }
        _this.setData({ //设置suggestion属性，将关键词搜索结果以列表形式展示
          suggestion: sug,
          zt: 1
        });
      },
      fail: function (error) {
        // console.error(error);
      },
    });
    _this.setData({
      area: e.detail.value
    })
  },
  moveToLocation: function () {

    var that = this;

    wx.chooseLocation({

      success: function (res) {

        console.log(res);
        app.globalData.ss_xq_name = res.name
        app.globalData.ss_xq_latitude = res.latitude
        app.globalData.ss_sq_longitude = res.longitude
        app.globalData.ss_xq_latitude1 = res.latitude
        app.globalData.ss_sq_longitude1 = res.longitude
        app.globalData.ss_xq_addr = res.address
        wx.setStorageSync('addr', res.address)
        wx.setStorageSync('lat', res.latitude)
        wx.setStorageSync('lng', res.longitude)
        //选择地点之后返回的结果
        wx.navigateBack({
          
        })
      },

      fail: function (err) {

        console.log(err)
        
        
      }

    });

  }
})