// pages/nowrefresh/nowrefresh.js
const app = getApp()
// // import WxParse from '../../wxParse/wxParse.js';
Page({

  /**
   * 页面的初始数据
   */
  data: {

  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function(e) {
    var that = this
    var id = e.id
    var type = e.type
    app.globalData.red_id = id
    wx.setNavigationBarTitle({
      title: '推广刷新',
    })
    var tel = wx.getStorageSync('tel')
    wx.request({
      url: app.globalData.url + 'api/shuaxin/liji_show',
      data: {
        tel: tel,
        id:id
      },
      method: 'post',
      success: function(res) {
        // var content = res.data.content;
        // WxParse.wxParse('content', 'html', content, that, 5)
        app.globalData.s_num = res.data.num
        app.globalData.s_type = res.data.type
        console.log(res)
        that.setData({
          num: res.data.num,
          html: res.data.content,
          type: res.data.type,
          id: id,
          z_type: type
        })
      }
    })
  },
  submit: function(e) {
    var that = this
    var id = e.currentTarget.dataset.id
    var tel = wx.getStorageSync('tel')
    var num = app.globalData.s_num
    var type = app.globalData.s_type
    if (type == 0) {
      console.log('type == 0')
      if (num <= 0) {
        console.log('num <= 0')
        wx.showToast({
          title: '当前次数不足，请前往购买',
          duration: 2000,
          icon: 'none'
        })
        setTimeout(function(){
          wx.navigateTo({
            url: '../buyrefresh/buyrefresh?id='+that.data.id+'&type='+that.data.z_type,
          })
        },2000)
        return;
      } else if (num > 0) {
        console.log('num > 0')
        wx.request({
          url: app.globalData.url + 'api/shuaxin/liji_shua',
          data: {
            id: id,
            tel: tel
          },
          method: 'post',
          success: function(res) {
            console.log(res)
            if (res.data.info == 1 && res.data.info1 == 1) {
              wx.showToast({
                title: '刷新成功，正在跳转',
                duration: 2000,
                icon: 'none'
              })
              var num = that.data.num
              that.setData({
                num: num-1
              })
              setTimeout(function(){
                wx.navigateBack({
                  
                })
              },2000)
            } else if (res.data.info == 2 && res.data.info1 == 2) {
              wx.showToast({
                title: '当前求租贴已被刷新，请勿重复刷新',
                duration: 2000,
                icon: 'none'
              })
              return;
            }
          }
        })
      }
    } else if (type == 1) {
      console.log('type == 1')
      wx.request({
        url: app.globalData.url + 'api/shuaxin/liji_shua',
        data: {
          id: id,
          tel: tel
        },
        method: 'post',
        success: function(res) {
          console.log(res)
          if (res.data.info == 1 && res.data.info1 == 1) {
            wx.showToast({
              title: '刷新成功，正在跳转',
              duration: 2000,
              icon: 'none'
            })
            setTimeout(function () {
              wx.navigateBack({

              })
            }, 2000)
          } else if (res.data.info == 2 && res.data.info1 == 2) {
            wx.showToast({
              title: '当前求租贴已被刷新，请勿重复刷新',
              duration: 2000,
              icon: 'none'
            })
            return;
          }
        }
      })
    }
  },
  onShow: function() {
    var that = this
    var tel = wx.getStorageSync('tel')
    wx.request({
      url: app.globalData.url + 'api/shuaxin/liji_show',
      data: {
        tel: tel,
        id: app.globalData.red_id
      },
      method: 'post',
      success: function (res) {
        // var content = res.data.content;
        // WxParse.wxParse('content', 'html', content, that, 5)
        app.globalData.s_num = res.data.num
        app.globalData.s_type = res.data.type
        console.log(res)
        that.setData({
          num: res.data.num,
          type: res.data.type,
          id: app.globalData.red_id
        })
      }
    })
  },
})