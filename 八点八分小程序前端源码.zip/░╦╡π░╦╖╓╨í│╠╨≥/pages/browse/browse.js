const app = getApp()
Page({
  data: {
    yincang: true,
    yincang1: true,
    yincang2: true,
    shan_zt: 0,
    select_all: false,
    batchIds: [],
    batchIds1: [],
  },
  liubtn: function(e) {

    this.setData({
      yincang: false,
      yincang2: false,
      bottom: 0,
      shan_zt: 1
    })
  },
  liubtn1: function(e) {
    var that = this
    var tel = wx.getStorageSync('tel');
    wx.request({
      url: app.globalData.url + 'api/my/liulan',
      data: {
        tel: tel,
        url: app.globalData.url,
        lat: app.globalData.lat,
        lng: app.globalData.lng
      },
      method: 'post',
      success: function(res) {
        console.log(res)
        that.setData({
          p_list: res.data.plist,
          list: res.data.list,
          url: app.globalData.url,
        })
      }
    })
    that.setData({
      yincang: true,
      yincang2: true,
      bottom: 0,
      select_all: false,
      shan_zt: 0,
      batchIds: [],
      batchIds1: []
    })
  },
  quanxuan: function(e) {
    console.log(e)
    var that = this;
    var arr = [];
    for (let i = 0; i < that.data.p_list.length; i++) {
      for (var j = 0; j < that.data.p_list[i].info.length; j++) {
        that.data.p_list[i].info[j].checked = (!that.data.select_all)

        if (that.data.p_list[i].info[j].checked == true) {
          arr = arr.concat(that.data.p_list[i].info[j].l_id);
        }
      }
    }
    console.log(arr)
    
    that.setData({
      p_list: that.data.p_list,
      list: that.data.list,
      select_all: (!that.data.select_all),
      batchIds: arr,
      batchIds1:[],
    })
  },
  danxuan: function(e) {
    var that = this
    var type = e.currentTarget.dataset.type
    if (e.detail.value == '') {
      var id = e.currentTarget.dataset.id
      var type = e.currentTarget.dataset.type
      var batchIds = that.data.batchIds
      var batchIds1 = that.data.batchIds1
      if (type == 0) {
        var index = batchIds.indexOf(id)
        batchIds.splice(index, 1);
      } else if (type == 1) {
        var index = batchIds1.indexOf(id)
        batchIds1.splice(index, 1);
      }
      that.setData({
        select_all: false,
        batchIds: batchIds,
        batchIds1: batchIds1
      })
    } else {
      if (type == 0) {
        if (that.data.batchIds.includes(parseInt(e.detail.value))) {
          that.setData({
            select_all: true
          })
        } else {
          var batchIds = []
          var batchIds = that.data.batchIds.concat(parseInt(e.detail.value))
          that.setData({
            batchIds: batchIds
          })
        }
      } else if (type == 1) {
        if (that.data.batchIds1.includes(parseInt(e.detail.value))) {
          that.setData({
            select_all: true
          })
        } else {
          var batchIds1 = []
          var batchIds1 = that.data.batchIds1.concat(parseInt(e.detail.value))

          that.setData({
            batchIds1: batchIds1
          })
        }
      }
      var batchIds1 = that.data.batchIds1
      var batchIds = that.data.batchIds
      if ((batchIds.length + batchIds1.length) == (that.data.zong.length + that.data.zong1.length)) {
        that.setData({
          select_all: true
        })
      } else {
        console.log(that.data.zong.length + that.data.zong1.length)
        console.log('不相等')
      }
    }

  },
  tiao: function(e) {
    var that = this
    wx.navigateTo({
      url: '../home_ex/home_ex?id=' + e.currentTarget.dataset.id,
    })
  },
  tishi: function(e) {
    var that = this
    wx.showToast({
      title: '当前房源已下架',
      duration: 2000,
      icon: 'none',
      mask: true
    })
  },
  onLoad: function(e) {
    var that = this
    wx.setNavigationBarTitle({
      title: '浏览记录',
    })
    var tel = wx.getStorageSync('tel');
    wx.request({
      url: app.globalData.url + 'api/my/liulan',
      data: {
        tel: tel,
        url: app.globalData.url,
        lat: app.globalData.lat,
        lng: app.globalData.lng
      },
      method: 'post',
      success: function(res) {
        console.log(res)
        var arr = []
        var arr1 = []
        if (res.data.plist) {
          for (let i = 0; i < res.data.plist.length; i++) {
            for (var j = 0; j < res.data.plist[i].info.length; j++) {
              var arr = arr.concat(res.data.plist[i].info[j].id);
            }
          }
        }
        if (res.data.list) {
          for (let a = 0; a < res.data.list.length; a++) {
            for (var b = 0; b < res.data.list[a].info.length; b++) {
              var arr1 = arr1.concat(res.data.list[a].info[b].id);
            }
          }
        }
        that.setData({
          p_list: res.data.plist,
          list: res.data.list,
          url: app.globalData.url,
          zong: arr,
          zong1: arr1,
          pinpai: app.globalData.pinpai,
          wei: app.globalData.wei,
          bao: app.globalData.bao,
          youxuan: app.globalData.youxuan,
          pinpai1: app.globalData.pinpai1,
          wei1: app.globalData.wei1,
          bao1: app.globalData.bao1,
          youxuan1: app.globalData.youxuan1,
          gengxin: app.globalData.gengxin
        })
      }
    })

  },
  shan: function(e) {
    var that = this
    if (that.data.batchIds.length == 0 && that.data.batchIds1.length == 0) {
      wx.showToast({
        title: '请选择需要删除的房源或求租贴',
        duration: 2000,
        icon: 'none',
        mask: true
      })
      return;
    }
    var fid = that.data.batchIds.toString()
    var qid = that.data.batchIds1.toString()
    wx.showModal({
      title: '提示',
      content: '删除后将无法恢复,确定继续删除吗?',
      cancelText: '取消',
      confirmText: '继续',
      success(res) {
        if (res.cancel) {
        } else if (res.confirm) {
          wx.request({
            url: app.globalData.url + 'api/my/liulanshan',
            data: {
              tel: wx.getStorageSync('tel'),
              fid: fid,
              qid: qid
            },
            method: 'post',
            success: function(rag) {
              console.log(rag)
              wx.showToast({
                title: '删除成功',
                duration: 2000,
                icon: 'none',
                mask: true
              })
              that.onLoad()
              that.setData({
                type: 1,
                batchIds: [],
                batchIds1: [],
                shan_zt: 0,
                select_all: false,
                yincang: true,
                yincang2: true,
              })
            }
          })
        }
      }
    })
  },
})