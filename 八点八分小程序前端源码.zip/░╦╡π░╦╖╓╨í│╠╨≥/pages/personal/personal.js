// pages/personal/personal.js
const app = getApp()
Page({

  /**
   * 页面的初始数据
   */
  data: {
    countryList: ['未选择', '男', '女'],
    countryIndex: 0,
    type: 0,
    countryList1: ['IT', 'IT'],
    countryIndex1: 0,
    countryList2: ['11', '11IT'],
    countryIndex2: 0,
    default: '请选择兴趣爱好',
    default1: '请选择职业',
    // date: '2018-10-01',
    isChecked2: true,
    f_type: 0,
    f_typeid: 0,
    f_status: 0
  },

  changeDate(e) {
    app.globalData.birthday = e.detail.value
    this.setData({
      date: e.detail.value
    });
  },
  changeCountry(e) {
    var that = this
    app.globalData.sex = e.detail.value
    console.log(app.globalData.sex)
    that.setData({
      countryIndex: e.detail.value
    });
  },
  changeCountry1(e) {
    var that = this

    console.log('picker发送选择改变，携带值为', e.detail.value)
    var zhiye = that.data.zhiye
    var index = e.detail.value
    app.globalData.zhiye = zhiye[e.detail.value]

    that.setData({
      index,

      default1: zhiye[index],
      // user.zhiye: zhiye[index]
    })
  },
  changeCountry2(e) {
    var that = this

    console.log('picker发送选择改变，携带值为', e.detail.value)
    var aihao = that.data.aihao
    var index = e.detail.value
    app.globalData.aihao = aihao[e.detail.value]
    that.setData({
      index,
      default: aihao[index]
    })
    // that.setData({ countryIndex2: e.detail.value });
  },
  jianjie: function (e) {
    var that = this
    var jianjie = e.detail.value
    
      that.setData({
        jianjie: e.detail.value,
        type: 0
      })
    
  },
  submit1: function (e) {
    var that = this
    wx.showToast({
      title: '请填写完整',
      duration: 2000,
      icon: 'none'
    })
  },
  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (e) {
    var that = this
    wx.setNavigationBarTitle({
      title: '个人中心',
    })
    var openid = wx.getStorageSync('openid')
    var tel = wx.getStorageSync('tel')
    that.setData({
      tiaozhuan: e.tiaozhuan
    })
    if (e.f_status) {
      that.setData({
        f_status: e.f_status
      })
    }
    if (e.f_type) {
      that.setData({
        f_type: e.f_type
      })
    }
    if (e.f_typeid) {
      that.setData({
        f_typeid: e.f_typeid
      })
    }
    if (e.type_id) {
      that.setData({
        type_id: e.type_id
      })
    }
    if (e.type) {
      that.setData({
        type2: e.type
      })
    }
    app.globalData.tiaozhuan = e.tiaozhuan
    wx.request({
      url: app.globalData.url + 'api/my/show',
      data: {
        tel: tel,
        openid: openid,
        url: app.globalData.url
      },
      method: 'post',
      success: function (res) {
        console.log(res)

        that.setData({
          user: res.data.user,
          date: res.data.date,
          default1: res.data.user.zhiye,
          default: res.data.user.hobby,
          aihao: res.data.aihao,
          zhiye: res.data.zhiye,
          ewmImg: res.data.user.picurl,
          time: res.data.time,
          countryIndex: res.data.user.sex,
          geren_fd_yanzheng: res.data.geren_fd_yanzheng,
          zhiye_fd_yanzheng: res.data.zhiye_fd_yanzheng,
          name: res.data.user.name,
          jianjie: res.data.user.jianjie,
          wechat: res.data.user.wechat
        })
      }
    })
    that.setData({
      zt: e.zt
    })
  },
  changeSwitch2: function (e) {
    var that = this
    console.log(e)
    if (e.detail.value == true) {
      app.globalData.y_status = 0
      wx.showModal({
        title: '提示',
        content: '开启隐藏手机号，则发布的求租贴手机号不对外展示，谢谢。',
        showCancel: false, //是否显示取消按钮
        confirmText: "我知道了", //默认是“确定”
        success: function (res) {
          if (res.cancel) {
            //点击取消,默认隐藏弹框
          } else {
            wx.request({
              url: app.globalData.url + 'api/my/update_yin',
              data: {
                tel: wx.getStorageSync('tel'),
                yin: app.globalData.y_status
              },
              method: 'post',
              success: function (res) {
                console.log(res)
                if (res.data.info == 1) {
                  wx.showToast({
                    title: '设置成功',
                    duration: 2000,
                    icon: 'none'
                  })
                }
              }
            })
            //点击确定
          }
        },

      })
    } else if (e.detail.value == false) {
      app.globalData.y_status = 1
      wx.request({
        url: app.globalData.url + 'api/my/update_yin',
        data: {
          tel: wx.getStorageSync('tel'),
          yin: app.globalData.y_status
        },
        method: 'post',
        success: function (res) {
          console.log(res)
          if (res.data.info == 1) {
            wx.showToast({
              title: '设置成功',
              duration: 2000,
              icon: 'none'
            })
          }
        }
      })
    }
  },
  upload: function () {
    let that = this;
    app.globalData.pictures = []
    wx.chooseImage({
      count: 1, // 默认9
      sizeType: ['original', 'compressed'], // 可以指定是原图还是压缩图，默认二者都有
      sourceType: ['album', 'camera'], // 可以指定来源是相册还是相机，默认二者都有
      success: res => {
        wx.showToast({
          title: '正在上传...',
          icon: 'loading',
          mask: true,
          duration: 1000
        })
        // 返回选定照片的本地文件路径列表，tempFilePath可以作为img标签的src属性显示图片
        app.globalData.touxiang = app.globalData.touxiang.concat(res.tempFilePaths)
        console.log(app.globalData.touxiang)
        that.uploadimg();
        let tempFilePaths = res.tempFilePaths;
        that.setData({
          ewmImg: tempFilePaths
        })
      }
    })
  },
  aaa: function (e) {
    var that = this
    // console.log(app.globalData.zt)
    var imgs = app.globalData.touxiang;
    // console.log(code1)
    var index = e.currentTarget.dataset.index;
    imgs.splice(index, 1);
    app.globalData.touxiang = imgs
    that.setData({
      ewmImg: imgs,
    });
  },
  uploadimg: function () { //这里触发图片上传的方法
    var pics = app.globalData.touxiang
    for (var i = 0; i < pics.length; i++) {
      wx.uploadFile({
        url: app.globalData.url + 'api/my/img',
        filePath: pics[i],
        name: 'file',
        success: function (res) {
          //打印
          // console.log(res)
          app.globalData.touxiang1 = res.data
          console.log(app.globalData.touxiang1)
        }
      })
    }
  },
  name: function (e) {
    var that = this
    that.setData({
      name: e.detail.value
    })
  },
  // aihao: function (e) {
  //   var that = this
  //   that.setData({
  //     aihao: e.detail.value
  //   })
  // },
  wechat: function (e) {
    var that = this
    that.setData({
      wechat: e.detail.value
    })
  },
  submit: function (e) {
    var that = this
    that.setData({
      type: 1
    })
    var name1 = that.data.name
    if (!name1) {
      wx.showToast({
        title: '请输入昵称',
        duration: 2000,
        icon:'none',
        mask: true
      })
      that.setData({
        type: 0
      })
      return;
    } else {
      var name = name1
    }
    var pic1 = app.globalData.touxiang1
    if (!pic1) {
      var pic2 = that.data.user.picurl
      if (!pic2) {
        wx.showToast({
          title: '请添加头像',
          duration: 2000,
          icon: 'none',
          mask: true
        })
        that.setData({
          type: 0
        })
        return;
      }
      var pic = that.data.user.picurl1
    } else {
      var pic = app.globalData.touxiang1
    }
    // timestamp = timestamp / 1000;
    var time1 = app.globalData.birthday
    if (!time1) {
      if (that.data.user.birth == null) {
        var time = that.data.date
      } else {
        var time = that.data.user.birth
      }
    } else {
      var time = time1
    }
    var sex1 = app.globalData.sex
    if (!sex1) {
      var sex = that.data.user.sex
      if (sex == 0) {
        wx.showToast({
          title: '请选择性别',
          duration: 2000,
          icon: 'none'
        })
        that.setData({
          type: 0
        })
        return;
      }
    } else {
      if (sex1 == 0) {
        wx.showToast({
          title: '请选择性别',
          duration: 2000,
          icon: 'none'
        })
        that.setData({
          type: 0
        })
        return;
      } else {
        var sex = sex1
      }
    }
    var wechat = that.data.wechat
    // var wechat1 = that.data.user.wechat
    if (!wechat) {
      wx.showToast({
        title: '请填写微信号',
        duration: 2000,
        icon: 'none',
        mask:true
      })
      that.setData({
        type: 0
      })
      return;
    }else{
      if(wechat.length < 9){
        wx.showToast({
          title: '微信号格式错误',
          duration: 2000,
          icon: 'none',
          mask:true
        })
        that.setData({
          type: 0
        })
        return;
      }
    }
    var jianjie = that.data.jianjie
    if (!jianjie) {
      var jianjie2 = ''
    } else {
      var jianjie2 = jianjie

    }
    // console.log(1)
    // return;
    var hobby = app.globalData.aihao
    var hobby1 = that.data.user.hobby
    console.log(hobby1)
    if (hobby === undefined && !hobby1) {
      wx.showToast({
        title: '请选择兴趣爱好',
        duration: 2000,
        icon: 'none'
      })
      that.setData({
        type: 0
      })
      return;
    } else {
      if (hobby === undefined) {
        var hobby2 = hobby1
      } else {
        var hobby2 = hobby
      }
    }
    var zhiye = app.globalData.zhiye
    var zhiye1 = that.data.user.zhiye
    if (zhiye === undefined && !zhiye1) {
      wx.showToast({
        title: '请选择职业',
        duration: 2000,
        icon: 'none'
      })
      that.setData({
        type: 0
      })
      return;
    } else {
      if (zhiye === undefined) {
        var zhiye2 = zhiye1
      } else {
        var zhiye2 = zhiye
      }
    }
    var yin1 = app.globalData.y_status
    console.log(yin1)
    if (yin1 === undefined) {
      var yin = yin1
    } else {
      var yin = yin1
    }
    var tel = wx.getStorageSync('tel')
    var openid = wx.getStorageSync('openid')
    wx.request({
      url: app.globalData.url + 'api/my/check_name_jianjie',
      data: {
        name: name,
        jianjie: jianjie2
      },
      method: 'post',
      success: function (rag) {
        console.log(rag)
        if (rag.data.info != 1) {
          wx.showToast({
            title: '昵称中存在敏感词，请重新输入',
            duration: 2000,
            icon: 'none',
            mask: true
          })
          return
        } else if (rag.data.info1 != 1) {
          wx.showToast({
            title: '简介中存在敏感词，请重新输入',
            duration: 2000,
            icon: 'none',
            mask: true
          })
          return
        } else if (rag.data.info == 1 && rag.data.info1 == 1) {
          wx.request({
            url: app.globalData.url + 'api/my/save',
            data: {
              name: name,
              pic: pic,
              time: time,
              sex: sex,
              wechat: wechat,
              yin: yin,
              zhiye: zhiye2,
              hobby: hobby2,
              jianjie: jianjie2,
              tel: tel,
              openid: openid,
              url: app.globalData.url
            },
            method: 'post',
            success: function (res) {
              console.log(res)
              if (res.data.update == 1 || res.data.update == 0) {
                wx.showToast({
                  title: '提交成功',
                  duration: 2000,
                  icon: 'none',
                  mask: true
                })
                setTimeout(function () {
                  if (that.data.zt == 1) {
                    if (that.data.tiaozhuan == 0) {
                      wx.reLaunch({
                        url: '../rlease/rlease',
                      })
                    } else if (that.data.tiaozhuan == 1) {
                      if(that.data.f_status == 0){
                        wx.redirectTo({
                          url: '../rleaseone/rleaseone?type_id=' + that.data.f_typeid + '&type=' + that.data.f_type,
                        })
                      }else{
                        wx.redirectTo({
                          url: '../rlease_post/rlease_post?zt=' + that.data.f_type
                        })
                      }
                    } else if (that.data.tiaozhuan == 2) {
                      wx.navigateBack({

                      })
                    }
                  } else if (that.data.zt == 2) {
                    if (that.data.tiaozhuan == 0) {
                      wx.reLaunch({
                        url: '../rlease/rlease',
                      })
                    } else if (that.data.tiaozhuan == 1) {
                      if(that.data.f_status == 0){
                        wx.redirectTo({
                          url: '../rleaseone/rleaseone?type_id=' + that.data.f_typeid + '&type=' + that.data.f_type,
                        })
                      }else{
                        wx.redirectTo({
                          url: '../rlease_post/rlease_post?zt=' + that.data.f_type
                        })
                      }
                    } else if (that.data.tiaozhuan == 2) {
                      wx.navigateBack({
                        
                      })
                    }
                  } else if (that.data.zt == 3) {
                    if (that.data.tiaozhuan == 0) {
                      wx.reLaunch({
                        url: '../rlease/rlease',
                      })
                    } else if (that.data.tiaozhuan == 1) {
                      if(that.data.f_status == 0){
                        wx.redirectTo({
                          url: '../rleaseone/rleaseone?type_id=' + that.data.f_typeid + '&type=' + that.data.f_type,
                        })
                      }else{
                        wx.redirectTo({
                          url: '../rlease_post/rlease_post?zt=' + that.data.f_type
                        })
                      }
                    } else if (that.data.tiaozhuan == 2) {
                      wx.navigateBack({
                        // zt=2&f_status=0&f_type=1&f_typeid=13&tiaozhuan=1
                      })
                    }
                  } else if (that.data.zt == 0) {
                    wx.request({
                      url: app.globalData.url + 'api/my/mendian_check',
                      data: {
                        tel: wx.getStorageSync('tel')
                      },
                      method: 'post',
                      success: function (rag) {
                        console.log(rag)
                        if (rag.data.info == 1) {
                          setTimeout(function () {
                            wx.navigateTo({
                              url: '../rleaseone/rleaseone?type_id=' + that.data.f_typeid + '&type=' + that.data.f_type,
                            })
                          }, 2000)
                        } else if (rag.data.info == 0) {
                          wx.showToast({
                            title: '正在前往填写公寓信息',
                            duration: 2000,
                            icon: 'none',
                            mask: true
                          })
                          setTimeout(function () {
                            wx.navigateTo({
                              url: '../gongyu/gongyu',
                            })
                          }, 2000)
                        }
                      }
                    })
                  }
                }, 2000)

              }
            }
          })
        }
      }
    })

  },
})