const app = getApp()
Page({
  data: {
    canIUseGetUserProfile: false,
    width: wx.getSystemInfoSync().windowWidth - 30.5, //图片宽度  
    height: wx.getSystemInfoSync().windowWidth * 8 / 15, //图片高度
  },
  //事件处理函数
  bindViewTap: function () {
    wx.navigateTo({
      url: '../logs/logs'
    })
  },
  key: function (e) {
    var that = this
    that.setData({
      key: e.detail.value
    })
  },
  tiaotiao: function (e) {
    var that = this
    var type = e.currentTarget.dataset.type
    wx.navigateTo({
      url: '../choise/choise?id=0&type=' + type,
    })
  },
  sousuo: function (e) {
    var that = this
    var key = that.data.key
    if (!key) {
      wx.showToast({
        title: '请输入关键字',
        duration: 2000,
        icon: 'none'
      })
      return;
    }

    wx.navigateTo({
      url: '../home/home?key=' + key,
    })

  },
  onLoad: function (e) {
    var that = this
    var uid = e.uid
    if (wx.getUserProfile) {
      that.setData({
        canIUseGetUserProfile: true
      })
    }
    // var str = undefined
    // console.log(str.length)
    if (uid) {
      wx.setStorageSync('uid', uid)
    } else {
      wx.setStorageSync('uid', 0)
    }
    console.log()
    if (app.globalData.chengshi == 0) {
      wx.getLocation({
        type: 'gcj02',
        altitude: true,
        success: function (res) {
          console.log("获取当前城市名...");
          console.log(res);
          if (res && res.longitude && res.latitude) {
            var longitude = res.longitude;
            var latitude = res.latitude;
            app.globalData.lng = longitude
            app.globalData.lat = latitude
            that.getLocate(latitude, longitude)

          } else {
            that.setData({
              city: '获取失败',
              addre: 1
            })
          }
        }
      })
    }

    if (wx.getStorageSync('tel')) {
      that.setData({
        login: 1
      })
    } else {
      that.setData({
        login: 0
      })
    }
    setTimeout(function () {
      that.login();
    }, 1000)
  },
  login: function () {
    var that = this
    console.log(app.globalData.city_code)
    wx.request({
      url: app.globalData.url + 'api/index/index',
      data: {
        url: app.globalData.url,
        tel: wx.getStorageSync('tel'),
        uid: wx.getStorageSync('uid'),
        city_code: app.globalData.city_code,
        lng: app.globalData.lng,
        lat: app.globalData.lat
      },
      method: 'post',
      success: function (res) {
        console.log(res)
        app.globalData.login_logo = app.globalData.url + res.data.login_logo
        app.globalData.tishi_logo = app.globalData.url + res.data.tishi_logo
        app.globalData.webname = res.data.web_name
        app.globalData.fenxiang = res.data.fenxiang.picurl
        wx.setNavigationBarTitle({
          title: app.globalData.webname,
        })
        app.globalData.youxuan = res.data.youxuan
        app.globalData.wei = res.data.wei
        app.globalData.bao = res.data.bao
        app.globalData.pinpai = res.data.pinpai
        app.globalData.youxuan1 = res.data.youxuan1
        app.globalData.wei1 = res.data.wei1
        app.globalData.bao1 = res.data.bao1
        app.globalData.pinpai1 = res.data.pinpai1
        app.globalData.gengxin = res.data.gengxin
        wx.setStorageSync('ip', res.data.ip)
        that.setData({
          banner: res.data.banner,
          url: app.globalData.url,
          mk_type: res.data.mk_type,
          count: res.data.count,
          tese: res.data.tese,
          gy: res.data.gy,

          pinpai: app.globalData.pinpai,
          wei: app.globalData.wei,
          bao: app.globalData.bao,
          youxuan: app.globalData.youxuan,
          pinpai1: app.globalData.pinpai1,
          wei1: app.globalData.wei1,
          bao1: app.globalData.bao1,
          youxuan1: app.globalData.youxuan1,
          remen: app.globalData.url + res.data.remen,
          yangguang_title: res.data.yangguang_info,
          mokuaifangyuan_title: res.data.mokuaifangyuan_info,
          tesetuijian_title: res.data.tesetuijian_info,
          pinpaigongyu_title: res.data.pinpaigongyu_info,
          remenxiaoqu_title: res.data.remenxiaoqu_info,
          tishi_logo: app.globalData.url + res.data.tishi_logo,
          diqu: res.data.diqu,
          gengxin: res.data.gengxin
        })
      }
    })

    var tel = wx.getStorageSync('tel')
    if (tel) {
      wx.request({
        url: app.globalData.url + 'api/index/login',
        data: {
          tel: wx.getStorageSync('tel')
        },
        method: 'post',
        success: function (res) {
          console.log(res)
        }
      })
    }
  },

  getUserInfo: function (e) {
    console.log(e)
    app.globalData.userInfo = e.detail.userInfo
    this.setData({
      userInfo: e.detail.userInfo,
      hasUserInfo: true
    })
  },
  getLocate(latitude, longitude) {
    var that = this;
    console.log(latitude, longitude)
    var locationString = latitude + "," + longitude;
    wx.request({
      url: 'https://apis.map.qq.com/ws/geocoder/v1/?location=',
      data: {
        "key": "I4CBZ-FYL6G-X2LQD-I56ON-N6K7E-UQFK4",
        "location": locationString
      },
      method: 'GET',
      success: function (res) {
        console.log(res)
        app.globalData.adcode = res.data.result.ad_info.adcode
        var citycode = res.data.result.ad_info.city_code
        that.setData({
          city_code: citycode.slice(3, 9)
        })
        wx.request({
          url: app.globalData.url + 'api/about/check_city',
          data: {
            id: that.data.city_code
          },
          method: 'post',
          success: function (res1) {
            console.log(res1)
            if (res1.data.status == 1) {
              console.log(that.data.city_code)
              if (!app.globalData.city_name || !app.globalData.city_code) {
                app.globalData.city_name = res.data.result.ad_info.city
                app.globalData.city_code = citycode.slice(3, 9)
                console.log(1)
              }

              var val = res.data.result.address_component.city

              if (app.globalData.locateCity) {
                console.log('有城市')
                var val = app.globalData.locateCity
              } else {
                console.log('没有城市')
                app.globalData.locateCity = val
              }
              that.setData({
                locateCity: val.replace('市', '')
              });
              wx.request({
                url: app.globalData.url + 'api/index/flist',
                data: {
                  city_code: app.globalData.city_code,
                  url: app.globalData.url,
                  lat: app.globalData.lat,
                  lng: app.globalData.lng
                },
                method: 'post',
                success: function (rag) {
                  console.log(rag)
                  that.setData({
                    p_list: rag.data.plist,
                    yg1: rag.data.yang.yg1
                  })
                }
              })
            } else {
              wx.showModal({
                title: '提示',
                content: res1.data.tishi,
                showCancel: false, //是否显示取消按钮
                confirmText: "我知道了", //默认是“确定”
                success: function (res) {
                  if (!app.globalData.city_name || !app.globalData.city_code) {
                    app.globalData.city_name = '上海'
                    app.globalData.city_code = '310000'
                    console.log(1)
                  }

                  var val = '上海'

                  if (app.globalData.locateCity) {
                    var val = app.globalData.locateCity
                  } else {
                    app.globalData.locateCity = val
                  }

                  that.setData({
                    locateCity: val.replace('市', '')
                  });
                  wx.request({
                    url: app.globalData.url + 'api/index/flist',
                    data: {
                      city_code: app.globalData.city_code,
                      url: app.globalData.url,
                      lat: app.globalData.lat,
                      lng: app.globalData.lng
                    },
                    method: 'post',
                    success: function (rag) {
                      console.log(rag)
                      that.setData({
                        p_list: rag.data.plist,
                        yg1: rag.data.yang.yg1
                      })
                    }
                  })
                },
              })
            }
          }
        })
      },
    })
  },
  onShow: function () {
    var that = this
    app.globalData.key = ''
    if (app.globalData.locateCity) {
      that.setData({
        locateCity: app.globalData.locateCity.replace('市', '')
      })
    }
    console.log(wx.getStorageSync('tel'))
    if (wx.getStorageSync('tel')) {
      wx.request({
        url: app.globalData.url + 'api/index/count_shu',
        data: {
          tel: wx.getStorageSync('tel')
        },
        method: 'post',
        success: function (res) {
          console.log(res)
          app.globalData.fenxiang1 = res.data.fenxiang1
          app.globalData.webname = res.data.web_name
          wx.setNavigationBarTitle({
            title: app.globalData.webname,
          })
          that.setData({
            yanggguang_title: res.data.yanggguang_info
          })
          console.log(app.globalData.locateCity)
          if (app.globalData.locateCity) {
            that.setData({
              locateCity: app.globalData.locateCity.replace('市', '')
            })
            console.log(app.globalData.lat, app.globalData.lng, app.globalData.city_code)
            wx.request({
              url: app.globalData.url + 'api/index/flist',
              data: {
                city_code: app.globalData.city_code,
                url: app.globalData.url,
                lat: app.globalData.lat,
                lng: app.globalData.lng
              },
              method: 'post',
              success: function (rag) {
                console.log(rag)
                that.setData({
                  p_list: rag.data.plist,
                  yg1: rag.data.yang.yg1
                })
              }
            })
          } else {
            that.setData({
              locateCity: '暂无'
            })
          }
          that.setData({
            count: res.data.count,
            mk_zt: res.data.mokuai,
            ts_zt: res.data.tese1,
            pp_zt: res.data.pp_zt,
            yang1: res.data.yang1,
            diqu: res.data.diqu

          })
        }
      })
    } else {
      wx.request({
        url: app.globalData.url + 'api/index/count_shu1',
        data: {
          tel: wx.getStorageSync('tel')
        },
        method: 'post',
        success: function (res) {
          console.log(res)
          that.setData({
            mk_zt: res.data.mokuai,
            ts_zt: res.data.tese1,
            pp_zt: res.data.pp_zt,
            yang1: res.data.yang1,
          })
        }
      })
    }
    wx.request({
      url: app.globalData.url + 'api/index/index',
      data: {
        url: app.globalData.url,
        tel: wx.getStorageSync('tel'),
        uid: wx.getStorageSync('uid'),
        city_code: app.globalData.city_code,
        lng: app.globalData.lng,
        lat: app.globalData.lat
      },
      method: 'post',
      success: function (res) {
        console.log(res)
        app.globalData.login_logo = app.globalData.url + res.data.login_logo
        app.globalData.tishi_logo = app.globalData.url + res.data.tishi_logo
        app.globalData.webname = res.data.web_name
        app.globalData.fenxiang = res.data.fenxiang.picurl
        wx.setNavigationBarTitle({
          title: app.globalData.webname,
        })
        app.globalData.youxuan = res.data.youxuan
        app.globalData.wei = res.data.wei
        app.globalData.bao = res.data.bao
        app.globalData.pinpai = res.data.pinpai
        app.globalData.youxuan1 = res.data.youxuan1
        app.globalData.wei1 = res.data.wei1
        app.globalData.bao1 = res.data.bao1
        app.globalData.pinpai1 = res.data.pinpai1
        wx.setStorageSync('ip', res.data.ip)
        that.setData({
          banner: res.data.banner,
          url: app.globalData.url,
          mk_type: res.data.mk_type,
          count: res.data.count,
          tese: res.data.tese,
          gy: res.data.gy,

          pinpai: app.globalData.pinpai,
          wei: app.globalData.wei,
          bao: app.globalData.bao,
          youxuan: app.globalData.youxuan,
          pinpai1: app.globalData.pinpai1,
          wei1: app.globalData.wei1,
          bao1: app.globalData.bao1,
          youxuan1: app.globalData.youxuan1,
          remen: app.globalData.url + res.data.remen,
          yangguang_title: res.data.yangguang_info,
          mokuaifangyuan_title: res.data.mokuaifangyuan_info,
          tesetuijian_title: res.data.tesetuijian_info,
          pinpaigongyu_title: res.data.pinpaigongyu_info,
          remenxiaoqu_title: res.data.remenxiaoqu_info,
          tishi_logo: app.globalData.url + res.data.tishi_logo,
          diqu: res.data.diqu
        })
      }
    })
    that.setData({
      key: ''
    })
    var tel = wx.getStorageSync('tel')
    wx.request({
      url: app.globalData.url + 'api/index/check_status',
      data: {
        tel: tel
      },
      method: 'post',
      success: function (res) {
        console.log(res)
        if (res.data.info == 0) {
          wx.showModal({
            title: '提示',
            content: '账号已停用',
            showCancel: false, //是否显示取消按钮

            confirmText: "我知道了", //默认是“确定”
            success: function (res) {
              if (res.cancel) {
                //点击取消,默认隐藏弹框
              } else {
                console.log('封号')
                wx.removeStorageSync('tel')
                that.setData({
                  count: 0
                });
              }
            },
          })
        }
      }
    })
  },
  powerDrawer: function (e) {
    console.log(1)
    var currentStatu1 = e.currentTarget.dataset.statu;
    console.log(e)
    this.util(currentStatu1)
  },
  util: function (currentStatu1) {
    /* 动画部分 */
    // 第1步：创建动画实例
    var animation1 = wx.createAnimation({
      duration: 1, //动画时长
      timingFunction: "linear", //线性
      delay: 0 //0则不延迟
    });
    // 第2步：这个动画实例赋给当前的动画实例
    this.animation1 = animation1;
    // 第3步：执行第一组动画：Y轴偏移240px后(盒子高度是240px)，停
    animation1.translateX(240).step();
    // 第4步：导出动画对象赋给数据对象储存
    this.setData({
      animationData1: animation1.export()
    })
    // 第5步：设置定时器到指定时候后，执行第二组动画
    setTimeout(function () {
      // 执行第二组动画：Y轴不偏移，停
      animation1.translateX(0).step()
      // 给数据对象储存的第一组动画，更替为执行完第二组动画的动画对象
      this.setData({
        animationData1: animation1
      })
      //关闭抽屉
      if (currentStatu1 == "close") {
        this.setData({
          showModalStatus1: false
        });
      }
    }.bind(this), 1)
    // 显示抽屉
    if (currentStatu1 == "open") {
      this.setData({
        showModalStatus1: true
      });
    }
  },
  getUserProfile(e) {
    var that = this
    // 推荐使用wx.getUserProfile获取用户信息，开发者每次通过该接口获取用户个人信息均需用户确认
    // 开发者妥善保管用户快速填写的头像昵称，避免重复弹窗
    wx.getUserProfile({
      desc: '用于完善会员资料', // 声明获取用户个人信息后的用途，后续会展示在弹窗中，请谨慎填写
      success: (res) => {
        console.log(res)
        app.globalData.user_info = res.userInfo
        wx.login({
          success: res1 => {
            app.globalData.user_code = res1.code;
            wx.request({
              url: app.globalData.url + 'api/wechat/login',
              headers: {
                "Content-Type": "application/x-www-form-urlencoded"
              },
              data: {
                user_code: app.globalData.user_code,
                url: app.globalData.url,
                ip: wx.getStorageSync('ip')
              },
              method: 'POST',
              dataType: 'json',
              responseType: 'Text',
              success: function(res){
                console.log(res)
                var openid = res.data.info.openid
                var sessionkey = res.data.info.session_key
                wx.setStorageSync('sessionkey', sessionkey)
                wx.setStorageSync('openid', openid)
                wx.reLaunch({
                  url: '../login/login',
                })
              }
            })
          }
        })

        that.setData({
          userInfo: res.userInfo,
          hasUserInfo: true
        })
      }
    })
  },
  getUserInfo(e) {
    // 不推荐使用getUserInfo获取用户信息，预计自2021年4月13日起，getUserInfo将不再弹出弹窗，并直接返回匿名的用户个人信息
    this.setData({
      userInfo: e.detail.userInfo,
      hasUserInfo: true
    })
  },
  // getUserInfo(e) {
  //   // 把用户信息设置成全局变量
  //   console.log(e)
  //   var that = this
  //   if (e.detail.errMsg === 'getUserInfo:ok') {
  //     app.globalData.user_info = e.detail.userInfo
  //     // console.log(app.globalData.openid)
  //     console.log(app.globalData.user_info)
  //     wx.login({
  //       success: res => {
  //         app.globalData.user_code = res.code;
  //         // console.log(that.globalData.user_code)
  //         // 发送 res.code 到后台换取 openId, sessionKey, unionId
  //       }
  //     })
  //     app.globalData.iv = e.detail.iv
  //     app.globalData.encryptedData = e.detail.encryptedData
  //     app.globalData.errMsg = e.detail.errMsg
  //     wx.request({
  //       url: app.globalData.url + 'api/wechat/login',
  //       headers: {
  //         "Content-Type": "application/x-www-form-urlencoded"
  //       },
  //       data: {
  //         user_code: app.globalData.user_code,
  //         url: app.globalData.url,
  //         ip: wx.getStorageSync('ip')
  //       },
  //       method: 'POST',
  //       dataType: 'json',
  //       responseType: 'Text',
  //       success: function (res) {
  //         console.log(res)
  //         var openid = res.data.info.openid
  //         var sessionkey = res.data.info.session_key
  //         wx.setStorageSync('sessionkey', sessionkey)
  //         wx.setStorageSync('openid', openid)
  //         wx.reLaunch({
  //           url: '../login/login',
  //         })
  //       }
  //     })
  //     ///3.得到全局变量中的用户信息
  //     // console.log(app.globalData.user_code)
  //   } else if (e.detail.errMsg === 'getUserInfo:fail auth deny') {
  //     wx.showToast({
  //       title: '取消授权将无法正常使用小程序',
  //       icon: 'none',
  //       duration: 5000
  //     })
  //     that.setData({
  //       warning: false,
  //     })
  //   }
  // },
  onReady: function () {

  },
  onShareAppMessage: function (e) {
    console.log(e)
    var that = this
    if (e.from == 'menu') {
      return {
        title: app.globalData.fenxiang1,
        path: '/pages/index/index',
        imageUrl: app.globalData.url + app.globalData.fenxiang,
        success: function (shareTickets) {
          console.info(shareTickets + '成功');
          // 转发成功
        },
        fail: function (res) {
          console.log(res + '失败');
          // 转发失败
        },
        complete: function (res) {
          // 不管成功失败都会执行
        }
      }
    }
  }
})