// pages/modular/modular.js
const app = getApp()
Page({

  /**
   * 页面的初始数据
   */
  data: {

  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    var that = this
    wx.setNavigationBarTitle({
      title: '模块房源',
    })
    wx.request({
      url: app.globalData.url + 'api/mokuai/index',
      success: function(res){
        console.log(res)
        that.setData({
          mk_type: res.data.mk_type,
          url: app.globalData.url
        })
      }
    })
  },
})