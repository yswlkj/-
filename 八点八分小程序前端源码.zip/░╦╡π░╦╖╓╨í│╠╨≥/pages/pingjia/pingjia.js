// pages/customer/customer.js
const app = getApp()
Page({

  /**
   * 页面的初始数据
   */
  data: {
    canIUseGetUserProfile: false,
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (e) {
    var that = this
    wx.setNavigationBarTitle({
      title: '评论',
    })
    if (wx.getUserProfile) {
      that.setData({
        canIUseGetUserProfile: true
      })
    }
    wx.request({
      url: app.globalData.url + 'api/my/pj_list',
      data: {
        id: e.id,
        zt: e.zt,
        tel: wx.getStorageSync('tel'),
        url: app.globalData.url
      },
      method: 'post',
      success: function (res) {
        console.log(res)
        that.setData({
          list: res.data.list,
          user: res.data.user,
          info:res.data.info,
          fid: e.id,
          zt: e.zt,
          tel: wx.getStorageSync('tel'),
          tishi_logo: app.globalData.tishi_logo
        })
      }
    })
  },
  powerDrawer: function (e) {
    console.log(1)
    var currentStatu1 = e.currentTarget.dataset.statu;
    this.util(currentStatu1)
  },
  util: function (currentStatu1) {
    /* 动画部分 */
    // 第1步：创建动画实例
    var animation1 = wx.createAnimation({
      duration: 1, //动画时长
      timingFunction: "linear", //线性
      delay: 0 //0则不延迟
    });
    // 第2步：这个动画实例赋给当前的动画实例
    this.animation1 = animation1;
    // 第3步：执行第一组动画：Y轴偏移240px后(盒子高度是240px)，停
    animation1.translateX(240).step();
    // 第4步：导出动画对象赋给数据对象储存
    this.setData({
      animationData1: animation1.export()
    })
    // 第5步：设置定时器到指定时候后，执行第二组动画
    setTimeout(function () {
      // 执行第二组动画：Y轴不偏移，停
      animation1.translateX(0).step()
      // 给数据对象储存的第一组动画，更替为执行完第二组动画的动画对象
      this.setData({
        animationData1: animation1
      })
      //关闭抽屉
      if (currentStatu1 == "close") {
        this.setData(
          {
            showModalStatus1: false
          }
        );
      }
    }.bind(this), 1)
    // 显示抽屉
    if (currentStatu1 == "open") {
      this.setData(
        {
          showModalStatus1: true
        }
      );
    }
  },
  getUserProfile(e) {
    var that = this
    // 推荐使用wx.getUserProfile获取用户信息，开发者每次通过该接口获取用户个人信息均需用户确认
    // 开发者妥善保管用户快速填写的头像昵称，避免重复弹窗
    wx.getUserProfile({
      desc: '用于完善会员资料', // 声明获取用户个人信息后的用途，后续会展示在弹窗中，请谨慎填写
      success: (res) => {
        console.log(res)
        app.globalData.user_info = res.userInfo
        wx.login({
          success: res1 => {
            app.globalData.user_code = res1.code;
            wx.request({
              url: app.globalData.url + 'api/wechat/login',
              headers: {
                "Content-Type": "application/x-www-form-urlencoded"
              },
              data: {
                user_code: app.globalData.user_code,
                url: app.globalData.url,
                ip: wx.getStorageSync('ip')
              },
              method: 'POST',
              dataType: 'json',
              responseType: 'Text',
              success: function(res){
                console.log(res)
                var openid = res.data.info.openid
                var sessionkey = res.data.info.session_key
                wx.setStorageSync('sessionkey', sessionkey)
                wx.setStorageSync('openid', openid)
                wx.reLaunch({
                  url: '../login/login',
                })
              }
            })
          }
        })

        that.setData({
          userInfo: res.userInfo,
          hasUserInfo: true
        })
      }
    })
  },
  getUserInfo(e) {
    // 不推荐使用getUserInfo获取用户信息，预计自2021年4月13日起，getUserInfo将不再弹出弹窗，并直接返回匿名的用户个人信息
    this.setData({
      userInfo: e.detail.userInfo,
      hasUserInfo: true
    })
  },
  // getUserInfo(e) {
  //   // 把用户信息设置成全局变量
  //   console.log(e)
  //   var that = this
  //   if (e.detail.errMsg === 'getUserInfo:ok') {
  //     app.globalData.user_info = e.detail.userInfo
  //     // console.log(app.globalData.openid)
  //     console.log(app.globalData.user_info)
  //     wx.login({
  //       success: res => {
  //         app.globalData.user_code = res.code;
  //         // console.log(that.globalData.user_code)
  //         // 发送 res.code 到后台换取 openId, sessionKey, unionId
  //       }
  //     })
  //     app.globalData.iv = e.detail.iv
  //     app.globalData.encryptedData = e.detail.encryptedData
  //     app.globalData.errMsg = e.detail.errMsg
  //     wx.request({
  //       url: app.globalData.url + 'api/wechat/login',
  //       headers: {
  //         "Content-Type": "application/x-www-form-urlencoded"
  //       },
  //       data: {
  //         user_code: app.globalData.user_code,
  //         url: app.globalData.url,
  //         ip: wx.getStorageSync('ip')
  //       },
  //       method: 'POST',
  //       dataType: 'json',
  //       responseType: 'Text',
  //       success: function (res) {
  //         console.log(res)
  //         var openid = res.data.info.openid
  //         var sessionkey = res.data.info.session_key
  //         wx.setStorageSync('sessionkey', sessionkey)
  //         wx.setStorageSync('openid', openid)
  //         wx.reLaunch({
  //           url: '../login/login',
  //         })
  //       }
  //     })
  //     ///3.得到全局变量中的用户信息
  //     // console.log(app.globalData.user_code)
  //   } else if (e.detail.errMsg === 'getUserInfo:fail auth deny') {
  //     wx.showToast({
  //       title: '取消授权将无法正常使用小程序',
  //       icon: 'none',
  //       duration: 5000
  //     })
  //     that.setData({
  //       warning: false,
  //     })
  //   }
  // },
})