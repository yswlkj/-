const app = getApp()
Page({
  data: {

  },
  onLoad: function (e) {
    var that = this
    var tel = wx.getStorageSync('tel')
    var id = e.id
    wx.setNavigationBarTitle({
      title: '留言回复内容',
    })
    wx.request({
      url: app.globalData.url + 'api/xitong/pj_show3',
      data: {
        id: id,
        url: app.globalData.url,
        lng: app.globalData.lng,
        lat: app.globalData.lat,
        tel: tel
      },
      method: 'post',
      success: function (res) {
        console.log(res)
        if(res.data.f_info.lianxi == 0 && res.data.info.type == 0){
          var reg = /^(\d{3})\d{4}(\d{4})$/
          that.setData({
            // u_tel: res.data.f_info.u_tel.replace(reg, "$1****$2")
            u_tel: '已隐藏'
          })
        }else{
          that.setData({
            u_tel: res.data.f_info.u_tel
          })
        }
        that.setData({
          info: res.data.info,
          f_info: res.data.f_info,
          lianxi: res.data.f_info.lianxi,
          url: app.globalData.url,
          u_info: res.data.u_info,
          user_info: res.data.user_info,
          pinpai: app.globalData.pinpai,
          wei: app.globalData.wei,
          bao: app.globalData.bao,
          youxuan: app.globalData.youxuan,
          pinpai1: app.globalData.pinpai1,
          wei1: app.globalData.wei1,
          bao1: app.globalData.bao1,
          youxuan1: app.globalData.youxuan1,
          gengxin: app.globalData.gengxin
        })
      }
    })
  },
  
  call: function(e){
    var that = this
    var info = that.data.info
    var f_info = that.data.f_info
    if(info.type == 1){
      that.call_home(f_info.id)
    }else{
      that.call_qiu(f_info.id)
    }
  },
  call_home: function(id) {
    var that = this
    var id = id
    var tel = wx.getStorageSync('tel')
    wx.request({
      url: app.globalData.url + 'api/mokuai/phone_call',
      data: {
        id: id,
        tel: tel
      },
      method: 'post',
      success: function(res) {
        console.log(res)
        if (res.data.info == 0) {
          wx.showToast({
            title: '请勿联系自己',
            duration: 2000,
            icon: 'none',
            mask: true
          })
          return;
        } else if (res.data.info == 1) {
          wx.showModal({
            title: '提示',
            content: '联系我时请说明【租小圣租房】小程序上看到的～',
            showCancel: false,
            confirmText: "我知道了",
            success: function (rag) {
              if (rag.cancel) {
                //点击取消,默认隐藏弹框
              } else {
                //点击确定
                wx.makePhoneCall({
                  phoneNumber: res.data.info1.tel,
                })
              }
            },
          })
          
        }else if (res.data.info == 2) {
          wx.showToast({
            title: '当前房源的房东已隐藏手机号',
            duration: 2000,
            icon: 'none',
            mask: true
          })
          return;
        }
      }
    })
  },
  call_qiu: function(id) {
    var that = this
    var id = id
    var tel = wx.getStorageSync('tel')
    wx.request({
      url: app.globalData.url + 'api/about/qiu_check',
      data:{
        id: id,
        tel: wx.getStorageSync('tel')
      },
      method: 'post',
      success: function(rag){
        console.log(rag)
        if(rag.data.qiu_status == 1){
          wx.showToast({
            title: '请勿联系自己',
            duration: 2000,
            icon: 'none',
            mask: true
          })
          return;
        }else if(rag.data.qiu_status == 0){
          wx.request({
            url: app.globalData.url + 'api/yanzheng/qiuzu_lianxi',
            data: {
              fid: id,
              type: 1,
              tel: tel
            },
            method: 'post',
            success: function (res1) {
              console.log(res1)
              if (res1.data.count == 1) {
                wx.request({
                  url: app.globalData.url + 'api/qiuzu/dianhua1',
                  data: {
                    tel: tel,
                    id: id
                  },
                  method: 'post',
                  success: function (res) {
                    console.log(res)
                    if (res.data.info == 0) {
                      wx.showToast({
                        title: '请勿联系自己',
                        duration: 2000,
                        icon: 'none'
                      })
                      return;
                    } else if (res.data.info == 2) {
                      wx.showModal({
                        title: '提示',
                        content: '贴主已隐藏手机号',
                        showCancel: false, //是否显示取消按钮
                        confirmText: "知道了", //默认是“确定”
                        success: function (ras) {

                        },
                      })
                    } else if (res.data.info == 1) {
                      that.setData({
                        mobile1: res.data.info1.mobile
                      })
                      // console.log(that.data.mobile1)
                      wx.showModal({
                        title: '提示',
                        content: '联系我时请备注在【租小圣租房】小程序上看到的～',
                        showCancel: true, //是否显示取消按钮
                        confirmText: "确认拨打", //默认是“确定”
                        cancelText: "我再想想",
                        success: function (ras) {
                          if (ras.cancel) {
                            //点击取消,默认隐藏弹框
                          } else {
                            //点击确定
                            wx.makePhoneCall({
                              phoneNumber: res.data.info1.mobile,
                            })
                          }
                        },
                      })
                    }
                  }
                })
              } else if (res1.data.count == 0) {
                wx.request({
                  url: app.globalData.url + 'api/yanzheng/check_qiuzu',
                  data: {
                    id: id,
                    type: 1
                  },
                  method: 'post',
                  success: function (rag1) {
                    console.log(rag1)
                    if (rag1.data.user == 0) {
                      wx.showModal({
                        title: '提示',
                        content: '当前贴主已隐藏手机号',
                        showCancel: false, //是否显示取消按钮
                        confirmText: "知道了", //默认是“确定”
                        success: function (res) { },
                      })
                    } else {
                      // console.log(that.data.lianxi)
                      // return
                      if (that.data.lianxi == 0) {
                        wx.showModal({
                          title: '提示',
                          content: '获取贴主手机号需要消耗1积分',
                          cancelText: "我再想想",
                          confirmText: "确认获取",
                          success: function (res) {
                            if (res.cancel) { } else {
                              wx.request({
                                url: app.globalData.url + 'api/qiuzu/dianhua',
                                data: {
                                  tel: tel,
                                  id: id
                                },
                                method: 'post',
                                success: function (res) {
                                  console.log(res)
                                  that.reload(that.data.info.id)
                                  if (res.data.info == 0) {
                                    wx.showToast({
                                      title: '请勿联系自己',
                                      duration: 2000,
                                      icon: 'none'
                                    })
                                    return;
                                  } else if (res.data.info == 1) {
                                    if (res.data.info1 == 0) {
                                      wx.showModal({
                                        title: '提示',
                                        content: '当前贴主已隐藏手机号，积分未消耗',
                                        showCancel: false, //是否显示取消按钮
                                        confirmText: "知道了", //默认是“确定”
                                        success: function (res) { },
                                      })
                                    } else {
                                      console.log(1)
                                      that.setData({
                                        lianxi: 1
                                      })
                                      wx.showModal({
                                        title: '提示',
                                        content: '联系我时请备注在【租小圣租房】小程序上看到的～',
                                        showCancel: true, //是否显示取消按钮
                                        confirmText: "确认拨打", //默认是“确定”
                                        cancelText: "我再想想",
                                        success: function (ras) {
                                          if (ras.cancel) {
                                            //点击取消,默认隐藏弹框
                                          } else {
                                            //点击确定
                                            wx.makePhoneCall({
                                              phoneNumber: res.data.info1.mobile,
                                            })
                                          }
                                        },
                                      })

                                    }
                                  } else {
                                    wx.showToast({
                                      title: '您的积分为0无法拨打发布人电话',
                                      duration: 2000,
                                      icon: 'none'
                                    })
                                    return;
                                  }
                                }
                              })
                            }
                          },
                        })
                      } else {
                        wx.request({
                          url: app.globalData.url + 'api/qiuzu/dianhua1',
                          data: {
                            tel: tel,
                            id: id
                          },
                          method: 'post',
                          success: function (res) {
                            console.log(res)
                            if (res.data.info == 0) {
                              wx.showToast({
                                title: '请勿联系自己',
                                duration: 2000,
                                icon: 'none'
                              })
                              return;
                            } else if (res.data.info == 2) {
                              wx.showToast({
                                title: '贴主已隐藏手机号',
                                duration: 2000,
                                icon: 'none'
                              })
                              return;
                            } else if (res.data.info == 1) {
                              that.setData({
                                mobile1: res.data.info1.mobile
                              })
                              wx.showModal({
                                title: '提示',
                                content: '联系我时请备注在【租小圣租房】小程序上看到的～',
                                showCancel: true, //是否显示取消按钮
                                confirmText: "确认拨打", //默认是“确定”
                                cancelText: "我再想想",
                                success: function (ras) {
                                  if (ras.cancel) {
                                    //点击取消,默认隐藏弹框
                                  } else {
                                    //点击确定
                                    wx.makePhoneCall({
                                      phoneNumber: that.data.mobile1,
                                    })
                                  }
                                },
                              })
                            }
                          }
                        })
                      }
                    }
                  }
                })
              }

            }
          })
        }
      }
    })
    
  },
  reload: function(id){
    var that = this
    var tel = wx.getStorageSync('tel')
    
    wx.setNavigationBarTitle({
      title: '留言回复内容',
    })
    wx.request({
      url: app.globalData.url + 'api/xitong/pj_show3',
      data: {
        id: id,
        url: app.globalData.url,
        lng: app.globalData.lng,
        lat: app.globalData.lat,
        tel: tel
      },
      method: 'post',
      success: function (res) {
        console.log(res)
        if(res.data.f_info.lianxi == 0 && res.data.info.type == 0){
          var reg = /^(\d{3})\d{4}(\d{4})$/
          that.setData({
            // u_tel: res.data.f_info.u_tel.replace(reg, "$1****$2")
            u_tel: '已隐藏'
          })
        }else{
          that.setData({
            u_tel: res.data.f_info.u_tel
          })
        }
        that.setData({
          info: res.data.info,
          f_info: res.data.f_info,
          lianxi: res.data.f_info.lianxi,
          url: app.globalData.url,
          u_info: res.data.u_info,
          user_info: res.data.user_info,
          pinpai: app.globalData.pinpai,
          wei: app.globalData.wei,
          bao: app.globalData.bao,
          youxuan: app.globalData.youxuan,
          pinpai1: app.globalData.pinpai1,
          wei1: app.globalData.wei1,
          bao1: app.globalData.bao1,
          youxuan1: app.globalData.youxuan1
        })
      }
    })
  }
})