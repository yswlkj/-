//app.js
App({
  onLaunch: function () {
    // 展示本地存储能力
    var that = this
    var logs = wx.getStorageSync('logs') || []
    logs.unshift(Date.now())
    wx.setStorageSync('logs', logs)
    that.globalData.url = 'https://xcx.zuxiaosheng.com/'
    // 登录
    wx.login({
      success: res => {
        that.globalData.user_code = res.code;
        console.log(that.globalData.user_code)
      }
    })
    
    // 获取用户信息
    wx.getSetting({
      success: res => {
        if (res.authSetting['scope.userInfo']) {
          wx.getUserInfo({
            success: res => {
              console.log(1111)
              console.log(res)
              that.globalData.iv = res.iv
              that.globalData.encryptedData = res.encryptedData
              that.globalData.userInfo = res.userInfo
              if (that.userInfoReadyCallback) {
                that.userInfoReadyCallback(res)
              }
            }
          })
        }
      }
    })
    
  },
  
  uploadimg4: function (data) {
    var that = this
    console.log(222)
    console.log(data)
    console.log(data.path)
    wx.uploadFile({
      url: data.url,
      filePath: data.path,
      name: 'file',//这里根据自己的实际情况改
      formData: null,//这里是上传图片时一起上传的数据
      success: (resp) => {
        console.log(resp)
        // that.globalData.tupian2 = '';
        that.globalData.tupian4 = resp.data
        wx.setStorageSync('picture', that.globalData.tupian4)
        console.log(that.globalData.tupian4)
      },
    });
  },
  globalData: {
    userInfo: null,
    pictures2: [],
    cailiao: [],
    pictures1: [],
    ss_xq_latitude: '',
    ss_sq_longitude: '',
    ss_xq_latitude1: '',
    ss_sq_longitude1: '',
    pics: [],
    pics1: [],
    fabu:[],
    shipin: [],
    touxiang: [],
    fabu_update: [],
    zonghe: [],
    zonghe1: [],
    fengmian:0,
    city_code: 1,
    tempFilePaths:[],
    tempFilePaths2: [],
    zhen:[],
    md_pic: [],
    chengshi: 0,
    huan: 1
  }
})